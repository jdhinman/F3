
HeroLocomotionData = {}
HeroLocomotionData.MinControlMagForMovement = 0.1
HeroLocomotionData.MinControlMagForTurn = -0.1
HeroLocomotionData.MinVelMagForMovement = 0.01
HeroLocomotionData.MaxTurnSpeedStatic = 650 --800
HeroLocomotionData.MaxTurnSpeedRunning = 50 -- 1
HeroLocomotionData.MaxSpeed = 4.5
HeroLocomotionData.SprintSpeedMultiplier = 1.45
HeroLocomotionData.SprintTerminationSpeedFraction = 0.5 -- 0
HeroLocomotionData.FrictionCoefficient = 9 -- 7
HeroLocomotionData.FrictionCoefficientSecondOrder = 3 -- 8
HeroLocomotionData.FrictionCoefficientLateral = 3 -- 8
HeroLocomotionData.MaxSpeedLateralStatic = 0.1 -- 0.8
HeroLocomotionData.MaxSpeedLateralRunning = 0.8 -- 1.5
HeroLocomotionData.AllowedToMoveBackwards = 0

HeroLocomotionDataHandHoldingLeader = {}
HeroLocomotionDataHandHoldingLeader.MinControlMagForMovement = 0.1 -- 0.25
HeroLocomotionDataHandHoldingLeader.MinControlMagForTurn = 0
HeroLocomotionDataHandHoldingLeader.MinVelMagForMovement = 0.05
HeroLocomotionDataHandHoldingLeader.MaxTurnSpeedStatic = 500
HeroLocomotionDataHandHoldingLeader.MaxTurnSpeedRunning = 1
HeroLocomotionDataHandHoldingLeader.MaxSpeed = 4.25
HeroLocomotionDataHandHoldingLeader.SprintSpeedMultiplier = 1.15
HeroLocomotionDataHandHoldingLeader.SprintTerminationSpeedFraction = 0
HeroLocomotionDataHandHoldingLeader.FrictionCoefficient = 16 -- 4
HeroLocomotionDataHandHoldingLeader.FrictionCoefficientSecondOrder = 4
HeroLocomotionDataHandHoldingLeader.FrictionCoefficientLateral = 8
HeroLocomotionDataHandHoldingLeader.MaxSpeedLateralStatic = 0.8
HeroLocomotionDataHandHoldingLeader.MaxSpeedLateralRunning = 1.5
HeroLocomotionDataHandHoldingLeader.AllowedToMoveBackwards = 0

HeroLocomotionDataHandHoldingLeaderDragging = {}
HeroLocomotionDataHandHoldingLeaderDragging.MinControlMagForMovement = 0.1
HeroLocomotionDataHandHoldingLeaderDragging.MinControlMagForTurn = 0
HeroLocomotionDataHandHoldingLeaderDragging.MinVelMagForMovement = 0.001
HeroLocomotionDataHandHoldingLeaderDragging.MaxTurnSpeedStatic = 300
HeroLocomotionDataHandHoldingLeaderDragging.MaxTurnSpeedRunning = 300
HeroLocomotionDataHandHoldingLeaderDragging.MaxSpeed = 2.5 -- 2
HeroLocomotionDataHandHoldingLeaderDragging.SprintSpeedMultiplier = 1.0
HeroLocomotionDataHandHoldingLeaderDragging.SprintTerminationSpeedFraction = 0
HeroLocomotionDataHandHoldingLeaderDragging.FrictionCoefficient = 3 -- 4
HeroLocomotionDataHandHoldingLeaderDragging.FrictionCoefficientSecondOrder = 4
HeroLocomotionDataHandHoldingLeaderDragging.FrictionCoefficientLateral = 8
HeroLocomotionDataHandHoldingLeaderDragging.MaxSpeedLateralStatic = 0.8
HeroLocomotionDataHandHoldingLeaderDragging.MaxSpeedLateralRunning = 1.5
HeroLocomotionDataHandHoldingLeaderDragging.AllowedToMoveBackwards = 0

HeroLocomotionDataIndoorsDefault = {}
HeroLocomotionDataIndoorsDefault.MinControlMagForMovement = 0.1
HeroLocomotionDataIndoorsDefault.MinControlMagForTurn = 0
HeroLocomotionDataIndoorsDefault.MinVelMagForMovement = 0.001
HeroLocomotionDataIndoorsDefault.MaxTurnSpeedStatic = 800
HeroLocomotionDataIndoorsDefault.MaxTurnSpeedRunning = 7
HeroLocomotionDataIndoorsDefault.MaxSpeed = 4.2 -- 4.5
HeroLocomotionDataIndoorsDefault.SprintSpeedMultiplier = 1.25 -- 1.45
HeroLocomotionDataIndoorsDefault.SprintTerminationSpeedFraction = 0
HeroLocomotionDataIndoorsDefault.FrictionCoefficient = 8 -- 7
HeroLocomotionDataIndoorsDefault.FrictionCoefficientSecondOrder = 8
HeroLocomotionDataIndoorsDefault.FrictionCoefficientLateral = 8
HeroLocomotionDataIndoorsDefault.MaxSpeedLateralStatic = 0.8
HeroLocomotionDataIndoorsDefault.MaxSpeedLateralRunning = 1.5
HeroLocomotionDataIndoorsDefault.AllowedToMoveBackwards = 0

HeroLocomotionDataHandHoldingDefault = {}
HeroLocomotionDataHandHoldingDefault.MinControlMagForMovement = 0.1 --0.25
HeroLocomotionDataHandHoldingDefault.MinControlMagForTurn = 0
HeroLocomotionDataHandHoldingDefault.MinVelMagForMovement = 0.01 -- 0.001
HeroLocomotionDataHandHoldingDefault.MaxTurnSpeedStatic = 700
HeroLocomotionDataHandHoldingDefault.MaxTurnSpeedRunning = 615
HeroLocomotionDataHandHoldingDefault.MaxSpeed = 8 -- 7
HeroLocomotionDataHandHoldingDefault.SprintSpeedMultiplier = 1.0 -- 1.4 
HeroLocomotionDataHandHoldingDefault.SprintTerminationSpeedFraction = 0
HeroLocomotionDataHandHoldingDefault.FrictionCoefficient = 8 -- 4
HeroLocomotionDataHandHoldingDefault.FrictionCoefficientSecondOrder = 4
HeroLocomotionDataHandHoldingDefault.FrictionCoefficientLateral = 4
HeroLocomotionDataHandHoldingDefault.MaxSpeedLateralStatic = 0.8
HeroLocomotionDataHandHoldingDefault.MaxSpeedLateralRunning = 1.5
HeroLocomotionDataHandHoldingDefault.AllowedToMoveBackwards = 0

HeroLocomotionDataChild = {}
HeroLocomotionDataChild.MinControlMagForMovement = 0.1 --0.25
HeroLocomotionDataChild.MinControlMagForTurn = 0
HeroLocomotionDataChild.MinVelMagForMovement = 0.001
HeroLocomotionDataChild.MaxTurnSpeedStatic = 350
HeroLocomotionDataChild.MaxTurnSpeedRunning = 95
HeroLocomotionDataChild.MaxSpeed = 4.5
HeroLocomotionDataChild.SprintSpeedMultiplier = 1.3
HeroLocomotionDataChild.SprintTerminationSpeedFraction = 0
HeroLocomotionDataChild.FrictionCoefficient = 4
HeroLocomotionDataChild.FrictionCoefficientSecondOrder = 4
HeroLocomotionDataChild.FrictionCoefficientLateral = 4
HeroLocomotionDataChild.MaxSpeedLateralStatic = 0.8
HeroLocomotionDataChild.MaxSpeedLateralRunning = 1.5
HeroLocomotionDataChild.AllowedToMoveBackwards = 0

HeroLocomotionDataChildIndoorsDefault = {}
HeroLocomotionDataChildIndoorsDefault.MinControlMagForMovement = 0.025 --0.25
HeroLocomotionDataChildIndoorsDefault.MinControlMagForTurn = 0
HeroLocomotionDataChildIndoorsDefault.MinVelMagForMovement = 0.0010000000474975
HeroLocomotionDataChildIndoorsDefault.MaxTurnSpeedStatic = 300
HeroLocomotionDataChildIndoorsDefault.MaxTurnSpeedRunning = 95
HeroLocomotionDataChildIndoorsDefault.MaxSpeed = 4.25
HeroLocomotionDataChildIndoorsDefault.SprintSpeedMultiplier = 1.25
HeroLocomotionDataChildIndoorsDefault.SprintTerminationSpeedFraction = 0
HeroLocomotionDataChildIndoorsDefault.FrictionCoefficient = 4
HeroLocomotionDataChildIndoorsDefault.FrictionCoefficientSecondOrder = 4
HeroLocomotionDataChildIndoorsDefault.FrictionCoefficientLateral = 4
HeroLocomotionDataChildIndoorsDefault.MaxSpeedLateralStatic = 0.8
HeroLocomotionDataChildIndoorsDefault.MaxSpeedLateralRunning = 1.25
HeroLocomotionDataChildIndoorsDefault.AllowedToMoveBackwards = 0

HeroLocomotionDataStrafe = {}
HeroLocomotionDataStrafe.MinControlMagForMovement = 0.25
HeroLocomotionDataStrafe.MinControlMagForTurn = 0
HeroLocomotionDataStrafe.MinVelMagForMovement = 0.001
HeroLocomotionDataStrafe.MaxTurnSpeedStatic = 300
HeroLocomotionDataStrafe.MaxTurnSpeedRunning = 150
HeroLocomotionDataStrafe.MaxSpeed = 4.25
HeroLocomotionDataStrafe.SprintSpeedMultiplier = 1
HeroLocomotionDataStrafe.SprintTerminationSpeedFraction = 0
HeroLocomotionDataStrafe.FrictionCoefficient = 14 -- 7
HeroLocomotionDataStrafe.FrictionCoefficientSecondOrder = 4
HeroLocomotionDataStrafe.FrictionCoefficientLateral = 7
HeroLocomotionDataStrafe.MaxSpeedLateralStatic = 4.25
HeroLocomotionDataStrafe.MaxSpeedLateralRunning = 4.25
HeroLocomotionDataStrafe.AllowedToMoveBackwards = 1

HeroLocomotionDataRanged = {}
HeroLocomotionDataRanged.MinControlMagForMovement = 0.25
HeroLocomotionDataRanged.MinControlMagForTurn = 0
HeroLocomotionDataRanged.MinVelMagForMovement = 0.001
HeroLocomotionDataRanged.MaxTurnSpeedStatic = 1200
HeroLocomotionDataRanged.MaxTurnSpeedRunning = 200
HeroLocomotionDataRanged.MaxSpeed = HeroLocomotionData.MaxSpeed
HeroLocomotionDataRanged.SprintSpeedMultiplier = HeroLocomotionData.SprintSpeedMultiplier
HeroLocomotionDataRanged.SprintTerminationSpeedFraction = 0
HeroLocomotionDataRanged.FrictionCoefficient = 12 -- 4
HeroLocomotionDataRanged.FrictionCoefficientSecondOrder = 4
HeroLocomotionDataRanged.FrictionCoefficientLateral = 4
HeroLocomotionDataRanged.MaxSpeedLateralStatic = 4.25
HeroLocomotionDataRanged.MaxSpeedLateralRunning = 4.25
HeroLocomotionDataRanged.AllowedToMoveBackwards = 1

HeroLocomotionDataRangedStrafe = {}
HeroLocomotionDataRangedStrafe.MinControlMagForMovement = 0.25
HeroLocomotionDataRangedStrafe.MinControlMagForTurn = 0
HeroLocomotionDataRangedStrafe.MinVelMagForMovement = 0.001
HeroLocomotionDataRangedStrafe.MaxTurnSpeedStatic = 300
HeroLocomotionDataRangedStrafe.MaxTurnSpeedRunning = 150
HeroLocomotionDataRangedStrafe.MaxSpeed = 4.25
HeroLocomotionDataRangedStrafe.SprintSpeedMultiplier = HeroLocomotionDataRanged.SprintSpeedMultiplier
HeroLocomotionDataRangedStrafe.SprintTerminationSpeedFraction = 0
HeroLocomotionDataRangedStrafe.FrictionCoefficient = 12 -- 4
HeroLocomotionDataRangedStrafe.FrictionCoefficientSecondOrder = 4
HeroLocomotionDataRangedStrafe.FrictionCoefficientLateral = 4
HeroLocomotionDataRangedStrafe.MaxSpeedLateralStatic = 4.25
HeroLocomotionDataRangedStrafe.MaxSpeedLateralRunning = 4.25
HeroLocomotionDataRangedStrafe.AllowedToMoveBackwards = 1

HeroLocomotionDataRangedAimStrafe = {}
HeroLocomotionDataRangedAimStrafe.MinControlMagForMovement = 0.1
HeroLocomotionDataRangedAimStrafe.MinControlMagForTurn = 0.5
HeroLocomotionDataRangedAimStrafe.MinVelMagForMovement = 0.01
HeroLocomotionDataRangedAimStrafe.MaxTurnSpeedStatic = 720
HeroLocomotionDataRangedAimStrafe.MaxTurnSpeedRunning = 100
HeroLocomotionDataRangedAimStrafe.MaxSpeed = 3.5 -- 2.25
HeroLocomotionDataRangedAimStrafe.SprintSpeedMultiplier = 1
HeroLocomotionDataRangedAimStrafe.SprintTerminationSpeedFraction = 0
HeroLocomotionDataRangedAimStrafe.FrictionCoefficient = 7
HeroLocomotionDataRangedAimStrafe.FrictionCoefficientSecondOrder = 2 -- 4
HeroLocomotionDataRangedAimStrafe.FrictionCoefficientLateral = 4
HeroLocomotionDataRangedAimStrafe.MaxSpeedLateralStatic = 3.5 -- 2.25
HeroLocomotionDataRangedAimStrafe.MaxSpeedLateralRunning = 3.5 -- 2.25
HeroLocomotionDataRangedAimStrafe.AllowedToMoveBackwards = 1

HeroLocomotionDataChildStrafe = {}
HeroLocomotionDataChildStrafe.MinControlMagForMovement = 0.25
HeroLocomotionDataChildStrafe.MinControlMagForTurn = 0
HeroLocomotionDataChildStrafe.MinVelMagForMovement = 0.001
HeroLocomotionDataChildStrafe.MaxTurnSpeedStatic = 300
HeroLocomotionDataChildStrafe.MaxTurnSpeedRunning = 150
HeroLocomotionDataChildStrafe.MaxSpeed = 3.5
HeroLocomotionDataChildStrafe.SprintSpeedMultiplier = 1
HeroLocomotionDataChildStrafe.SprintTerminationSpeedFraction = 0
HeroLocomotionDataChildStrafe.FrictionCoefficient = 7
HeroLocomotionDataChildStrafe.FrictionCoefficientSecondOrder = 4
HeroLocomotionDataChildStrafe.FrictionCoefficientLateral = 7
HeroLocomotionDataChildStrafe.MaxSpeedLateralStatic = 3.5
HeroLocomotionDataChildStrafe.MaxSpeedLateralRunning = 3.5
HeroLocomotionDataChildStrafe.AllowedToMoveBackwards = 1

HeroLocomotionDataChildRanged = {}
HeroLocomotionDataChildRanged.MinControlMagForMovement = 0.25
HeroLocomotionDataChildRanged.MinControlMagForTurn = 0
HeroLocomotionDataChildRanged.MinVelMagForMovement = 0.001
HeroLocomotionDataChildRanged.MaxTurnSpeedStatic = 1200
HeroLocomotionDataChildRanged.MaxTurnSpeedRunning = 200
HeroLocomotionDataChildRanged.MaxSpeed = 3.5
HeroLocomotionDataChildRanged.SprintSpeedMultiplier = 1.4
HeroLocomotionDataChildRanged.SprintTerminationSpeedFraction = 0
HeroLocomotionDataChildRanged.FrictionCoefficient = 4
HeroLocomotionDataChildRanged.FrictionCoefficientSecondOrder = 4
HeroLocomotionDataChildRanged.FrictionCoefficientLateral = 4
HeroLocomotionDataChildRanged.MaxSpeedLateralStatic = 3.5
HeroLocomotionDataChildRanged.MaxSpeedLateralRunning = 3.5
HeroLocomotionDataChildRanged.AllowedToMoveBackwards = 1

HeroLocomotionDataChildRangedStrafe = {}
HeroLocomotionDataChildRangedStrafe.MinControlMagForMovement = 0.25
HeroLocomotionDataChildRangedStrafe.MinControlMagForTurn = 0
HeroLocomotionDataChildRangedStrafe.MinVelMagForMovement = 0.001
HeroLocomotionDataChildRangedStrafe.MaxTurnSpeedStatic = 300
HeroLocomotionDataChildRangedStrafe.MaxTurnSpeedRunning = 150
HeroLocomotionDataChildRangedStrafe.MaxSpeed = 3.5
HeroLocomotionDataChildRangedStrafe.SprintSpeedMultiplier = 1
HeroLocomotionDataChildRangedStrafe.SprintTerminationSpeedFraction = 0
HeroLocomotionDataChildRangedStrafe.FrictionCoefficient = 4
HeroLocomotionDataChildRangedStrafe.FrictionCoefficientSecondOrder = 4
HeroLocomotionDataChildRangedStrafe.FrictionCoefficientLateral = 4
HeroLocomotionDataChildRangedStrafe.MaxSpeedLateralStatic = 3.5
HeroLocomotionDataChildRangedStrafe.MaxSpeedLateralRunning = 3.5
HeroLocomotionDataChildRangedStrafe.AllowedToMoveBackwards = 1

-- HeroLocomotionStateHHIdle --
HeroLocomotionStateHHIdle = {}
HeroLocomotionStateHHIdle.Anim = {
	"Pose",
	"PoseLF",
	"PoseRF"
}
HeroLocomotionStateHHIdle.BlendInTime = 0.5
HeroLocomotionStateHHIdle.BlendOutTime = 0.5
HeroLocomotionStateHHIdle.VelocityArea = {
	CVector3(-HeroLocomotionDataHandHoldingLeader.MinVelMagForMovement, -180, 0),
	CVector3(HeroLocomotionDataHandHoldingLeader.MinVelMagForMovement, 180, 0)
}
HeroLocomotionStateHHIdle.ControlArea = {
	CVector3(-HeroLocomotionDataHandHoldingLeader.MinControlMagForMovement, -180, 0),
	CVector3(1.05, 180, 0)
}
HeroLocomotionStateHHIdle.CombatState = ECombatState.COMBAT_STATE_NOT_SET
HeroLocomotionStateHHIdle.AnimBlendType = EAnimBlendType.ANIM_BLEND_MATCH_FOOTING
HeroLocomotionStateHHIdle.FootMatchType = EFootMatchType.FOOT_MATCH_RELATIVE
HeroLocomotionStateHHIdle.States = {
	"HeroLocomotionStateHHLocomoteWalk",
	"HeroLocomotionStateHHIdle"
}

-- HeroLocomotionStateHHLocomoteWalk --
HeroLocomotionStateHHLocomoteWalk = {}
HeroLocomotionStateHHLocomoteWalk.Anim = {
	"WalkSlow",
	-- "Walk",
	"WalkFast",
	"Run"
	-- "Sprint"
}
HeroLocomotionStateHHLocomoteWalk.BlendInTime = 0.75 -- 0.5
HeroLocomotionStateHHLocomoteWalk.BlendOutTime = 0.75
HeroLocomotionStateHHLocomoteWalk.VelocityArea = {
	CVector3(HeroLocomotionDataHandHoldingLeader.MinVelMagForMovement, -180, 0),
	CVector3(10, 180, 0)
}
HeroLocomotionStateHHLocomoteWalk.ControlArea = {
	CVector3(HeroLocomotionDataHandHoldingLeader.MinControlMagForMovement, -180, 0),
	CVector3(1.05, 180, 0)
}
HeroLocomotionStateHHLocomoteWalk.States = {
	"HeroLocomotionStateHHLocomoteWalk",
	"HeroLocomotionStateHHIdle"
}

-- HeroLocomotionStateHHDragIdle --
HeroLocomotionStateHHDragIdle = {}
HeroLocomotionStateHHDragIdle.Anim = {
    "PoseDrag"
}
HeroLocomotionStateHHDragIdle.BlendInTime = 0.5
HeroLocomotionStateHHDragIdle.VelocityArea = {
	CVector3(-HeroLocomotionDataHandHoldingLeaderDragging.MinVelMagForMovement, -180, 0),
	CVector3(HeroLocomotionDataHandHoldingLeaderDragging.MinVelMagForMovement, 180, 0)
}
HeroLocomotionStateHHDragIdle.ControlArea = {
	CVector3(-HeroLocomotionDataHandHoldingLeaderDragging.MinControlMagForMovement, -180, 0),
	CVector3(1.05, 180, 0)
}
HeroLocomotionStateHHDragIdle.CombatState = ECombatState.COMBAT_STATE_NOT_SET
HeroLocomotionStateHHDragIdle.AnimBlendType = EAnimBlendType.ANIM_BLEND_MATCH_FOOTING
HeroLocomotionStateHHDragIdle.FootMatchType = EFootMatchType.FOOT_MATCH_RELATIVE
HeroLocomotionStateHHDragIdle.States = {
	"HeroLocomotionStateHHDragLocomoteWalk",
	"HeroLocomotionStateHHDragIdleIdle",
	"HeroLocomotionStateHHDragIdle"
}

-- HeroLocomotionStateHHDragIdleIdle --
HeroLocomotionStateHHDragIdleIdle = {}
HeroLocomotionStateHHDragIdleIdle.Anim = {
    "IdleDrag"
}
HeroLocomotionStateHHDragIdleIdle.IdleState = true
HeroLocomotionStateHHDragIdleIdle.BlendInTime = 0.2
HeroLocomotionStateHHDragIdleIdle.ValidTime = 5
HeroLocomotionStateHHDragIdleIdle.AllowLooking = true
HeroLocomotionStateHHDragIdleIdle.VelocityArea = {
	CVector3(-HeroLocomotionDataHandHoldingLeaderDragging.MinVelMagForMovement, -180, 0),
	CVector3(HeroLocomotionDataHandHoldingLeaderDragging.MinVelMagForMovement, 180, 0)
}
HeroLocomotionStateHHDragIdleIdle.ControlArea = {
	CVector3(-HeroLocomotionDataHandHoldingLeaderDragging.MinControlMagForMovement, -180, 0),
	CVector3(1.05, 180, 0)
}
HeroLocomotionStateHHDragIdleIdle.States = {
	"HeroLocomotionStateHHDragLocomoteWalk",
	"HeroLocomotionStateHHDragIdleIdle",
	"HeroLocomotionStateHHDragIdle"
}

-- HeroLocomotionStateHHDragLocomoteWalk --
HeroLocomotionStateHHDragLocomoteWalk = {}
HeroLocomotionStateHHDragLocomoteWalk.Anim = {
    "WalkDrag"
}
HeroLocomotionStateHHDragLocomoteWalk.BlendInTime = 0.5
HeroLocomotionStateHHDragLocomoteWalk.VelocityArea = {
	CVector3(HeroLocomotionDataHandHoldingLeaderDragging.MinVelMagForMovement, -180, 0),
	CVector3(10, 180, 0)
}
HeroLocomotionStateHHDragLocomoteWalk.ControlArea = {
	CVector3(HeroLocomotionDataHandHoldingLeaderDragging.MinControlMagForMovement, -180, 0),
	CVector3(1.05, 180, 0)
}
HeroLocomotionStateHHDragLocomoteWalk.States = {
	"HeroLocomotionStateHHDragLocomoteWalk",
	"HeroLocomotionStateHHDragIdle"
}
HeroLocomotionStateHHDragLocomoteWalk.MovementParams = {}
HeroLocomotionStateHHDragLocomoteWalk.MovementParams.MaxTurnSpeedStatic = 100
HeroLocomotionStateHHDragLocomoteWalk.MovementParams.MaxTurnSpeedRunning = 150
HeroLocomotionStateHHDragLocomoteWalk.MovementParams.FrictionCoefficient = 20
HeroLocomotionStateHHDragLocomoteWalk.MovementParams.FrictionCoefficientLateral = 20

-- HeroLocomotionStateIdleIdle --
HeroLocomotionStateIdleIdle = {}
HeroLocomotionStateIdleIdle.Anim = {
	"Idle"
}
HeroLocomotionStateIdleIdle.IdleState = true
HeroLocomotionStateIdleIdle.BlendInTime = 0.2
HeroLocomotionStateIdleIdle.ValidTime = 2.25
-- HeroLocomotionStateIdleIdle.FeetMatchPoseTolerance = 0.8
HeroLocomotionStateIdleIdle.FootMatchCompareTolerance = 0.8
HeroLocomotionStateIdleIdle.AllowLooking = false
HeroLocomotionStateIdleIdle.AnimBlendType = EAnimBlendType.ANIM_BLEND_MATCH_FOOTING
HeroLocomotionStateIdleIdle.FootMatchType = EFootMatchType.FOOT_MATCH_RELATIVE
HeroLocomotionStateIdleIdle.CombatState = ECombatState.COMBAT_STATE_NOT_SET
HeroLocomotionStateIdleIdle.States = {
	"HeroLocomotionStateTurn180IntoRunLeft",
	"HeroLocomotionStateTurn180IntoRunRight",
	"HeroLocomotionStateTurn90IntoRunLeft",
	"HeroLocomotionStateTurn90IntoRunRight",
	"HeroLocomotionStateTurn90CW",
	"HeroLocomotionStateTurn90ACW",
	{"HeroLocomotionStateLocomoteSprint", 0.25},
	{"HeroLocomotionStateLocomoteRun", 0.20},
	{"HeroLocomotionStateLocomoteWalkFast", 0.2},
	{"HeroLocomotionStateLocomoteWalkNormal", 0.15},
	{"HeroLocomotionStateLocomoteWalk", 0.1},
	"HeroLocomotionStateIdleIdle",
	"HeroLocomotionStateIdle"
}
HeroLocomotionStateIdleIdle.MovementParams = {}
HeroLocomotionStateIdleIdle.MovementParams.MaxSpeed = 1.0

-- HeroLocomotionStateIdle --
HeroLocomotionStateIdle = {}
HeroLocomotionStateIdle.Anim = {
	"Pose",
	"PoseLF",
	"PoseRF"
}
HeroLocomotionStateIdle.BlendInTime = 0.25
HeroLocomotionStateIdle.VelocityArea = {
	CVector3(-HeroLocomotionData.MinVelMagForMovement, -180, 0),
	CVector3(0.1, 180, 0)
}
HeroLocomotionStateIdle.ControlArea = {
	CVector3(-HeroLocomotionData.MinControlMagForMovement, -180, 0),
	CVector3(0.15, 180, 0)
}
HeroLocomotionStateIdle.CombatState = ECombatState.COMBAT_STATE_NOT_SET
HeroLocomotionStateIdle.AnimBlendType = EAnimBlendType.ANIM_BLEND_MATCH_FOOTING
HeroLocomotionStateIdle.FootMatchType = EFootMatchType.FOOT_MATCH_RELATIVE
HeroLocomotionStateIdle.States = {
	"HeroLocomotionStateTurn180IntoRunLeft",
	"HeroLocomotionStateTurn180IntoRunRight",
	"HeroLocomotionStateTurn90IntoRunLeft",
	"HeroLocomotionStateTurn90IntoRunRight",
	"HeroLocomotionStateTurn90CW",
	"HeroLocomotionStateTurn90ACW",
	{"HeroLocomotionStateLocomoteSprint", 0.25},
	{"HeroLocomotionStateLocomoteRun", 0.20},
	{"HeroLocomotionStateLocomoteWalkFast", 0.2},
	{"HeroLocomotionStateLocomoteWalkNormal", 0.15},
	{"HeroLocomotionStateLocomoteWalk", 0.1},
	"HeroLocomotionStateIdleCombatPoseLF",
	"HeroLocomotionStateIdleCombatPoseRF",
	"HeroLocomotionStateIdleIdle",
	"HeroLocomotionStateIdle"
}

-- HeroLocomotionStateIdleCombatPoseLF --
HeroLocomotionStateIdleCombatPoseLF = {}
HeroLocomotionStateIdleCombatPoseLF.Anim = {
	"CombatPose"
}
HeroLocomotionStateIdleCombatPoseLF.BlendInTime = 0.2
HeroLocomotionStateIdleCombatPoseLF.AnimBlendType = EAnimBlendType.ANIM_BLEND_BLEND
HeroLocomotionStateIdleCombatPoseLF.CombatState = ECombatState.COMBAT_STATE_SET
HeroLocomotionStateIdleCombatPoseLF.Stance = EStance.STANCE_REGULAR
HeroLocomotionStateIdleCombatPoseLF.States = {
	"HeroLocomotionStateTurn180IntoRunLeft",
	"HeroLocomotionStateTurn180IntoRunRight",
	"HeroLocomotionStateTurn90IntoRunLeft",
	"HeroLocomotionStateTurn90IntoRunRight",
	"HeroLocomotionStateTurn90CW",
	"HeroLocomotionStateTurn90ACW",
	"HeroLocomotionStateLocomoteForwardsUphill",
	"HeroLocomotionStateLocomoteForwardsDownhill",
	{"HeroLocomotionStateLocomoteSprint", 0.25},
	{"HeroLocomotionStateLocomoteRun", 0.20},
	{"HeroLocomotionStateLocomoteWalkFast", 0.2},
	{"HeroLocomotionStateLocomoteWalkNormal", 0.15},
	{"HeroLocomotionStateLocomoteWalk", 0.1},
	"HeroLocomotionStateIdleCombatPoseLF",
	"HeroLocomotionStateIdle"
}

-- HeroLocomotionStateIdleCombatPoseRF --
HeroLocomotionStateIdleCombatPoseRF = {}
HeroLocomotionStateIdleCombatPoseRF.Anim = {
	"CombatPoseGoofy"
}
HeroLocomotionStateIdleCombatPoseRF.BlendInTime = 0.2
HeroLocomotionStateIdleCombatPoseRF.AnimBlendType = EAnimBlendType.ANIM_BLEND_BLEND
HeroLocomotionStateIdleCombatPoseRF.CombatState = ECombatState.COMBAT_STATE_SET
HeroLocomotionStateIdleCombatPoseRF.Stance = EStance.STANCE_GOOFY
HeroLocomotionStateIdleCombatPoseRF.States = {
	"HeroLocomotionStateTurn180IntoRunLeft",
	"HeroLocomotionStateTurn180IntoRunRight",
	"HeroLocomotionStateTurn90IntoRunLeft",
	"HeroLocomotionStateTurn90IntoRunRight",
	"HeroLocomotionStateTurn90CW",
	"HeroLocomotionStateTurn90ACW",
	"HeroLocomotionStateLocomoteForwardsUphill",
	"HeroLocomotionStateLocomoteForwardsDownhill",
	{"HeroLocomotionStateLocomoteSprint", 0.25},
	{"HeroLocomotionStateLocomoteRun", 0.20},
	{"HeroLocomotionStateLocomoteWalkFast", 0.2},
	{"HeroLocomotionStateLocomoteWalkNormal", 0.15},
	{"HeroLocomotionStateLocomoteWalk", 0.1},
	"HeroLocomotionStateIdleCombatPoseRF",
	"HeroLocomotionStateIdle"
}

-- HeroLocomotionStateTurnLeft45 --
HeroLocomotionStateTurnLeft45 = {}
HeroLocomotionStateTurnLeft45.Anim = {
	"TurnLeft45"
}
HeroLocomotionStateTurnLeft45.TransitionType = ETransitionType.TRANSITION_MATCH_FOOTING
HeroLocomotionStateTurnLeft45.FootMatchType = EFootMatchType.FOOT_MATCH_RELATIVE
HeroLocomotionStateTurnLeft45.AnimBlendType = EAnimBlendType.ANIM_BLEND_BLEND
HeroLocomotionStateTurnLeft45.BlendInTime = 0.1
HeroLocomotionStateTurnLeft45.TargetFacingAngles = CVector3(-50, -10, 0)
HeroLocomotionStateTurnLeft45.TerminationTargetFacingAngles = CVector3(-60, -5, 0)
HeroLocomotionStateTurnLeft45.VelocityArea = {
	CVector3(HeroLocomotionData.MinVelMagForMovement, -180, 0),
	CVector3(0.55, 180, 0)
}
HeroLocomotionStateTurnLeft45.TerminationVelocityArea = {
	CVector3(-HeroLocomotionData.MinVelMagForMovement, -180, 0),
	CVector3(0.75, 180, 0)
}
HeroLocomotionStateTurnLeft45.States = {
	"HeroLocomotionStateTurn180IntoRunLeft",
	"HeroLocomotionStateTurn90IntoRunLeft",
	"HeroLocomotionStateWalkTurn90Left",
	"HeroLocomotionStateTurnLeft180",
	"HeroLocomotionStateTurnLeft90",
	"HeroLocomotionStateTurnLeft45",
	"HeroLocomotionStateTurn90ACW",
	"HeroLocomotionStateLocomoteSprint",
	"HeroLocomotionStateLocomoteRun",
	"HeroLocomotionStateLocomoteWalkFast",
	"HeroLocomotionStateLocomoteWalkNormal",
	"HeroLocomotionStateLocomoteWalk",
	{"HeroLocomotionStateIdle", 0.25}
}
HeroLocomotionStateTurnLeft45.MovementParams = {}
HeroLocomotionStateTurnLeft45.MovementParams.MaxSpeed = 1

-- HeroLocomotionStateTurnRight45 --
HeroLocomotionStateTurnRight45 = {}
HeroLocomotionStateTurnRight45.Anim = {
	"TurnRight45"
}
HeroLocomotionStateTurnRight45.TransitionType = ETransitionType.TRANSITION_MATCH_FOOTING
HeroLocomotionStateTurnRight45.FootMatchType = EFootMatchType.FOOT_MATCH_RELATIVE
HeroLocomotionStateTurnRight45.AnimBlendType = EAnimBlendType.ANIM_BLEND_BLEND
HeroLocomotionStateTurnRight45.BlendInTime = 0.25
HeroLocomotionStateTurnRight45.BlendOutTime = 0.5
HeroLocomotionStateTurnRight45.TargetFacingAngles = CVector3(10, 50, 0)
HeroLocomotionStateTurnRight45.TerminationTargetFacingAngles = CVector3(5, 60, 0)
HeroLocomotionStateTurnRight45.VelocityArea = {
	CVector3(HeroLocomotionData.MinVelMagForMovement, -180, 0),
	CVector3(0.55, 180, 0)
}
HeroLocomotionStateTurnRight45.TerminationVelocityArea = {
	CVector3(-HeroLocomotionData.MinVelMagForMovement, -180, 0),
	CVector3(0.75, 180, 0)
}
HeroLocomotionStateTurnRight45.States = {
	"HeroLocomotionStateTurn180IntoRunRight",
	"HeroLocomotionStateTurn90IntoRunRight",
	"HeroLocomotionStateWalkTurn90Right",
	"HeroLocomotionStateTurnRight180",
	"HeroLocomotionStateTurnRight90",
	"HeroLocomotionStateTurnRight45",
	"HeroLocomotionStateTurn90CW",
	"HeroLocomotionStateLocomoteSprint",
	"HeroLocomotionStateLocomoteRun",
	"HeroLocomotionStateLocomoteWalkFast",
	"HeroLocomotionStateLocomoteWalkNormal",
	"HeroLocomotionStateLocomoteWalk",
	"HeroLocomotionStateIdleCombatPoseRF",
	{"HeroLocomotionStateIdle", 0.25}
}
HeroLocomotionStateTurnRight45.MovementParams = {}
HeroLocomotionStateTurnRight45.MovementParams.MaxSpeed = 1

-- HeroLocomotionStateTurnLeft90 --
HeroLocomotionStateTurnLeft90 = {}
HeroLocomotionStateTurnLeft90.Anim = {
	"TurnLeft90"
}
HeroLocomotionStateTurnLeft90.TransitionType = ETransitionType.TRANSITION_MATCH_FOOTING
HeroLocomotionStateTurnLeft90.FootMatchType = EFootMatchType.FOOT_MATCH_RELATIVE
HeroLocomotionStateTurnLeft90.AnimBlendType = EAnimBlendType.ANIM_BLEND_BLEND
HeroLocomotionStateTurnLeft90.BlendInTime = 0.25
HeroLocomotionStateTurnLeft90.BlendOutTime = 0.5
HeroLocomotionStateTurnLeft90.TargetFacingAngles = CVector3(-90, -50, 0)
HeroLocomotionStateTurnLeft90.TerminationTargetFacingAngles = CVector3(-100, -40, 0)
HeroLocomotionStateTurnLeft90.VelocityArea = {
	CVector3(HeroLocomotionData.MinVelMagForMovement, -180, 0),
	CVector3(0.55, 180, 0)
}
HeroLocomotionStateTurnLeft90.TerminationVelocityArea = {
	CVector3(-HeroLocomotionData.MinVelMagForMovement, -180, 0),
	CVector3(0.75, 180, 0)
}
HeroLocomotionStateTurnLeft90.States = {
	-- "HeroLocomotionStateTurn180IntoRunLeft",
	-- "HeroLocomotionStateTurn90IntoRunLeft",
	-- "HeroLocomotionStateWalkTurn90Left",
	"HeroLocomotionStateTurnLeft180",
	-- "HeroLocomotionStateTurnLeft45",
	"HeroLocomotionStateTurnLeft90",
	-- "HeroLocomotionStateTurn90ACW",
	"HeroLocomotionStateLocomoteSprint",
	"HeroLocomotionStateLocomoteRun",
	"HeroLocomotionStateLocomoteWalkFast",
	"HeroLocomotionStateLocomoteWalkNormal",
	"HeroLocomotionStateLocomoteWalk",
	"HeroLocomotionStateIdleCombatPoseLF",
	{"HeroLocomotionStateIdle", 0.25}
}
HeroLocomotionStateTurnLeft90.MovementParams = {}
HeroLocomotionStateTurnLeft90.MovementParams.MaxSpeed = 1

-- HeroLocomotionStateTurnRight90 --
HeroLocomotionStateTurnRight90 = {}
HeroLocomotionStateTurnRight90.Anim = {
	"TurnRight90"
}
HeroLocomotionStateTurnRight90.TransitionType = ETransitionType.TRANSITION_MATCH_FOOTING
HeroLocomotionStateTurnRight90.FootMatchType = EFootMatchType.FOOT_MATCH_RELATIVE
HeroLocomotionStateTurnRight90.AnimBlendType = EAnimBlendType.ANIM_BLEND_BLEND
HeroLocomotionStateTurnRight90.BlendInTime = 0.25
HeroLocomotionStateTurnRight90.BlendOutTime = 0.5
HeroLocomotionStateTurnRight90.TargetFacingAngles = CVector3(50, 90, 0)
HeroLocomotionStateTurnRight90.TerminationTargetFacingAngles = CVector3(40, 100, 0)
HeroLocomotionStateTurnRight90.VelocityArea = {
	CVector3(HeroLocomotionData.MinVelMagForMovement, -180, 0),
	CVector3(0.55, 180, 0)
}
HeroLocomotionStateTurnRight90.TerminationVelocityArea = {
	CVector3(-HeroLocomotionData.MinVelMagForMovement, -180, 0),
	CVector3(0.75, 180, 0)
}
HeroLocomotionStateTurnRight90.States = {
	-- "HeroLocomotionStateTurn180IntoRunRight",
	-- "HeroLocomotionStateTurn90IntoRunRight",
	-- "HeroLocomotionStateWalkTurn90Right",
	"HeroLocomotionStateTurnRight180",
	-- "HeroLocomotionStateTurnRight45",
	"HeroLocomotionStateTurnRight90",
	-- "HeroLocomotionStateTurn90CW",
	"HeroLocomotionStateLocomoteSprint",
	"HeroLocomotionStateLocomoteRun",
	"HeroLocomotionStateLocomoteWalkFast",
	"HeroLocomotionStateLocomoteWalkNormal",
	"HeroLocomotionStateLocomoteWalk",
	"HeroLocomotionStateIdleCombatPoseRF",
	{"HeroLocomotionStateIdle", 0.25}
}
HeroLocomotionStateTurnRight90.MovementParams = {}
HeroLocomotionStateTurnRight90.MovementParams.MaxSpeed = 1

-- HeroLocomotionStateTurnLeft180 --
HeroLocomotionStateTurnLeft180 = {}
HeroLocomotionStateTurnLeft180.Anim = {
	"TurnLeft180",
	"TurnLeft180Var001",
	"TurnLeft180Var002",
	"TurnLeft180Var003"
}
HeroLocomotionStateTurnLeft180.TransitionType = ETransitionType.TRANSITION_MATCH_FOOTING
HeroLocomotionStateTurnLeft180.FootMatchType = EFootMatchType.FOOT_MATCH_RELATIVE
HeroLocomotionStateTurnLeft180.AnimBlendType = EAnimBlendType.ANIM_BLEND_BLEND
HeroLocomotionStateTurnLeft180.BlendInTime = 0.25
HeroLocomotionStateTurnLeft180.BlendOutTime = 0.5
HeroLocomotionStateTurnLeft180.TargetFacingAngles = CVector3(-180, -30, 0)
HeroLocomotionStateTurnLeft180.TerminationTargetFacingAngles = CVector3(-181, -25, 0)
HeroLocomotionStateTurnLeft180.VelocityArea = {
	CVector3(HeroLocomotionData.MinVelMagForMovement, -180, 0),
	CVector3(0.55, 180, 0)
}
HeroLocomotionStateTurnLeft180.TerminationVelocityArea = {
	CVector3(-HeroLocomotionData.MinVelMagForMovement, -180, 0),
	CVector3(0.75, 180, 0)
}
HeroLocomotionStateTurnLeft180.States = {
	-- "HeroLocomotionStateWalkTurn90Left",
	-- "HeroLocomotionStateTurn90IntoRunLeft",
	-- "HeroLocomotionStateTurn180IntoRunLeft",
	-- "HeroLocomotionStateTurnLeft45",
	-- "HeroLocomotionStateTurnLeft90",
	"HeroLocomotionStateTurnLeft180",
	-- "HeroLocomotionStateTurn90ACW",
	"HeroLocomotionStateLocomoteSprint",
	"HeroLocomotionStateLocomoteRun",
	"HeroLocomotionStateLocomoteWalkFast",
	"HeroLocomotionStateLocomoteWalkNormal",
	"HeroLocomotionStateLocomoteWalk",
	"HeroLocomotionStateIdleCombatPoseLF",
	{"HeroLocomotionStateIdle", 0.25}
}
HeroLocomotionStateTurnLeft180.MovementParams = {}
HeroLocomotionStateTurnLeft180.MovementParams.MaxSpeed = 1

-- HeroLocomotionStateTurnRight180 --
HeroLocomotionStateTurnRight180 = {}
HeroLocomotionStateTurnRight180.Anim = {
	"TurnRight180",
	"TurnRight180Var001",
	"TurnRight180Var002",
	"TurnRight180Var003"
}
HeroLocomotionStateTurnRight180.TransitionType = ETransitionType.TRANSITION_MATCH_FOOTING
HeroLocomotionStateTurnRight180.FootMatchType = EFootMatchType.FOOT_MATCH_RELATIVE
HeroLocomotionStateTurnRight180.AnimBlendType = EAnimBlendType.ANIM_BLEND_BLEND
HeroLocomotionStateTurnRight180.BlendInTime = 0.25
HeroLocomotionStateTurnRight180.BlendOutTime = 0.5
HeroLocomotionStateTurnRight180.TargetFacingAngles = CVector3(30, 180, 0)
HeroLocomotionStateTurnRight180.TerminationTargetFacingAngles = CVector3(25, 181, 0)
HeroLocomotionStateTurnRight180.VelocityArea = {
	CVector3(HeroLocomotionData.MinVelMagForMovement, -180, 0),
	CVector3(0.55, 180, 0)
}
HeroLocomotionStateTurnRight180.TerminationVelocityArea = {
	CVector3(-HeroLocomotionData.MinVelMagForMovement, -180, 0),
	CVector3(0.75, 180, 0)
}
HeroLocomotionStateTurnRight180.States = {
	-- "HeroLocomotionStateWalkTurn90Right",
	-- "HeroLocomotionStateTurn90IntoRunRight",
	-- "HeroLocomotionStateTurn180IntoRunRight",
	-- "HeroLocomotionStateTurnRight45",
	-- "HeroLocomotionStateTurnRight90",
	"HeroLocomotionStateTurnRight180",
	-- "HeroLocomotionStateTurn90CW",
	"HeroLocomotionStateLocomoteSprint",
	"HeroLocomotionStateLocomoteRun",
	"HeroLocomotionStateLocomoteWalkFast",
	"HeroLocomotionStateLocomoteWalkNormal",
	"HeroLocomotionStateLocomoteWalk",
	"HeroLocomotionStateIdleCombatPoseRF",
	{"HeroLocomotionStateIdle", 0.25}
}
HeroLocomotionStateTurnRight180.MovementParams = {}
HeroLocomotionStateTurnRight180.MovementParams.MaxSpeed = 1

-- HeroLocomotionStateWalkTurn90Left --
HeroLocomotionStateWalkTurn90Left = {}
HeroLocomotionStateWalkTurn90Left.Anim = {
	"WalkTurn90Left"
}
HeroLocomotionStateWalkTurn90Left.TransitionType = ETransitionType.TRANSITION_MATCH_FOOTING
HeroLocomotionStateWalkTurn90Left.FootMatchType = EFootMatchType.FOOT_MATCH_RELATIVE
HeroLocomotionStateWalkTurn90Left.AnimBlendType = EAnimBlendType.ANIM_BLEND_BLEND
HeroLocomotionStateWalkTurn90Left.BlendInTime = 0.25
HeroLocomotionStateWalkTurn90Left.BlendOutTime = 0.25
HeroLocomotionStateWalkTurn90Left.TargetFacingAngles = CVector3(-180, -10, 0)
HeroLocomotionStateWalkTurn90Left.TerminationTargetFacingAngles = CVector3(-181, -5, 0)
HeroLocomotionStateWalkTurn90Left.VelocityArea = {
	CVector3(0.4, -180, 0),
	CVector3(0.75, 180, 0)
}
HeroLocomotionStateWalkTurn90Left.TerminationVelocityArea = {
	CVector3(-0.1, -180, 0),
	CVector3(0.8, 180, 0)
}
HeroLocomotionStateWalkTurn90Left.States = {
	-- "HeroLocomotionStateTurn180IntoRunLeft",
	-- "HeroLocomotionStateTurn90IntoRunLeft",
	"HeroLocomotionStateWalkTurn90Left",
	-- "HeroLocomotionStateTurnLeft180",
	-- "HeroLocomotionStateTurnLeft90",
	-- "HeroLocomotionStateTurnLeft45",
	-- "HeroLocomotionStateTurn90ACW",
	"HeroLocomotionStateLocomoteSprint",
	"HeroLocomotionStateLocomoteRun",
	"HeroLocomotionStateLocomoteWalkFast",
	"HeroLocomotionStateLocomoteWalkNormal",
	"HeroLocomotionStateLocomoteWalk",
	"HeroLocomotionStateIdleCombatPoseLF",
	{"HeroLocomotionStateIdle", 0.15}
}
HeroLocomotionStateWalkTurn90Left.MovementParams = {}
HeroLocomotionStateWalkTurn90Left.MovementParams.MaxTurnSpeedStatic = 300
HeroLocomotionStateWalkTurn90Left.MovementParams.MaxTurnSpeedRunning = 300
HeroLocomotionStateWalkTurn90Left.MovementParams.FrictionCoefficient = 4
HeroLocomotionStateWalkTurn90Left.MovementParams.FrictionCoefficientLateral = 4
HeroLocomotionStateWalkTurn90Left.MovementParams.MaxSpeed = 2

-- HeroLocomotionStateWalkTurn90Right --
HeroLocomotionStateWalkTurn90Right = {}
HeroLocomotionStateWalkTurn90Right.Anim = {
	"WalkTurn90Right"
}
HeroLocomotionStateWalkTurn90Right.TransitionType = ETransitionType.TRANSITION_MATCH_FOOTING
HeroLocomotionStateWalkTurn90Right.FootMatchType = EFootMatchType.FOOT_MATCH_RELATIVE
HeroLocomotionStateWalkTurn90Right.AnimBlendType = EAnimBlendType.ANIM_BLEND_BLEND
HeroLocomotionStateWalkTurn90Right.BlendInTime = 0.25
HeroLocomotionStateWalkTurn90Right.BlendOutTime = 0.25
HeroLocomotionStateWalkTurn90Right.TargetFacingAngles = CVector3(10, 180, 0)
HeroLocomotionStateWalkTurn90Right.TerminationTargetFacingAngles = CVector3(5, 181, 0)
HeroLocomotionStateWalkTurn90Right.VelocityArea = {
	CVector3(0.15, -180, 0),
	CVector3(0.75, 180, 0)
}
HeroLocomotionStateWalkTurn90Right.TerminationVelocityArea = {
	CVector3(-0.1, -180, 0),
	CVector3(0.8, 180, 0)
}
HeroLocomotionStateWalkTurn90Right.States = {
	-- "HeroLocomotionStateTurn180IntoRunRight",
	-- "HeroLocomotionStateTurn90IntoRunRight",
	"HeroLocomotionStateWalkTurn90Right",
	-- "HeroLocomotionStateTurnRight180",
	-- "HeroLocomotionStateTurnRight90",
	-- "HeroLocomotionStateTurnRight45",
	-- "HeroLocomotionStateTurn90CW",
	"HeroLocomotionStateLocomoteSprint",
	"HeroLocomotionStateLocomoteRun",
	"HeroLocomotionStateLocomoteWalkFast",
	"HeroLocomotionStateLocomoteWalkNormal",
	"HeroLocomotionStateLocomoteWalk",
	"HeroLocomotionStateIdleCombatPoseRF",
	{"HeroLocomotionStateIdle", 0.15}
}
HeroLocomotionStateWalkTurn90Right.MovementParams = {}
HeroLocomotionStateWalkTurn90Right.MovementParams.MaxTurnSpeedStatic = 300
HeroLocomotionStateWalkTurn90Right.MovementParams.MaxTurnSpeedRunning = 300
HeroLocomotionStateWalkTurn90Right.MovementParams.FrictionCoefficient = 4
HeroLocomotionStateWalkTurn90Right.MovementParams.FrictionCoefficientLateral = 4
HeroLocomotionStateWalkTurn90Right.MovementParams.MaxSpeed = 2

-- HeroLocomotionStateRunTurn180Left --
HeroLocomotionStateRunTurn180Left = {}
HeroLocomotionStateRunTurn180Left.Anim = {
	"RunTurn180Left"
}
HeroLocomotionStateRunTurn180Left.TransitionType = ETransitionType.TRANSITION_MATCH_FOOTING
HeroLocomotionStateRunTurn180Left.FootMatchType = EFootMatchType.FOOT_MATCH_RELATIVE
HeroLocomotionStateRunTurn180Left.AnimBlendType = EAnimBlendType.ANIM_BLEND_BLEND
HeroLocomotionStateRunTurn180Left.BlendInTime = 0.25
HeroLocomotionStateRunTurn180Left.TargetFacingAngles = CVector3(-181, -45, 0)
HeroLocomotionStateRunTurn180Left.TerminationTargetFacingAngles = CVector3(-181, -15, 0)
HeroLocomotionStateRunTurn180Left.VelocityArea = {
	CVector3(0.5, -180, 0),
	CVector3(1.25, 180, 0)
}
HeroLocomotionStateRunTurn180Left.TerminationVelocityArea = {
	CVector3(-0.1, -180, 0),
	CVector3(1.3, 180, 0)
}
HeroLocomotionStateRunTurn180Left.States = {
	-- "HeroLocomotionStateSprintTurn180Left",
	"HeroLocomotionStateRunTurn180Left",
	"HeroLocomotionStateRunLeanLeft",
	"HeroLocomotionStateLocomoteSprint",
	"HeroLocomotionStateLocomoteRun",
	"HeroLocomotionStateLocomoteWalkFast",
	"HeroLocomotionStateLocomoteWalkNormal",
	"HeroLocomotionStateLocomoteWalk",
	"HeroLocomotionStateIdleCombatPoseLF",
	{"HeroLocomotionStateIdle", 0.15}
}
HeroLocomotionStateRunTurn180Left.MovementParams = {}
HeroLocomotionStateRunTurn180Left.MovementParams.MaxTurnSpeedStatic = 250
HeroLocomotionStateRunTurn180Left.MovementParams.MaxTurnSpeedRunning = 250
HeroLocomotionStateRunTurn180Left.MovementParams.FrictionCoefficient = 4
HeroLocomotionStateRunTurn180Left.MovementParams.FrictionCoefficientLateral = 4
HeroLocomotionStateRunTurn180Left.MovementParams.MaxSpeed = 3

-- HeroLocomotionStateRunTurn180Right --
HeroLocomotionStateRunTurn180Right = {}
HeroLocomotionStateRunTurn180Right.Anim = {
	"RunTurn180Right"
}
HeroLocomotionStateRunTurn180Right.TransitionType = ETransitionType.TRANSITION_MATCH_FOOTING
HeroLocomotionStateRunTurn180Right.FootMatchType = EFootMatchType.FOOT_MATCH_RELATIVE
HeroLocomotionStateRunTurn180Right.AnimBlendType = EAnimBlendType.ANIM_BLEND_BLEND
HeroLocomotionStateRunTurn180Right.BlendInTime = 0.25
HeroLocomotionStateRunTurn180Right.TargetFacingAngles = CVector3(45, 181, 0)
HeroLocomotionStateRunTurn180Right.TerminationTargetFacingAngles = CVector3(15, 181, 0)
HeroLocomotionStateRunTurn180Right.VelocityArea = {
	CVector3(0.5, -180, 0),
	CVector3(1.25, 180, 0)
}
HeroLocomotionStateRunTurn180Right.TerminationVelocityArea = {
	CVector3(-0.1, -180, 0),
	CVector3(1.3, 180, 0)
}
HeroLocomotionStateRunTurn180Right.States = {
	-- "HeroLocomotionStateSprintTurn180Right",
	"HeroLocomotionStateRunTurn180Right",
	"HeroLocomotionStateRunLeanRight",
	"HeroLocomotionStateLocomoteSprint",
	"HeroLocomotionStateLocomoteRun",
	"HeroLocomotionStateLocomoteWalkFast",
	"HeroLocomotionStateLocomoteWalkNormal",
	"HeroLocomotionStateLocomoteWalk",
	"HeroLocomotionStateIdleCombatPoseRF",
	{"HeroLocomotionStateIdle", 0.15}
}
HeroLocomotionStateRunTurn180Right.MovementParams = {}
HeroLocomotionStateRunTurn180Right.MovementParams.MaxTurnSpeedStatic = 250
HeroLocomotionStateRunTurn180Right.MovementParams.MaxTurnSpeedRunning = 250
HeroLocomotionStateRunTurn180Right.MovementParams.FrictionCoefficient = 4
HeroLocomotionStateRunTurn180Right.MovementParams.FrictionCoefficientLateral = 4
HeroLocomotionStateRunTurn180Right.MovementParams.MaxSpeed = 3

-- HeroLocomotionStateSprintTurn180Left --
HeroLocomotionStateSprintTurn180Left = {}
HeroLocomotionStateSprintTurn180Left.Anim = {
	"SprintTurn180Left"
}
HeroLocomotionStateSprintTurn180Left.TransitionType = ETransitionType.TRANSITION_MATCH_FOOTING
HeroLocomotionStateSprintTurn180Left.FootMatchType = EFootMatchType.FOOT_MATCH_RELATIVE
HeroLocomotionStateSprintTurn180Left.AnimBlendType = EAnimBlendType.ANIM_BLEND_BLEND
HeroLocomotionStateSprintTurn180Left.BlendInTime = 0.25
HeroLocomotionStateSprintTurn180Left.TargetFacingAngles = CVector3(-181, -45, 0)
HeroLocomotionStateSprintTurn180Left.TerminationTargetFacingAngles = CVector3(-181, -15, 0)
HeroLocomotionStateSprintTurn180Left.VelocityArea = {
	CVector3(0.9, -180, 0),
	CVector3(10, 180, 0)
}
HeroLocomotionStateSprintTurn180Left.TerminationVelocityArea = {
	CVector3(-0.1, -180, 0),
	CVector3(1.5, 180, 0)
}
HeroLocomotionStateSprintTurn180Left.States = {
	"HeroLocomotionStateSprintTurn180Left",
	-- "HeroLocomotionStateRunTurn180Left",
	"HeroLocomotionStateRunLeanLeft",
	"HeroLocomotionStateLocomoteSprint",
	"HeroLocomotionStateLocomoteRun",
	"HeroLocomotionStateLocomoteWalkFast",
	"HeroLocomotionStateLocomoteWalkNormal",
	"HeroLocomotionStateLocomoteWalk",
	"HeroLocomotionStateIdleCombatPoseLF",
	{"HeroLocomotionStateIdle", 0.15}
}
HeroLocomotionStateSprintTurn180Left.MovementParams = {}
HeroLocomotionStateSprintTurn180Left.MovementParams.MaxTurnSpeedStatic = 300
HeroLocomotionStateSprintTurn180Left.MovementParams.MaxTurnSpeedRunning = 300
HeroLocomotionStateSprintTurn180Left.MovementParams.FrictionCoefficient = 4
HeroLocomotionStateSprintTurn180Left.MovementParams.FrictionCoefficientLateral = 4
HeroLocomotionStateSprintTurn180Left.MovementParams.MaxSpeed = 3

-- HeroLocomotionStateSprintTurn180Right --
HeroLocomotionStateSprintTurn180Right = {}
HeroLocomotionStateSprintTurn180Right.Anim = {
	"SprintTurn180Right"
}
HeroLocomotionStateSprintTurn180Right.TransitionType = ETransitionType.TRANSITION_MATCH_FOOTING
HeroLocomotionStateSprintTurn180Right.FootMatchType = EFootMatchType.FOOT_MATCH_RELATIVE
HeroLocomotionStateSprintTurn180Right.AnimBlendType = EAnimBlendType.ANIM_BLEND_BLEND
HeroLocomotionStateSprintTurn180Right.BlendInTime = 0.25
HeroLocomotionStateSprintTurn180Right.TargetFacingAngles = CVector3(45, 181, 0)
HeroLocomotionStateSprintTurn180Right.TerminationTargetFacingAngles = CVector3(15, 181, 0)
HeroLocomotionStateSprintTurn180Right.VelocityArea = {
	CVector3(0.9, -180, 0),
	CVector3(10, 180, 0)
}
HeroLocomotionStateSprintTurn180Right.TerminationVelocityArea = {
	CVector3(-0.1, -180, 0),
	CVector3(1.5, 180, 0)
}
HeroLocomotionStateSprintTurn180Right.States = {
	"HeroLocomotionStateSprintTurn180Right",
	-- "HeroLocomotionStateRunTurn180Right",
	"HeroLocomotionStateRunLeanRight",
	"HeroLocomotionStateLocomoteSprint",
	"HeroLocomotionStateLocomoteRun",
	"HeroLocomotionStateLocomoteWalkFast",
	"HeroLocomotionStateLocomoteWalkNormal",
	"HeroLocomotionStateLocomoteWalk",
	"HeroLocomotionStateIdleCombatPoseRF",
	{"HeroLocomotionStateIdle", 0.15}
}
HeroLocomotionStateSprintTurn180Right.MovementParams = {}
HeroLocomotionStateSprintTurn180Right.MovementParams.MaxTurnSpeedStatic = 300
HeroLocomotionStateSprintTurn180Right.MovementParams.MaxTurnSpeedRunning = 300
HeroLocomotionStateSprintTurn180Right.MovementParams.FrictionCoefficient = 4
HeroLocomotionStateSprintTurn180Right.MovementParams.FrictionCoefficientLateral = 4
HeroLocomotionStateSprintTurn180Right.MovementParams.MaxSpeed = 3

-- HeroLocomotionStateTurn90IntoRunLeft --
HeroLocomotionStateTurn90IntoRunLeft = {}
HeroLocomotionStateTurn90IntoRunLeft.Anim = {
	-- "Turn90IntoRunACW"
	"RFTurn180IntoRun"
}
HeroLocomotionStateTurn90IntoRunLeft.TransitionType = ETransitionType.TRANSITION_MATCH_FOOTING
HeroLocomotionStateTurn90IntoRunLeft.FootMatchType = EFootMatchType.FOOT_MATCH_RELATIVE
HeroLocomotionStateTurn90IntoRunLeft.AnimBlendType = EAnimBlendType.ANIM_BLEND_BLEND
HeroLocomotionStateTurn90IntoRunLeft.BlendInTime = 0.25
HeroLocomotionStateTurn90IntoRunLeft.TargetFacingAngles = CVector3(-135, -45, 0)
HeroLocomotionStateTurn90IntoRunLeft.TerminationTargetFacingAngles = CVector3(-135, 30, 0)
HeroLocomotionStateTurn90IntoRunLeft.VelocityArea = {
	CVector3(0.75, -180, 0),
	CVector3(1.2, 180, 0)
}
HeroLocomotionStateTurn90IntoRunLeft.TerminationVelocityArea = {
	CVector3(-0.1, -181, 0),
	CVector3(1.4, 181, 0)
}
HeroLocomotionStateTurn90IntoRunLeft.States = {
	"HeroLocomotionStateTurn90IntoRunLeft",
	"HeroLocomotionStateRunLeanLeft",
	"HeroLocomotionStateLocomoteSprint",
	"HeroLocomotionStateLocomoteRun",
	"HeroLocomotionStateLocomoteWalkFast",
	"HeroLocomotionStateLocomoteWalkNormal",
	"HeroLocomotionStateLocomoteWalk",
	"HeroLocomotionStateIdleCombatPoseLF",
	"HeroLocomotionStateIdle"
}
HeroLocomotionStateTurn90IntoRunLeft.MovementParams = {}
HeroLocomotionStateTurn90IntoRunLeft.MovementParams.MaxTurnSpeedStatic = 350
HeroLocomotionStateTurn90IntoRunLeft.MovementParams.MaxTurnSpeedRunning = 350
HeroLocomotionStateTurn90IntoRunLeft.MovementParams.FrictionCoefficient = 5
HeroLocomotionStateTurn90IntoRunLeft.MovementParams.FrictionCoefficientLateral = 5
HeroLocomotionStateTurn90IntoRunLeft.MovementParams.MaxSpeed = 2

-- HeroLocomotionStateTurn90IntoRunRight --
HeroLocomotionStateTurn90IntoRunRight = {}
HeroLocomotionStateTurn90IntoRunRight.Anim = {
	-- "Turn90IntoRunCW"
	"LFTurn180IntoRun"
}
HeroLocomotionStateTurn90IntoRunRight.TransitionType = ETransitionType.TRANSITION_MATCH_FOOTING
HeroLocomotionStateTurn90IntoRunRight.FootMatchType = EFootMatchType.FOOT_MATCH_RELATIVE
HeroLocomotionStateTurn90IntoRunRight.AnimBlendType = EAnimBlendType.ANIM_BLEND_BLEND
HeroLocomotionStateTurn90IntoRunRight.BlendInTime = 0.25
HeroLocomotionStateTurn90IntoRunRight.TargetFacingAngles = CVector3(45, 135, 0)
HeroLocomotionStateTurn90IntoRunRight.TerminationTargetFacingAngles = CVector3(-30, 135, 0)
HeroLocomotionStateTurn90IntoRunRight.VelocityArea = {
	CVector3(0.75, -180, 0),
	CVector3(1.2, 180, 0)
}
HeroLocomotionStateTurn90IntoRunRight.TerminationVelocityArea = {
	CVector3(-0.1, -181, 0),
	CVector3(1.4, 181, 0)
}
HeroLocomotionStateTurn90IntoRunRight.States = {
	"HeroLocomotionStateTurn90IntoRunRight",
	"HeroLocomotionStateRunLeanRight",
	"HeroLocomotionStateLocomoteSprint",
	"HeroLocomotionStateLocomoteRun",
	"HeroLocomotionStateLocomoteWalkFast",
	"HeroLocomotionStateLocomoteWalkNormal",
	"HeroLocomotionStateLocomoteWalk",
	"HeroLocomotionStateIdleCombatPoseRF",
	"HeroLocomotionStateIdle"
}
HeroLocomotionStateTurn90IntoRunRight.MovementParams = {}
HeroLocomotionStateTurn90IntoRunRight.MovementParams.MaxTurnSpeedStatic = 350
HeroLocomotionStateTurn90IntoRunRight.MovementParams.MaxTurnSpeedRunning = 350
HeroLocomotionStateTurn90IntoRunRight.MovementParams.FrictionCoefficient = 5
HeroLocomotionStateTurn90IntoRunRight.MovementParams.FrictionCoefficientLateral = 5
HeroLocomotionStateTurn90IntoRunRight.MovementParams.MaxSpeed = 2

-- HeroLocomotionStateTurn180IntoRunLeft --
HeroLocomotionStateTurn180IntoRunLeft = {}
HeroLocomotionStateTurn180IntoRunLeft.Anim = {
	"Turn180IntoRunACW"
}
HeroLocomotionStateTurn180IntoRunLeft.TransitionType = ETransitionType.TRANSITION_MATCH_FOOTING
HeroLocomotionStateTurn180IntoRunLeft.FootMatchType = EFootMatchType.FOOT_MATCH_RELATIVE
HeroLocomotionStateTurn180IntoRunLeft.AnimBlendType = EAnimBlendType.ANIM_BLEND_BLEND
HeroLocomotionStateTurn180IntoRunLeft.BlendInTime = 0.25
HeroLocomotionStateTurn180IntoRunLeft.TargetFacingAngles = CVector3(-225, -135, 0)
HeroLocomotionStateTurn180IntoRunLeft.TerminationTargetFacingAngles = CVector3(-225, 60, 0)
HeroLocomotionStateTurn180IntoRunLeft.VelocityArea = {
	CVector3(0.7, -180, 0),
	CVector3(1.0, 180, 0)
}
HeroLocomotionStateTurn180IntoRunLeft.TerminationVelocityArea = {
	CVector3(-0.1, -181, 0),
	CVector3(1.2, 181, 0)
}
HeroLocomotionStateTurn180IntoRunLeft.States = {
	"HeroLocomotionStateTurn180IntoRunLeft",
	"HeroLocomotionStateLocomoteSprint",
	"HeroLocomotionStateLocomoteRun",
	"HeroLocomotionStateLocomoteWalkFast",
	"HeroLocomotionStateLocomoteWalkNormal",
	"HeroLocomotionStateLocomoteWalk",
	"HeroLocomotionStateIdleCombatPoseLF",
	"HeroLocomotionStateIdle"
}
HeroLocomotionStateTurn180IntoRunLeft.MovementParams = {}
HeroLocomotionStateTurn180IntoRunLeft.MovementParams.MaxTurnSpeedStatic = 300
HeroLocomotionStateTurn180IntoRunLeft.MovementParams.MaxTurnSpeedRunning = 300
HeroLocomotionStateTurn180IntoRunLeft.MovementParams.FrictionCoefficient = 4
HeroLocomotionStateTurn180IntoRunLeft.MovementParams.FrictionCoefficientLateral = 4
HeroLocomotionStateTurn180IntoRunLeft.MovementParams.MaxSpeed = 2

-- HeroLocomotionStateTurn180IntoRunRight --
HeroLocomotionStateTurn180IntoRunRight = {}
HeroLocomotionStateTurn180IntoRunRight.Anim = {
	"Turn180IntoRunCW"
}
HeroLocomotionStateTurn180IntoRunRight.TransitionType = ETransitionType.TRANSITION_MATCH_FOOTING
HeroLocomotionStateTurn180IntoRunRight.FootMatchType = EFootMatchType.FOOT_MATCH_RELATIVE
HeroLocomotionStateTurn180IntoRunRight.AnimBlendType = EAnimBlendType.ANIM_BLEND_BLEND
HeroLocomotionStateTurn180IntoRunRight.BlendInTime = 0.25
HeroLocomotionStateTurn180IntoRunRight.TargetFacingAngles = CVector3(135, 225, 0)
HeroLocomotionStateTurn180IntoRunRight.TerminationTargetFacingAngles = CVector3(-60, 225, 0)
HeroLocomotionStateTurn180IntoRunRight.VelocityArea = {
	CVector3(0.7, -180, 0),
	CVector3(1.0, 180, 0)
}
HeroLocomotionStateTurn180IntoRunRight.TerminationVelocityArea = {
	CVector3(-0.1, -181, 0),
	CVector3(1.2, 181, 0)
}
HeroLocomotionStateTurn180IntoRunRight.States = {
	"HeroLocomotionStateTurn180IntoRunRight",
	"HeroLocomotionStateLocomoteSprint",
	"HeroLocomotionStateLocomoteRun",
	"HeroLocomotionStateLocomoteWalkFast",
	"HeroLocomotionStateLocomoteWalkNormal",
	"HeroLocomotionStateLocomoteWalk",
	"HeroLocomotionStateIdleCombatPoseRF",
	"HeroLocomotionStateIdle"
}
HeroLocomotionStateTurn180IntoRunRight.MovementParams = {}
HeroLocomotionStateTurn180IntoRunRight.MovementParams.MaxTurnSpeedStatic = 300
HeroLocomotionStateTurn180IntoRunRight.MovementParams.MaxTurnSpeedRunning = 300
HeroLocomotionStateTurn180IntoRunRight.MovementParams.FrictionCoefficient = 4
HeroLocomotionStateTurn180IntoRunRight.MovementParams.FrictionCoefficientLateral = 4
HeroLocomotionStateTurn180IntoRunRight.MovementParams.MaxSpeed = 2

-- HeroLocomotionStateTurn90ACW --
HeroLocomotionStateTurn90ACW = {}
HeroLocomotionStateTurn90ACW.Anim = {
	"Turn90Left"
}
HeroLocomotionStateTurn90ACW.TransitionType = ETransitionType.TRANSITION_ROTATION
HeroLocomotionStateTurn90ACW.BlendInTime = 0.1
HeroLocomotionStateTurn90ACW.TargetFacingAngles = CVector3(-135, -45, 0)
HeroLocomotionStateTurn90ACW.TerminationTargetFacingAngles = CVector3(-135, -2, 0)
HeroLocomotionStateTurn90ACW.VelocityArea = {
	CVector3(-HeroLocomotionData.MinVelMagForMovement, -181, 0),
	CVector3(0.05, 181, 0)
}
HeroLocomotionStateTurn90ACW.TerminationVelocityArea = {
	CVector3(-HeroLocomotionData.MinVelMagForMovement, -181, 0),
	CVector3(0.6, 181, 0)
}
HeroLocomotionStateTurn90ACW.States = {
	"HeroLocomotionStateTurn90IntoRunLeft",
	"HeroLocomotionStateTurn180IntoRunLeft",
	"HeroLocomotionStateWalkTurn90Left",
	"HeroLocomotionStateTurnLeft180",
	"HeroLocomotionStateTurnLeft90",
	"HeroLocomotionStateTurnLeft45",
	"HeroLocomotionStateTurn90ACW",
	"HeroLocomotionStateTurn180",
	"HeroLocomotionStateLocomoteForwardsUphill",
	"HeroLocomotionStateLocomoteForwardsDownhill",
	"HeroLocomotionStateLocomoteForwardsConfinedFront",
	"HeroLocomotionStateLocomoteSprint",
	"HeroLocomotionStateLocomoteRun",
	"HeroLocomotionStateLocomoteWalkFast",
	"HeroLocomotionStateLocomoteWalkNormal",
	"HeroLocomotionStateLocomoteWalk",
	"HeroLocomotionStateIdleCombatPoseLF",
	"HeroLocomotionStateIdle"
}

-- HeroLocomotionStateTurn90CW --
HeroLocomotionStateTurn90CW = {}
HeroLocomotionStateTurn90CW.Anim = {
	"Turn90Right"
}
HeroLocomotionStateTurn90CW.TransitionType = ETransitionType.TRANSITION_ROTATION
HeroLocomotionStateTurn90CW.BlendInTime = 0.1
HeroLocomotionStateTurn90CW.TargetFacingAngles = CVector3(45, 135, 0)
HeroLocomotionStateTurn90CW.TerminationTargetFacingAngles = CVector3(2, 135, 0)
HeroLocomotionStateTurn90CW.VelocityArea = {
	CVector3(-HeroLocomotionData.MinVelMagForMovement, -181, 0),
	CVector3(0.05, 181, 0)
}
HeroLocomotionStateTurn90CW.TerminationVelocityArea = {
	CVector3(-HeroLocomotionData.MinVelMagForMovement, -181, 0),
	CVector3(0.6, 181, 0)
}
HeroLocomotionStateTurn90CW.States = {
	"HeroLocomotionStateTurn90IntoRunRight",
	"HeroLocomotionStateTurn180IntoRunRight",
	"HeroLocomotionStateWalkTurn90Right",
	"HeroLocomotionStateTurnRight180",
	"HeroLocomotionStateTurnRight90",
	"HeroLocomotionStateTurnRight45",
	"HeroLocomotionStateTurn90CW",
	"HeroLocomotionStateTurn180",
	"HeroLocomotionStateLocomoteForwardsUphill",
	"HeroLocomotionStateLocomoteForwardsDownhill",
	"HeroLocomotionStateLocomoteForwardsConfinedFront",
	"HeroLocomotionStateLocomoteSprint",
	"HeroLocomotionStateLocomoteRun",
	"HeroLocomotionStateLocomoteWalkFast",
	"HeroLocomotionStateLocomoteWalkNormal",
	"HeroLocomotionStateLocomoteWalk",
	"HeroLocomotionStateIdleCombatPoseRF",
	"HeroLocomotionStateIdle"
}

-- HeroLocomotionStateTurn180 --
HeroLocomotionStateTurn180 = {}
HeroLocomotionStateTurn180.Anim = {
	"TurnLeft180Var001",
	"TurnRight180Var001",
	"TurnLeft180Var002",
	"TurnRight180Var002",
	"TurnLeft180Var003",
	"TurnRight180Var003",
	"TurnLeft180",
	"TurnRight180"
}
HeroLocomotionStateTurn180.TransitionType = ETransitionType.TRANSITION_ROTATION
HeroLocomotionStateTurn180.BlendInTime = 0.1
HeroLocomotionStateTurn180.TargetFacingAngles = CVector3(135, 180, 0)
HeroLocomotionStateTurn180.TerminationTargetFacingAngles = CVector3(2, 180, 0)
HeroLocomotionStateTurn180.TerminationVelocityArea = {
	CVector3(HeroLocomotionData.MinVelMagForMovement, -181, 0),
	CVector3(0.05, 181, 0)
}
HeroLocomotionStateTurn180.States = {
	"HeroLocomotionStateTurn180",
	{"HeroLocomotionStateLocomoteSprint", 0.25},
	{"HeroLocomotionStateLocomoteRun", 0.25},
	{"HeroLocomotionStateLocomoteWalkFast", 0.25},
	{"HeroLocomotionStateLocomoteWalkNormal", 0.25},
	{"HeroLocomotionStateLocomoteWalk", 0.25},
	"HeroLocomotionStateIdleCombatPoseLF",
	"HeroLocomotionStateIdleCombatPoseRF",
	"HeroLocomotionStateIdle"
}
HeroLocomotionStateTurn180.Symmetrical = true

-- HeroLocomotionStateLocomoteForwardsConfinedFront --
HeroLocomotionStateLocomoteForwardsConfinedFront = {}
HeroLocomotionStateLocomoteForwardsConfinedFront.Anim = {
	"RunIntoIdleConfinedFront"
	-- "IdleConfinedFront"
}
HeroLocomotionStateLocomoteForwardsConfinedFront.Confinement = EConfinementType.CONFINED_FRONT
-- HeroLocomotionStateLocomoteForwardsConfinedFront.AvailableToChild = false
HeroLocomotionStateLocomoteForwardsConfinedFront.BlendInTime = 0.25
HeroLocomotionStateLocomoteForwardsConfinedFront.ValidTime = 0.5
HeroLocomotionStateLocomoteForwardsConfinedFront.CombatState = ECombatState.COMBAT_STATE_NOT_SET
HeroLocomotionStateLocomoteForwardsConfinedFront.TargetFacingAngles = CVector3(-25, 25, 0)
HeroLocomotionStateLocomoteForwardsConfinedFront.TerminationTargetFacingAngles = CVector3(30, 330, 0)
HeroLocomotionStateLocomoteForwardsConfinedFront.VelocityArea = {
	CVector3(HeroLocomotionData.MinVelMagForMovement, -180, 0),
	CVector3(10, 180, 0)
}
HeroLocomotionStateLocomoteForwardsConfinedFront.ControlArea = {
	CVector3(-HeroLocomotionData.MinControlMagForMovement, -180, 0),
	CVector3(1.05, 180, 0)
}
HeroLocomotionStateLocomoteForwardsConfinedFront.States = {
	"HeroLocomotionStateTurn180IntoRunLeft",
	"HeroLocomotionStateTurn180IntoRunRight",
	"HeroLocomotionStateTurn90IntoRunLeft",
	"HeroLocomotionStateTurn90IntoRunRight",
	"HeroLocomotionStateTurnLeft180",
	"HeroLocomotionStateTurnRight180",
	"HeroLocomotionStateTurnLeft90",
	"HeroLocomotionStateTurnRight90",
	"HeroLocomotionStateTurnLeft45",
	"HeroLocomotionStateTurnRight45",
	"HeroLocomotionStateTurn90CW",
	"HeroLocomotionStateTurn90ACW",
	{"HeroLocomotionStateLocomoteForwardsConfinedRight", 0.25},
	{"HeroLocomotionStateLocomoteForwardsConfinedLeft", 0.25},
	"HeroLocomotionStateLocomoteForwardsConfinedFront",
	"HeroLocomotionStateLocomoteForwardsUphill",
	"HeroLocomotionStateLocomoteForwardsDownhill",
	"HeroLocomotionStateLocomoteSprint",
	"HeroLocomotionStateLocomoteRun",
	"HeroLocomotionStateLocomoteWalkFast",
	"HeroLocomotionStateLocomoteWalkNormal",
	"HeroLocomotionStateLocomoteWalk",
	"HeroLocomotionStateIdleCombatPoseLF",
	"HeroLocomotionStateIdleCombatPoseRF",
	"HeroLocomotionStateIdle"
}
HeroLocomotionStateLocomoteForwardsConfinedFront.MovementParams = {}
HeroLocomotionStateLocomoteForwardsConfinedFront.MovementParams.MaxSpeed = 0.01
HeroLocomotionStateLocomoteForwardsConfinedFront.MovementParams.SprintSpeedMultiplier = 1

-- HeroLocomotionStateLocomoteForwardsConfinedRight --
HeroLocomotionStateLocomoteForwardsConfinedRight = {}
HeroLocomotionStateLocomoteForwardsConfinedRight.Anim = {
	"IdleConfinedRight",
	"WalkConfinedRight",
	"RunConfinedRight"
}
HeroLocomotionStateLocomoteForwardsConfinedRight.Confinement = EConfinementType.CONFINED_RIGHT
HeroLocomotionStateLocomoteForwardsConfinedRight.AnimBlendType = EAnimBlendType.ANIM_BLEND_BLEND
-- HeroLocomotionStateLocomoteForwardsConfinedRight.AvailableToChild = false
HeroLocomotionStateLocomoteForwardsConfinedRight.BlendInTime = 0.25
HeroLocomotionStateLocomoteForwardsConfinedRight.BlendOutTime = 0.25
HeroLocomotionStateLocomoteForwardsConfinedRight.ValidTime = 0.2
HeroLocomotionStateLocomoteForwardsConfinedRight.VelocityArea = {
	CVector3(-HeroLocomotionData.MinVelMagForMovement, -60, 0),
	CVector3(10, 60, 0)
}
HeroLocomotionStateLocomoteForwardsConfinedRight.ControlArea = {
	CVector3(HeroLocomotionData.MinControlMagForMovement, -180, 0),
	CVector3(1.05, 180, 0)
}
HeroLocomotionStateLocomoteForwardsConfinedRight.States = {
	"HeroLocomotionStateTurn180IntoRunLeft",
	"HeroLocomotionStateTurn90IntoRunLeft",
	"HeroLocomotionStateTurnLeft180",
	"HeroLocomotionStateTurnLeft90",
	"HeroLocomotionStateTurnLeft45",
	"HeroLocomotionStateWalkTurn90Left",
	"HeroLocomotionStateRunTurn180Left",
	"HeroLocomotionStateSprintTurn180Left",
	"HeroLocomotionStateTurn90ACW",
	{"HeroLocomotionStateLocomoteForwardsUphill", 0.25},
	{"HeroLocomotionStateLocomoteForwardsDownhill", 0.25},
	"HeroLocomotionStateLocomoteForwardsConfinedLeft",
	"HeroLocomotionStateLocomoteForwardsConfinedRight",
	{"HeroLocomotionStateLocomoteForwardsConfinedFront", 0.3},
	{"HeroLocomotionStateLocomoteSprint", 0.25},
	{"HeroLocomotionStateLocomoteRun", 0.25},
	{"HeroLocomotionStateLocomoteWalkFast", 0.25},
	{"HeroLocomotionStateLocomoteWalkNormal", 0.25},
	{"HeroLocomotionStateLocomoteWalk", 0.25},
	"HeroLocomotionStateIdleCombatPoseRF",
	"HeroLocomotionStateIdle"
}
HeroLocomotionStateLocomoteForwardsConfinedRight.MovementParams = {}
HeroLocomotionStateLocomoteForwardsConfinedRight.MovementParams.SprintSpeedMultiplier = 1.1

-- HeroLocomotionStateLocomoteForwardsConfinedLeft --
HeroLocomotionStateLocomoteForwardsConfinedLeft = {}
HeroLocomotionStateLocomoteForwardsConfinedLeft.Anim = {
	"IdleConfinedLeft",
	"WalkConfinedLeft",
	"RunConfinedLeft"
}
HeroLocomotionStateLocomoteForwardsConfinedLeft.Confinement = EConfinementType.CONFINED_LEFT
HeroLocomotionStateLocomoteForwardsConfinedLeft.AnimBlendType = EAnimBlendType.ANIM_BLEND_BLEND
-- HeroLocomotionStateLocomoteForwardsConfinedLeft.AvailableToChild = false
HeroLocomotionStateLocomoteForwardsConfinedLeft.BlendInTime = 0.25
HeroLocomotionStateLocomoteForwardsConfinedLeft.BlendOutTime = 0.25
HeroLocomotionStateLocomoteForwardsConfinedLeft.ValidTime = 0.2
HeroLocomotionStateLocomoteForwardsConfinedLeft.VelocityArea = {
	CVector3(-HeroLocomotionData.MinVelMagForMovement, -60, 0),
	CVector3(10, 60, 0)
}
HeroLocomotionStateLocomoteForwardsConfinedLeft.ControlArea = {
	CVector3(HeroLocomotionData.MinControlMagForMovement, -180, 0),
	CVector3(1.05, 180, 0)
}
HeroLocomotionStateLocomoteForwardsConfinedLeft.States = {
	"HeroLocomotionStateTurn180IntoRunRight",
	"HeroLocomotionStateTurn90IntoRunRight",
	"HeroLocomotionStateTurnRight180",
	"HeroLocomotionStateTurnRight90",
	"HeroLocomotionStateTurnRight45",
	"HeroLocomotionStateWalkTurn90Right",
	"HeroLocomotionStateRunTurn180Right",
	"HeroLocomotionStateSprintTurn180Right",
	"HeroLocomotionStateTurn90CW",
	{"HeroLocomotionStateLocomoteForwardsUphill", 0.25},
	{"HeroLocomotionStateLocomoteForwardsDownhill", 0.25},
	"HeroLocomotionStateLocomoteForwardsConfinedRight",
	"HeroLocomotionStateLocomoteForwardsConfinedLeft",
	{"HeroLocomotionStateLocomoteForwardsConfinedFront", 0.3},
	{"HeroLocomotionStateLocomoteSprint", 0.25},
	{"HeroLocomotionStateLocomoteRun", 0.25},
	{"HeroLocomotionStateLocomoteWalkFast", 0.25},
	{"HeroLocomotionStateLocomoteWalkNormal", 0.25},
	{"HeroLocomotionStateLocomoteWalk", 0.25},
	"HeroLocomotionStateIdleCombatPoseLF",
	"HeroLocomotionStateIdle"
}
HeroLocomotionStateLocomoteForwardsConfinedLeft.MovementParams = {}
HeroLocomotionStateLocomoteForwardsConfinedLeft.MovementParams.SprintSpeedMultiplier = 1.1

-- HeroLocomotionStateLocomoteForwardsUphill --
HeroLocomotionStateLocomoteForwardsUphill = {}
HeroLocomotionStateLocomoteForwardsUphill.Anim = {
	"WalkUphill",
	"RunUphill"
}
HeroLocomotionStateLocomoteForwardsUphill.BlendInTime = 0.125
HeroLocomotionStateLocomoteForwardsUphill.BlendOutTime = 0.25
HeroLocomotionStateLocomoteForwardsUphill.AllowLooking = true
-- HeroLocomotionStateLocomoteForwardsUphill.ValidTime = 0.1
HeroLocomotionStateLocomoteForwardsUphill.AnimBlendType = EAnimBlendType.ANIM_BLEND_BLEND
HeroLocomotionStateLocomoteForwardsUphill.VerticalVelocityRange = CVector3(0.3, 2, 0) --CVector3(0.2, 2, 0)
HeroLocomotionStateLocomoteForwardsUphill.TerminationVerticalVelocityRange = CVector3(0.06, 2, 0) --CVector3(0.1, 2, 0)
HeroLocomotionStateLocomoteForwardsUphill.VelocityArea = {
	CVector3(HeroLocomotionData.MinVelMagForMovement, -180, 0),
	CVector3(10, 180, 0)
}
HeroLocomotionStateLocomoteForwardsUphill.ControlArea = {
	CVector3(HeroLocomotionData.MinControlMagForMovement, -90, 0),
	CVector3(1.05, 90, 0)
}
HeroLocomotionStateLocomoteForwardsUphill.States = {
	"HeroLocomotionStateTurn180IntoRunLeft",
	"HeroLocomotionStateTurn180IntoRunRight",
	"HeroLocomotionStateTurn90IntoRunLeft",
	"HeroLocomotionStateTurn90IntoRunRight",
	"HeroLocomotionStateSprintTurn180Left",
	"HeroLocomotionStateSprintTurn180Right",
	"HeroLocomotionStateRunTurn180Left",
	"HeroLocomotionStateRunTurn180Right",
	"HeroLocomotionStateWalkTurn90Left",
	"HeroLocomotionStateWalkTurn90Right",
	"HeroLocomotionStateTurnLeft180",
	"HeroLocomotionStateTurnRight180",
	"HeroLocomotionStateTurnLeft90",
	"HeroLocomotionStateTurnRight90",
	"HeroLocomotionStateTurnLeft45",
	"HeroLocomotionStateTurnRight45",
	"HeroLocomotionStateLocomoteForwardsDownhill",
	"HeroLocomotionStateLocomoteForwardsUphill",
	"HeroLocomotionStateLocomoteForwardsConfinedFront",
	"HeroLocomotionStateLocomoteSprint",
	"HeroLocomotionStateLocomoteRun",
	"HeroLocomotionStateLocomoteWalkFast",
	"HeroLocomotionStateLocomoteWalkNormal",
	"HeroLocomotionStateLocomoteWalk",
	"HeroLocomotionStateIdleCombatPoseLF",
	"HeroLocomotionStateIdleCombatPoseRF",
	"HeroLocomotionStateIdle"
}
HeroLocomotionStateLocomoteForwardsUphill.MovementParams = {}
HeroLocomotionStateLocomoteForwardsUphill.MovementParams.MaxSpeed = 4.35
HeroLocomotionStateLocomoteForwardsUphill.MovementParams.SprintSpeedMultiplier = 1.05

-- HeroLocomotionStateLocomoteForwardsDownhill --
HeroLocomotionStateLocomoteForwardsDownhill = {}
HeroLocomotionStateLocomoteForwardsDownhill.Anim = {
	"WalkDownhill",
	"RunDownhill"
}
HeroLocomotionStateLocomoteForwardsDownhill.BlendInTime = 0.125
HeroLocomotionStateLocomoteForwardsDownhill.BlendOutTime = 0.25
HeroLocomotionStateLocomoteForwardsDownhill.AllowLooking = true
-- HeroLocomotionStateLocomoteForwardsDownhill.ValidTime = 0.2
HeroLocomotionStateLocomoteForwardsDownhill.AnimBlendType = EAnimBlendType.ANIM_BLEND_BLEND
HeroLocomotionStateLocomoteForwardsDownhill.VerticalVelocityRange = CVector3(-2, -0.3, 0) --CVector3(-2, -0.2, 0)
HeroLocomotionStateLocomoteForwardsDownhill.TerminationVerticalVelocityRange = CVector3(-2, -0.06, 0) --CVector3(-2, -0.1, 0)
HeroLocomotionStateLocomoteForwardsDownhill.VelocityArea = {
	CVector3(HeroLocomotionData.MinVelMagForMovement, -180, 0),
	CVector3(10, 180, 0)
}
HeroLocomotionStateLocomoteForwardsDownhill.ControlArea = {
	CVector3(HeroLocomotionData.MinControlMagForMovement, -90, 0),
	CVector3(1.05, 90, 0)
}
HeroLocomotionStateLocomoteForwardsDownhill.States = {
	"HeroLocomotionStateTurn180IntoRunLeft",
	"HeroLocomotionStateTurn180IntoRunRight",
	"HeroLocomotionStateTurn90IntoRunLeft",
	"HeroLocomotionStateTurn90IntoRunRight",
	"HeroLocomotionStateSprintTurn180Left",
	"HeroLocomotionStateSprintTurn180Right",
	"HeroLocomotionStateRunTurn180Left",
	"HeroLocomotionStateRunTurn180Right",
	"HeroLocomotionStateWalkTurn90Left",
	"HeroLocomotionStateWalkTurn90Right",
	"HeroLocomotionStateTurnLeft180",
	"HeroLocomotionStateTurnRight180",
	"HeroLocomotionStateTurnLeft90",
	"HeroLocomotionStateTurnRight90",
	"HeroLocomotionStateTurnLeft45",
	"HeroLocomotionStateTurnRight45",
	"HeroLocomotionStateLocomoteForwardsUphill",
	"HeroLocomotionStateLocomoteForwardsDownhill",
	"HeroLocomotionStateLocomoteForwardsConfinedFront",
	"HeroLocomotionStateLocomoteSprint",
	"HeroLocomotionStateLocomoteRun",
	"HeroLocomotionStateLocomoteWalkFast",
	"HeroLocomotionStateLocomoteWalkNormal",
	"HeroLocomotionStateLocomoteWalk",
	"HeroLocomotionStateIdleCombatPoseLF",
	"HeroLocomotionStateIdleCombatPoseRF",
	"HeroLocomotionStateIdle"
}
HeroLocomotionStateLocomoteForwardsDownhill.MovementParams = {}
HeroLocomotionStateLocomoteForwardsDownhill.MovementParams.SprintSpeedMultiplier = 1.2

-- HeroLocomotionStateRunLeanLeft --
HeroLocomotionStateRunLeanLeft = {}
HeroLocomotionStateRunLeanLeft.Anim = {
	"RunLeanLeft"
}
HeroLocomotionStateRunLeanLeft.AnimBlendType = EAnimBlendType.ANIM_BLEND_BLEND
HeroLocomotionStateRunLeanLeft.BlendInTime = 0.4
HeroLocomotionStateRunLeanLeft.BlendOutTime = 0.8
HeroLocomotionStateRunLeanLeft.FootMatchType = EFootMatchType.FOOT_MATCH_RELATIVE
HeroLocomotionStateRunLeanLeft.TargetFacingAngles = CVector3(-135, -25, 0)
HeroLocomotionStateRunLeanLeft.TerminationTargetFacingAngles = CVector3(-175, -10, 0)
HeroLocomotionStateRunLeanLeft.VelocityArea = {
	CVector3(0.8, -180, 0),
	CVector3(10, 180, 0)
}
HeroLocomotionStateRunLeanLeft.ControlArea = {
	CVector3(HeroLocomotionData.MinControlMagForMovement, -135, 0),
	CVector3(1.05, -25, 0)
}
HeroLocomotionStateRunLeanLeft.States = {
	"HeroLocomotionStateSprintTurn180Left",
	"HeroLocomotionStateRunTurn180Left",
	"HeroLocomotionStateRunLeanLeft",
	"HeroLocomotionStateLocomoteForwardsUphill",
	"HeroLocomotionStateLocomoteForwardsDownhill",
	"HeroLocomotionStateLocomoteForwardsConfinedFront",
	"HeroLocomotionStateLocomoteSprint",
	"HeroLocomotionStateLocomoteRun",
	"HeroLocomotionStateLocomoteWalkFast",
	"HeroLocomotionStateLocomoteWalkNormal",
	"HeroLocomotionStateLocomoteWalk",
	{"HeroLocomotionStateIdleCombatPoseLF", 0.2},
	{"HeroLocomotionStateIdle", 0.2}
}

-- HeroLocomotionStateRunLeanRight --
HeroLocomotionStateRunLeanRight = {}
HeroLocomotionStateRunLeanRight.Anim = {
	"RunLeanRight"
}
HeroLocomotionStateRunLeanRight.AnimBlendType = EAnimBlendType.ANIM_BLEND_BLEND
HeroLocomotionStateRunLeanRight.BlendInTime = 0.4
HeroLocomotionStateRunLeanRight.BlendOutTime = 0.8
HeroLocomotionStateRunLeanRight.FootMatchType = EFootMatchType.FOOT_MATCH_RELATIVE
HeroLocomotionStateRunLeanRight.TargetFacingAngles = CVector3(25, 135, 0)
HeroLocomotionStateRunLeanRight.TerminationTargetFacingAngles = CVector3(10, 175, 0)
HeroLocomotionStateRunLeanRight.VelocityArea = {
	CVector3(0.8, -180, 0),
	CVector3(10, 180, 0)
}
HeroLocomotionStateRunLeanRight.ControlArea = {
	CVector3(HeroLocomotionData.MinControlMagForMovement, 25, 0),
	CVector3(1.05, 135, 0)
}
HeroLocomotionStateRunLeanRight.States = {
	"HeroLocomotionStateSprintTurn180Right",
	"HeroLocomotionStateRunTurn180Right",
	"HeroLocomotionStateRunLeanRight",
	"HeroLocomotionStateLocomoteForwardsUphill",
	"HeroLocomotionStateLocomoteForwardsDownhill",
	"HeroLocomotionStateLocomoteForwardsConfinedFront",
	"HeroLocomotionStateLocomoteSprint",
	"HeroLocomotionStateLocomoteRun",
	"HeroLocomotionStateLocomoteWalkFast",
	"HeroLocomotionStateLocomoteWalkNormal",
	"HeroLocomotionStateLocomoteWalk",
	{"HeroLocomotionStateIdleCombatPoseRF", 0.2},
	{"HeroLocomotionStateIdle", 0.2}
}

-- HeroLocomotionStateLocomoteWalkBack --
HeroLocomotionStateLocomoteWalkBack = {}
HeroLocomotionStateLocomoteWalkBack.Anim = {
	"WalkBack",
	"RunBack"
}
HeroLocomotionStateLocomoteWalkBack.BlendInTime = 0.25
HeroLocomotionStateLocomoteWalkBack.AllowLooking = true
HeroLocomotionStateLocomoteWalkBack.AnimBlendType = EAnimBlendType.ANIM_BLEND_BLEND
-- HeroLocomotionStateLocomoteWalkBack.TargetFacingAngles = CVector3(-190, 190, 0)
-- HeroLocomotionStateLocomoteWalkBack.TerminationTargetFacingAngles = CVector3(-170, 170, 0)
HeroLocomotionStateLocomoteWalkBack.VelocityArea = {
	CVector3(HeroLocomotionData.MinVelMagForMovement, -180, 0),
	CVector3(0.9, 180, 0)
}
HeroLocomotionStateLocomoteWalkBack.ControlArea = {
	CVector3(HeroLocomotionData.MinControlMagForMovement, -60, 0),
	CVector3(1.05, 60, 0)
}
HeroLocomotionStateLocomoteWalkBack.TerminationVelocityArea = {
	CVector3(-HeroLocomotionData.MinVelMagForMovement, -181, 0),
	CVector3(0.91, 181, 0)
}
HeroLocomotionStateLocomoteWalkBack.States = {
	"HeroLocomotionStateTurn90CW",
	"HeroLocomotionStateTurn90ACW",
	"HeroLocomotionStateWalkTurn90Left",
	"HeroLocomotionStateWalkTurn90Right",
	"HeroLocomotionStateTurnLeft45",
	"HeroLocomotionStateTurnRight45",
	"HeroLocomotionStateTurnLeft90",
	"HeroLocomotionStateTurnRight90",
	"HeroLocomotionStateLocomoteWalkBack",
	-- "HeroLocomotionStateTurnLeft180",
	-- "HeroLocomotionStateTurnRight180",
	-- {"HeroLocomotionStateLocomoteSprint", 0.25},
	-- {"HeroLocomotionStateLocomoteRun", 0.25},
	-- {"HeroLocomotionStateLocomoteWalkFast", 0.25},
	-- {"HeroLocomotionStateLocomoteWalkNormal", 0.25},
	-- "HeroLocomotionStateLocomoteWalk",
	"HeroLocomotionStateLocomoteForwardsConfinedFront",
	"HeroLocomotionStateLocomoteSprint",
	"HeroLocomotionStateLocomoteRun",
	"HeroLocomotionStateLocomoteWalkFast",
	"HeroLocomotionStateLocomoteWalkNormal",
	"HeroLocomotionStateLocomoteWalk",
	"HeroLocomotionStateIdleCombatPoseLF",
	"HeroLocomotionStateIdleCombatPoseRF",
	{"HeroLocomotionStateIdle", 0.15}
}
HeroLocomotionStateLocomoteWalkBack.MovementParams = {}
-- HeroLocomotionStateLocomoteWalkBack.MovementParams.MaxSpeed = 1
-- HeroLocomotionStateLocomoteWalkBack.MovementParams.SprintSpeedMultiplier = 0
HeroLocomotionStateLocomoteWalkBack.MovementParams.AllowedToMoveBackwards = 1

-- HeroLocomotionStateLocomoteWalk --
HeroLocomotionStateLocomoteWalk = {}
HeroLocomotionStateLocomoteWalk.Anim = {
	"WalkSlow"
}
HeroLocomotionStateLocomoteWalk.BlendInTime = 0.1
HeroLocomotionStateLocomoteWalk.AllowLooking = true
HeroLocomotionStateLocomoteWalk.AnimBlendType = EAnimBlendType.ANIM_BLEND_BLEND
HeroLocomotionStateLocomoteWalk.VelocityArea = {
	CVector3(0.02, -180, 0),
	CVector3(10, 180, 0)
}
HeroLocomotionStateLocomoteWalk.ControlArea = {
	CVector3(HeroLocomotionData.MinControlMagForMovement, -60, 0),
	CVector3(1.05, 60, 0)
}
HeroLocomotionStateLocomoteWalk.States = {
	"HeroLocomotionStateTurn90IntoRunLeft",
	"HeroLocomotionStateTurn90IntoRunRight",
	"HeroLocomotionStateTurn180IntoRunLeft",
	"HeroLocomotionStateTurn180IntoRunRight",
	"HeroLocomotionStateWalkTurn90Left",
	"HeroLocomotionStateWalkTurn90Right",
	"HeroLocomotionStateTurnLeft180",
	"HeroLocomotionStateTurnRight180",
	"HeroLocomotionStateTurnLeft90",
	"HeroLocomotionStateTurnRight90",
	"HeroLocomotionStateTurnLeft45",
	"HeroLocomotionStateTurnRight45",
	"HeroLocomotionStateTurn90CW",
	"HeroLocomotionStateTurn90ACW",
	"HeroLocomotionStateTurn180",
	"HeroLocomotionStateLocomoteForwardsUphill",
	"HeroLocomotionStateLocomoteForwardsDownhill",
	{"HeroLocomotionStateLocomoteForwardsConfinedFront", 0.5},
	"HeroLocomotionStateLocomoteForwardsConfinedRight",
	"HeroLocomotionStateLocomoteForwardsConfinedLeft",
	"HeroLocomotionStateLocomoteSprint",
	"HeroLocomotionStateLocomoteRun",
	"HeroLocomotionStateLocomoteWalkFast",
	"HeroLocomotionStateLocomoteWalkNormal",
	"HeroLocomotionStateLocomoteWalk",
	"HeroLocomotionStateIdleCombatPoseLF",
	"HeroLocomotionStateIdleCombatPoseRF",
	{"HeroLocomotionStateIdle", 0.15}
}

-- HeroLocomotionStateLocomoteWalkNormal --
HeroLocomotionStateLocomoteWalkNormal = {}
HeroLocomotionStateLocomoteWalkNormal.Anim = {
	"Walk"
}
HeroLocomotionStateLocomoteWalkNormal.BlendInTime = 0.15
HeroLocomotionStateLocomoteWalkNormal.AllowLooking = true
HeroLocomotionStateLocomoteWalkNormal.ValidTime = 0.05
HeroLocomotionStateLocomoteWalkNormal.AnimBlendType = EAnimBlendType.ANIM_BLEND_BLEND
HeroLocomotionStateLocomoteWalkNormal.VelocityArea = {
	CVector3(0.39, -180, 0),
	CVector3(10, 180, 0)
}
HeroLocomotionStateLocomoteWalkNormal.ControlArea = {
	CVector3(HeroLocomotionData.MinControlMagForMovement, -60, 0),
	CVector3(1.05, 60, 0)
}
HeroLocomotionStateLocomoteWalkNormal.States = {
	"HeroLocomotionStateTurn90IntoRunLeft",
	"HeroLocomotionStateTurn90IntoRunRight",
	"HeroLocomotionStateTurn180IntoRunLeft",
	"HeroLocomotionStateTurn180IntoRunRight",
	"HeroLocomotionStateWalkTurn90Left",
	"HeroLocomotionStateWalkTurn90Right",
	"HeroLocomotionStateTurnLeft180",
	"HeroLocomotionStateTurnRight180",
	"HeroLocomotionStateTurnLeft90",
	"HeroLocomotionStateTurnRight90",
	"HeroLocomotionStateTurnLeft45",
	"HeroLocomotionStateTurnRight45",
	"HeroLocomotionStateTurn90CW",
	"HeroLocomotionStateTurn90ACW",
	"HeroLocomotionStateTurn180",
	"HeroLocomotionStateLocomoteForwardsUphill",
	"HeroLocomotionStateLocomoteForwardsDownhill",
	{"HeroLocomotionStateLocomoteForwardsConfinedFront", 0.4},
	"HeroLocomotionStateLocomoteForwardsConfinedRight",
	"HeroLocomotionStateLocomoteForwardsConfinedLeft",
	"HeroLocomotionStateLocomoteSprint",
	"HeroLocomotionStateLocomoteRun",
	"HeroLocomotionStateLocomoteWalkFast",
	"HeroLocomotionStateLocomoteWalkNormal",
	"HeroLocomotionStateLocomoteWalk",
	"HeroLocomotionStateIdleCombatPoseLF",
	"HeroLocomotionStateIdleCombatPoseRF",
	"HeroLocomotionStateIdle"
}

-- HeroLocomotionStateLocomoteWalkFast --
HeroLocomotionStateLocomoteWalkFast = {}
HeroLocomotionStateLocomoteWalkFast.Anim = {
	"WalkFast"
}
HeroLocomotionStateLocomoteWalkFast.BlendInTime = 0.2
HeroLocomotionStateLocomoteWalkFast.AllowLooking = true
HeroLocomotionStateLocomoteWalkFast.ValidTime = 0.05
HeroLocomotionStateLocomoteWalkFast.AnimBlendType = EAnimBlendType.ANIM_BLEND_BLEND
HeroLocomotionStateLocomoteWalkFast.VelocityArea = {
	CVector3(0.57, -180, 0),
	CVector3(10, 180, 0)
}
HeroLocomotionStateLocomoteWalkFast.ControlArea = {
	CVector3(HeroLocomotionData.MinControlMagForMovement, -60, 0),
	CVector3(1.05, 60, 0)
}
HeroLocomotionStateLocomoteWalkFast.States = {
	"HeroLocomotionStateTurn90IntoRunLeft",
	"HeroLocomotionStateTurn90IntoRunRight",
	"HeroLocomotionStateTurn180IntoRunLeft",
	"HeroLocomotionStateTurn180IntoRunRight",
	"HeroLocomotionStateRunTurn180Left",
	"HeroLocomotionStateRunTurn180Right",
	"HeroLocomotionStateSprintTurn180Left",
	"HeroLocomotionStateSprintTurn180Right",
	"HeroLocomotionStateTurnLeft180",
	"HeroLocomotionStateTurnRight180",
	"HeroLocomotionStateTurnLeft90",
	"HeroLocomotionStateTurnRight90",
	"HeroLocomotionStateTurnLeft45",
	"HeroLocomotionStateTurnRight45",
	"HeroLocomotionStateTurn90CW",
	"HeroLocomotionStateTurn90ACW",
	"HeroLocomotionStateTurn180",
	"HeroLocomotionStateLocomoteForwardsUphill",
	"HeroLocomotionStateLocomoteForwardsDownhill",
	{"HeroLocomotionStateLocomoteForwardsConfinedFront", 0.3},
	"HeroLocomotionStateLocomoteForwardsConfinedRight",
	"HeroLocomotionStateLocomoteForwardsConfinedLeft",
	"HeroLocomotionStateRunLeanRight",
	"HeroLocomotionStateRunLeanLeft",
	"HeroLocomotionStateLocomoteSprint",
	"HeroLocomotionStateLocomoteRun",
	"HeroLocomotionStateLocomoteWalkFast",
	"HeroLocomotionStateLocomoteWalkNormal",
	"HeroLocomotionStateLocomoteWalk",
	"HeroLocomotionStateIdleCombatPoseLF",
	"HeroLocomotionStateIdleCombatPoseRF",
	{"HeroLocomotionStateIdle", 0.2}
}

-- HeroLocomotionStateLocomoteRun --
HeroLocomotionStateLocomoteRun = {}
if Stats.GetFat(GetLocalHero()) > 0.5 then
	HeroLocomotionStateLocomoteRun.Anim = { "RunFat" }
else
	HeroLocomotionStateLocomoteRun.Anim = { "Run" }
end
HeroLocomotionStateLocomoteRun.BlendInTime = 0.25
HeroLocomotionStateLocomoteRun.AllowLooking = true
HeroLocomotionStateLocomoteRun.ValidTime = 0.05
HeroLocomotionStateLocomoteRun.AnimBlendType = EAnimBlendType.ANIM_BLEND_BLEND
HeroLocomotionStateLocomoteRun.VelocityArea = {
	CVector3(0.82, -180, 0),
	CVector3(10, 180, 0)
}
HeroLocomotionStateLocomoteRun.ControlArea = {
	CVector3(HeroLocomotionData.MinControlMagForMovement, -60, 0),
	CVector3(1.05, 60, 0)
}
HeroLocomotionStateLocomoteRun.States = {
	"HeroLocomotionStateTurn90IntoRunLeft",
	"HeroLocomotionStateTurn90IntoRunRight",
	"HeroLocomotionStateTurn180IntoRunLeft",
	"HeroLocomotionStateTurn180IntoRunRight",
	"HeroLocomotionStateSprintTurn180Left",
	"HeroLocomotionStateSprintTurn180Right",
	"HeroLocomotionStateRunTurn180Left",
	"HeroLocomotionStateRunTurn180Right",
	"HeroLocomotionStateTurnLeft180",
	"HeroLocomotionStateTurnRight180",
	"HeroLocomotionStateTurnLeft90",
	"HeroLocomotionStateTurnRight90",
	"HeroLocomotionStateTurnLeft45",
	"HeroLocomotionStateTurnRight45",
	"HeroLocomotionStateTurn90CW",
	"HeroLocomotionStateTurn90ACW",
	"HeroLocomotionStateTurn180",
	"HeroLocomotionStateLocomoteForwardsConfinedFront",
	"HeroLocomotionStateRunLeanRight",
	"HeroLocomotionStateRunLeanLeft",
	"HeroLocomotionStateLocomoteForwardsUphill",
	"HeroLocomotionStateLocomoteForwardsDownhill",
	"HeroLocomotionStateLocomoteForwardsConfinedLeft",
	"HeroLocomotionStateLocomoteForwardsConfinedRight",
	"HeroLocomotionStateLocomoteSprint",
	"HeroLocomotionStateLocomoteRun",
	"HeroLocomotionStateLocomoteWalkFast",
	"HeroLocomotionStateLocomoteWalkNormal",
	"HeroLocomotionStateLocomoteWalk",
	"HeroLocomotionStateIdleCombatPoseLF",
	"HeroLocomotionStateIdleCombatPoseRF",
	{"HeroLocomotionStateIdle", 0.25}
}

-- HeroLocomotionStateLocomoteSprint --
HeroLocomotionStateLocomoteSprint = {}
HeroLocomotionStateLocomoteSprint.Anim = {
	"Sprint"
}
HeroLocomotionStateLocomoteSprint.BlendInTime = 0.3
HeroLocomotionStateLocomoteSprint.AllowLooking = false
HeroLocomotionStateLocomoteSprint.ValidTime = 0.05
HeroLocomotionStateLocomoteSprint.AnimBlendType = EAnimBlendType.ANIM_BLEND_BLEND
HeroLocomotionStateLocomoteSprint.VelocityArea = {
	CVector3(1.25, -180, 0),
	CVector3(10, 180, 0)
}
HeroLocomotionStateLocomoteSprint.ControlArea = {
	CVector3(HeroLocomotionData.MinControlMagForMovement, -60, 0),
	CVector3(1.05, 60, 0)
}
HeroLocomotionStateLocomoteSprint.States = {
	"HeroLocomotionStateSprintTurn180Left",
	"HeroLocomotionStateSprintTurn180Right",
	"HeroLocomotionStateRunTurn180Left",
	"HeroLocomotionStateRunTurn180Right",
	"HeroLocomotionStateTurnLeft180",
	"HeroLocomotionStateTurnRight180",
	"HeroLocomotionStateTurnLeft90",
	"HeroLocomotionStateTurnRight90",
	"HeroLocomotionStateTurnLeft45",
	"HeroLocomotionStateTurnRight45",
	"HeroLocomotionStateTurn90CW",
	"HeroLocomotionStateTurn90ACW",
	"HeroLocomotionStateTurn180",
	"HeroLocomotionStateLocomoteForwardsConfinedFront",
	"HeroLocomotionStateLocomoteForwardsUphill",
	"HeroLocomotionStateLocomoteForwardsDownhill",
	"HeroLocomotionStateRunLeanRight",
	"HeroLocomotionStateRunLeanLeft",
	"HeroLocomotionStateLocomoteForwardsConfinedLeft",
	"HeroLocomotionStateLocomoteForwardsConfinedRight",
	"HeroLocomotionStateLocomoteSprint",
	"HeroLocomotionStateLocomoteRun",
	"HeroLocomotionStateLocomoteWalkFast",
	"HeroLocomotionStateLocomoteWalkNormal",
	"HeroLocomotionStateLocomoteWalk",
	"HeroLocomotionStateIdleCombatPoseLF",
	"HeroLocomotionStateIdleCombatPoseRF",
	{"HeroLocomotionStateIdle", 0.25}
}

-- HeroLocomotionStateLocomoteJog --
HeroLocomotionStateLocomoteJog = {}
HeroLocomotionStateLocomoteJog.Anim = {
	"Jog"
}
HeroLocomotionStateLocomoteJog.BlendInTime = 0.5
HeroLocomotionStateLocomoteJog.VelocityArea = {
	CVector3(0.25, -180, 0),
	CVector3(0.5, 180, 0)
}
HeroLocomotionStateLocomoteJog.ControlArea = {
	CVector3(HeroLocomotionData.MinControlMagForMovement, -180, 0),
	CVector3(1.05, 180, 0)
}
HeroLocomotionStateLocomoteJog.States = {
	"HeroLocomotionStateLocomoteForwardsConfinedFront",
	{"HeroLocomotionStateLocomoteSprint", 0.125},
	{"HeroLocomotionStateLocomoteRun", 0.125},
	"HeroLocomotionStateLocomoteJog",
	{"HeroLocomotionStateLocomoteWalkFast", 0.125},
	{"HeroLocomotionStateLocomoteWalkNormal", 0.125},
	{"HeroLocomotionStateLocomoteWalk", 0.125},
	"HeroLocomotionStateIdleCombatPoseLF",
	"HeroLocomotionStateIdleCombatPoseRF",
	{"HeroLocomotionStateIdle", 0.25}
}

-- HeroLocomotionStateAimIdle --
HeroLocomotionStateAimIdle = {}
HeroLocomotionStateAimIdle.Anim = {
	"Pose"
}
HeroLocomotionStateAimIdle.BlendInTime = 0.2
HeroLocomotionStateAimIdle.BlendOutTime = 0.5
HeroLocomotionStateAimIdle.CombatState = ECombatState.COMBAT_STATE_NOT_SET
HeroLocomotionStateAimIdle.States = {
	"HeroLocomotionStateStrafeForward",
	"HeroLocomotionStateStrafeForwardLeft",
	"HeroLocomotionStateStrafeForwardRight",
	"HeroLocomotionStateStrafeLeftForwards",
	"HeroLocomotionStateStrafeRightForwards",
	"HeroLocomotionStateStrafeLeft",
	"HeroLocomotionStateStrafeRight",
	"HeroLocomotionStateStrafeRightBackwards",
	"HeroLocomotionStateStrafeLeftBackwards",
	"HeroLocomotionStateStrafeBackLeft",
	"HeroLocomotionStateStrafeBackRight",
	"HeroLocomotionStateStrafeBack",
	"HeroLocomotionStateAimIdle"
}

-- HeroLocomotionStateStrafeIdle --
HeroLocomotionStateStrafeIdle = {}
HeroLocomotionStateStrafeIdle.Anim = {
	"CombatPose"
}
HeroLocomotionStateStrafeIdle.AllowLooking = false
HeroLocomotionStateStrafeIdle.BlendInTime = 0.25
HeroLocomotionStateStrafeIdle.Stance = EStance.STANCE_REGULAR
HeroLocomotionStateStrafeIdle.CombatState = ECombatState.COMBAT_STATE_SET
HeroLocomotionStateStrafeIdle.VelocityArea = {
	CVector3(-HeroLocomotionData.MinVelMagForMovement, -180, 0),
	CVector3(10, 180, 0)
}
HeroLocomotionStateStrafeIdle.ControlArea = {
	CVector3(-HeroLocomotionData.MinControlMagForMovement, -180, 0),
	CVector3(0.05, 180, 0)
}
HeroLocomotionStateStrafeIdle.States = {
	"HeroLocomotionStateStrafeLeftTurn90ACW",
	"HeroLocomotionStateStrafeLeftTurn90CW",
	"HeroLocomotionStateStrafeForward",
	"HeroLocomotionStateStrafeForwardLeft",
	"HeroLocomotionStateStrafeForwardRight",
	"HeroLocomotionStateStrafeLeftForwards",
	"HeroLocomotionStateStrafeRightForwards",
	"HeroLocomotionStateStrafeLeft",
	"HeroLocomotionStateStrafeRight",
	"HeroLocomotionStateStrafeRightBackwards",
	"HeroLocomotionStateStrafeLeftBackwards",
	"HeroLocomotionStateStrafeBackLeft",
	"HeroLocomotionStateStrafeBackRight",
	"HeroLocomotionStateStrafeBack",
	"HeroLocomotionStateStrafeForwardRF",
	"HeroLocomotionStateStrafeLeftRF",
	"HeroLocomotionStateStrafeRightRF",
	"HeroLocomotionStateStrafeBackRF",
	"HeroLocomotionStateStrafeTransitionToRF",
	"HeroLocomotionStateStrafeIdleRF",
	"HeroLocomotionStateAimIdle",
	"HeroLocomotionStateStrafeIdle"
}

-- HeroLocomotionStateStrafeIdleRF --
HeroLocomotionStateStrafeIdleRF = {}
HeroLocomotionStateStrafeIdleRF.Anim = {
	-- "CombatPoseGoofy"
	"CombatStrafeIdleGoofy"
}
HeroLocomotionStateStrafeIdleRF.AllowLooking = false
HeroLocomotionStateStrafeIdleRF.BlendInTime = 0.25
HeroLocomotionStateStrafeIdleRF.Stance = EStance.STANCE_GOOFY
HeroLocomotionStateStrafeIdleRF.CombatState = ECombatState.COMBAT_STATE_SET
HeroLocomotionStateStrafeIdleRF.VelocityArea = {
	CVector3(-HeroLocomotionData.MinVelMagForMovement, -180, 0),
	CVector3(10, 180, 0)
}
HeroLocomotionStateStrafeIdleRF.ControlArea = {
	CVector3(-HeroLocomotionData.MinControlMagForMovement, -180, 0),
	CVector3(0.05, 180, 0)
}
HeroLocomotionStateStrafeIdleRF.States = {
	"HeroLocomotionStateStrafeRightTurn90ACW",
	"HeroLocomotionStateStrafeRightTurn90CW",
	"HeroLocomotionStateStrafeLeftRF",
	"HeroLocomotionStateStrafeRightRF",
	"HeroLocomotionStateStrafeBackRF",
	"HeroLocomotionStateStrafeForwardRF",
	"HeroLocomotionStateStrafeForward",
	"HeroLocomotionStateStrafeForwardLeft",
	"HeroLocomotionStateStrafeForwardRight",
	"HeroLocomotionStateStrafeLeftForwards",
	"HeroLocomotionStateStrafeRightForwards",
	"HeroLocomotionStateStrafeLeft",
	"HeroLocomotionStateStrafeRight",
	"HeroLocomotionStateStrafeRightBackwards",
	"HeroLocomotionStateStrafeLeftBackwards",
	"HeroLocomotionStateStrafeBackLeft",
	"HeroLocomotionStateStrafeBackRight",
	"HeroLocomotionStateStrafeBack",
	"HeroLocomotionStateStrafeTransitionToLF",
	"HeroLocomotionStateStrafeIdle",
	"HeroLocomotionStateStrafeIdleRF"
}

-- HeroLocomotionStateStrafeTransitionToRF --
HeroLocomotionStateStrafeTransitionToRF = {}
HeroLocomotionStateStrafeTransitionToRF.Anim = {
	"CombatPoseGoofy"
}
HeroLocomotionStateStrafeTransitionToRF.BlendInTime = 0.25
HeroLocomotionStateStrafeTransitionToRF.Stance = EStance.STANCE_GOOFY
HeroLocomotionStateStrafeTransitionToRF.CombatState = ECombatState.COMBAT_STATE_SET
HeroLocomotionStateStrafeTransitionToRF.VelocityArea = {
	CVector3(-HeroLocomotionData.MinVelMagForMovement, -180, 0),
	CVector3(1.5, 180, 0)
}
HeroLocomotionStateStrafeTransitionToRF.ControlArea = {
	CVector3(-HeroLocomotionData.MinControlMagForMovement, -180, 0),
	CVector3(1.05, 180, 0)
}
HeroLocomotionStateStrafeTransitionToRF.States = {
	"HeroLocomotionStateStrafeIdleRF",
	"HeroLocomotionStateStrafeForwardRF",
	"HeroLocomotionStateStrafeLeftRF",
	"HeroLocomotionStateStrafeRightRF",
	"HeroLocomotionStateStrafeBackRF",
	"HeroLocomotionStateStrafeForwardLeft",
	"HeroLocomotionStateStrafeForwardRight",
	"HeroLocomotionStateStrafeLeftForwards",
	"HeroLocomotionStateStrafeRightForwards",
	"HeroLocomotionStateStrafeForward",
	"HeroLocomotionStateStrafeLeft",
	"HeroLocomotionStateStrafeRight",
	"HeroLocomotionStateStrafeRightBackwards",
	"HeroLocomotionStateStrafeLeftBackwards",
	"HeroLocomotionStateStrafeBackLeft",
	"HeroLocomotionStateStrafeBackRight",
	"HeroLocomotionStateStrafeBack",
	"HeroLocomotionStateStrafeIdle"
}

-- HeroLocomotionStateStrafeTransitionToLF --
HeroLocomotionStateStrafeTransitionToLF = {}
HeroLocomotionStateStrafeTransitionToLF.Anim = {
	"CombatPose"
}
HeroLocomotionStateStrafeTransitionToLF.BlendInTime = 0.25
HeroLocomotionStateStrafeTransitionToLF.Stance = EStance.STANCE_REGULAR
HeroLocomotionStateStrafeTransitionToLF.CombatState = ECombatState.COMBAT_STATE_SET
HeroLocomotionStateStrafeTransitionToLF.VelocityArea = {
	CVector3(-HeroLocomotionData.MinVelMagForMovement, -180, 0),
	CVector3(1.5, 180, 0)
}
HeroLocomotionStateStrafeTransitionToLF.ControlArea = {
	CVector3(-HeroLocomotionData.MinControlMagForMovement, -180, 0),
	CVector3(1.05, 180, 0)
}
HeroLocomotionStateStrafeTransitionToLF.States = {
	"HeroLocomotionStateStrafeIdle",
	"HeroLocomotionStateStrafeForward",
	"HeroLocomotionStateStrafeForwardLeft",
	"HeroLocomotionStateStrafeForwardRight",
	"HeroLocomotionStateStrafeLeftForwards",
	"HeroLocomotionStateStrafeRightForwards",
	"HeroLocomotionStateStrafeLeft",
	"HeroLocomotionStateStrafeRight",
	"HeroLocomotionStateStrafeRightBackwards",
	"HeroLocomotionStateStrafeLeftBackwards",
	"HeroLocomotionStateStrafeBackLeft",
	"HeroLocomotionStateStrafeBackRight",
	"HeroLocomotionStateStrafeBack",
	"HeroLocomotionStateStrafeForwardRF",
	"HeroLocomotionStateStrafeLeftRF",
	"HeroLocomotionStateStrafeRightRF",
	"HeroLocomotionStateStrafeBackRF",
	"HeroLocomotionStateStrafeIdleRF"
}

-- HeroLocomotionStateStrafeForward --
HeroLocomotionStateStrafeForward = {}
HeroLocomotionStateStrafeForward.Anim = {
	"CombatStrafeForwardsSlow",
	"CombatStrafeForwards",
	"CombatStrafeForwardsLong"
}
HeroLocomotionStateStrafeForward.BlendInTime = 0.25
HeroLocomotionStateStrafeForward.AllowLooking = false
HeroLocomotionStateStrafeForward.CombatState = ECombatState.COMBAT_STATE_SET
HeroLocomotionStateStrafeForward.Stance = EStance.STANCE_REGULAR
HeroLocomotionStateStrafeForward.VelocityArea = {
	CVector3(HeroLocomotionData.MinVelMagForMovement, -180, 0),
	CVector3(10, 180, 0)
}
HeroLocomotionStateStrafeForward.ControlArea = {
	CVector3(HeroLocomotionData.MinControlMagForMovement, -12.5, 0),
	CVector3(1.05, 12.5, 0)
}
HeroLocomotionStateStrafeForward.States = {
	"HeroLocomotionStateStrafeForward",
	"HeroLocomotionStateStrafeForwardLeft",
	"HeroLocomotionStateStrafeForwardRight",
	"HeroLocomotionStateStrafeLeftForwards",
	"HeroLocomotionStateStrafeRightForwards",
	"HeroLocomotionStateStrafeLeft",
	"HeroLocomotionStateStrafeRight",
	"HeroLocomotionStateStrafeRightBackwards",
	"HeroLocomotionStateStrafeLeftBackwards",
	"HeroLocomotionStateStrafeBackLeft",
	"HeroLocomotionStateStrafeBackRight",
	"HeroLocomotionStateStrafeBack",
	"HeroLocomotionStateStrafeIdle",
	"HeroLocomotionStateStrafeLeftRF",
	"HeroLocomotionStateStrafeRightRF",
	"HeroLocomotionStateStrafeBackRF",
	"HeroLocomotionStateStrafeIdleRF"
}

-- HeroLocomotionStateStrafeForwardLeft --
HeroLocomotionStateStrafeForwardLeft = {}
HeroLocomotionStateStrafeForwardLeft.Anim = {
	"CombatStrafeForwardsLeft",
	"CombatStrafeForwardsLeftLong"
}
HeroLocomotionStateStrafeForwardLeft.BlendInTime = 0.25
HeroLocomotionStateStrafeForwardLeft.AllowLooking = false
HeroLocomotionStateStrafeForwardLeft.CombatState = ECombatState.COMBAT_STATE_SET
HeroLocomotionStateStrafeForwardLeft.Stance = EStance.STANCE_REGULAR
HeroLocomotionStateStrafeForwardLeft.VelocityArea = {
	CVector3(HeroLocomotionData.MinVelMagForMovement, -180, 0),
	CVector3(10, 180, 0)
}
HeroLocomotionStateStrafeForwardLeft.ControlArea = {
	CVector3(HeroLocomotionData.MinControlMagForMovement, -40, 0),
	CVector3(1.05, -12.5, 0)
}
HeroLocomotionStateStrafeForwardLeft.States = {
	"HeroLocomotionStateStrafeForwardLeft",
	"HeroLocomotionStateStrafeLeftCrossedToForward",
	"HeroLocomotionStateStrafeForwardRight",
	"HeroLocomotionStateStrafeLeftForwards",
	"HeroLocomotionStateStrafeRightForwards",
	"HeroLocomotionStateStrafeForward",
	"HeroLocomotionStateStrafeLeft",
	"HeroLocomotionStateStrafeRight",
	"HeroLocomotionStateStrafeLeftCrossedToBack",
	"HeroLocomotionStateStrafeRightBackwards",
	"HeroLocomotionStateStrafeLeftBackwards",
	"HeroLocomotionStateStrafeBackLeft",
	"HeroLocomotionStateStrafeBackRight",
	"HeroLocomotionStateStrafeBack",
	"HeroLocomotionStateStrafeIdle",
	"HeroLocomotionStateStrafeLeftRF",
	"HeroLocomotionStateStrafeRightRF",
	"HeroLocomotionStateStrafeBackRF",
	"HeroLocomotionStateStrafeIdleRF"
}

-- HeroLocomotionStateStrafeLeftForwards --
HeroLocomotionStateStrafeLeftForwards = {}
HeroLocomotionStateStrafeLeftForwards.Anim = {
	"CombatStrafeLeftForwardsLong"
}
HeroLocomotionStateStrafeLeftForwards.BlendInTime = 0.25
HeroLocomotionStateStrafeLeftForwards.AllowLooking = false
HeroLocomotionStateStrafeLeftForwards.CombatState = ECombatState.COMBAT_STATE_SET
HeroLocomotionStateStrafeLeftForwards.Stance = EStance.STANCE_REGULAR
HeroLocomotionStateStrafeLeftForwards.VelocityArea = {
	CVector3(HeroLocomotionData.MinVelMagForMovement, -180, 0),
	CVector3(10, 180, 0)
}
HeroLocomotionStateStrafeLeftForwards.ControlArea = {
	CVector3(HeroLocomotionData.MinControlMagForMovement, -77.5, 0),
	CVector3(1.05, -40, 0)
}
HeroLocomotionStateStrafeLeftForwards.States = {
	"HeroLocomotionStateStrafeLeftForwards",
	"HeroLocomotionStateStrafeLeftCrossedToForward",
	"HeroLocomotionStateStrafeRightForwards",
	"HeroLocomotionStateStrafeForwardLeft",
	"HeroLocomotionStateStrafeForwardRight",
	"HeroLocomotionStateStrafeForward",
	"HeroLocomotionStateStrafeLeft",
	"HeroLocomotionStateStrafeRight",
	"HeroLocomotionStateStrafeLeftCrossedToBack",
	"HeroLocomotionStateStrafeRightBackwards",
	"HeroLocomotionStateStrafeLeftBackwards",
	"HeroLocomotionStateStrafeBackLeft",
	"HeroLocomotionStateStrafeBackRight",
	"HeroLocomotionStateStrafeBack",
	"HeroLocomotionStateStrafeIdle",
	"HeroLocomotionStateStrafeLeftRF",
	"HeroLocomotionStateStrafeRightRF",
	"HeroLocomotionStateStrafeBackRF",
	"HeroLocomotionStateStrafeIdleRF"
}

-- HeroLocomotionStateStrafeLeft --
HeroLocomotionStateStrafeLeft = {}
HeroLocomotionStateStrafeLeft.Anim = {
	"CombatStrafeLeftSlow",
	"CombatStrafeLeft",
	"CombatStrafeLeftLong"
}
HeroLocomotionStateStrafeLeft.BlendInTime = 0.25
HeroLocomotionStateStrafeLeft.AllowLooking = false
HeroLocomotionStateStrafeLeft.CombatState = ECombatState.COMBAT_STATE_SET
HeroLocomotionStateStrafeLeft.Stance = EStance.STANCE_REGULAR
HeroLocomotionStateStrafeLeft.VelocityArea = {
	CVector3(HeroLocomotionData.MinVelMagForMovement, -180, 0),
	CVector3(10, 180, 0)
}
HeroLocomotionStateStrafeLeft.ControlArea = {
	CVector3(HeroLocomotionData.MinControlMagForMovement, -102.5, 0),
	CVector3(1.05, -77.5, 0)
}
HeroLocomotionStateStrafeLeft.States = {
	"HeroLocomotionStateStrafeLeft",
	"HeroLocomotionStateStrafeLeftCrossedToForward",
	"HeroLocomotionStateStrafeLeftForwards",
	"HeroLocomotionStateStrafeRightForwards",
	"HeroLocomotionStateStrafeForwardLeft",
	"HeroLocomotionStateStrafeForwardRight",
	"HeroLocomotionStateStrafeForward",
	"HeroLocomotionStateStrafeRight",
	"HeroLocomotionStateStrafeLeftCrossedToBack",
	"HeroLocomotionStateStrafeRightBackwards",
	"HeroLocomotionStateStrafeLeftBackwards",
	"HeroLocomotionStateStrafeBackLeft",
	"HeroLocomotionStateStrafeBackRight",
	"HeroLocomotionStateStrafeBack",
	"HeroLocomotionStateStrafeIdle",
	"HeroLocomotionStateStrafeForwardRF",
	"HeroLocomotionStateStrafeRightRF",
	"HeroLocomotionStateStrafeBackRF",
	"HeroLocomotionStateStrafeIdleRF"
}

-- HeroLocomotionStateStrafeLeftBackwards --
HeroLocomotionStateStrafeLeftBackwards = {}
HeroLocomotionStateStrafeLeftBackwards.Anim = {
	"CombatStrafeLeftBackwardsLong"
}
HeroLocomotionStateStrafeLeftBackwards.BlendInTime = 0.25
HeroLocomotionStateStrafeLeftBackwards.AllowLooking = false
HeroLocomotionStateStrafeLeftBackwards.CombatState = ECombatState.COMBAT_STATE_SET
HeroLocomotionStateStrafeLeftBackwards.Stance = EStance.STANCE_REGULAR
HeroLocomotionStateStrafeLeftBackwards.VelocityArea = {
	CVector3(HeroLocomotionData.MinVelMagForMovement, -180, 0),
	CVector3(10, 180, 0)
}
HeroLocomotionStateStrafeLeftBackwards.ControlArea = {
	CVector3(HeroLocomotionData.MinControlMagForMovement, -130, 0),
	CVector3(1.05, -102.5, 0)
}
HeroLocomotionStateStrafeLeftBackwards.States = {
	"HeroLocomotionStateStrafeLeftBackwards",
	"HeroLocomotionStateStrafeLeftCrossedToBack",
	"HeroLocomotionStateStrafeRightBackwards",
	"HeroLocomotionStateStrafeBackLeft",
	"HeroLocomotionStateStrafeBackRight",
	"HeroLocomotionStateStrafeBack",
	"HeroLocomotionStateStrafeLeftCrossedToForward",
	"HeroLocomotionStateStrafeForwardLeft",
	"HeroLocomotionStateStrafeForwardRight",
	"HeroLocomotionStateStrafeLeftForwards",
	"HeroLocomotionStateStrafeRightForwards",
	"HeroLocomotionStateStrafeForward",
	"HeroLocomotionStateStrafeLeft",
	"HeroLocomotionStateStrafeRight",
	"HeroLocomotionStateStrafeIdle",
	"HeroLocomotionStateStrafeForwardRF",
	"HeroLocomotionStateStrafeLeftRF",
	"HeroLocomotionStateStrafeRightRF",
	"HeroLocomotionStateStrafeIdleRF"
}

-- HeroLocomotionStateStrafeBackLeft --
HeroLocomotionStateStrafeBackLeft = {}
HeroLocomotionStateStrafeBackLeft.Anim = {
	"CombatStrafeBackwardsLeftLong"
}
HeroLocomotionStateStrafeBackLeft.BlendInTime = 0.25
HeroLocomotionStateStrafeBackLeft.AllowLooking = false
HeroLocomotionStateStrafeBackLeft.CombatState = ECombatState.COMBAT_STATE_SET
HeroLocomotionStateStrafeBackLeft.Stance = EStance.STANCE_REGULAR
HeroLocomotionStateStrafeBackLeft.VelocityArea = {
	CVector3(HeroLocomotionData.MinVelMagForMovement, -180, 0),
	CVector3(10, 180, 0)
}
HeroLocomotionStateStrafeBackLeft.ControlArea = {
	CVector3(HeroLocomotionData.MinControlMagForMovement, -167.5, 0),
	CVector3(1.05, -130, 0)
}
HeroLocomotionStateStrafeBackLeft.States = {
	"HeroLocomotionStateStrafeBackLeft",
	"HeroLocomotionStateStrafeLeftCrossedToBack",
	"HeroLocomotionStateStrafeBackRight",
	"HeroLocomotionStateStrafeRightBackwards",
	"HeroLocomotionStateStrafeLeftBackwards",
	"HeroLocomotionStateStrafeBack",
	"HeroLocomotionStateStrafeLeftCrossedToForward",
	"HeroLocomotionStateStrafeForwardLeft",
	"HeroLocomotionStateStrafeForwardRight",
	"HeroLocomotionStateStrafeLeftForwards",
	"HeroLocomotionStateStrafeRightForwards",
	"HeroLocomotionStateStrafeForward",
	"HeroLocomotionStateStrafeLeft",
	"HeroLocomotionStateStrafeRight",
	"HeroLocomotionStateStrafeIdle",
	"HeroLocomotionStateStrafeForwardRF",
	"HeroLocomotionStateStrafeLeftRF",
	"HeroLocomotionStateStrafeRightRF",
	"HeroLocomotionStateStrafeIdleRF"
}

-- HeroLocomotionStateStrafeForwardRight --
HeroLocomotionStateStrafeForwardRight = {}
HeroLocomotionStateStrafeForwardRight.Anim = {
	"CombatStrafeForwardsRight",
	"CombatStrafeForwardsRightLong"
}
HeroLocomotionStateStrafeForwardRight.BlendInTime = 0.25
HeroLocomotionStateStrafeForwardRight.AllowLooking = false
HeroLocomotionStateStrafeForwardRight.CombatState = ECombatState.COMBAT_STATE_SET
HeroLocomotionStateStrafeForwardRight.Stance = EStance.STANCE_REGULAR
HeroLocomotionStateStrafeForwardRight.VelocityArea = {
	CVector3(HeroLocomotionData.MinVelMagForMovement, -180, 0),
	CVector3(10, 180, 0)
}
HeroLocomotionStateStrafeForwardRight.ControlArea = {
	CVector3(HeroLocomotionData.MinControlMagForMovement, 12.25, 0),
	CVector3(1.05, 40, 0)
}
HeroLocomotionStateStrafeForwardRight.States = {
	"HeroLocomotionStateStrafeForwardRight",
	"HeroLocomotionStateStrafeRightCrossedToForwardRF",
	"HeroLocomotionStateStrafeForwardLeft",
	"HeroLocomotionStateStrafeLeftForwards",
	"HeroLocomotionStateStrafeRightForwards",
	"HeroLocomotionStateStrafeForward",
	"HeroLocomotionStateStrafeLeft",
	"HeroLocomotionStateStrafeRight",
	"HeroLocomotionStateStrafeRightCrossedToBackRF",
	"HeroLocomotionStateStrafeRightBackwards",
	"HeroLocomotionStateStrafeLeftBackwards",
	"HeroLocomotionStateStrafeBackLeft",
	"HeroLocomotionStateStrafeBackRight",
	"HeroLocomotionStateStrafeBack",
	"HeroLocomotionStateStrafeIdle",
	"HeroLocomotionStateStrafeLeftRF",
	"HeroLocomotionStateStrafeRightRF",
	"HeroLocomotionStateStrafeBackRF",
	"HeroLocomotionStateStrafeIdleRF"
}

-- HeroLocomotionStateStrafeRightForwards --
HeroLocomotionStateStrafeRightForwards = {}
HeroLocomotionStateStrafeRightForwards.Anim = {
	"CombatStrafeRightForwardsLong"
}
HeroLocomotionStateStrafeRightForwards.BlendInTime = 0.25
HeroLocomotionStateStrafeRightForwards.AllowLooking = false
HeroLocomotionStateStrafeRightForwards.CombatState = ECombatState.COMBAT_STATE_SET
HeroLocomotionStateStrafeRightForwards.Stance = EStance.STANCE_REGULAR
HeroLocomotionStateStrafeRightForwards.VelocityArea = {
	CVector3(HeroLocomotionData.MinVelMagForMovement, -180, 0),
	CVector3(10, 180, 0)
}
HeroLocomotionStateStrafeRightForwards.ControlArea = {
	CVector3(HeroLocomotionData.MinControlMagForMovement, 40, 0),
	CVector3(1.05, 77.5, 0)
}
HeroLocomotionStateStrafeRightForwards.States = {
	"HeroLocomotionStateStrafeRightForwards",
	"HeroLocomotionStateStrafeRightCrossedToForwardRF",
	"HeroLocomotionStateStrafeLeftForwards",
	"HeroLocomotionStateStrafeForwardRight",
	"HeroLocomotionStateStrafeForwardLeft",
	"HeroLocomotionStateStrafeForward",
	"HeroLocomotionStateStrafeLeft",
	"HeroLocomotionStateStrafeRight",
	"HeroLocomotionStateStrafeRightCrossedToBackRF",
	"HeroLocomotionStateStrafeRightBackwards",
	"HeroLocomotionStateStrafeLeftBackwards",
	"HeroLocomotionStateStrafeBackLeft",
	"HeroLocomotionStateStrafeBackRight",
	"HeroLocomotionStateStrafeBack",
	"HeroLocomotionStateStrafeIdle",
	"HeroLocomotionStateStrafeLeftRF",
	"HeroLocomotionStateStrafeRightRF",
	"HeroLocomotionStateStrafeBackRF",
	"HeroLocomotionStateStrafeIdleRF"
}

-- HeroLocomotionStateStrafeRight --
HeroLocomotionStateStrafeRight = {}
HeroLocomotionStateStrafeRight.Anim = {
	"CombatStrafeRightSlow",
	"CombatStrafeRight",
	"CombatStrafeRightLong"
}
HeroLocomotionStateStrafeRight.BlendInTime = 0.25
HeroLocomotionStateStrafeRight.AllowLooking = false
HeroLocomotionStateStrafeRight.CombatState = ECombatState.COMBAT_STATE_SET
HeroLocomotionStateStrafeRight.Stance = EStance.STANCE_REGULAR
HeroLocomotionStateStrafeRight.VelocityArea = {
	CVector3(HeroLocomotionData.MinVelMagForMovement, -180, 0),
	CVector3(10, 180, 0)
}
HeroLocomotionStateStrafeRight.ControlArea = {
	CVector3(HeroLocomotionData.MinControlMagForMovement, 77.5, 0),
	CVector3(1.05, 102.5, 0)
}
HeroLocomotionStateStrafeRight.States = {
	"HeroLocomotionStateStrafeRight",
	"HeroLocomotionStateStrafeRightCrossedToForwardRF",
	"HeroLocomotionStateStrafeForwardLeft",
	"HeroLocomotionStateStrafeForwardRight",
	"HeroLocomotionStateStrafeLeftForwards",
	"HeroLocomotionStateStrafeRightForwards",
	"HeroLocomotionStateStrafeForward",
	"HeroLocomotionStateStrafeLeft",
	"HeroLocomotionStateStrafeRightCrossedToBackRF",
	"HeroLocomotionStateStrafeRightBackwards",
	"HeroLocomotionStateStrafeLeftBackwards",
	"HeroLocomotionStateStrafeBackLeft",
	"HeroLocomotionStateStrafeBackRight",
	"HeroLocomotionStateStrafeBack",
	"HeroLocomotionStateStrafeIdle",
	"HeroLocomotionStateStrafeForwardRF",
	"HeroLocomotionStateStrafeLeftRF",
	"HeroLocomotionStateStrafeBackRF",
	"HeroLocomotionStateStrafeIdleRF"
}

-- HeroLocomotionStateStrafeRightBackwards --
HeroLocomotionStateStrafeRightBackwards = {}
HeroLocomotionStateStrafeRightBackwards.Anim = {
	"CombatStrafeRightBackwardsLong"
}
HeroLocomotionStateStrafeRightBackwards.BlendInTime = 0.25
HeroLocomotionStateStrafeRightBackwards.AllowLooking = false
HeroLocomotionStateStrafeRightBackwards.CombatState = ECombatState.COMBAT_STATE_SET
HeroLocomotionStateStrafeRightBackwards.Stance = EStance.STANCE_REGULAR
HeroLocomotionStateStrafeRightBackwards.VelocityArea = {
	CVector3(HeroLocomotionData.MinVelMagForMovement, -180, 0),
	CVector3(10, 180, 0)
}
HeroLocomotionStateStrafeRightBackwards.ControlArea = {
	CVector3(HeroLocomotionData.MinControlMagForMovement, 102.5, 0),
	CVector3(1.05, 130, 0)
}
HeroLocomotionStateStrafeRightBackwards.States = {
	"HeroLocomotionStateStrafeRightBackwards",
	"HeroLocomotionStateStrafeRightCrossedToBackRF",
	"HeroLocomotionStateStrafeLeftBackwards",
	"HeroLocomotionStateStrafeBackRight",
	"HeroLocomotionStateStrafeBackLeft",
	"HeroLocomotionStateStrafeBack",
	"HeroLocomotionStateStrafeRightCrossedToForwardRF",
	"HeroLocomotionStateStrafeForwardLeft",
	"HeroLocomotionStateStrafeForwardRight",
	"HeroLocomotionStateStrafeLeftForwards",
	"HeroLocomotionStateStrafeRightForwards",
	"HeroLocomotionStateStrafeForward",
	"HeroLocomotionStateStrafeLeft",
	"HeroLocomotionStateStrafeRight",
	"HeroLocomotionStateStrafeIdle",
	"HeroLocomotionStateStrafeForwardRF",
	"HeroLocomotionStateStrafeLeftRF",
	"HeroLocomotionStateStrafeRightRF",
	"HeroLocomotionStateStrafeIdleRF"
}

-- HeroLocomotionStateStrafeBackRight --
HeroLocomotionStateStrafeBackRight = {}
HeroLocomotionStateStrafeBackRight.Anim = {
	"CombatStrafeBackwardsRightLong"
}
HeroLocomotionStateStrafeBackRight.BlendInTime = 0.25
HeroLocomotionStateStrafeBackRight.AllowLooking = false
HeroLocomotionStateStrafeBackRight.CombatState = ECombatState.COMBAT_STATE_SET
HeroLocomotionStateStrafeBackRight.Stance = EStance.STANCE_REGULAR
HeroLocomotionStateStrafeBackRight.VelocityArea = {
	CVector3(HeroLocomotionData.MinVelMagForMovement, -180, 0),
	CVector3(10, 180, 0)
}
HeroLocomotionStateStrafeBackRight.ControlArea = {
	CVector3(HeroLocomotionData.MinControlMagForMovement, 130, 0),
	CVector3(1.05, 167.5, 0)
}
HeroLocomotionStateStrafeBackRight.States = {
	"HeroLocomotionStateStrafeBackRight",
	"HeroLocomotionStateStrafeRightCrossedToBackRF",
	"HeroLocomotionStateStrafeBackLeft",
	"HeroLocomotionStateStrafeRightBackwards",
	"HeroLocomotionStateStrafeLeftBackwards",
	"HeroLocomotionStateStrafeBack",
	"HeroLocomotionStateStrafeRightCrossedToForwardRF",
	"HeroLocomotionStateStrafeForwardLeft",
	"HeroLocomotionStateStrafeForwardRight",
	"HeroLocomotionStateStrafeLeftForwards",
	"HeroLocomotionStateStrafeRightForwards",
	"HeroLocomotionStateStrafeForward",
	"HeroLocomotionStateStrafeLeft",
	"HeroLocomotionStateStrafeRight",
	"HeroLocomotionStateStrafeIdle",
	"HeroLocomotionStateStrafeForwardRF",
	"HeroLocomotionStateStrafeLeftRF",
	"HeroLocomotionStateStrafeRightRF",
	"HeroLocomotionStateStrafeIdleRF"
}

-- HeroLocomotionStateStrafeBack --
HeroLocomotionStateStrafeBack = {}
HeroLocomotionStateStrafeBack.Anim = {
	"CombatStrafeBackwardsSlow",
	"CombatStrafeBackwards",
	"CombatStrafeBackwardsLong"
}
HeroLocomotionStateStrafeBack.BlendInTime = 0.25
HeroLocomotionStateStrafeBack.AllowLooking = false
HeroLocomotionStateStrafeBack.CombatState = ECombatState.COMBAT_STATE_SET
HeroLocomotionStateStrafeBack.Stance = EStance.STANCE_REGULAR
HeroLocomotionStateStrafeBack.VelocityArea = {
	CVector3(HeroLocomotionData.MinVelMagForMovement, -180, 0),
	CVector3(10, 180, 0)
}
HeroLocomotionStateStrafeBack.ControlArea = {
	CVector3(HeroLocomotionData.MinControlMagForMovement, 167.5, 0),
	CVector3(1.05, 192.5, 0)
}
HeroLocomotionStateStrafeBack.States = {
	"HeroLocomotionStateStrafeBack",
	"HeroLocomotionStateStrafeForwardLeft",
	"HeroLocomotionStateStrafeForwardRight",
	"HeroLocomotionStateStrafeLeftForwards",
	"HeroLocomotionStateStrafeRightForwards",
	"HeroLocomotionStateStrafeForward",
	"HeroLocomotionStateStrafeLeftBackwards",
	"HeroLocomotionStateStrafeRightBackwards",
	"HeroLocomotionStateStrafeBackLeft",
	"HeroLocomotionStateStrafeBackRight",
	"HeroLocomotionStateStrafeLeft",
	"HeroLocomotionStateStrafeRight",
	"HeroLocomotionStateStrafeIdle",
	"HeroLocomotionStateStrafeForwardRF",
	"HeroLocomotionStateStrafeLeftRF",
	"HeroLocomotionStateStrafeRightRF",
	"HeroLocomotionStateStrafeIdleRF"
}

-- HeroLocomotionStateStrafeForwardRF --
HeroLocomotionStateStrafeForwardRF = {}
HeroLocomotionStateStrafeForwardRF.Anim = {
	"CombatStrafeForwardsGoofySlow",
	"CombatStrafeForwardsGoofy"
}
HeroLocomotionStateStrafeForwardRF.BlendInTime = 0.25
HeroLocomotionStateStrafeForwardRF.AllowLooking = false
HeroLocomotionStateStrafeForwardRF.CombatState = ECombatState.COMBAT_STATE_SET
HeroLocomotionStateStrafeForwardRF.Stance = EStance.STANCE_GOOFY
HeroLocomotionStateStrafeForwardRF.VelocityArea = {
	CVector3(HeroLocomotionData.MinVelMagForMovement, -180, 0),
	CVector3(10, 180, 0)
}
HeroLocomotionStateStrafeForwardRF.ControlArea = {
	CVector3(HeroLocomotionData.MinControlMagForMovement, -45, 0),
	CVector3(1.05, 45, 0)
}
HeroLocomotionStateStrafeForwardRF.States = {
	"HeroLocomotionStateStrafeForwardRF",
	"HeroLocomotionStateStrafeLeftRF",
	"HeroLocomotionStateStrafeRightRF",
	"HeroLocomotionStateStrafeBackRF",
	"HeroLocomotionStateStrafeIdleRF",
	"HeroLocomotionStateStrafeLeft",
	"HeroLocomotionStateStrafeRight",
	"HeroLocomotionStateStrafeBackLeft",
	"HeroLocomotionStateStrafeBackRight",
	"HeroLocomotionStateStrafeLeftBackwards",
	"HeroLocomotionStateStrafeRightBackwards",
	"HeroLocomotionStateStrafeBack",
	"HeroLocomotionStateStrafeIdle"
}

-- HeroLocomotionStateStrafeLeftRF --
HeroLocomotionStateStrafeLeftRF = {}
HeroLocomotionStateStrafeLeftRF.Anim = {
	"CombatStrafeLeftGoofySlow",
	"CombatStrafeLeftGoofy"
}
HeroLocomotionStateStrafeLeftRF.BlendInTime = 0.25
HeroLocomotionStateStrafeLeftRF.AllowLooking = false
HeroLocomotionStateStrafeLeftRF.CombatState = ECombatState.COMBAT_STATE_SET
HeroLocomotionStateStrafeLeftRF.Stance = EStance.STANCE_GOOFY
HeroLocomotionStateStrafeLeftRF.VelocityArea = {
	CVector3(HeroLocomotionData.MinVelMagForMovement, -180, 0),
	CVector3(10, 180, 0)
}
HeroLocomotionStateStrafeLeftRF.ControlArea = {
	CVector3(HeroLocomotionData.MinControlMagForMovement, -135, 0),
	CVector3(1.05, -45, 0)
}
HeroLocomotionStateStrafeLeftRF.States = {
	"HeroLocomotionStateStrafeLeftRF",
	"HeroLocomotionStateStrafeLeftCrossedToForward",
	"HeroLocomotionStateStrafeForwardRF",
	"HeroLocomotionStateStrafeRightRF",
	"HeroLocomotionStateStrafeLeftCrossedToBack",
	"HeroLocomotionStateStrafeBackRF",
	"HeroLocomotionStateStrafeIdleRF",
	"HeroLocomotionStateStrafeForward",
	"HeroLocomotionStateStrafeForwardRight",
	"HeroLocomotionStateStrafeRightForwards",
	"HeroLocomotionStateStrafeRight",
	"HeroLocomotionStateStrafeRightBackwards",
	"HeroLocomotionStateStrafeBackRight",
	"HeroLocomotionStateStrafeBack",
	"HeroLocomotionStateStrafeIdle"
}

-- HeroLocomotionStateStrafeRightRF --
HeroLocomotionStateStrafeRightRF = {}
HeroLocomotionStateStrafeRightRF.Anim = {
	"CombatStrafeRightGoofySlow",
	"CombatStrafeRightGoofy"
}
HeroLocomotionStateStrafeRightRF.BlendInTime = 0.25
HeroLocomotionStateStrafeRightRF.AllowLooking = false
HeroLocomotionStateStrafeRightRF.CombatState = ECombatState.COMBAT_STATE_SET
HeroLocomotionStateStrafeRightRF.Stance = EStance.STANCE_GOOFY
HeroLocomotionStateStrafeRightRF.VelocityArea = {
	CVector3(HeroLocomotionData.MinVelMagForMovement, -180, 0),
	CVector3(10, 180, 0)
}
HeroLocomotionStateStrafeRightRF.ControlArea = {
	CVector3(HeroLocomotionData.MinControlMagForMovement, 45, 0),
	CVector3(1.05, 135, 0)
}
HeroLocomotionStateStrafeRightRF.States = {
	"HeroLocomotionStateStrafeRightRF",
	"HeroLocomotionStateStrafeRightCrossedToForwardRF",
	"HeroLocomotionStateStrafeForwardRF",
	"HeroLocomotionStateStrafeLeftRF",
	"HeroLocomotionStateStrafeRightCrossedToBackRF",
	"HeroLocomotionStateStrafeBackRF",
	"HeroLocomotionStateStrafeIdleRF",
	"HeroLocomotionStateStrafeForward",
	"HeroLocomotionStateStrafeForwardLeft",
	"HeroLocomotionStateStrafeLeftForwards",
	"HeroLocomotionStateStrafeLeft",
	"HeroLocomotionStateStrafeLeftBackwards",
	"HeroLocomotionStateStrafeBackLeft",
	"HeroLocomotionStateStrafeBack",
	"HeroLocomotionStateStrafeIdle"
}

-- HeroLocomotionStateStrafeBackRF --
HeroLocomotionStateStrafeBackRF = {}
HeroLocomotionStateStrafeBackRF.Anim = {
	"CombatStrafeBackwardsGoofySlow",
	"CombatStrafeBackwardsGoofy"
}
HeroLocomotionStateStrafeBackRF.BlendInTime = 0.25
HeroLocomotionStateStrafeBackRF.AllowLooking = false
HeroLocomotionStateStrafeBackRF.CombatState = ECombatState.COMBAT_STATE_SET
HeroLocomotionStateStrafeBackRF.Stance = EStance.STANCE_GOOFY
HeroLocomotionStateStrafeBackRF.VelocityArea = {
	CVector3(HeroLocomotionData.MinVelMagForMovement, -180, 0),
	CVector3(10, 180, 0)
}
HeroLocomotionStateStrafeBackRF.ControlArea = {
	CVector3(HeroLocomotionData.MinControlMagForMovement, 135, 0),
	CVector3(1.05, 225, 0)
}
HeroLocomotionStateStrafeBackRF.States = {
	"HeroLocomotionStateStrafeBackRF",
	"HeroLocomotionStateStrafeForwardRF",
	"HeroLocomotionStateStrafeLeftRF",
	"HeroLocomotionStateStrafeRightRF",
	"HeroLocomotionStateStrafeIdleRF",
	"HeroLocomotionStateStrafeForwardLeft",
	"HeroLocomotionStateStrafeForwardRight",
	"HeroLocomotionStateStrafeLeftForwards",
	"HeroLocomotionStateStrafeRightForwards",
	"HeroLocomotionStateStrafeForward",
	"HeroLocomotionStateStrafeLeft",
	"HeroLocomotionStateStrafeRight",
	"HeroLocomotionStateStrafeIdle"
}

-- HeroLocomotionStateStrafeLeftCrossedToForward --
HeroLocomotionStateStrafeLeftCrossedToForward = {}
HeroLocomotionStateStrafeLeftCrossedToForward.Anim = {
	"CombatStrafeLeftCrossedIntoStrafeForwardsRF"
}
HeroLocomotionStateStrafeLeftCrossedToForward.BlendInTime = 0.25 -- 0.1
HeroLocomotionStateStrafeLeftCrossedToForward.BlendOutTime = 0.5
HeroLocomotionStateStrafeLeftCrossedToForward.TransitionType = ETransitionType.TRANSITION_MATCH_FOOTING
HeroLocomotionStateStrafeLeftCrossedToForward.FeetMatchPoseTolerance = 0.1
HeroLocomotionStateStrafeLeftCrossedToForward.FootMatchType = EFootMatchType.FOOT_MATCH_RELATIVE
HeroLocomotionStateStrafeLeftCrossedToForward.CombatState = ECombatState.COMBAT_STATE_SET
HeroLocomotionStateStrafeLeftCrossedToForward.VelocityArea = {
	CVector3(-HeroLocomotionData.MinVelMagForMovement, -180, 0),
	CVector3(10, 180, 0)
}
HeroLocomotionStateStrafeLeftCrossedToForward.ControlArea = {
	CVector3(HeroLocomotionData.MinControlMagForMovement, -45, 0),
	CVector3(1.05, 45, 0)
}
HeroLocomotionStateStrafeLeftCrossedToForward.States = {
	"HeroLocomotionStateStrafeLeftCrossedToForward",
	"HeroLocomotionStateStrafeForward",
	"HeroLocomotionStateStrafeForwardLeft",
	"HeroLocomotionStateStrafeForwardRight",
	"HeroLocomotionStateStrafeLeftForwards",
	"HeroLocomotionStateStrafeRightForwards",
	"HeroLocomotionStateStrafeLeft",
	"HeroLocomotionStateStrafeRight",
	"HeroLocomotionStateStrafeLeftBackwards",
	"HeroLocomotionStateStrafeRightBackwards",
	"HeroLocomotionStateStrafeBackLeft",
	"HeroLocomotionStateStrafeBackRight",
	"HeroLocomotionStateStrafeBack",
	"HeroLocomotionStateStrafeIdle",
	"HeroLocomotionStateStrafeForwardRF",
	"HeroLocomotionStateStrafeLeftRF",
	"HeroLocomotionStateStrafeRightRF",
	"HeroLocomotionStateStrafeBackRF",
	"HeroLocomotionStateStrafeIdleRF"
}

-- HeroLocomotionStateStrafeLeftCrossedToBack --
HeroLocomotionStateStrafeLeftCrossedToBack = {}
HeroLocomotionStateStrafeLeftCrossedToBack.Anim = {
	"CombatStrafeLeftCrossedIntoStrafeBackwardsRF"
}
HeroLocomotionStateStrafeLeftCrossedToBack.BlendInTime = 0.25 -- 0.1
HeroLocomotionStateStrafeLeftCrossedToBack.BlendOutTime = 0.5
HeroLocomotionStateStrafeLeftCrossedToBack.TransitionType = ETransitionType.TRANSITION_MATCH_FOOTING
HeroLocomotionStateStrafeLeftCrossedToBack.FeetMatchPoseTolerance = 0.1
HeroLocomotionStateStrafeLeftCrossedToBack.FootMatchType = EFootMatchType.FOOT_MATCH_RELATIVE
HeroLocomotionStateStrafeLeftCrossedToBack.CombatState = ECombatState.COMBAT_STATE_SET
-- HeroLocomotionStateStrafeLeftCrossedToBack.Symmetrical = true
HeroLocomotionStateStrafeLeftCrossedToBack.VelocityArea = {
	CVector3(-HeroLocomotionData.MinVelMagForMovement, -180, 0),
	CVector3(10, 180, 0)
}
HeroLocomotionStateStrafeLeftCrossedToBack.ControlArea = {
	CVector3(HeroLocomotionData.MinControlMagForMovement, 135, 0),
	CVector3(1.05, 180, 0)
}
HeroLocomotionStateStrafeLeftCrossedToBack.States = {
	"HeroLocomotionStateStrafeLeftCrossedToBack",
	"HeroLocomotionStateStrafeForward",
	"HeroLocomotionStateStrafeForwardLeft",
	"HeroLocomotionStateStrafeForwardRight",
	"HeroLocomotionStateStrafeLeftForwards",
	"HeroLocomotionStateStrafeRightForwards",
	"HeroLocomotionStateStrafeLeft",
	"HeroLocomotionStateStrafeRight",
	"HeroLocomotionStateStrafeLeftBackwards",
	"HeroLocomotionStateStrafeRightBackwards",
	"HeroLocomotionStateStrafeBackLeft",
	"HeroLocomotionStateStrafeBackRight",
	"HeroLocomotionStateStrafeBack",
	"HeroLocomotionStateStrafeIdle",
	"HeroLocomotionStateStrafeForwardRF",
	"HeroLocomotionStateStrafeLeftRF",
	"HeroLocomotionStateStrafeRightRF",
	"HeroLocomotionStateStrafeBackRF",
	"HeroLocomotionStateStrafeIdleRF"
}

-- HeroLocomotionStateStrafeRightCrossedToForwardRF --
HeroLocomotionStateStrafeRightCrossedToForwardRF = {}
HeroLocomotionStateStrafeRightCrossedToForwardRF.Anim = {
	"CombatStrafeRightCrossedIntoStrafeForwardsRF"
}
HeroLocomotionStateStrafeRightCrossedToForwardRF.BlendInTime = 0.25 -- 0.1
HeroLocomotionStateStrafeRightCrossedToForwardRF.BlendOutTime = 0.5
HeroLocomotionStateStrafeRightCrossedToForwardRF.TransitionType = ETransitionType.TRANSITION_MATCH_FOOTING
HeroLocomotionStateStrafeRightCrossedToForwardRF.FeetMatchPoseTolerance = 0.1
HeroLocomotionStateStrafeRightCrossedToForwardRF.FootMatchType = EFootMatchType.FOOT_MATCH_RELATIVE
HeroLocomotionStateStrafeRightCrossedToForwardRF.CombatState = ECombatState.COMBAT_STATE_SET
HeroLocomotionStateStrafeRightCrossedToForwardRF.Stance = EStance.STANCE_GOOFY
HeroLocomotionStateStrafeRightCrossedToForwardRF.VelocityArea = {
	CVector3(-HeroLocomotionData.MinVelMagForMovement, -180, 0),
	CVector3(10, 180, 0)
}
HeroLocomotionStateStrafeRightCrossedToForwardRF.ControlArea = {
	CVector3(HeroLocomotionData.MinControlMagForMovement, -45, 0),
	CVector3(1.05, 45, 0)
}
HeroLocomotionStateStrafeRightCrossedToForwardRF.States = {
	"HeroLocomotionStateStrafeRightCrossedToForwardRF",
	"HeroLocomotionStateStrafeForwardRF",
	"HeroLocomotionStateStrafeLeftRF",
	"HeroLocomotionStateStrafeRightRF",
	"HeroLocomotionStateStrafeBackRF",
	"HeroLocomotionStateStrafeIdleRF",
	"HeroLocomotionStateStrafeForward",
	"HeroLocomotionStateStrafeForwardLeft",
	"HeroLocomotionStateStrafeForwardRight",
	"HeroLocomotionStateStrafeLeftForwards",
	"HeroLocomotionStateStrafeRightForwards",
	"HeroLocomotionStateStrafeLeft",
	"HeroLocomotionStateStrafeRight",
	"HeroLocomotionStateStrafeLeftBackwards",
	"HeroLocomotionStateStrafeRightBackwards",
	"HeroLocomotionStateStrafeBackLeft",
	"HeroLocomotionStateStrafeBackRight",
	"HeroLocomotionStateStrafeBack",
	"HeroLocomotionStateStrafeIdle"
}

-- HeroLocomotionStateStrafeRightCrossedToBackRF --
HeroLocomotionStateStrafeRightCrossedToBackRF = {}
HeroLocomotionStateStrafeRightCrossedToBackRF.Anim = {
	"CombatStrafeRightCrossedIntoStrafeBackwardsRF"
}
HeroLocomotionStateStrafeRightCrossedToBackRF.BlendInTime = 0.25 -- 0.1
HeroLocomotionStateStrafeRightCrossedToBackRF.BlendOutTime = 0.5
HeroLocomotionStateStrafeRightCrossedToBackRF.TransitionType = ETransitionType.TRANSITION_MATCH_FOOTING
HeroLocomotionStateStrafeRightCrossedToBackRF.FeetMatchPoseTolerance = 0.1
HeroLocomotionStateStrafeRightCrossedToBackRF.FootMatchType = EFootMatchType.FOOT_MATCH_RELATIVE
HeroLocomotionStateStrafeRightCrossedToBackRF.CombatState = ECombatState.COMBAT_STATE_SET
HeroLocomotionStateStrafeRightCrossedToBackRF.Stance = EStance.STANCE_GOOFY
HeroLocomotionStateStrafeRightCrossedToBackRF.VelocityArea = {
	CVector3(-HeroLocomotionData.MinVelMagForMovement, -180, 0),
	CVector3(10, 180, 0)
}
HeroLocomotionStateStrafeRightCrossedToBackRF.ControlArea = {
	CVector3(HeroLocomotionData.MinControlMagForMovement, 135, 0),
	CVector3(1.05, 180, 0)
}
HeroLocomotionStateStrafeRightCrossedToBackRF.States = {
	"HeroLocomotionStateStrafeRightCrossedToBackRF",
	"HeroLocomotionStateStrafeForwardRF",
	"HeroLocomotionStateStrafeLeftRF",
	"HeroLocomotionStateStrafeRightRF",
	"HeroLocomotionStateStrafeBackRF",
	"HeroLocomotionStateStrafeIdleRF",
	"HeroLocomotionStateStrafeForward",
	"HeroLocomotionStateStrafeForwardLeft",
	"HeroLocomotionStateStrafeForwardRight",
	"HeroLocomotionStateStrafeLeftForwards",
	"HeroLocomotionStateStrafeRightForwards",
	"HeroLocomotionStateStrafeLeft",
	"HeroLocomotionStateStrafeRight",
	"HeroLocomotionStateStrafeLeftBackwards",
	"HeroLocomotionStateStrafeRightBackwards",
	"HeroLocomotionStateStrafeBackLeft",
	"HeroLocomotionStateStrafeBackRight",
	"HeroLocomotionStateStrafeBack",
	"HeroLocomotionStateStrafeIdle"
}

-- HeroLocomotionStateStrafeLeftTurn90ACW --
HeroLocomotionStateStrafeLeftTurn90ACW = {}
HeroLocomotionStateStrafeLeftTurn90ACW.Anim = {
	"CombatStrafeLeftTurn90ACW"
}
HeroLocomotionStateStrafeLeftTurn90ACW.BlendInTime = 0.15
HeroLocomotionStateStrafeLeftTurn90ACW.BlendOutTime = 0.25
HeroLocomotionStateStrafeLeftTurn90ACW.TransitionType = ETransitionType.TRANSITION_MATCH_FOOTING
HeroLocomotionStateStrafeLeftTurn90ACW.FootMatchType = EFootMatchType.FOOT_MATCH_RELATIVE
HeroLocomotionStateStrafeLeftTurn90ACW.CombatState = ECombatState.COMBAT_STATE_SET
HeroLocomotionStateStrafeLeftTurn90ACW.TargetFacingAngles = CVector3(-135, -45, 0)
HeroLocomotionStateStrafeLeftTurn90ACW.TerminationTargetFacingAngles = CVector3(-135, -2, 0)
HeroLocomotionStateStrafeLeftTurn90ACW.TerminationVelocityArea = {
	CVector3(-HeroLocomotionData.MinVelMagForMovement, -181, 0),
	CVector3(0.15, 181, 0)
}
HeroLocomotionStateStrafeLeftTurn90ACW.States = {
	"HeroLocomotionStateStrafeLeftTurn90CW",
	"HeroLocomotionStateStrafeLeftTurn90ACW",
	"HeroLocomotionStateStrafeForward",
	"HeroLocomotionStateStrafeForwardLeft",
	"HeroLocomotionStateStrafeForwardRight",
	"HeroLocomotionStateStrafeLeftForwards",
	"HeroLocomotionStateStrafeRightForwards",
	"HeroLocomotionStateStrafeLeft",
	"HeroLocomotionStateStrafeRight",
	"HeroLocomotionStateStrafeLeftBackwards",
	"HeroLocomotionStateStrafeRightBackwards",
	"HeroLocomotionStateStrafeBackLeft",
	"HeroLocomotionStateStrafeBackRight",
	"HeroLocomotionStateStrafeBack",
	"HeroLocomotionStateStrafeIdle",
	"HeroLocomotionStateStrafeForwardRF",
	"HeroLocomotionStateStrafeLeftRF",
	"HeroLocomotionStateStrafeRightRF",
	"HeroLocomotionStateStrafeBackRF",
	"HeroLocomotionStateStrafeIdleRF"
}

-- HeroLocomotionStateStrafeLeftTurn90CW --
HeroLocomotionStateStrafeLeftTurn90CW = {}
HeroLocomotionStateStrafeLeftTurn90CW.Anim = {
	"CombatStrafeLeftTurn90CW"
}
HeroLocomotionStateStrafeLeftTurn90CW.BlendInTime = 0.15
HeroLocomotionStateStrafeLeftTurn90CW.BlendOutTime = 0.25
HeroLocomotionStateStrafeLeftTurn90CW.TransitionType = ETransitionType.TRANSITION_MATCH_FOOTING
HeroLocomotionStateStrafeLeftTurn90CW.FootMatchType = EFootMatchType.FOOT_MATCH_RELATIVE
HeroLocomotionStateStrafeLeftTurn90CW.CombatState = ECombatState.COMBAT_STATE_SET
HeroLocomotionStateStrafeLeftTurn90CW.TargetFacingAngles = CVector3(45, 135, 0)
HeroLocomotionStateStrafeLeftTurn90CW.TerminationTargetFacingAngles = CVector3(2, 135, 0)
HeroLocomotionStateStrafeLeftTurn90CW.TerminationVelocityArea = {
	CVector3(-HeroLocomotionData.MinVelMagForMovement, -181, 0),
	CVector3(0.15, 181, 0)
}
HeroLocomotionStateStrafeLeftTurn90CW.States = {
	"HeroLocomotionStateStrafeLeftTurn90ACW",
	"HeroLocomotionStateStrafeLeftTurn90CW",
	"HeroLocomotionStateStrafeForward",
	"HeroLocomotionStateStrafeForwardLeft",
	"HeroLocomotionStateStrafeForwardRight",
	"HeroLocomotionStateStrafeLeftForwards",
	"HeroLocomotionStateStrafeRightForwards",
	"HeroLocomotionStateStrafeLeft",
	"HeroLocomotionStateStrafeRight",
	"HeroLocomotionStateStrafeBack",
	"HeroLocomotionStateStrafeLeftBackwards",
	"HeroLocomotionStateStrafeRightBackwards",
	"HeroLocomotionStateStrafeBackLeft",
	"HeroLocomotionStateStrafeBackRight",
	"HeroLocomotionStateStrafeIdle",
	"HeroLocomotionStateStrafeForwardRF",
	"HeroLocomotionStateStrafeLeftRF",
	"HeroLocomotionStateStrafeRightRF",
	"HeroLocomotionStateStrafeBackRF",
	"HeroLocomotionStateStrafeIdleRF"
}

-- HeroLocomotionStateStrafeRightTurn90ACW --
HeroLocomotionStateStrafeRightTurn90ACW = {}
HeroLocomotionStateStrafeRightTurn90ACW.Anim = {
	"CombatStrafeRightTurn90ACW"
}
HeroLocomotionStateStrafeRightTurn90ACW.BlendInTime = 0.15
HeroLocomotionStateStrafeRightTurn90ACW.BlendOutTime = 0.25
HeroLocomotionStateStrafeRightTurn90ACW.TransitionType = ETransitionType.TRANSITION_MATCH_FOOTING
HeroLocomotionStateStrafeRightTurn90ACW.FootMatchType = EFootMatchType.FOOT_MATCH_RELATIVE
HeroLocomotionStateStrafeRightTurn90ACW.CombatState = ECombatState.COMBAT_STATE_SET
HeroLocomotionStateStrafeRightTurn90ACW.Stance = EStance.STANCE_GOOFY
HeroLocomotionStateStrafeRightTurn90ACW.TargetFacingAngles = CVector3(-135, -45, 0)
HeroLocomotionStateStrafeRightTurn90ACW.TerminationTargetFacingAngles = CVector3(-135, -2, 0)
HeroLocomotionStateStrafeRightTurn90ACW.TerminationVelocityArea = {
	CVector3(-HeroLocomotionData.MinVelMagForMovement, -181, 0),
	CVector3(0.15, 181, 0)
}
HeroLocomotionStateStrafeRightTurn90ACW.States = {
	"HeroLocomotionStateStrafeRightTurn90CW",
	"HeroLocomotionStateStrafeRightTurn90ACW",
	"HeroLocomotionStateStrafeForwardRF",
	"HeroLocomotionStateStrafeLeftRF",
	"HeroLocomotionStateStrafeRightRF",
	"HeroLocomotionStateStrafeBackRF",
	"HeroLocomotionStateStrafeIdleRF",
	"HeroLocomotionStateStrafeForward",
	"HeroLocomotionStateStrafeForwardLeft",
	"HeroLocomotionStateStrafeForwardRight",
	"HeroLocomotionStateStrafeLeftForwards",
	"HeroLocomotionStateStrafeRightForwards",
	"HeroLocomotionStateStrafeLeft",
	"HeroLocomotionStateStrafeRight",
	"HeroLocomotionStateStrafeLeftBackwards",
	"HeroLocomotionStateStrafeRightBackwards",
	"HeroLocomotionStateStrafeBackLeft",
	"HeroLocomotionStateStrafeBackRight",
	"HeroLocomotionStateStrafeBack",
	"HeroLocomotionStateStrafeIdle"
}

-- HeroLocomotionStateStrafeRightTurn90CW --
HeroLocomotionStateStrafeRightTurn90CW = {}
HeroLocomotionStateStrafeRightTurn90CW.Anim = {
	"CombatStrafeRightTurn90CW"
}
HeroLocomotionStateStrafeRightTurn90CW.BlendInTime = 0.15
HeroLocomotionStateStrafeRightTurn90CW.BlendOutTime = 0.25
HeroLocomotionStateStrafeRightTurn90CW.TransitionType = ETransitionType.TRANSITION_MATCH_FOOTING
HeroLocomotionStateStrafeRightTurn90CW.FeetMatchPoseTolerance = 0.1
HeroLocomotionStateStrafeRightTurn90CW.FootMatchType = EFootMatchType.FOOT_MATCH_RELATIVE
HeroLocomotionStateStrafeRightTurn90CW.CombatState = ECombatState.COMBAT_STATE_SET
HeroLocomotionStateStrafeRightTurn90CW.Stance = EStance.STANCE_GOOFY
HeroLocomotionStateStrafeRightTurn90CW.TargetFacingAngles = CVector3(45, 135, 0)
HeroLocomotionStateStrafeRightTurn90CW.TerminationTargetFacingAngles = CVector3(2, 135, 0)
HeroLocomotionStateStrafeRightTurn90CW.TerminationVelocityArea = {
	CVector3(-HeroLocomotionData.MinVelMagForMovement, -181, 0),
	CVector3(0.15, 181, 0)
}
HeroLocomotionStateStrafeRightTurn90CW.States = {
	"HeroLocomotionStateStrafeRightTurn90ACW",
	"HeroLocomotionStateStrafeRightTurn90CW",
	"HeroLocomotionStateStrafeForwardRF",
	"HeroLocomotionStateStrafeLeftRF",
	"HeroLocomotionStateStrafeRightRF",
	"HeroLocomotionStateStrafeBackRF",
	"HeroLocomotionStateStrafeIdleRF",
	"HeroLocomotionStateStrafeForward",
	"HeroLocomotionStateStrafeForwardLeft",
	"HeroLocomotionStateStrafeForwardRight",
	"HeroLocomotionStateStrafeLeftForwards",
	"HeroLocomotionStateStrafeRightForwards",
	"HeroLocomotionStateStrafeLeft",
	"HeroLocomotionStateStrafeRight",
	"HeroLocomotionStateStrafeLeftBackwards",
	"HeroLocomotionStateStrafeRightBackwards",
	"HeroLocomotionStateStrafeBackLeft",
	"HeroLocomotionStateStrafeBackRight",
	"HeroLocomotionStateStrafeBack",
	"HeroLocomotionStateStrafeIdle"
}

-- NPCLocomotionStateIdle --
NPCLocomotionStateIdle = {}
NPCLocomotionStateIdle.Anim = {
	"Pose"
}
NPCLocomotionStateIdle.BlendInTime = 0.5
NPCLocomotionStateIdle.VelocityArea = {
	CVector3(-HeroLocomotionDataHandHoldingDefault.MinVelMagForMovement, -180, 0),
	CVector3(1.05, 180, 0)
}
NPCLocomotionStateIdle.ControlArea = {
	CVector3(-HeroLocomotionDataHandHoldingDefault.MinControlMagForMovement, -180, 0),
	CVector3(1.05, 180, 0)
}
NPCLocomotionStateIdle.States = {
	"NPCLocomotionStateLocomoteForwards",
	"NPCLocomotionStateIdle"
}

-- NPCLocomotionStateLocomoteForwards --
NPCLocomotionStateLocomoteForwards = {}
NPCLocomotionStateLocomoteForwards.Anim = {
	-- "Walk",
	-- "HeroLocoRun"
	"WalkSlow",
	"Walk",
	"WalkFast",
	"Run",
	"Sprint"
}
NPCLocomotionStateLocomoteForwards.BlendInTime = 0.5
NPCLocomotionStateLocomoteForwards.VelocityArea = {
	CVector3(HeroLocomotionDataHandHoldingDefault.MinVelMagForMovement, -180, 0),
	CVector3(10, 180, 0)
}
NPCLocomotionStateLocomoteForwards.ControlArea = {
	CVector3(-HeroLocomotionDataHandHoldingDefault.MinControlMagForMovement, -180, 0),
	CVector3(1.05, 180, 0)
}
NPCLocomotionStateLocomoteForwards.States = {
	"NPCLocomotionStateLocomoteForwards",
	"NPCLocomotionStateIdle"
}
NPCLocomotionStateLocomoteForwards.MovementParams = {}
NPCLocomotionStateLocomoteForwards.MovementParams.MaxSpeed = 4.5
NPCLocomotionStateLocomoteForwards.MovementParams.SprintSpeedMultiplier = 1.45

-- NPCLocomotionStateDraggedIdleIdle --
NPCLocomotionStateDraggedIdleIdle = {}
NPCLocomotionStateDraggedIdleIdle.Anim = {
	"IdleDragged"
}
NPCLocomotionStateDraggedIdleIdle.IdleState = true
NPCLocomotionStateDraggedIdleIdle.BlendInTime = 0.2
NPCLocomotionStateDraggedIdleIdle.ValidTime = 3
NPCLocomotionStateDraggedIdleIdle.VelocityArea = {
	CVector3(-HeroLocomotionDataHandHoldingDefault.MinVelMagForMovement, -180, 0),
	CVector3(1.05, 180, 0)
}
NPCLocomotionStateDraggedIdleIdle.ControlArea = {
	CVector3(-HeroLocomotionDataHandHoldingDefault.MinControlMagForMovement, -180, 0),
	CVector3(1.05, 180, 0)
}
NPCLocomotionStateDraggedIdleIdle.States = {
	"NPCLocomotionStateDraggedLocomoteForwards",
	"NPCLocomotionStateDraggedIdleIdle",
	"NPCLocomotionStateDraggedIdle"
}

-- NPCLocomotionStateDraggedIdle --
NPCLocomotionStateDraggedIdle = {}
NPCLocomotionStateDraggedIdle.Anim = {
	"PoseDragged"
}
NPCLocomotionStateDraggedIdle.BlendInTime = 0.5
NPCLocomotionStateDraggedIdle.VelocityArea = {
	CVector3(-HeroLocomotionDataHandHoldingDefault.MinVelMagForMovement, -180, 0),
	CVector3(1.05, 180, 0)
}
NPCLocomotionStateDraggedIdle.ControlArea = {
	CVector3(-HeroLocomotionDataHandHoldingDefault.MinControlMagForMovement, -180, 0),
	CVector3(1.05, 180, 0)
}
NPCLocomotionStateDraggedIdle.States = {
	"NPCLocomotionStateDraggedLocomoteForwards",
	"NPCLocomotionStateDraggedIdleIdle",
	"NPCLocomotionStateDraggedIdle"
}

-- NPCLocomotionStateDraggedLocomoteForwards --
NPCLocomotionStateDraggedLocomoteForwards = {}
NPCLocomotionStateDraggedLocomoteForwards.Anim = {
	"WalkDragged"
}
NPCLocomotionStateDraggedLocomoteForwards.BlendInTime = 0.5
NPCLocomotionStateDraggedLocomoteForwards.VelocityArea = {
	CVector3(HeroLocomotionDataHandHoldingDefault.MinVelMagForMovement, -180, 0),
	CVector3(10, 180, 0)
}
NPCLocomotionStateDraggedLocomoteForwards.ControlArea = {
	CVector3(-HeroLocomotionDataHandHoldingDefault.MinControlMagForMovement, -180, 0),
	CVector3(1.05, 180, 0)
}
NPCLocomotionStateDraggedLocomoteForwards.States = {
	"NPCLocomotionStateDraggedLocomoteForwards",
	"NPCLocomotionStateDraggedIdle"
}

-- HeroLocomotionStateLocomoteForwards --
HeroLocomotionStateLocomoteForwards = {}
HeroLocomotionStateLocomoteForwards.Anim = {
	"WalkSlow",
	"Walk",
	"WalkFast",
	"Run",
	"Sprint"
}
HeroLocomotionStateLocomoteForwards.BlendInTime = 0.5
HeroLocomotionStateLocomoteForwards.VelocityArea = {
	CVector3(HeroLocomotionData.MinVelMagForMovement, -180, 0),
	CVector3(10, 180, 0)
}
HeroLocomotionStateLocomoteForwards.ControlArea = {
	CVector3(-HeroLocomotionData.MinControlMagForMovement, -180, 0),
	CVector3(1.05, 180, 0)
}
HeroLocomotionStateLocomoteForwards.States = {
	-- "HeroLocomotionStateRunTurn180",
	-- "HeroLocomotionStateLocomoteForwardsUphill",
	-- "HeroLocomotionStateLocomoteForwardsDownhill",
	-- "HeroLocomotionStateLocomoteForwardsConfinedLeft",
	-- "HeroLocomotionStateLocomoteForwardsConfinedRight",
	-- "HeroLocomotionStateIdleCombatPoseLF",
	-- "HeroLocomotionStateIdleCombatPoseRF",
	-- "HeroLocomotionStateLocomoteJog",
	"HeroLocomotionStateLocomoteForwards",
	"HeroLocomotionStateIdle"
}

-- HeroLocomotionStateRunTurn180 --
HeroLocomotionStateRunTurn180 = {}
HeroLocomotionStateRunTurn180.Anim = {
	"RunTurn180Left",
	"RunTurn180Right"
}
HeroLocomotionStateRunTurn180.BlendInTime = 0.25 --0.125
HeroLocomotionStateRunTurn180.TransitionType = ETransitionType.TRANSITION_ROTATION
HeroLocomotionStateRunTurn180.AnimBlendType = EAnimBlendType.ANIM_BLEND_BLEND
HeroLocomotionStateRunTurn180.VelocityArea = {
	CVector3(0.5, 0, 0),
	CVector3(1.3, 35, 0)
}
HeroLocomotionStateRunTurn180.ControlArea = {
	CVector3(-HeroLocomotionData.MinControlMagForMovement, 135, 0),
	CVector3(1.05, 180.1, 0)
}
HeroLocomotionStateRunTurn180.TerminationControlArea = {
	CVector3(-HeroLocomotionData.MinControlMagForMovement, 5, 0),
	CVector3(1.05, 181, 0)
}
HeroLocomotionStateRunTurn180.TerminationVelocityArea = {
	CVector3(-HeroLocomotionData.MinVelMagForMovement, 0, 0),
	CVector3(1.3, 181, 0)
}
HeroLocomotionStateRunTurn180.States = {
	"HeroLocomotionStateRunTurn180",
	"HeroLocomotionStateLocomoteSprint",
	"HeroLocomotionStateLocomoteRun",
	"HeroLocomotionStateLocomoteWalkFast",
	"HeroLocomotionStateLocomoteWalkNormal",
	"HeroLocomotionStateLocomoteWalk",
	"HeroLocomotionStateIdleCombatPoseLF",
	"HeroLocomotionStateIdleCombatPoseRF",
	"HeroLocomotionStateIdle"
}
HeroLocomotionStateRunTurn180.MovementParams = {}
HeroLocomotionStateRunTurn180.MovementParams.MaxTurnSpeedStatic = 300
HeroLocomotionStateRunTurn180.MovementParams.MaxTurnSpeedRunning = 300
HeroLocomotionStateRunTurn180.MovementParams.FrictionCoefficient = 4
HeroLocomotionStateRunTurn180.MovementParams.FrictionCoefficientLateral = 4

-- HeroLocomotionStateRegister --
HeroLocomotionStateRegister = {
	"HeroLocomotionStateIdle",
	"HeroLocomotionStateIdleIdle",
	"HeroLocomotionStateLocomoteForwardsConfinedFront",
	"HeroLocomotionStateIdleCombatPoseLF",
	"HeroLocomotionStateIdleCombatPoseRF",
	"HeroLocomotionStateLocomoteWalkBack",
	"HeroLocomotionStateLocomoteWalk",
	"HeroLocomotionStateLocomoteWalkNormal",
	"HeroLocomotionStateLocomoteWalkFast",
	"HeroLocomotionStateLocomoteRun",
	"HeroLocomotionStateLocomoteSprint",
	"HeroLocomotionStateLocomoteJog",
	"HeroLocomotionStateLocomoteForwards",
	"HeroLocomotionStateLocomoteForwardsUphill",
	"HeroLocomotionStateLocomoteForwardsDownhill",
	"HeroLocomotionStateLocomoteForwardsConfinedLeft",
	"HeroLocomotionStateLocomoteForwardsConfinedRight",
	"HeroLocomotionStateWalkTurn90Left",
	"HeroLocomotionStateWalkTurn90Right",
	"HeroLocomotionStateTurnLeft45",
	"HeroLocomotionStateTurnRight45",
	"HeroLocomotionStateTurnLeft90",
	"HeroLocomotionStateTurnRight90",
	"HeroLocomotionStateTurnLeft180",
	"HeroLocomotionStateTurnRight180",
	"HeroLocomotionStateTurn90IntoRunRight",
	"HeroLocomotionStateTurn90IntoRunLeft",
	"HeroLocomotionStateTurn180IntoRunLeft",
	"HeroLocomotionStateTurn180IntoRunRight",
	"HeroLocomotionStateRunTurn180Right",
	"HeroLocomotionStateRunTurn180Left",
	"HeroLocomotionStateSprintTurn180Left",
	"HeroLocomotionStateSprintTurn180Right",
	"HeroLocomotionStateRunLeanRight",
	"HeroLocomotionStateRunLeanLeft",
	"HeroLocomotionStateTurn90CW",
	"HeroLocomotionStateTurn90ACW",
	"HeroLocomotionStateTurn180",
	"HeroLocomotionStateRunTurn180",
	"HeroLocomotionStateAimIdle",
	"HeroLocomotionStateStrafeIdle",
	"HeroLocomotionStateStrafeIdleRF",
	"HeroLocomotionStateStrafeTransitionToRF",
	"HeroLocomotionStateStrafeTransitionToLF",
	"HeroLocomotionStateStrafeForward",
	"HeroLocomotionStateStrafeForwardLeft",
	"HeroLocomotionStateStrafeForwardRight",
	"HeroLocomotionStateStrafeLeftForwards",
	"HeroLocomotionStateStrafeRightForwards",
	"HeroLocomotionStateStrafeLeft",
	"HeroLocomotionStateStrafeRight",
	"HeroLocomotionStateStrafeBack",
	"HeroLocomotionStateStrafeLeftBackwards",
	"HeroLocomotionStateStrafeRightBackwards",
	"HeroLocomotionStateStrafeBackLeft",
	"HeroLocomotionStateStrafeBackRight",
	"HeroLocomotionStateStrafeForwardRF",
	"HeroLocomotionStateStrafeLeftRF",
	"HeroLocomotionStateStrafeRightRF",
	"HeroLocomotionStateStrafeBackRF",
	"HeroLocomotionStateStrafeLeftCrossedToForward",
	"HeroLocomotionStateStrafeLeftCrossedToBack",
	"HeroLocomotionStateStrafeRightCrossedToForwardRF",
	"HeroLocomotionStateStrafeRightCrossedToBackRF",
	"HeroLocomotionStateStrafeLeftTurn90ACW",
	"HeroLocomotionStateStrafeLeftTurn90CW",
	"HeroLocomotionStateStrafeRightTurn90ACW",
	"HeroLocomotionStateStrafeRightTurn90CW",
	"NPCLocomotionStateIdle",
	"NPCLocomotionStateLocomoteForwards",
	"NPCLocomotionStateDraggedIdleIdle",
	"NPCLocomotionStateDraggedIdle",
	"NPCLocomotionStateDraggedLocomoteForwards",
	"HeroLocomotionStateHHIdle",
	"HeroLocomotionStateHHLocomoteWalk",
	"HeroLocomotionStateHHDragIdle",
	"HeroLocomotionStateHHDragIdleIdle",
	"HeroLocomotionStateHHDragLocomoteWalk"
}

Debug.ReloadHeroLocomotionStates()

-- uncomment for debug
-- GUI.DisplayMessageBox("herolocomotionstates.lua successfully loaded!")
-- while (GUI.IsDisplayBoxActive()) do
	-- coroutine.yield()
-- end
