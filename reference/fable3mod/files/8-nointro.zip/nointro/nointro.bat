@echo Furby's Fable3 No-Intro Fix
@echo --------------------------
@echo injecting microsoft_logo.bik
bnktool -i d:\apps\fable3\data\levels.bnk art\videos\microsoft_logo.bik d:\nointro\microsoft_logo.bik
@echo done..
@echo injecting lionhead_logo.bik
bnktool -i d:\apps\fable3\data\levels.bnk art\videos\lionhead_logo.bik d:\nointro\lionhead_logo.bik
@echo done..
@echo ...
@echo You're now intro free
pause