put Controls.xml to
%AppData%\Lionhead Studios\Fable 3\Controls\"your xuid"

example:
%AppData%\Lionhead Studios\Fable 3\Controls\1000100010001000


DON'T CHANGE RIGHT "SHIFT" BUTTON!!

Switch RUN on\off now with Caps-Lock

right "Shift" is extra forward button, with combination it's adds speed (only when you move forward)






