@echo off
CD /D "%~dp0"
IF "%~1" == "-f" (
	GDB_Dump.exe %~1 "%~2" > "%~dpn2_float.txt"
) ELSE (
	IF "%~1" == "-l" (
		GDB_Dump.exe %~1 "%~2" > "%~dpn2_labels.txt"
	) ELSE (
		IF "%~1" == "-u" (
			GDB_Dump.exe %~1 "%~2" > "%~dpn2_unknown.txt"
		) ELSE (
			GDB_Dump.exe "%~1" > "%~dpn1.txt"
		)
	)
)