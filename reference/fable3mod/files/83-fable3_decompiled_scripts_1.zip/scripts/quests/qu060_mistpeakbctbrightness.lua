module(...,package.seeall)

QuestManager.NewQuestQuestThread("QU060_MistPeakBCTBrightness")

function QU060_MistPeakBCTBrightness:Init()

end

function QU060_MistPeakBCTBrightness:State_BRIGHTNESS_CHECK_SkipTo()

end

function QU060_MistPeakBCTBrightness:State_BRIGHTNESS_CHECK_Main()
	while true do
		coroutine.yield()
		
		if not Breadcrumber.GetSnowBoostEnabled() then
			if IsLevelLoaded("Albion\\MistpeakValley") or IsLevelLoaded("Albion\\MistPeak_GypsyCamp") then
				-- print("In MistPeak - change intensity")
				Breadcrumber.SetSnowBoostEnabled(true)
			end
		elseif Breadcrumber.GetSnowBoostEnabled() then
			if not IsLevelLoaded("Albion\\MistpeakValley") and not IsLevelLoaded("Albion\\MistPeak_GypsyCamp") then
				-- print("Left MistPeak change intensity")
				Breadcrumber.SetSnowBoostEnabled(false)
			end
		end
		
	end
end

