ScriptEnum = {}
ScriptCode = CreateInverseTable(
	{
		"START",
		"QC010",
		"QC015",
		"QC020",
		"QC030",
		"QC040",
		"QC050",
		"QC060",
		"QC070",
		"QC080",
		"QC090",
		"QC100",
		"QC110",
		"QC120",
		"QC130",
		"QC140",
		"QC150",
		"QC160",
		"QC170",
		"QC180",
		"QC999",
		"QD010",
		"QD020",
		"QD050",
		"QD060",
		"QD070",
		"QD080",
		"QMP010",
		"QMP020",
		"QMP040",
		"QN020",
		"QO010",
		"QO020",
		"QO030",
		"QO040",
		"QO050",
		"QO060",
		"QO070",
		"QO080",
		"QO085",
		"QO090",
		"QO100",
		"QO110",
		"QO120",
		"QO130",
		"QO140",
		"QO160",
		"QO170",
		"QO200",
		"QO210",
		--don't get what it means...
		--setlist        1   50  1    ; index 1 to 50
		"QO810",
		"QT000",
		"QD030",
		"QD040",
		"QT001",
		"QT020",
		"QT060",
		"QT065",
		"QT066",
		"QT070",
		"QT080",
		"QT999",
		"QU000",
		"QU010",
		"QU020",
		"QU030",
		"QU040",
		"QU050",
		"QU060",
		"QU070",
		"QU080",
		"QU090",
		"QU100",
		"QU110",
		"QU120",
		"QU130",
		"QU140",
		"QU150",
		"QU160",
		"QU247",
		"QU400",
		"QU365",
		"QV010",
		"QV020",
		"QV030",
		"QV040",
		"QV050",
		"QV060",
		"QV070",
		"QV080",
		"QV090",
		"QV100",
		"QV110",
		"QV120",
		"QV130",
		"QV150",
		"QV380",
		"QDEM010",
		"DEMO001",
		"QP000",
		--setlist        1   50  2    ; index 51 to 100
		"QT666",
		"END",
		"QU001",
		"QU170",
		"QC190",
		"QC200",
		"QC210",
		"QC220",
		"QC230",
		"QC240",
		"QD090",
		"QU666",
		"QU667"
		--setlist        1   13  3    ; index 101 to 113

	}
)
	

ScriptEnum.GAMEFLOW_START = 0
ScriptEnum.DebugQC010 = 1
ScriptEnum.DebugQC020 = 2
ScriptEnum.DebugQC030 = 3
ScriptEnum.DebugQC040 = 4
ScriptEnum.DebugQC045 = 5
ScriptEnum.DebugQC050 = 6
ScriptEnum.DebugQC055 = 7
ScriptEnum.DebugQC060 = 8
ScriptEnum.DebugQC065 = 9
ScriptEnum.DebugQC070 = 10
ScriptEnum.DebugQC075 = 11
ScriptEnum.DebugQC080 = 12
ScriptEnum.DebugQC085 = 13
ScriptEnum.DebugQC090 = 14
ScriptEnum.DebugQC100 = 15
ScriptEnum.DebugQC110 = 16
ScriptEnum.DebugQC120 = 17
ScriptEnum.DebugQC130 = 18
ScriptEnum.DebugQC140 = 19
ScriptEnum.DebugQC150 = 20
ScriptEnum.DebugQC160 = 21
ScriptEnum.DebugQC170 = 22
ScriptEnum.DebugQC180 = 23
ScriptEnum.DebugQC200 = 24
ScriptEnum.DebugQC220 = 25
ScriptEnum.DebugQC230 = 26
ScriptEnum.DebugQC240 = 27
ScriptEnum.DebugQC250 = 28
ScriptEnum.DebugQC260 = 29
ScriptEnum.DebugQC270 = 30
ScriptEnum.Sandbox = 31
ScriptEnum.GAMEFLOW_END = 32
ScriptEnum.DebugQO010 = 33
ScriptEnum.DebugQO020 = 35
ScriptEnum.DebugQO040 = 36
ScriptEnum.DebugQO100 = 37
ScriptEnum.DebugQO110 = 38
ScriptEnum.DebugQO150 = 39
ScriptEnum.DebugQFP = 40
ScriptEnum.DebugQO666 = 41
ScriptEnum.DebugQO240 = 42
ScriptEnum.DebugQO250 = 43
ScriptEnum.DebugQO320 = 44
ScriptEnum.DebugQO330 = 45
ScriptEnum.DebugQO340 = 46
ScriptEnum.DebugQO350 = 47
ScriptEnum.DebugQO380 = 48
ScriptEnum.DebugQO390 = 49
ScriptEnum.DebugQO460 = 51
ScriptEnum.DebugQO470 = 52
ScriptEnum.DebugQO540 = 53
ScriptEnum.DebugQO570 = 54
ScriptEnum.DebugQO030 = 56
ScriptEnum.DebugQO015 = 57
ScriptEnum.DebugQO160 = 58
ScriptEnum.DebugQO130 = 59
ScriptEnum.DebugQO700 = 60
ScriptEnum.DebugQO135 = 61
ScriptEnum.DebugQO230 = 62
ScriptEnum.DebugQJ001 = 63
ScriptEnum.DebugQO220 = 64
ScriptEnum.DebugQO225 = 65
ScriptEnum.DebugQO270 = 66
ScriptEnum.DebugQO571 = 67
ScriptEnum.DebugQJ002 = 68
ScriptEnum.DebugQO800 = 69
ScriptEnum.DebugQO805 = 70
ScriptEnum.DebugQO810 = 71
ScriptEnum.DebugQO815 = 72
ScriptEnum.DebugQO820 = 73
ScriptEnum.DebugQO400 = 74
ScriptEnum.DebugQO050 = 75
ScriptEnum.DebugQO880 = 76
ScriptEnum.DebugQO190 = 77
ScriptEnum.DebugQJ003 = 78
ScriptEnum.DebugQJ004 = 79
ScriptEnum.DebugQC066 = 80
ScriptEnum.DebugQO650 = 81
ScriptEnum.DebugQO200 = 82
ScriptEnum.DebugQO170 = 83
ScriptEnum.DebugQO060 = 84
ScriptEnum.DebugQO850 = 85
ScriptEnum.DebugQO840 = 86
ScriptEnum.DebugQO180 = 87
ScriptEnum.DebugQO660 = 88
ScriptEnum.DebugQO630 = 89
ScriptEnum.DebugQC235 = 90
ScriptEnum.DebugQO600 = 91
ScriptEnum.DLC2_DrunkEffect = 92

