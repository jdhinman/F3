module(...,package.seeall)

QuestManager.NewQuestQuestThread("QC999_Sandbox")

function QC999_Sandbox:Init()

end

function QC999_Sandbox:State_START_SkipTo()

end

function QC999_Sandbox:State_START_Main()
	while true do
		coroutine.yield()
	end
end

function QC999_Sandbox:OnExit()

end
