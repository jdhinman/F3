
Debug.ScaleConsoleForTelevisionScreen = function()
	Debug.SetConsoleFontSize = 28
	Debug.SetConsoleOffsetX = 65
end

Debug.ScaleConsoleForMonitor = function()
	Debug.SetConsoleFontSize = 14
	Debug.SetConsoleOffsetX = 0
end

Debug.DisableLocalLights = function()
	Debug.EngineConfig.EnableSpotLights = false
	Debug.EngineConfig.EnablePointLights = false
end

Debug.RestoreLightingDebug = function()
	Debug.EngineConfig.MissingLightmapAmbientOffsetOverride = -1
	Debug.EngineConfig.UseWhiteTexture = false
	Debug.EngineConfig.EnablePRT = true
	Debug.EngineConfig.EnableLightmaps = true
	Debug.EngineConfig.EnableToneMapping = true
	Debug.EngineConfig.EnableShadows = true
	Debug.EngineConfig.EnableSpotLights = true
	Debug.EngineConfig.EnablePointLights = true
end

Debug.AddLuaDebugKeyFunc(EInputKey.KB_F1, Debug.ScaleConsoleForTelevisionScreen)
Debug.AddLuaDebugKeyFunc(EInputKey.KB_F2, Debug.ScaleConsoleForMonitor)

Debug.AddOptionalStartupConsoleScript("MyStartupConsoleScript.lua")

Debug.AddConsoleKeyShortcut(EInputKey.KB_D, "Debug.")
Debug.AddConsoleKeyShortcut(EInputKey.KB_F, "Fable2Scripts.")
Debug.AddConsoleKeyShortcut(EInputKey.KB_H, "GetLocalHero()")
Debug.AddConsoleKeyShortcut(EInputKey.KB_T, "Debug.SetTextSpeechDebugMenuFilter('")
Debug.AddConsoleKeyShortcut(EInputKey.KB_V, "CVector3(")

Debug.SetVaultingCheckImpassability = false

DoStartupStuffAfterHeroCreated = function()

	-- GetLocalHero()
	-- PhysicsCharacter.SetUseSliding(QuestManager.HeroEntity) = true
	
	PhysicsCharacter.SetUseSliding(GetLocalHero()) = true

end

GeneralScriptManager.CallFunction(DoStartupStuffAfterHeroCreated())

Debug.SetFootLockingEnabled2 = false











