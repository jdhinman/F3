
Debug.SetTutorialsEnabled = true
Debug.SetDeathMinigameEnabled = true
