
SetUseRetailFrontEnd = false
SetDemoMode = 3
