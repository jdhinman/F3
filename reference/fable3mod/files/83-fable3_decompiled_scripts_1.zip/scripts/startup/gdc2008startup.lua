
SetDrawWorldIcons = false
SetInitialHeroMeleeWeapon("ObjectInventory_L_Cutlass_GDC")
SetInitialHeroRangedWeapon("ObjectInventoryPistol_Flintlock_Master")
SetInitialHenchmanMeleeWeapon("ObjectInventory_L_LongSword_GDC")
SetInitialHenchmanRangedWeapon("ObjectInventoryPistol_Flintlock_Master")
