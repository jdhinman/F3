
SetControlSystemRecordName = "GameControlsE3"
SetDemoMode = EDemoMode.DEMO_E3_2007
SetInitialWorldName = "TestWorld"
SetInitialLevelName = "E3_Demo"
SetSkipFrontEnd = true
SetDisplayTipOfTheDay = false
SetMillisecondsToWaitForLuaDebugger = 0
SetPresentationInterval = 3
SetVSync = true



