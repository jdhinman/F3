
Debug.IsE3Demo = true
Debug.LoadControlSystem("GameControlsE3")
Debug.SetConsoleOffsetX = 30
Debug.SetHeroSkidTurningEnabled = false
Debug.SetStopTimeSpellDurationSeconds = 5
Debug.SetDrawGUI = false
Debug.SetHeroGodMode = true
Debug.SetHeroManaInfinite = true
Debug.SetExperienceOrbsEnabled = false
Debug.SetHeroSprintingEnabled = false
Debug.SetDrawTargetingHighlight = false
Debug.SetDrawMilestoneVersionText = true
Debug.SetDrawPausedTextWhenGUIDisabled = true
Debug.SetEnableEntityDrawDebugInfo = false
Debug.UnleashThePinkMist = true
Debug.SetHavokFriction = 0.95
Debug.SetHavokRestitution = 0
Debug.SetHavokAngularDamping = 0.75
Debug.SetHavokMaxLinearVelocity = 10
Debug.SetHavokMaxAngularVelocity = 200
Debug.SetHavokMinMass = 10
Debug.EngineConfig.EnablePointLights = false
Debug.EngineConfig.LightmapGamma = 1

Debug.ApplyE3AITweaks = function()

end

Debug.RestartE3Demo = function()

	EntityManager.E3BodgeReload()
	Debug.LoadLevel("TestWorld", "E3_Demo", "")
	Debug.ReloadAI()
	Debug.ApplyE3AITweaks()
	GeneralScriptManager.CallFunction(ScriptFunction.CreateDog)
	
end

Debug.AddLuaDebugKeyFunc(EInputKey.KB_F11, Debug.RestartE3Demo)
Timing.SetDaySpeed(0)
Timing.SetTimeOfDay(11.3)
