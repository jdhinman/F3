
memory_mount = true
disk_mount = false
AddOptionalStartupScript("MyStartup.lua")
