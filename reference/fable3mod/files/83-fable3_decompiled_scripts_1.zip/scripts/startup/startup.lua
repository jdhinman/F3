
RunScript("Miscellaneous/StartupSettings.lua")
ProperResolution = GetScreenResolution()
SmallResolution = CI32Vector2(640,480)
BigResolution = CI32Vector2(1024,768)


if GetApplicationName() == 'Fable 2' then
	SetApplicationName = " - the one where Lua works"
elseif GetApplicationName() == 'Big res' then
	SetApplicationName = "Fable III"
end

AddOptionalStartupScript("audio.lua")


if GetPlatform() == Platform.Win32 then

elseif GetPlatform() == Platform.Xbox360 then

end



SetInitialHeroMeleeWeapon = "ObjectInventoryLivingSword"
SetInitialHeroRangedWeapon = "ObjectInventoryLivingPistol"
SetInitialHenchmanMeleeWeapon = "ObjectInventoryLivingSword"
SetInitialHenchmanRangedWeapon = "ObjectInventoryLivingPistol"

if IsReleaseBuild() then
	SetUseMemoryMountedBanks = false
end

SetScreenResolution = CI32Vector2(1280,720)
SetDisableLiveFunctionality = false
AddOptionalStartupScript("MyStartup.lua")
SetUseRetailFrontEnd = false
SetEnableFullDebugMenu = true
SetFrontEndDemoMode = EDemoMode(DEMO_2010_GC_BOWERSTONE_BOAT)

