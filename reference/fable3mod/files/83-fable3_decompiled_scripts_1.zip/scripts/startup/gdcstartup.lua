
SetControlSystemRecordName("GameControlsGDC")
SetStartGDCDemo = true
SetInitialWorldName("TestWorld")
SetInitialLevelName("DogBed")
SetSkipFrontEnd = true
SetDisplayTipOfTheDay = false
