if GUI() then
	GUI.Timing = {}
	GUI.Timing.FIRST_NAVIGATE_INTERVAL = 0.25
	GUI.Timing.SUBSEQUENT_NAVIGATE_INTERVAL = 0.14
	GUI.Timing.TRANSITION_TIME = 0.5
	GUI.Timing.Input_INTERVAL_CLAMP = 10
	GUI.Timing.NavigateInterval = GUI.Timing.FIRST_NAVIGATE_INTERVAL
	GUI.Timing.TimeSinceLastNavigate = GUI.Timing.FIRST_NAVIGATE_INTERVAL
	GUI.Input = {}
	GUI.Input.THUMBSTICK_PUSH_THRESHOLD = 0.7
	GUI.Input.THUMBSTICK_RELEASE_THRESHOLD = 0.65
	GUI.Input.PushingUpHeld = false
	GUI.Input.PushingDownHeld = false
	GUI.Input.PushingLeftHeld = false
	GUI.Input.PushingRightHeld = false
	GUI.Input.NavigationCount = 0
	GUI.Const = {}
	GUI.Const.MIN_NAVIGATE_INTERVAL = 0.2
	GUI.Const.MIN_ADJUST_INTERVAL = 0.2
	GUI.Const.MIN_GUI._WHEEL_GRAPH_NAV_INTERVAL = 0.6
	GUI.Const.EVENT_TYPE_NAVIGATION = 100
	GUI.Const.EVENT_TYPE_BUTTON_REMOVE = 101
	GUI.Const.EVENT_TYPE_BUTTON_SET = 102
	GUI.Const.EVENT_TYPE_MENU_SCROLL_UP = 140
	GUI.Const.EVENT_TYPE_MENU_SCROLL_DOWN = 141
	GUI.Const.BUTTON_TYPE_UP = 1
	GUI.Const.BUTTON_TYPE_DOWN = 2
	GUI.Const.BUTTON_TYPE_LEFT = 3
	GUI.Const.BUTTON_TYPE_RIGHT = 4
	GUI.Const.BUTTON_TYPE_A = 11
	GUI.Const.BUTTON_TYPE_B = 12
	GUI.Const.BUTTON_TYPE_X = 13
	GUI.Const.BUTTON_TYPE_Y = 14
	GUI.Const.PageTitleColour = Color:new(255, 255, 128, 255)

	GUI.State = {}
	GUI.State.PlayerPosX = 0
	GUI.State.PlayerPosY = 0
	GUI.State.ViewOrientation = 0
	GUI.State.DoesRotateMap = false
	GUI.State.MaxHealth = 200
	GUI.State.BaseHealth = 100
	GUI.State.CurrHealth = 120
	GUI.State.MaxMana = 250
	GUI.State.BaseMana = 100
	GUI.State.CurrMana = 150
	GUI.State.TimeElapsed = 0
	GUI.State.LastUpdateTime = getElapsedTime()
	GUI.State.TimeSinceNavigate = 10
	GUI.State.TimeSinceAdjust = 10
	GUI.State.FirstFewUpdates = 0
	GUI.State.IsWidescreen = false
	GUI.State.LeftThumbStickX = 0
	GUI.State.LeftThumbStickY = 0
	GUI.State.RightThumbStickX = 0
	GUI.State.RightThumbStickY = 0
	GUI.State.NormStickX = 0
	GUI.State.NormStickY = 0
	GUI.State.HaveAppliedLocalisedText = false
	GUI.State.EventQueue = {}
	GUI.State.EventQueue.Type = {}
	GUI.State.EventQueue.Name = {}
	GUI.State.EventQueue.Param1Low = {}
	GUI.State.EventQueue.Param1High = {}
	GUI.State.EventQueue.Type = {}
	GUI.FLAG_WheelGraphIsAtRoot = false

end

-- uncomment for debug
-- GUI.DisplayMessageBox("guistateandconstants.lua successfully loaded!")
-- while (GUI.IsDisplayBoxActive()) do
	-- coroutine.yield()
-- end