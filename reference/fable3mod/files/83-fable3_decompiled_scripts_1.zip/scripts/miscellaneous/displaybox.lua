EDisplayBoxStyle = {}
EDisplayBoxStyle.DBS_OLD_STYLE = 0
EDisplayBoxStyle.DBS_JOB_ACCEPTANCE = 1
EDisplayBoxStyle.DBS_QUEST_ACCEPTANCE = 2
EDisplayBoxStyle.DBS_INFO_BOX = 3
