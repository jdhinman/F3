FastTravel = {}
FastTravel.CoachRoutes = {}
FastTravel.ShipRoutes = {
	{
		World = "Fable3",
		Level = "Albion\\BowerstoneIndustrial",
		Destinations = {
			{
				RegionNameTag = "TEXT_LEVEL_AURORA_BLOODWESHARE",
				TextTag = "TEXT_GUI_FAST_TRAVEL_BOWERSTONEINDUSTRIAL_BLOODWESHARE"
			}
		}
	},
	{
		World = "Fable3",
		Level = "Aurora\\BloodWeShare",
		Destinations = {
			{
				RegionNameTag = "TEXT_LEVEL_ALBION_BOWERSTONEINDUSTRIAL"
				TextTag = "TEXT_GUI_FAST_TRAVEL_BLOODWESHARE_BOWERSTONEINDUSTRIAL"
			}
		}
	},
	{
		World = "Fable3",
		Level = "Albion\\CastleBattle",
		Destinations = {
			{
				RegionNameTag = "TEXT_DLC2_LEVEL_PRISONISLAND",
				TextTag = "TEXT_GUI_FAST_TRAVEL_CASTLEBATTLE_RAVENSCARPRISON"
			}
		}
	},
	{
		World = "Fable3",
		Level = "Episode1\\RavenscarPrison",
		Destinations = {
			{
				RegionNameTag = "TEXT_LEVEL_ALBION_CASTLEBATTLE",
				TextTag = "TEXT_GUI_FAST_TRAVEL_RAVENSCARPRISON_CASTLEBATTLE"
			},
			{
				RegionNameTag = "TEXT_DLC2_LEVEL_CLOCKMANISLAND",
				TextTag = "TEXT_GUI_FAST_TRAVEL_RAVENSCARPRISON_CLOCKMAN"
			},
			{
				RegionNameTag = "TEXT_DLC2_LEVEL_GODWIN_MANSION",
				TextTag = "TEXT_GUI_FAST_TRAVEL_RAVENSCARPRISON_THEVESTIGES"
			}
		}
	},
	{
		World = "Fable3",
		Level = "Episode1\\Clockman",
		Destinations = {
			{
				RegionNameTag = "TEXT_DLC2_LEVEL_PRISONISLAND",
				TextTag = "TEXT_GUI_FAST_TRAVEL_CLOCKMAN_RAVENSCARPRISON"
			}
		}
	},
	{
		World = "Fable3",
		Level = "Episode1\\TheVestiges",
		Destinations = {
			{
				RegionNameTag = "TEXT_DLC2_LEVEL_PRISONISLAND",
				TextTag = "TEXT_GUI_FAST_TRAVEL_THEVESTIGES_RAVENSCARPRISON"
			}
		}
	}
}
FastTravel.CoachTravelMarkers = {}
FastTravel.ShipTravelMarkers = {
	{
		RegionNameTag = "TEXT_LEVEL_ALBION_BOWERSTONEINDUSTRIAL",
		MarkerEntityName = "Travel_BSI_Dock"
	},
	{
		RegionNameTag = "TEXT_LEVEL_AURORA_BLOODWESHARE",
		MarkerEntityName = "Travel_BloodWeShareDock"
	},
	{
		RegionNameTag = "TEXT_LEVEL_ALBION_CASTLEBATTLE",
		MarkerEntityName = "Travel_CBBeach"
	},
	{
		RegionNameTag = "TEXT_DLC2_LEVEL_PRISONISLAND",
		MarkerEntityName = "RPI_StartFromMainDock"
	},
	{
		RegionNameTag = "TEXT_DLC2_LEVEL_CLOCKMANISLAND",
		MarkerEntityName = "MarkerPlayerStart"
	},
	{
		RegionNameTag = "TEXT_DLC2_LEVEL_GODWIN_MANSION",
		MarkerEntityName = "MarkerPlayerStart"
	}
}

