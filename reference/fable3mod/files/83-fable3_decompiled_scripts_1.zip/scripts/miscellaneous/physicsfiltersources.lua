EFilterObjectSource = {}
EFilterObjectSource.FILTER_FROM_AI = 0
EFilterObjectSource.FILTER_FROM_SCRIPT = 1
