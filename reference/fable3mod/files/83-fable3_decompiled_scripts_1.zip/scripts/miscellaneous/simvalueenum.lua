EExpressionSimValue = {}
EExpressionSimValue.NEM_SIM_VALUE_NULL = 0
EExpressionSimValue.NEM_SIM_VALUE_SCARY = 1
EExpressionSimValue.NEM_SIM_VALUE_HATEFUL = 2
EExpressionSimValue.NEM_SIM_VALUE_FUNNY = 3
EExpressionSimValue.NEM_SIM_VALUE_FRIENDLY = 4
EExpressionSimValue.NEM_SIM_VALUE_ATTRACTIVE = 5
