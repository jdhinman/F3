EDestroyedRegion = {}
EDestroyedRegion.EDR_NONE = 0
EDestroyedRegion.EDR_CASTLE_BATTLE = 1
EDestroyedRegion.EDR_BRIGHTWALL = 2
EDestroyedRegion.EDR_BOWERSTONE_MARKET = 4




