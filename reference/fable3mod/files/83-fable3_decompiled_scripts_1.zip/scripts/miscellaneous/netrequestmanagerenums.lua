ERequestStatus = {}
ERequestStatus.REQUEST_IN_PROGESS = 0
ERequestStatus.REQUEST_FAILED = 1
ERequestStatus.REQUEST_SUCCEEDED = 2
