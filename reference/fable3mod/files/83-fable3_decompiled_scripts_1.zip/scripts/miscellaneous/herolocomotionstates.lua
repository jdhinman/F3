
HeroLocomotionData = {}
HeroLocomotionData.MinControlMagForMovement = 0.1
HeroLocomotionData.MinControlMagForTurn = 0
HeroLocomotionData.MinVelMagForMovement = 0.001
HeroLocomotionData.MaxTurnSpeedStatic = 800
HeroLocomotionData.MaxTurnSpeedRunning = 1
HeroLocomotionData.MaxSpeed = 4.5
HeroLocomotionData.SprintSpeedMultiplier = 1.45
HeroLocomotionData.SprintTerminationSpeedFraction = 0
HeroLocomotionData.FrictionCoefficient = 7
HeroLocomotionData.FrictionCoefficientSecondOrder = 8
HeroLocomotionData.FrictionCoefficientLateral = 8
HeroLocomotionData.MaxSpeedLateralStatic = 0.8
HeroLocomotionData.MaxSpeedLateralRunning = 1.5
HeroLocomotionData.AllowedToMoveBackwards = 0

HeroLocomotionDataHandHoldingLeader = {}
HeroLocomotionDataHandHoldingLeader.MaxSpeed = HeroLocomotionData.MaxSpeed
HeroLocomotionDataHandHoldingLeader.SprintSpeedMultiplier = HeroLocomotionData.SprintSpeedMultiplier
HeroLocomotionDataHandHoldingLeader.MinControlMagForMovement = 0.25
HeroLocomotionDataHandHoldingLeader.MinControlMagForTurn = 0
HeroLocomotionDataHandHoldingLeader.MinVelMagForMovement = 0.05
HeroLocomotionDataHandHoldingLeader.MaxTurnSpeedStatic = 500
HeroLocomotionDataHandHoldingLeader.MaxTurnSpeedRunning = 1
HeroLocomotionDataHandHoldingLeader.SprintTerminationSpeedFraction = 0
HeroLocomotionDataHandHoldingLeader.FrictionCoefficient = 4
HeroLocomotionDataHandHoldingLeader.FrictionCoefficientSecondOrder = 4
HeroLocomotionDataHandHoldingLeader.FrictionCoefficientLateral = 8
HeroLocomotionDataHandHoldingLeader.MaxSpeedLateralStatic = 0.8
HeroLocomotionDataHandHoldingLeader.MaxSpeedLateralRunning = 1.5
HeroLocomotionDataHandHoldingLeader.AllowedToMoveBackwards = 0

HeroLocomotionDataHandHoldingLeaderDragging = {}
HeroLocomotionDataHandHoldingLeaderDragging.MinControlMagForMovement = 0.1
HeroLocomotionDataHandHoldingLeaderDragging.MinControlMagForTurn = 0
HeroLocomotionDataHandHoldingLeaderDragging.MinVelMagForMovement = 0.001
HeroLocomotionDataHandHoldingLeaderDragging.MaxTurnSpeedStatic = 300
HeroLocomotionDataHandHoldingLeaderDragging.MaxTurnSpeedRunning = 300
HeroLocomotionDataHandHoldingLeaderDragging.MaxSpeed = 2
HeroLocomotionDataHandHoldingLeaderDragging.SprintSpeedMultiplier = 1.1
HeroLocomotionDataHandHoldingLeaderDragging.SprintTerminationSpeedFraction = 0
HeroLocomotionDataHandHoldingLeaderDragging.FrictionCoefficient = 4
HeroLocomotionDataHandHoldingLeaderDragging.FrictionCoefficientSecondOrder = 4
HeroLocomotionDataHandHoldingLeaderDragging.FrictionCoefficientLateral = 8
HeroLocomotionDataHandHoldingLeaderDragging.MaxSpeedLateralStatic = 0.8
HeroLocomotionDataHandHoldingLeaderDragging.MaxSpeedLateralRunning = 1.5
HeroLocomotionDataHandHoldingLeaderDragging.AllowedToMoveBackwards = 0

HeroLocomotionDataIndoorsDefault = {}
HeroLocomotionDataIndoorsDefault.MinControlMagForMovement = 0.1
HeroLocomotionDataIndoorsDefault.MinControlMagForTurn = 0
HeroLocomotionDataIndoorsDefault.MinVelMagForMovement = 0.001
HeroLocomotionDataIndoorsDefault.MaxTurnSpeedStatic = 800
HeroLocomotionDataIndoorsDefault.MaxTurnSpeedRunning = 7
HeroLocomotionDataIndoorsDefault.MaxSpeed = 4.5
HeroLocomotionDataIndoorsDefault.SprintSpeedMultiplier = 1.45
HeroLocomotionDataIndoorsDefault.SprintTerminationSpeedFraction = 0
HeroLocomotionDataIndoorsDefault.FrictionCoefficient = 7
HeroLocomotionDataIndoorsDefault.FrictionCoefficientSecondOrder = 8
HeroLocomotionDataIndoorsDefault.FrictionCoefficientLateral = 8
HeroLocomotionDataIndoorsDefault.MaxSpeedLateralStatic = 0.8
HeroLocomotionDataIndoorsDefault.MaxSpeedLateralRunning = 1.5
HeroLocomotionDataIndoorsDefault.AllowedToMoveBackwards = 0

HeroLocomotionDataHandHoldingDefault = {}
HeroLocomotionDataHandHoldingDefault.MinControlMagForMovement = 0.25
HeroLocomotionDataHandHoldingDefault.MinControlMagForTurn = 0
HeroLocomotionDataHandHoldingDefault.MinVelMagForMovement = 0.001
HeroLocomotionDataHandHoldingDefault.MaxTurnSpeedStatic = 700
HeroLocomotionDataHandHoldingDefault.MaxTurnSpeedRunning = 615
HeroLocomotionDataHandHoldingDefault.MaxSpeed = 7
HeroLocomotionDataHandHoldingDefault.SprintSpeedMultiplier = 1.4
HeroLocomotionDataHandHoldingDefault.SprintTerminationSpeedFraction = 0
HeroLocomotionDataHandHoldingDefault.FrictionCoefficient = 4
HeroLocomotionDataHandHoldingDefault.FrictionCoefficientSecondOrder = 4
HeroLocomotionDataHandHoldingDefault.FrictionCoefficientLateral = 4
HeroLocomotionDataHandHoldingDefault.MaxSpeedLateralStatic = 0.8
HeroLocomotionDataHandHoldingDefault.MaxSpeedLateralRunning = 1.5
HeroLocomotionDataHandHoldingDefault.AllowedToMoveBackwards = 0

HeroLocomotionDataChild = {}
HeroLocomotionDataChild.MinControlMagForMovement = 0.25
HeroLocomotionDataChild.MinControlMagForTurn = 0
HeroLocomotionDataChild.MinVelMagForMovement = 0.001
HeroLocomotionDataChild.MaxTurnSpeedStatic = 350
HeroLocomotionDataChild.MaxTurnSpeedRunning = 95
HeroLocomotionDataChild.MaxSpeed = 4.5
HeroLocomotionDataChild.SprintSpeedMultiplier = 1.3
HeroLocomotionDataChild.SprintTerminationSpeedFraction = 0
HeroLocomotionDataChild.FrictionCoefficient = 4
HeroLocomotionDataChild.FrictionCoefficientSecondOrder = 4
HeroLocomotionDataChild.FrictionCoefficientLateral = 4
HeroLocomotionDataChild.MaxSpeedLateralStatic = 0.8
HeroLocomotionDataChild.MaxSpeedLateralRunning = 1.5
HeroLocomotionDataChild.AllowedToMoveBackwards = 0

HeroLocomotionDataChildIndoorsDefault = {}
HeroLocomotionDataChildIndoorsDefault.MinControlMagForMovement = 0.25
HeroLocomotionDataChildIndoorsDefault.MinControlMagForTurn = 0
HeroLocomotionDataChildIndoorsDefault.MinVelMagForMovement = 0.0010000000474975
HeroLocomotionDataChildIndoorsDefault.MaxTurnSpeedStatic = 300
HeroLocomotionDataChildIndoorsDefault.MaxTurnSpeedRunning = 95
HeroLocomotionDataChildIndoorsDefault.MaxSpeed = 4.25
HeroLocomotionDataChildIndoorsDefault.SprintSpeedMultiplier = 1.25
HeroLocomotionDataChildIndoorsDefault.SprintTerminationSpeedFraction = 0
HeroLocomotionDataChildIndoorsDefault.FrictionCoefficient = 4
HeroLocomotionDataChildIndoorsDefault.FrictionCoefficientSecondOrder = 4
HeroLocomotionDataChildIndoorsDefault.FrictionCoefficientLateral = 4
HeroLocomotionDataChildIndoorsDefault.MaxSpeedLateralStatic = 0.80000001192093
HeroLocomotionDataChildIndoorsDefault.MaxSpeedLateralRunning = 1.25
HeroLocomotionDataChildIndoorsDefault.AllowedToMoveBackwards = 0

HeroLocomotionDataStrafe = {}
HeroLocomotionDataStrafe.MinControlMagForMovement = 0.25
HeroLocomotionDataStrafe.MinControlMagForTurn = 0
HeroLocomotionDataStrafe.MinVelMagForMovement = 0.001
HeroLocomotionDataStrafe.MaxTurnSpeedStatic = 300
HeroLocomotionDataStrafe.MaxTurnSpeedRunning = 150
HeroLocomotionDataStrafe.MaxSpeed = 4.25
HeroLocomotionDataStrafe.SprintSpeedMultiplier = 1
HeroLocomotionDataStrafe.SprintTerminationSpeedFraction = 0
HeroLocomotionDataStrafe.FrictionCoefficient = 7
HeroLocomotionDataStrafe.FrictionCoefficientSecondOrder = 4
HeroLocomotionDataStrafe.FrictionCoefficientLateral = 7
HeroLocomotionDataStrafe.MaxSpeedLateralStatic = 4.25
HeroLocomotionDataStrafe.MaxSpeedLateralRunning = 4.25
HeroLocomotionDataStrafe.AllowedToMoveBackwards = 1

HeroLocomotionDataRanged = {}
HeroLocomotionDataRanged.MinControlMagForMovement = 0.25
HeroLocomotionDataRanged.MinControlMagForTurn = 0
HeroLocomotionDataRanged.MinVelMagForMovement = 0.001
HeroLocomotionDataRanged.MaxTurnSpeedStatic = 1200
HeroLocomotionDataRanged.MaxTurnSpeedRunning = 200
HeroLocomotionDataRanged.MaxSpeed = 4.5
HeroLocomotionDataRanged.SprintSpeedMultiplier = 1.45
HeroLocomotionDataRanged.SprintTerminationSpeedFraction = 0
HeroLocomotionDataRanged.FrictionCoefficient = 4
HeroLocomotionDataRanged.FrictionCoefficientSecondOrder = 4
HeroLocomotionDataRanged.FrictionCoefficientLateral = 4
HeroLocomotionDataRanged.MaxSpeedLateralStatic = 4.25
HeroLocomotionDataRanged.MaxSpeedLateralRunning = 4.25
HeroLocomotionDataRanged.AllowedToMoveBackwards = 1

HeroLocomotionDataRangedStrafe = {}
HeroLocomotionDataRangedStrafe.MinControlMagForMovement = 0.25
HeroLocomotionDataRangedStrafe.MinControlMagForTurn = 0
HeroLocomotionDataRangedStrafe.MinVelMagForMovement = 0.001
HeroLocomotionDataRangedStrafe.MaxTurnSpeedStatic = 300
HeroLocomotionDataRangedStrafe.MaxTurnSpeedRunning = 150
HeroLocomotionDataRangedStrafe.MaxSpeed = 4.25
HeroLocomotionDataRangedStrafe.SprintSpeedMultiplier = 1
HeroLocomotionDataRangedStrafe.SprintTerminationSpeedFraction = 0
HeroLocomotionDataRangedStrafe.FrictionCoefficient = 4
HeroLocomotionDataRangedStrafe.FrictionCoefficientSecondOrder = 4
HeroLocomotionDataRangedStrafe.FrictionCoefficientLateral = 4
HeroLocomotionDataRangedStrafe.MaxSpeedLateralStatic = 4.25
HeroLocomotionDataRangedStrafe.MaxSpeedLateralRunning = 4.25
HeroLocomotionDataRangedStrafe.AllowedToMoveBackwards = 1

HeroLocomotionDataRangedAimStrafe = {}
HeroLocomotionDataRangedAimStrafe.MinControlMagForMovement = 0.25
HeroLocomotionDataRangedAimStrafe.MinControlMagForTurn = 0
HeroLocomotionDataRangedAimStrafe.MinVelMagForMovement = 0.001
HeroLocomotionDataRangedAimStrafe.MaxTurnSpeedStatic = 720
HeroLocomotionDataRangedAimStrafe.MaxTurnSpeedRunning = 720
HeroLocomotionDataRangedAimStrafe.MaxSpeed = 2.25
HeroLocomotionDataRangedAimStrafe.SprintSpeedMultiplier = 1
HeroLocomotionDataRangedAimStrafe.SprintTerminationSpeedFraction = 0
HeroLocomotionDataRangedAimStrafe.FrictionCoefficient = 4
HeroLocomotionDataRangedAimStrafe.FrictionCoefficientSecondOrder = 4
HeroLocomotionDataRangedAimStrafe.FrictionCoefficientLateral = 4
HeroLocomotionDataRangedAimStrafe.MaxSpeedLateralStatic = 2.25
HeroLocomotionDataRangedAimStrafe.MaxSpeedLateralRunning = 2.25
HeroLocomotionDataRangedAimStrafe.AllowedToMoveBackwards = 1

HeroLocomotionDataChildStrafe = {}
HeroLocomotionDataChildStrafe.MinControlMagForMovement = 0.25
HeroLocomotionDataChildStrafe.MinControlMagForTurn = 0
HeroLocomotionDataChildStrafe.MinVelMagForMovement = 0.001
HeroLocomotionDataChildStrafe.MaxTurnSpeedStatic = 300
HeroLocomotionDataChildStrafe.MaxTurnSpeedRunning = 150
HeroLocomotionDataChildStrafe.MaxSpeed = 3.5
HeroLocomotionDataChildStrafe.SprintSpeedMultiplier = 1
HeroLocomotionDataChildStrafe.SprintTerminationSpeedFraction = 0
HeroLocomotionDataChildStrafe.FrictionCoefficient = 7
HeroLocomotionDataChildStrafe.FrictionCoefficientSecondOrder = 4
HeroLocomotionDataChildStrafe.FrictionCoefficientLateral = 7
HeroLocomotionDataChildStrafe.MaxSpeedLateralStatic = 3.5
HeroLocomotionDataChildStrafe.MaxSpeedLateralRunning = 3.5
HeroLocomotionDataChildStrafe.AllowedToMoveBackwards = 1

HeroLocomotionDataChildRanged = {}
HeroLocomotionDataChildRanged.MinControlMagForMovement = 0.25
HeroLocomotionDataChildRanged.MinControlMagForTurn = 0
HeroLocomotionDataChildRanged.MinVelMagForMovement = 0.001
HeroLocomotionDataChildRanged.MaxTurnSpeedStatic = 1200
HeroLocomotionDataChildRanged.MaxTurnSpeedRunning = 200
HeroLocomotionDataChildRanged.MaxSpeed = 3.5
HeroLocomotionDataChildRanged.SprintSpeedMultiplier = 1.4
HeroLocomotionDataChildRanged.SprintTerminationSpeedFraction = 0
HeroLocomotionDataChildRanged.FrictionCoefficient = 4
HeroLocomotionDataChildRanged.FrictionCoefficientSecondOrder = 4
HeroLocomotionDataChildRanged.FrictionCoefficientLateral = 4
HeroLocomotionDataChildRanged.MaxSpeedLateralStatic = 3.5
HeroLocomotionDataChildRanged.MaxSpeedLateralRunning = 3.5
HeroLocomotionDataChildRanged.AllowedToMoveBackwards = 1

HeroLocomotionDataChildRangedStrafe = {}
HeroLocomotionDataChildRangedStrafe.MinControlMagForMovement = 0.25
HeroLocomotionDataChildRangedStrafe.MinControlMagForTurn = 0
HeroLocomotionDataChildRangedStrafe.MinVelMagForMovement = 0.001
HeroLocomotionDataChildRangedStrafe.MaxTurnSpeedStatic = 300
HeroLocomotionDataChildRangedStrafe.MaxTurnSpeedRunning = 150
HeroLocomotionDataChildRangedStrafe.MaxSpeed = 3.5
HeroLocomotionDataChildRangedStrafe.SprintSpeedMultiplier = 1
HeroLocomotionDataChildRangedStrafe.SprintTerminationSpeedFraction = 0
HeroLocomotionDataChildRangedStrafe.FrictionCoefficient = 4
HeroLocomotionDataChildRangedStrafe.FrictionCoefficientSecondOrder = 4
HeroLocomotionDataChildRangedStrafe.FrictionCoefficientLateral = 4
HeroLocomotionDataChildRangedStrafe.MaxSpeedLateralStatic = 3.5
HeroLocomotionDataChildRangedStrafe.MaxSpeedLateralRunning = 3.5
HeroLocomotionDataChildRangedStrafe.AllowedToMoveBackwards = 1

-- HeroLocomotionStateAimIdle --
HeroLocomotionStateAimIdle = {}
HeroLocomotionStateAimIdle.Anim = {
	"Pose"
}
HeroLocomotionStateAimIdle.BlendInTime = 0.2
HeroLocomotionStateAimIdle.CombatState = ECombatState.COMBAT_STATE_NOT_SET
HeroLocomotionStateAimIdle.States = {
	"HeroLocomotionStateAimIdle"
}

-- HeroLocomotionStateHHIdle --
HeroLocomotionStateHHIdle = {}
HeroLocomotionStateHHIdle.Anim = {
	"Pose",
	"PoseLF",
    "PoseRF"
}
HeroLocomotionStateHHIdle.BlendInTime = 0.5
HeroLocomotionStateHHIdle.VelocityArea = {
	CVector3(-HeroLocomotionDataHandHoldingLeader.MinVelMagForMovement, -180, 0),
	CVector3(HeroLocomotionDataHandHoldingLeader.MinVelMagForMovement, 180, 0)
}
HeroLocomotionStateHHIdle.ControlArea = {
	CVector3(-HeroLocomotionDataHandHoldingLeader.MinControlMagForMovement, -180, 0),
	CVector3(1.05, 180, 0)
}
HeroLocomotionStateHHIdle.CombatState = ECombatState.COMBAT_STATE_NOT_SET
HeroLocomotionStateHHIdle.AnimBlendType = EAnimBlendType.ANIM_BLEND_MATCH_FOOTING
HeroLocomotionStateHHIdle.FootMatchType = EFootMatchType.FOOT_MATCH_RELATIVE
HeroLocomotionStateHHIdle.States = {
	"HeroLocomotionStateHHLocomoteWalk",
	"HeroLocomotionStateHHIdle"
}

-- HeroLocomotionStateHHLocomoteWalk --
HeroLocomotionStateHHLocomoteWalk = {}
HeroLocomotionStateHHLocomoteWalk.Anim = {
	"WalkSlow",
	"Walk",
	"Run",
	"Sprint"
}
HeroLocomotionStateHHLocomoteWalk.BlendInTime = 0.5
HeroLocomotionStateHHLocomoteWalk.VelocityArea = {
	CVector3(HeroLocomotionDataHandHoldingLeader.MinVelMagForMovement, -180, 0),
	CVector3(10, 180, 0)
}
HeroLocomotionStateHHLocomoteWalk.ControlArea = {
	CVector3(HeroLocomotionDataHandHoldingLeader.MinControlMagForMovement, -180, 0),
	CVector3(1.05, 180, 0)
}
HeroLocomotionStateHHLocomoteWalk.States = {
	"HeroLocomotionStateHHLocomoteWalk",
	"HeroLocomotionStateHHIdle"
}

-- HeroLocomotionStateHHDragIdle --
HeroLocomotionStateHHDragIdle = {}
HeroLocomotionStateHHDragIdle.Anim = {
    "PoseDrag"
}
HeroLocomotionStateHHDragIdle.BlendInTime = 0.5
HeroLocomotionStateHHDragIdle.VelocityArea = {
	CVector3(-HeroLocomotionDataHandHoldingLeaderDragging.MinVelMagForMovement, -180, 0),
	CVector3(HeroLocomotionDataHandHoldingLeaderDragging.MinVelMagForMovement, 180, 0)
}
HeroLocomotionStateHHDragIdle.ControlArea = {
	CVector3(-HeroLocomotionDataHandHoldingLeaderDragging.MinControlMagForMovement, -180, 0),
	CVector3(1.05, 180, 0)
}
HeroLocomotionStateHHDragIdle.CombatState = ECombatState.COMBAT_STATE_NOT_SET
HeroLocomotionStateHHDragIdle.AnimBlendType = EAnimBlendType.ANIM_BLEND_MATCH_FOOTING
HeroLocomotionStateHHDragIdle.FootMatchType = EFootMatchType.FOOT_MATCH_RELATIVE
HeroLocomotionStateHHDragIdle.States = {
	"HeroLocomotionStateHHDragLocomoteWalk",
	"HeroLocomotionStateHHDragIdle"
}

-- HeroLocomotionStateHHDragIdleIdle --
HeroLocomotionStateHHDragIdleIdle = {}
HeroLocomotionStateHHDragIdleIdle.Anim = {
    "Idle"
}
HeroLocomotionStateHHDragIdleIdle.IdleState = true
HeroLocomotionStateHHDragIdleIdle.BlendInTime = 0.2
HeroLocomotionStateHHDragIdleIdle.ValidTime = 5
HeroLocomotionStateHHDragIdleIdle.AllowLooking = false
HeroLocomotionStateHHDragIdleIdle.VelocityArea = {
	CVector3(-HeroLocomotionDataHandHoldingLeaderDragging.MinVelMagForMovement, -180, 0),
	CVector3(HeroLocomotionDataHandHoldingLeaderDragging.MinVelMagForMovement, 180, 0)
}
HeroLocomotionStateHHDragIdleIdle.ControlArea = {
	CVector3(-HeroLocomotionDataHandHoldingLeaderDragging.MinControlMagForMovement, -180, 0),
	CVector3(1.05, 180, 0)
}
HeroLocomotionStateHHDragIdleIdle.States = {
	"HeroLocomotionStateHHDragLocomoteWalk",
	"HeroLocomotionStateHHDragIdleIdle",
	"HeroLocomotionStateHHDragIdle"
}

-- HeroLocomotionStateHHDragLocomoteWalk --
HeroLocomotionStateHHDragLocomoteWalk = {}
HeroLocomotionStateHHDragLocomoteWalk.Anim = {
    "WalkDrag"
}
HeroLocomotionStateHHDragLocomoteWalk.BlendInTime = 0.5
HeroLocomotionStateHHDragLocomoteWalk.VelocityArea = {
	CVector3(HeroLocomotionDataHandHoldingLeaderDragging.MinVelMagForMovement, -180, 0),
	CVector3(10, 180, 0)
}
HeroLocomotionStateHHDragLocomoteWalk.ControlArea = {
	CVector3(HeroLocomotionDataHandHoldingLeaderDragging.MinControlMagForMovement, -180, 0),
	CVector3(1.05, 180, 0)
}
HeroLocomotionStateHHDragLocomoteWalk.States = {
	"HeroLocomotionStateHHDragLocomoteWalk",
	"HeroLocomotionStateHHDragIdle"
}

-- HeroLocomotionStateIdleIdle --
HeroLocomotionStateIdleIdle = {}
HeroLocomotionStateIdleIdle.Anim = {
    "Idle"
}
HeroLocomotionStateIdleIdle.IdleState = true
HeroLocomotionStateIdleIdle.BlendInTime = 0.2
HeroLocomotionStateIdleIdle.ValidTime = 2.25
HeroLocomotionStateIdleIdle.FootMatchCompareTolerance = 0.8
HeroLocomotionStateIdleIdle.AllowLooking = false
HeroLocomotionStateIdleIdle.AnimBlendType = EAnimBlendType.ANIM_BLEND_MATCH_FOOTING
HeroLocomotionStateIdleIdle.FootMatchType = EFootMatchType.FOOT_MATCH_RELATIVE
HeroLocomotionStateIdleIdle.CombatState = ECombatState.COMBAT_STATE_NOT_SET
HeroLocomotionStateIdleIdle.States = {
	"HeroLocomotionStateTurn90CW",
	"HeroLocomotionStateTurn90ACW",
	"HeroLocomotionStateTurn180",
	{"HeroLocomotionStateLocomoteRun", 0.25},
	{"HeroLocomotionStateLocomoteWalk", 0.25},
	"HeroLocomotionStateIdleIdle",
    "HeroLocomotionStateIdle"
}
HeroLocomotionStateIdleIdle.MovementParams = {}
HeroLocomotionStateIdleIdle.MovementParams.MaxSpeed = 1

-- HeroLocomotionStateIdle --
HeroLocomotionStateIdle = {}
HeroLocomotionStateIdle.Anim = {
	"Pose",
	"PoseLF",
	"PoseRF"
}
HeroLocomotionStateIdle.BlendInTime = 0.25
HeroLocomotionStateIdle.VelocityArea = {
	CVector3(-HeroLocomotionData.MinVelMagForMovement, -180, 0),
	CVector3(1.05, 180, 0)
}
HeroLocomotionStateIdle.ControlArea = {
	CVector3(-HeroLocomotionData.MinControlMagForMovement, -180, 0),
	CVector3(1.05, 180, 0)
}
HeroLocomotionStateIdle.CombatState = ECombatState.COMBAT_STATE_NOT_SET
HeroLocomotionStateIdle.AnimBlendType = EAnimBlendType.ANIM_BLEND_MATCH_FOOTING
HeroLocomotionStateIdle.FootMatchType = EFootMatchType.FOOT_MATCH_RELATIVE
HeroLocomotionStateIdle.States = {
	"HeroLocomotionStateTurn90CW",
	"HeroLocomotionStateTurn90ACW",
	"HeroLocomotionStateTurn180",
	{"HeroLocomotionStateLocomoteRun", 0.25},
	{"HeroLocomotionStateLocomoteWalk", 0.25},
	"HeroLocomotionStateIdleCombatPoseLF",
	"HeroLocomotionStateIdleCombatPoseRF",
	"HeroLocomotionStateIdleIdle",
    "HeroLocomotionStateIdle"
}

-- HeroLocomotionStateIdleCombatPoseLF --
HeroLocomotionStateIdleCombatPoseLF = {}
HeroLocomotionStateIdleCombatPoseLF.Anim = {
    "CombatPose"
}
HeroLocomotionStateIdleCombatPoseLF.BlendInTime = 0.2
HeroLocomotionStateIdleCombatPoseLF.CombatState = ECombatState.COMBAT_STATE_SET
HeroLocomotionStateIdleCombatPoseLF.Stance = EStance.STANCE_REGULAR
HeroLocomotionStateIdleCombatPoseLF.States = {
	"HeroLocomotionStateLocomoteRun",
	"HeroLocomotionStateLocomoteWalk",
	"HeroLocomotionStateIdleCombatPoseRF",
	"HeroLocomotionStateIdle"
}

-- HeroLocomotionStateIdleCombatPoseRF --
HeroLocomotionStateIdleCombatPoseRF = {}
HeroLocomotionStateIdleCombatPoseRF.Anim = {
    "CombatPoseGoofy"
}
HeroLocomotionStateIdleCombatPoseRF.BlendInTime = 0.2
HeroLocomotionStateIdleCombatPoseRF.CombatState = ECombatState.COMBAT_STATE_SET
HeroLocomotionStateIdleCombatPoseRF.Stance = EStance.STANCE_GOOFY
HeroLocomotionStateIdleCombatPoseRF.States = {
	"HeroLocomotionStateLocomoteRun",
	"HeroLocomotionStateLocomoteWalk",
	"HeroLocomotionStateIdleCombatPoseLF",
	"HeroLocomotionStateIdle"
}

-- HeroLocomotionStateLocomoteForwards --
HeroLocomotionStateLocomoteForwards = {}
HeroLocomotionStateLocomoteForwards.Anim = {
	"Sprint",
	"Run",
	"WalkSlow",
	"Walk"
}
HeroLocomotionStateLocomoteForwards.BlendInTime = 0.5
HeroLocomotionStateLocomoteForwards.VelocityArea = {
	CVector3(HeroLocomotionData.MinVelMagForMovement, -180, 0),
	CVector3(10, 180, 0)
}
HeroLocomotionStateLocomoteForwards.ControlArea = {
	CVector3(-HeroLocomotionData.MinControlMagForMovement, -180, 0),
	CVector3(1.05, 180, 0)
}
HeroLocomotionStateLocomoteForwards.States = {
	"HeroLocomotionStateRunTurn180",
	"HeroLocomotionStateLocomoteForwardsUphill",
	"HeroLocomotionStateLocomoteForwardsDownhill",
	"HeroLocomotionStateLocomoteForwardsConfinedLeft",
	"HeroLocomotionStateLocomoteForwardsConfinedRight",
	"HeroLocomotionStateLocomoteForwards",
	"HeroLocomotionStateIdleCombatPoseLF",
	"HeroLocomotionStateIdleCombatPoseRF",
	"HeroLocomotionStateIdle"
}

-- HeroLocomotionStateTurn90ACW --
HeroLocomotionStateTurn90ACW = {}
HeroLocomotionStateTurn90ACW.Anim = {
	"Turn90Left"
}
HeroLocomotionStateTurn90ACW.TransitionType = ETransitionType.TRANSITION_ROTATION
HeroLocomotionStateTurn90ACW.BlendInTime = 0.1
HeroLocomotionStateTurn90ACW.TargetFacingAngles = CVector3(-135, -45, 0)
HeroLocomotionStateTurn90ACW.TerminationTargetFacingAngles = CVector3(-135, -2, 0)
HeroLocomotionStateTurn90ACW.TerminationVelocityArea = {
	CVector3(-HeroLocomotionData.MinVelMagForMovement, -181, 0),
	CVector3(0.15, 181, 0)
}
HeroLocomotionStateTurn90ACW.States = {
	"HeroLocomotionStateTurn90CW",
	"HeroLocomotionStateTurn90ACW",
	"HeroLocomotionStateTurn180",
	"HeroLocomotionStateLocomoteRun",
	"HeroLocomotionStateLocomoteWalk",
	"HeroLocomotionStateIdle"
}

-- HeroLocomotionStateTurn90CW --
HeroLocomotionStateTurn90CW = {}
HeroLocomotionStateTurn90CW.Anim = {
	"Turn90Right"
}
HeroLocomotionStateTurn90CW.TransitionType = ETransitionType.TRANSITION_ROTATION
HeroLocomotionStateTurn90CW.BlendInTime = 0.1
HeroLocomotionStateTurn90CW.TargetFacingAngles = CVector3(45, 135, 0)
HeroLocomotionStateTurn90CW.TerminationTargetFacingAngles = CVector3(2, 135, 0)
HeroLocomotionStateTurn90CW.TerminationVelocityArea = {
	CVector3(-HeroLocomotionData.MinVelMagForMovement, -181, 0),
	CVector3(0.15, 181, 0)
}
HeroLocomotionStateTurn90CW.States = {
	"HeroLocomotionStateTurn90ACW",
	"HeroLocomotionStateTurn90CW",
	"HeroLocomotionStateTurn180",
	"HeroLocomotionStateLocomoteRun",
	"HeroLocomotionStateLocomoteWalk",
	"HeroLocomotionStateIdle"
}

-- HeroLocomotionStateTurn180 --
HeroLocomotionStateTurn180 = {}
HeroLocomotionStateTurn180.Anim = {
	"TurnLeft180Var003",
	"TurnRight180Var003"
}
HeroLocomotionStateTurn180.TransitionType = ETransitionType.TRANSITION_ROTATION
HeroLocomotionStateTurn180.BlendInTime = 0.1
HeroLocomotionStateTurn180.TargetFacingAngles = CVector3(135, 181, 0)
HeroLocomotionStateTurn180.TerminationTargetFacingAngles = CVector3(2, 181, 0)
HeroLocomotionStateTurn180.TerminationVelocityArea = {
	CVector3(-HeroLocomotionData.MinVelMagForMovement, -181, 0),
	CVector3(0.15, 181, 0)
}
HeroLocomotionStateTurn180.States = {
	"HeroLocomotionStateTurn180",
	"HeroLocomotionStateTurn90CW",
	"HeroLocomotionStateTurn90ACW",
	"HeroLocomotionStateLocomoteRun",
	"HeroLocomotionStateLocomoteWalk",
	"HeroLocomotionStateIdle"
}
HeroLocomotionStateTurn180.Symmetrical = true

-- HeroLocomotionStateRunTurn180 --
HeroLocomotionStateRunTurn180 = {}
HeroLocomotionStateRunTurn180.Anim = {
	"RunTurn180Left",
	"RunTurn180Right"
}
HeroLocomotionStateRunTurn180.BlendInTime = 0.125
HeroLocomotionStateRunTurn180.TransitionType = ETransitionType.TRANSITION_ROTATION
HeroLocomotionStateRunTurn180.VelocityArea = {
	CVector3(0.5, 0, 0),
	CVector3(10, 35, 0)
}
HeroLocomotionStateRunTurn180.ControlArea = {
	CVector3(-HeroLocomotionData.MinControlMagForMovement, 135, 0),
	CVector3(1.05, 180.1, 0)
}
HeroLocomotionStateRunTurn180.TerminationControlArea = {
	CVector3(-HeroLocomotionData.MinControlMagForMovement, 5, 0),
	CVector3(1.05, 181, 0)
}
HeroLocomotionStateRunTurn180.TerminationVelocityArea = {
	CVector3(-HeroLocomotionData.MinVelMagForMovement, 0, 0),
	CVector3(HeroLocomotionData.SprintSpeedMultiplier + 0.05, 181, 0)
}
HeroLocomotionStateRunTurn180.States = {
	"HeroLocomotionStateRunTurn180",
	"HeroLocomotionStateLocomoteRun",
	"HeroLocomotionStateLocomoteWalk",
	"HeroLocomotionStateIdleCombatPoseLF",
	"HeroLocomotionStateIdleCombatPoseRF",
	"HeroLocomotionStateIdle"
}
HeroLocomotionStateRunTurn180.MovementParams = {}
HeroLocomotionStateRunTurn180.MovementParams.MaxTurnSpeedStatic = 300
HeroLocomotionStateRunTurn180.MovementParams.MaxTurnSpeedRunning = 300
HeroLocomotionStateRunTurn180.MovementParams.FrictionCoefficient = 4
HeroLocomotionStateRunTurn180.MovementParams.FrictionCoefficientLateral = 4
HeroLocomotionStateRunTurn180.Symmetrical = true


-- HeroLocomotionStateLocomoteForwardsConfinedLeft --
HeroLocomotionStateLocomoteForwardsConfinedLeft = {}
HeroLocomotionStateLocomoteForwardsConfinedLeft.Anim = {
	"IdleConfinedGeneric",
	"WalkConfinedLeft",
	"RunConfinedLeft"
}
HeroLocomotionStateLocomoteForwardsConfinedLeft.Confinement = EConfinementType.CONFINED_LEFT
HeroLocomotionStateLocomoteForwardsConfinedLeft.AvailableToChild = false
HeroLocomotionStateLocomoteForwardsConfinedLeft.BlendInTime = 0.25
HeroLocomotionStateLocomoteForwardsConfinedLeft.ValidTime = 0.2
HeroLocomotionStateLocomoteForwardsConfinedLeft.VelocityArea = {
	CVector3(-HeroLocomotionData.MinVelMagForMovement, -45, 0),
	CVector3(1.05, 45, 0)
}
HeroLocomotionStateLocomoteForwardsConfinedLeft.ControlArea = {
	CVector3(HeroLocomotionData.MinControlMagForMovement, -45, 0),
	CVector3(1.05, 45, 0)
}
HeroLocomotionStateLocomoteForwardsConfinedLeft.States = {
	"HeroLocomotionStateLocomoteForwardsConfinedLeft",
	"HeroLocomotionStateLocomoteForwardsConfinedRight",
	"HeroLocomotionStateLocomoteForwards",
	"HeroLocomotionStateIdleCombatPoseLF",
	"HeroLocomotionStateIdleCombatPoseRF",
	"HeroLocomotionStateIdle"
}

-- HeroLocomotionStateLocomoteForwardsConfinedRight --
HeroLocomotionStateLocomoteForwardsConfinedRight = {}
HeroLocomotionStateLocomoteForwardsConfinedRight.Anim = {
	"IdleConfinedGeneric",
	"WalkConfinedRight",
	"RunConfinedRight"
}
HeroLocomotionStateLocomoteForwardsConfinedRight.Confinement = EConfinementType.CONFINED_RIGHT
HeroLocomotionStateLocomoteForwardsConfinedRight.AvailableToChild = false
HeroLocomotionStateLocomoteForwardsConfinedRight.BlendInTime = 0.25
HeroLocomotionStateLocomoteForwardsConfinedRight.ValidTime = 0.2
HeroLocomotionStateLocomoteForwardsConfinedRight.VelocityArea = {
	CVector3(-HeroLocomotionData.MinVelMagForMovement, -45, 0),
	CVector3(1.05, 45, 0)
}
HeroLocomotionStateLocomoteForwardsConfinedRight.ControlArea = {
	CVector3(HeroLocomotionData.MinControlMagForMovement, -45, 0),
	CVector3(1.05, 45, 0)
}
HeroLocomotionStateLocomoteForwardsConfinedRight.States = {
	"HeroLocomotionStateLocomoteForwardsConfinedRight",
	"HeroLocomotionStateLocomoteForwardsConfinedLeft",
	"HeroLocomotionStateLocomoteForwards",
	"HeroLocomotionStateIdleCombatPoseLF",
	"HeroLocomotionStateIdleCombatPoseRF",
	"HeroLocomotionStateIdle"
}

-- HeroLocomotionStateLocomoteForwardsUphill --
HeroLocomotionStateLocomoteForwardsUphill = {}
HeroLocomotionStateLocomoteForwardsUphill.Anim = {
	"Pose",
	"WalkUphill",
	"RunUphill"
}
HeroLocomotionStateLocomoteForwardsUphill.BlendInTime = 0.125
HeroLocomotionStateLocomoteForwardsUphill.FootMatchType = EFootMatchType.FOOT_MATCH_ABSOLUTE
HeroLocomotionStateLocomoteForwardsUphill.VerticalVelocityRange = CVector3(0.2, 2, 0)
HeroLocomotionStateLocomoteForwardsUphill.TerminationVerticalVelocityRange = CVector3(0.1, 2, 0)
HeroLocomotionStateLocomoteForwardsUphill.VelocityArea = {
	CVector3(-HeroLocomotionData.MinVelMagForMovement, -180, 0),
	CVector3(1.15, 180.1, 0)
}
HeroLocomotionStateLocomoteForwardsUphill.ControlArea = {
	CVector3(HeroLocomotionData.MinControlMagForMovement, -90, 0),
	CVector3(1.05, 90, 0)
}
HeroLocomotionStateLocomoteForwardsUphill.States = {
	"HeroLocomotionStateRunTurn180",
	"HeroLocomotionStateLocomoteForwardsUphill",
	"HeroLocomotionStateLocomoteForwards",
	"HeroLocomotionStateIdle"
}

-- HeroLocomotionStateLocomoteForwardsDownhill --
HeroLocomotionStateLocomoteForwardsDownhill = {}
HeroLocomotionStateLocomoteForwardsDownhill.Anim = {
	"Pose",
	"WalkDownhill",
	"RunDownhill"
}
HeroLocomotionStateLocomoteForwardsDownhill.BlendInTime = 0.125
HeroLocomotionStateLocomoteForwardsDownhill.FootMatchType = EFootMatchType.FOOT_MATCH_ABSOLUTE
HeroLocomotionStateLocomoteForwardsDownhill.VerticalVelocityRange = CVector3(-2, -0.2, 0)
HeroLocomotionStateLocomoteForwardsDownhill.TerminationVerticalVelocityRange = CVector3(-2, -0.1, 0)
HeroLocomotionStateLocomoteForwardsDownhill.VelocityArea = {
	CVector3(-HeroLocomotionData.MinVelMagForMovement, -180.1, 0),
	CVector3(1.05, 180.1, 0)
}
HeroLocomotionStateLocomoteForwardsDownhill.ControlArea = {
	CVector3(HeroLocomotionData.MinControlMagForMovement, -90, 0),
	CVector3(1.05, 90, 0)
}
HeroLocomotionStateLocomoteForwardsDownhill.States = {
	"HeroLocomotionStateRunTurn180",
	"HeroLocomotionStateLocomoteForwardsDownhill",
	"HeroLocomotionStateLocomoteForwards",
	"HeroLocomotionStateIdle"
}

-- HeroLocomotionStateStrafeIdle --
HeroLocomotionStateStrafeIdle = {}
HeroLocomotionStateStrafeIdle.Anim = {
	"CombatPose"
}
HeroLocomotionStateStrafeIdle.AllowLooking = false
HeroLocomotionStateStrafeIdle.BlendInTime = 0.25
HeroLocomotionStateStrafeIdle.BlendOutTime = 0.5
HeroLocomotionStateStrafeIdle.Stance = EStance.STANCE_REGULAR
HeroLocomotionStateStrafeIdle.CombatState = ECombatState.COMBAT_STATE_SET
HeroLocomotionStateStrafeIdle.VelocityArea = {
	CVector3(-HeroLocomotionData.MinVelMagForMovement, -180, 0),
	CVector3(1, 180, 0)
}
HeroLocomotionStateStrafeIdle.ControlArea = {
	CVector3(-HeroLocomotionData.MinControlMagForMovement, -180, 0),
	CVector3(0.05, 180, 0)
}
HeroLocomotionStateStrafeIdle.States = {
	"HeroLocomotionStateStrafeForward",
	"HeroLocomotionStateStrafeLeft",
	"HeroLocomotionStateStrafeRight",
	"HeroLocomotionStateStrafeBack",
	"HeroLocomotionStateStrafeForwardRF",
	"HeroLocomotionStateStrafeLeftRF",
	"HeroLocomotionStateStrafeRightRF",
	"HeroLocomotionStateStrafeBackRF",
	"HeroLocomotionStateStrafeTransitionToRF",
	"HeroLocomotionStateStrafeIdle"
}

-- HeroLocomotionStateStrafeIdleRF --
HeroLocomotionStateStrafeIdleRF = {}
HeroLocomotionStateStrafeIdleRF.Anim = {
	"CombatPoseGoofy"
}
HeroLocomotionStateStrafeIdleRF.AllowLooking = false
HeroLocomotionStateStrafeIdleRF.BlendInTime = 0.25
HeroLocomotionStateStrafeIdleRF.BlendOutTime = 0.5
HeroLocomotionStateStrafeIdleRF.Stance = EStance.STANCE_GOOFY
HeroLocomotionStateStrafeIdleRF.CombatState = ECombatState.COMBAT_STATE_SET
HeroLocomotionStateStrafeIdleRF.VelocityArea = {
	CVector3(-HeroLocomotionData.MinVelMagForMovement, -180, 0),
	CVector3(1, 180, 0)
}
HeroLocomotionStateStrafeIdleRF.ControlArea = {
	CVector3(-HeroLocomotionData.MinControlMagForMovement, -180, 0),
	CVector3(0.05, 180, 0)
}
HeroLocomotionStateStrafeIdleRF.States = {
	"HeroLocomotionStateStrafeForwardRF",
	"HeroLocomotionStateStrafeLeftRF",
	"HeroLocomotionStateStrafeRightRF",
	"HeroLocomotionStateStrafeBackRF",
	"HeroLocomotionStateStrafeForward",
	"HeroLocomotionStateStrafeLeft",
	"HeroLocomotionStateStrafeRight",
	"HeroLocomotionStateStrafeBack",
	"HeroLocomotionStateStrafeTransitionToLF",
	"HeroLocomotionStateStrafeIdleRF"
}

-- HeroLocomotionStateStrafeTransitionToRF --
HeroLocomotionStateStrafeTransitionToRF = {}
HeroLocomotionStateStrafeTransitionToRF.Anim = {
	"CombatPoseGoofy"
}
HeroLocomotionStateStrafeTransitionToRF.BlendInTime = 0.25
HeroLocomotionStateStrafeTransitionToRF.Stance = EStance.STANCE_GOOFY
HeroLocomotionStateStrafeTransitionToRF.CombatState = ECombatState.COMBAT_STATE_SET
HeroLocomotionStateStrafeTransitionToRF.VelocityArea = {
	CVector3(-HeroLocomotionData.MinVelMagForMovement, -180, 0),
	CVector3(0.05, 180, 0)
}
HeroLocomotionStateStrafeTransitionToRF.ControlArea = {
	CVector3(-HeroLocomotionData.MinControlMagForMovement, -180, 0),
	CVector3(0.05, 180, 0)
}
HeroLocomotionStateStrafeTransitionToRF.States = {
	"HeroLocomotionStateStrafeIdleRF",
	"HeroLocomotionStateStrafeForwardRF",
	"HeroLocomotionStateStrafeLeftRF",
	"HeroLocomotionStateStrafeRightRF",
	"HeroLocomotionStateStrafeBackRF",
	"HeroLocomotionStateStrafeForward",
	"HeroLocomotionStateStrafeLeft",
	"HeroLocomotionStateStrafeRight",
	"HeroLocomotionStateStrafeBack",
	"HeroLocomotionStateStrafeIdle"
}

-- HeroLocomotionStateStrafeTransitionToLF --
HeroLocomotionStateStrafeTransitionToLF = {}
HeroLocomotionStateStrafeTransitionToLF.Anim = {
	"CombatPose"
}
HeroLocomotionStateStrafeTransitionToLF.BlendInTime = 0.25
HeroLocomotionStateStrafeTransitionToLF.Stance = EStance.STANCE_REGULAR
HeroLocomotionStateStrafeTransitionToLF.CombatState = ECombatState.COMBAT_STATE_SET
HeroLocomotionStateStrafeTransitionToLF.VelocityArea = {
	CVector3(-HeroLocomotionData.MinVelMagForMovement, -180, 0),
	CVector3(0.05, 180, 0)
}
HeroLocomotionStateStrafeTransitionToLF.ControlArea = {
	CVector3(-HeroLocomotionData.MinControlMagForMovement, -180, 0),
	CVector3(0.05, 180, 0)
}
HeroLocomotionStateStrafeTransitionToLF.States = {
	"HeroLocomotionStateStrafeIdle",
	"HeroLocomotionStateStrafeForward",
	"HeroLocomotionStateStrafeLeft",
	"HeroLocomotionStateStrafeRight",
	"HeroLocomotionStateStrafeBack",
	"HeroLocomotionStateStrafeForwardRF",
	"HeroLocomotionStateStrafeLeftRF",
	"HeroLocomotionStateStrafeRightRF",
	"HeroLocomotionStateStrafeBackRF",
	"HeroLocomotionStateStrafeIdleRF"
}

-- HeroLocomotionStateStrafeForward --
HeroLocomotionStateStrafeForward = {}
HeroLocomotionStateStrafeForward.Anim = {
	"CombatStrafeForwardsSlow",
	"CombatStrafeForwards"
}
HeroLocomotionStateStrafeForward.BlendInTime = 0.25
HeroLocomotionStateStrafeForward.AllowLooking = false
HeroLocomotionStateStrafeForward.CombatState = ECombatState.COMBAT_STATE_SET
HeroLocomotionStateStrafeForward.Stance = EStance.STANCE_REGULAR
HeroLocomotionStateStrafeForward.VelocityArea = {
	CVector3(HeroLocomotionData.MinVelMagForMovement, -180, 0),
	CVector3(1.05, 180, 0)
}
HeroLocomotionStateStrafeForward.ControlArea = {
	CVector3(HeroLocomotionData.MinControlMagForMovement, -45, 0),
	CVector3(1.05, 45, 0)
}
HeroLocomotionStateStrafeForward.States = {
	"HeroLocomotionStateStrafeForward",
	"HeroLocomotionStateStrafeLeft",
	"HeroLocomotionStateStrafeRight",
	"HeroLocomotionStateStrafeBack",
	"HeroLocomotionStateStrafeIdle",
	"HeroLocomotionStateStrafeLeftRF",
	"HeroLocomotionStateStrafeRightRF",
	"HeroLocomotionStateStrafeBackRF",
	"HeroLocomotionStateStrafeIdleRF"
}

-- HeroLocomotionStateStrafeLeft --
HeroLocomotionStateStrafeLeft = {}
HeroLocomotionStateStrafeLeft.Anim = {
	"CombatStrafeLeftSlow",
	"CombatStrafeLeft"
}
HeroLocomotionStateStrafeLeft.BlendInTime = 0.25
HeroLocomotionStateStrafeLeft.AllowLooking = false
HeroLocomotionStateStrafeLeft.CombatState = ECombatState.COMBAT_STATE_SET
HeroLocomotionStateStrafeLeft.Stance = EStance.STANCE_REGULAR
HeroLocomotionStateStrafeLeft.VelocityArea = {
	CVector3(HeroLocomotionData.MinVelMagForMovement, -180, 0),
	CVector3(1.05, 180, 0)
}
HeroLocomotionStateStrafeLeft.ControlArea = {
	CVector3(HeroLocomotionData.MinControlMagForMovement, -135, 0),
	CVector3(1.05, -45, 0)
}
HeroLocomotionStateStrafeLeft.States = {
	"HeroLocomotionStateStrafeLeft",
	"HeroLocomotionStateStrafeForward",
	"HeroLocomotionStateStrafeRight",
	"HeroLocomotionStateStrafeBack",
	"HeroLocomotionStateStrafeIdle",
	"HeroLocomotionStateStrafeForwardRF",
	"HeroLocomotionStateStrafeRightRF",
	"HeroLocomotionStateStrafeBackRF",
	"HeroLocomotionStateStrafeIdleRF"
}

-- HeroLocomotionStateStrafeRight --
HeroLocomotionStateStrafeRight = {}
HeroLocomotionStateStrafeRight.Anim = {
	"CombatStrafeRightSlow",
	"CombatStrafeRight"
}
HeroLocomotionStateStrafeRight.BlendInTime = 0.25
HeroLocomotionStateStrafeRight.AllowLooking = false
HeroLocomotionStateStrafeRight.CombatState = ECombatState.COMBAT_STATE_SET
HeroLocomotionStateStrafeRight.Stance = EStance.STANCE_REGULAR
HeroLocomotionStateStrafeRight.VelocityArea = {
	CVector3(HeroLocomotionData.MinVelMagForMovement, -180, 0),
	CVector3(1.05, 180, 0)
}
HeroLocomotionStateStrafeRight.ControlArea = {
	CVector3(HeroLocomotionData.MinControlMagForMovement, 45, 0),
	CVector3(1.05, 135, 0)
}
HeroLocomotionStateStrafeRight.States = {
	"HeroLocomotionStateStrafeRight",
	"HeroLocomotionStateStrafeForward",
	"HeroLocomotionStateStrafeLeft",
	"HeroLocomotionStateStrafeBack",
	"HeroLocomotionStateStrafeIdle",
	"HeroLocomotionStateStrafeForwardRF",
	"HeroLocomotionStateStrafeLeftRF",
	"HeroLocomotionStateStrafeBackRF",
	"HeroLocomotionStateStrafeIdleRF"
}

-- HeroLocomotionStateStrafeBack --
HeroLocomotionStateStrafeBack = {}
HeroLocomotionStateStrafeBack.Anim = {
	"CombatStrafeBackwardsSlow",
	"CombatStrafeBackwards"
}
HeroLocomotionStateStrafeBack.BlendInTime = 0.25
HeroLocomotionStateStrafeBack.AllowLooking = false
HeroLocomotionStateStrafeBack.CombatState = ECombatState.COMBAT_STATE_SET
HeroLocomotionStateStrafeBack.Stance = EStance.STANCE_REGULAR
HeroLocomotionStateStrafeBack.VelocityArea = {
	CVector3(HeroLocomotionData.MinVelMagForMovement, -180, 0),
	CVector3(1.05, 180, 0)
}
HeroLocomotionStateStrafeBack.ControlArea = {
	CVector3(HeroLocomotionData.MinControlMagForMovement, 135, 0),
	CVector3(1.05, 225, 0)
}
HeroLocomotionStateStrafeBack.States = {
	"HeroLocomotionStateStrafeBack",
	"HeroLocomotionStateStrafeForward",
	"HeroLocomotionStateStrafeLeft",
	"HeroLocomotionStateStrafeRight",
	"HeroLocomotionStateStrafeIdle",
	"HeroLocomotionStateStrafeForwardRF",
	"HeroLocomotionStateStrafeLeftRF",
	"HeroLocomotionStateStrafeRightRF",
	"HeroLocomotionStateStrafeIdleRF"
}

-- HeroLocomotionStateStrafeForwardRF --
HeroLocomotionStateStrafeForwardRF = {}
HeroLocomotionStateStrafeForwardRF.Anim = {
	"CombatStrafeForwardsGoofySlow",
	"CombatStrafeForwardsGoofy"
}
HeroLocomotionStateStrafeForwardRF.BlendInTime = 0.25
HeroLocomotionStateStrafeForwardRF.AllowLooking = false
HeroLocomotionStateStrafeForwardRF.CombatState = ECombatState.COMBAT_STATE_SET
HeroLocomotionStateStrafeForwardRF.Stance = EStance.STANCE_GOOFY
HeroLocomotionStateStrafeForwardRF.VelocityArea = {
	CVector3(HeroLocomotionData.MinVelMagForMovement, -180, 0),
	CVector3(1.05, 180, 0)
}
HeroLocomotionStateStrafeForwardRF.ControlArea = {
	CVector3(HeroLocomotionData.MinControlMagForMovement, -45, 0),
	CVector3(1.05, 45, 0)
}
HeroLocomotionStateStrafeForwardRF.States = {
	"HeroLocomotionStateStrafeForwardRF",
	"HeroLocomotionStateStrafeLeftRF",
	"HeroLocomotionStateStrafeRightRF",
	"HeroLocomotionStateStrafeBackRF",
	"HeroLocomotionStateStrafeIdleRF",
	"HeroLocomotionStateStrafeLeft",
	"HeroLocomotionStateStrafeRight",
	"HeroLocomotionStateStrafeBack",
	"HeroLocomotionStateStrafeIdle"
}

-- HeroLocomotionStateStrafeLeftRF --
HeroLocomotionStateStrafeLeftRF = {}
HeroLocomotionStateStrafeLeftRF.Anim = {
	"CombatStrafeLeftGoofySlow",
	"CombatStrafeLeftGoofy"
}
HeroLocomotionStateStrafeLeftRF.BlendInTime = 0.25
HeroLocomotionStateStrafeLeftRF.AllowLooking = false
HeroLocomotionStateStrafeLeftRF.CombatState = ECombatState.COMBAT_STATE_SET
HeroLocomotionStateStrafeLeftRF.Stance = EStance.STANCE_GOOFY
HeroLocomotionStateStrafeLeftRF.VelocityArea = {
	CVector3(HeroLocomotionData.MinVelMagForMovement, -180, 0),
	CVector3(1.05, 180, 0)
}
HeroLocomotionStateStrafeLeftRF.ControlArea = {
	CVector3(HeroLocomotionData.MinControlMagForMovement, -135, 0),
	CVector3(1.05, -45, 0)
}
HeroLocomotionStateStrafeLeftRF.States = {
	"HeroLocomotionStateStrafeLeftRF",
	"HeroLocomotionStateStrafeForwardRF",
	"HeroLocomotionStateStrafeRightRF",
	"HeroLocomotionStateStrafeBackRF",
	"HeroLocomotionStateStrafeIdleRF",
	"HeroLocomotionStateStrafeForward",
	"HeroLocomotionStateStrafeRight",
	"HeroLocomotionStateStrafeBack",
	"HeroLocomotionStateStrafeIdle"
}

-- HeroLocomotionStateStrafeRightRF --
HeroLocomotionStateStrafeRightRF = {}
HeroLocomotionStateStrafeRightRF.Anim = {
	"CombatStrafeRightGoofySlow",
	"CombatStrafeRightGoofy"
}
HeroLocomotionStateStrafeRightRF.BlendInTime = 0.25
HeroLocomotionStateStrafeRightRF.AllowLooking = false
HeroLocomotionStateStrafeRightRF.CombatState = ECombatState.COMBAT_STATE_SET
HeroLocomotionStateStrafeRightRF.Stance = EStance.STANCE_GOOFY
HeroLocomotionStateStrafeRightRF.VelocityArea = {
	CVector3(HeroLocomotionData.MinVelMagForMovement, -180, 0),
	CVector3(1.05, 180, 0)
}
HeroLocomotionStateStrafeRightRF.ControlArea = {
	CVector3(HeroLocomotionData.MinControlMagForMovement, 45, 0),
	CVector3(1.05, 135, 0)
}
HeroLocomotionStateStrafeRightRF.States = {
	"HeroLocomotionStateStrafeRightRF",
	"HeroLocomotionStateStrafeForwardRF",
	"HeroLocomotionStateStrafeLeftRF",
	"HeroLocomotionStateStrafeBackRF",
	"HeroLocomotionStateStrafeIdleRF",
	"HeroLocomotionStateStrafeForward",
	"HeroLocomotionStateStrafeLeft",
	"HeroLocomotionStateStrafeBack",
	"HeroLocomotionStateStrafeIdle"
}

-- HeroLocomotionStateStrafeBackRF --
HeroLocomotionStateStrafeBackRF = {}
HeroLocomotionStateStrafeBackRF.Anim = {
	"CombatStrafeBackwardsGoofySlow",
	"CombatStrafeBackwardsGoofy"
}
HeroLocomotionStateStrafeBackRF.BlendInTime = 0.25
HeroLocomotionStateStrafeBackRF.AllowLooking = false
HeroLocomotionStateStrafeBackRF.CombatState = ECombatState.COMBAT_STATE_SET
HeroLocomotionStateStrafeBackRF.Stance = EStance.STANCE_GOOFY
HeroLocomotionStateStrafeBackRF.VelocityArea = {
	CVector3(HeroLocomotionData.MinVelMagForMovement, -180, 0),
	CVector3(1.05, 180, 0)
}
HeroLocomotionStateStrafeBackRF.ControlArea = {
	CVector3(HeroLocomotionData.MinControlMagForMovement, 135, 0),
	CVector3(1.05, 225, 0)
}
HeroLocomotionStateStrafeBackRF.States = {
	"HeroLocomotionStateStrafeBackRF",
	"HeroLocomotionStateStrafeForwardRF",
	"HeroLocomotionStateStrafeLeftRF",
	"HeroLocomotionStateStrafeRightRF",
	"HeroLocomotionStateStrafeIdleRF",
	"HeroLocomotionStateStrafeForward",
	"HeroLocomotionStateStrafeLeft",
	"HeroLocomotionStateStrafeRight",
	"HeroLocomotionStateStrafeIdle"
}

-- HeroLocomotionStateStrafeRightCrossedToBack --
HeroLocomotionStateStrafeRightCrossedToBack = {}
HeroLocomotionStateStrafeRightCrossedToBack.Anim = {
	"CombatStrafeTransitionRightCrossedLFToBackwards"
}
HeroLocomotionStateStrafeRightCrossedToBack.BlendInTime = 0.1
HeroLocomotionStateStrafeRightCrossedToBack.TransitionType = ETransitionType.TRANSITION_MATCH_FOOTING
HeroLocomotionStateStrafeRightCrossedToBack.FeetMatchPoseTolerance = 0.1
HeroLocomotionStateStrafeRightCrossedToBack.FootMatchType = EFootMatchType.FOOT_MATCH_RELATIVE
HeroLocomotionStateStrafeRightCrossedToBack.CombatState = ECombatState.COMBAT_STATE_SET
HeroLocomotionStateStrafeRightCrossedToBack.Symmetrical = true
HeroLocomotionStateStrafeRightCrossedToBack.VelocityArea = {
	CVector3(-HeroLocomotionData.MinVelMagForMovement, -180, 0),
	CVector3(1.05, 180, 0)
}
HeroLocomotionStateStrafeRightCrossedToBack.ControlArea = {
	CVector3(HeroLocomotionData.MinControlMagForMovement, 135, 0),
	CVector3(1.05, 180.1, 0)
}
HeroLocomotionStateStrafeRightCrossedToBack.States = {
	"HeroLocomotionStateStrafeForward",
	"HeroLocomotionStateStrafeLeft",
	"HeroLocomotionStateStrafeRight",
	"HeroLocomotionStateStrafeBack",
	"HeroLocomotionStateStrafeIdle",
	"HeroLocomotionStateStrafeForwardRF",
	"HeroLocomotionStateStrafeLeftRF",
	"HeroLocomotionStateStrafeRightRF",
	"HeroLocomotionStateStrafeBackRF",
	"HeroLocomotionStateStrafeIdleRF"
}

-- HeroLocomotionStateStrafeLeftCrossedToForward --
HeroLocomotionStateStrafeLeftCrossedToForward = {}
HeroLocomotionStateStrafeLeftCrossedToForward.Anim = {
	"CombatStrafeTransitionLeftCrossedLFToForwards"
}
HeroLocomotionStateStrafeLeftCrossedToForward.BlendInTime = 0.1
HeroLocomotionStateStrafeLeftCrossedToForward.TransitionType = ETransitionType.TRANSITION_MATCH_FOOTING
HeroLocomotionStateStrafeLeftCrossedToForward.FeetMatchPoseTolerance = 0.1
HeroLocomotionStateStrafeLeftCrossedToForward.FootMatchType = EFootMatchType.FOOT_MATCH_RELATIVE
HeroLocomotionStateStrafeLeftCrossedToForward.CombatState = ECombatState.COMBAT_STATE_SET
HeroLocomotionStateStrafeLeftCrossedToForward.VelocityArea = {
	CVector3(-HeroLocomotionData.MinVelMagForMovement, -180, 0),
	CVector3(1.05, 180, 0)
}
HeroLocomotionStateStrafeLeftCrossedToForward.ControlArea = {
	CVector3(HeroLocomotionData.MinControlMagForMovement, -45, 0),
	CVector3(1.05, 45, 0)
}
HeroLocomotionStateStrafeLeftCrossedToForward.States = {
	"HeroLocomotionStateStrafeForward",
	"HeroLocomotionStateStrafeLeft",
	"HeroLocomotionStateStrafeRight",
	"HeroLocomotionStateStrafeBack",
	"HeroLocomotionStateStrafeIdle",
	"HeroLocomotionStateStrafeForwardRF",
	"HeroLocomotionStateStrafeLeftRF",
	"HeroLocomotionStateStrafeRightRF",
	"HeroLocomotionStateStrafeBackRF",
	"HeroLocomotionStateStrafeIdleRF"
}

-- HeroLocomotionStateStrafeRightCrossedToForwardRF --
HeroLocomotionStateStrafeRightCrossedToForwardRF = {}
HeroLocomotionStateStrafeRightCrossedToForwardRF.Anim = {
	"CombatStrafeRightCrossedIntoStrafeForwardsRF"
}
HeroLocomotionStateStrafeRightCrossedToForwardRF.BlendInTime = 0.1
HeroLocomotionStateStrafeRightCrossedToForwardRF.TransitionType = ETransitionType.TRANSITION_MATCH_FOOTING
HeroLocomotionStateStrafeRightCrossedToForwardRF.FeetMatchPoseTolerance = 0.1
HeroLocomotionStateStrafeRightCrossedToForwardRF.FootMatchType = EFootMatchType.FOOT_MATCH_RELATIVE
HeroLocomotionStateStrafeRightCrossedToForwardRF.CombatState = ECombatState.COMBAT_STATE_SET
HeroLocomotionStateStrafeRightCrossedToForwardRF.Stance = EStance.STANCE_GOOFY
HeroLocomotionStateStrafeRightCrossedToForwardRF.VelocityArea = {
	CVector3(-HeroLocomotionData.MinVelMagForMovement, -180, 0),
	CVector3(1.05, 180, 0)
}
HeroLocomotionStateStrafeRightCrossedToForwardRF.ControlArea = {
	CVector3(HeroLocomotionData.MinControlMagForMovement, -45, 0),
	CVector3(1.05, 45, 0)
}
HeroLocomotionStateStrafeRightCrossedToForwardRF.States = {
	"HeroLocomotionStateStrafeForwardRF",
	"HeroLocomotionStateStrafeLeftRF",
	"HeroLocomotionStateStrafeRightRF",
	"HeroLocomotionStateStrafeBackRF",
	"HeroLocomotionStateStrafeIdleRF",
	"HeroLocomotionStateStrafeForward",
	"HeroLocomotionStateStrafeLeft",
	"HeroLocomotionStateStrafeRight",
	"HeroLocomotionStateStrafeBack",
	"HeroLocomotionStateStrafeIdle"
}

-- HeroLocomotionStateStrafeRightCrossedToBackRF --
HeroLocomotionStateStrafeRightCrossedToBackRF = {}
HeroLocomotionStateStrafeRightCrossedToBackRF.Anim = {
	"CombatStrafeRightCrossedIntoStrafeBackwardsRF"
}
HeroLocomotionStateStrafeRightCrossedToBackRF.BlendInTime = 0.1
HeroLocomotionStateStrafeRightCrossedToBackRF.TransitionType = ETransitionType.TRANSITION_MATCH_FOOTING
HeroLocomotionStateStrafeRightCrossedToBackRF.FeetMatchPoseTolerance = 0.1
HeroLocomotionStateStrafeRightCrossedToBackRF.FootMatchType = EFootMatchType.FOOT_MATCH_RELATIVE
HeroLocomotionStateStrafeRightCrossedToBackRF.CombatState = ECombatState.COMBAT_STATE_SET
HeroLocomotionStateStrafeRightCrossedToBackRF.Stance = EStance.STANCE_GOOFY
HeroLocomotionStateStrafeRightCrossedToBackRF.VelocityArea = {
	CVector3(-HeroLocomotionData.MinVelMagForMovement, -180, 0),
	CVector3(1.05, 180, 0)
}
HeroLocomotionStateStrafeRightCrossedToBackRF.ControlArea = {
	CVector3(HeroLocomotionData.MinControlMagForMovement, 135, 0),
	CVector3(1.05, 180.1, 0)
}
HeroLocomotionStateStrafeRightCrossedToBackRF.States = {
	"HeroLocomotionStateStrafeForwardRF",
	"HeroLocomotionStateStrafeLeftRF",
	"HeroLocomotionStateStrafeRightRF",
	"HeroLocomotionStateStrafeBackRF",
	"HeroLocomotionStateStrafeIdleRF",
	"HeroLocomotionStateStrafeForward",
	"HeroLocomotionStateStrafeLeft",
	"HeroLocomotionStateStrafeRight",
	"HeroLocomotionStateStrafeBack",
	"HeroLocomotionStateStrafeIdle"
}

-- NPCLocomotionStateIdle --
NPCLocomotionStateIdle = {}
NPCLocomotionStateIdle.Anim = {
	"Pose"
}
NPCLocomotionStateIdle.BlendInTime = 0.5
NPCLocomotionStateIdle.VelocityArea = {
	CVector3(-HeroLocomotionDataHandHoldingDefault.MinVelMagForMovement, -180, 0),
	CVector3(1.05, 180, 0)
}
NPCLocomotionStateIdle.ControlArea = {
	CVector3(-HeroLocomotionDataHandHoldingDefault.MinControlMagForMovement, -180, 0),
	CVector3(1.05, 180, 0)
}
NPCLocomotionStateIdle.States = {
	"NPCLocomotionStateLocomoteForwards",
	"NPCLocomotionStateIdle"
}

-- NPCLocomotionStateLocomoteForwards --
NPCLocomotionStateLocomoteForwards = {}
NPCLocomotionStateLocomoteForwards.Anim = {
	"Walk",
	"HeroLocoRun"
}
NPCLocomotionStateLocomoteForwards.BlendInTime = 0.5
NPCLocomotionStateLocomoteForwards.VelocityArea = {
	CVector3(HeroLocomotionDataHandHoldingDefault.MinVelMagForMovement, -180, 0),
	CVector3(10, 180, 0)
}
NPCLocomotionStateLocomoteForwards.ControlArea = {
	CVector3(-HeroLocomotionDataHandHoldingDefault.MinControlMagForMovement, -180, 0),
	CVector3(1.05, 180, 0)
}
NPCLocomotionStateLocomoteForwards.States = {
	"NPCLocomotionStateLocomoteForwards",
	"NPCLocomotionStateIdle"
}

-- NPCLocomotionStateDraggedIdleIdle --
NPCLocomotionStateDraggedIdleIdle = {}
NPCLocomotionStateDraggedIdleIdle.Anim = {
	"IdleDragged"
}
NPCLocomotionStateDraggedIdleIdle.IdleState = true
NPCLocomotionStateDraggedIdleIdle.BlendInTime = 0.2
NPCLocomotionStateDraggedIdleIdle.ValidTime = 3
NPCLocomotionStateDraggedIdleIdle.VelocityArea = {
	CVector3(-HeroLocomotionDataHandHoldingDefault.MinVelMagForMovement, -180, 0),
	CVector3(1.05, 180, 0)
}
NPCLocomotionStateDraggedIdleIdle.ControlArea = {
	CVector3(-HeroLocomotionDataHandHoldingDefault.MinControlMagForMovement, -180, 0),
	CVector3(1.05, 180, 0)
}
NPCLocomotionStateDraggedIdleIdle.States = {
	"NPCLocomotionStateDraggedLocomoteForwards",
	"NPCLocomotionStateDraggedIdleIdle",
	"NPCLocomotionStateDraggedIdle"
}

-- NPCLocomotionStateDraggedIdle --
NPCLocomotionStateDraggedIdle = {}
NPCLocomotionStateDraggedIdle.Anim = {
	"PoseDragged"
}
NPCLocomotionStateDraggedIdle.BlendInTime = 0.5
NPCLocomotionStateDraggedIdle.VelocityArea = {
	CVector3(-HeroLocomotionDataHandHoldingDefault.MinVelMagForMovement, -180, 0),
	CVector3(1.05, 180, 0)
}
NPCLocomotionStateDraggedIdle.ControlArea = {
	CVector3(-HeroLocomotionDataHandHoldingDefault.MinControlMagForMovement, -180, 0),
	CVector3(1.05, 180, 0)
}
NPCLocomotionStateDraggedIdle.States = {
	"NPCLocomotionStateDraggedLocomoteForwards",
	"NPCLocomotionStateDraggedIdleIdle",
	"NPCLocomotionStateDraggedIdle"
}

-- NPCLocomotionStateDraggedLocomoteForwards --
NPCLocomotionStateDraggedLocomoteForwards = {}
NPCLocomotionStateDraggedLocomoteForwards.Anim = {
	"WalkDragged"
}
NPCLocomotionStateDraggedLocomoteForwards.BlendInTime = 0.5
NPCLocomotionStateDraggedLocomoteForwards.VelocityArea = {
	CVector3(HeroLocomotionDataHandHoldingDefault.MinVelMagForMovement, -180, 0),
	CVector3(10, 180, 0)
}
NPCLocomotionStateDraggedLocomoteForwards.ControlArea = {
	CVector3(-HeroLocomotionDataHandHoldingDefault.MinControlMagForMovement, -180, 0),
	CVector3(1.05, 180, 0)
}
NPCLocomotionStateDraggedLocomoteForwards.States = {
	"NPCLocomotionStateDraggedLocomoteForwards",
	"NPCLocomotionStateDraggedIdle"
}

-- HeroLocomotionStateLocomoteWalk --
HeroLocomotionStateLocomoteWalk = {}
HeroLocomotionStateLocomoteWalk.Anim = {
	"WalkSlow",
	"Walk",
	"WalkFast"
}
HeroLocomotionStateLocomoteWalk.BlendInTime = 0.25
HeroLocomotionStateLocomoteWalk.VelocityArea = {
	CVector3(HeroLocomotionData.MinVelMagForMovement, -180, 0),
	CVector3(0.85, 180, 0)
}
HeroLocomotionStateLocomoteWalk.ControlArea = {
	CVector3(HeroLocomotionData.MinControlMagForMovement, -60, 0),
	CVector3(1.05, 60, 0)
}
HeroLocomotionStateLocomoteWalk.States = {
	{"HeroLocomotionStateLocomoteRun", 0.25},
	"HeroLocomotionStateLocomoteWalk",
	"HeroLocomotionStateIdleCombatPoseLF",
	"HeroLocomotionStateIdleCombatPoseRF",
	{"HeroLocomotionStateIdle", 0.15},
	{"HeroLocomotionStateTurn180IntoRun", 0.25}
}

-- HeroLocomotionStateLocomoteJog --
HeroLocomotionStateLocomoteJog = {}
HeroLocomotionStateLocomoteJog.Anim = {
	"Jog"
}
HeroLocomotionStateLocomoteJog.BlendInTime = 0.5
HeroLocomotionStateLocomoteJog.VelocityArea = {
	CVector3(0.25, -180, 0),
	CVector3(0.5, 180, 0)
}
HeroLocomotionStateLocomoteJog.ControlArea = {
	CVector3(HeroLocomotionData.MinControlMagForMovement, -180, 0),
	CVector3(1.05, 180, 0)
}
HeroLocomotionStateLocomoteJog.States = {
	{"HeroLocomotionStateLocomoteRun", 0.125},
	"HeroLocomotionStateLocomoteJog",
	{"HeroLocomotionStateLocomoteWalk", 0.125},
	"HeroLocomotionStateIdleCombatPoseLF",
	"HeroLocomotionStateIdleCombatPoseRF",
	{"HeroLocomotionStateIdle", 0.25}
}

-- HeroLocomotionStateLocomoteRun --
HeroLocomotionStateLocomoteRun = {}
HeroLocomotionStateLocomoteRun.Anim = {
	"Run",
	"Sprint"
}
HeroLocomotionStateLocomoteRun.BlendInTime = 0.1
HeroLocomotionStateLocomoteRun.VelocityArea = {
	CVector3(0.84, -180, 0),
	CVector3(10, 180, 0)
}
HeroLocomotionStateLocomoteRun.ControlArea = {
	CVector3(HeroLocomotionData.MinControlMagForMovement, -60, 0),
	CVector3(1.05, 60, 0)
}
HeroLocomotionStateLocomoteRun.States = {
	"HeroLocomotionStateRunTurn180",
	"HeroLocomotionStateLocomoteRun",
	{"HeroLocomotionStateLocomoteWalk", 0.25},
	{"HeroLocomotionStateIdleCombatPoseLF", 0.2},
	{"HeroLocomotionStateIdleCombatPoseRF", 0.2},
	{"HeroLocomotionStateIdle", 0.2}
}

-- HeroLocomotionStateRegister --
HeroLocomotionStateRegister = {
	"HeroLocomotionStateIdle",
	"HeroLocomotionStateIdleIdle",
	"HeroLocomotionStateIdleCombatPoseLF",
	"HeroLocomotionStateIdleCombatPoseRF",
	"HeroLocomotionStateLocomoteWalk",
	"HeroLocomotionStateLocomoteRun",
	"HeroLocomotionStateLocomoteJog",
	"HeroLocomotionStateLocomoteForwards",
	"HeroLocomotionStateLocomoteForwardsUphill",
	"HeroLocomotionStateLocomoteForwardsDownhill",
	"HeroLocomotionStateLocomoteForwardsConfinedLeft",
	"HeroLocomotionStateLocomoteForwardsConfinedRight",
	"HeroLocomotionStateTurn90CW",
	"HeroLocomotionStateTurn90ACW",
	"HeroLocomotionStateTurn180",
	"HeroLocomotionStateRunTurn180",
	"HeroLocomotionStateAimIdle",
	"HeroLocomotionStateStrafeIdle",
	"HeroLocomotionStateStrafeIdleRF",
	"HeroLocomotionStateStrafeTransitionToRF",
	"HeroLocomotionStateStrafeTransitionToLF",
	"HeroLocomotionStateStrafeForward",
	"HeroLocomotionStateStrafeLeft",
	"HeroLocomotionStateStrafeRight",
	"HeroLocomotionStateStrafeBack",
	"HeroLocomotionStateStrafeForwardRF",
	"HeroLocomotionStateStrafeLeftRF",
	"HeroLocomotionStateStrafeRightRF",
	"HeroLocomotionStateStrafeBackRF",
	"HeroLocomotionStateStrafeLeftCrossedToForward",
	"HeroLocomotionStateStrafeRightCrossedToBack",
	"HeroLocomotionStateStrafeRightCrossedToForwardRF",
	"HeroLocomotionStateStrafeRightCrossedToBackRF",
	"NPCLocomotionStateIdle",
	"NPCLocomotionStateLocomoteForwards",
	"NPCLocomotionStateDraggedIdleIdle",
	"NPCLocomotionStateDraggedIdle",
	"NPCLocomotionStateDraggedLocomoteForwards",
	"HeroLocomotionStateHHIdle",
	"HeroLocomotionStateHHLocomoteWalk",
	"HeroLocomotionStateHHDragIdle",
	"HeroLocomotionStateHHDragIdleIdle",
	"HeroLocomotionStateHHDragLocomoteWalk"
}



-- uncomment for debug
-- GUI.DisplayMessageBox("herolocomotionstates.lua successfully loaded!")
-- while (GUI.IsDisplayBoxActive()) do
	-- coroutine.yield()
-- end
