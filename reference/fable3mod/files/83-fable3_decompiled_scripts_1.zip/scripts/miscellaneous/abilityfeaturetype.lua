EAbilityFeatureType = {}
EAbilityFeatureType.EAF_NONE = 0
EAbilityFeatureType.EAF_BUSINESS_PARTNERSHIP = 1
EAbilityFeatureType.EAF_LIVE_MARRIAGE = 2
EAbilityFeatureType.EAF_RELATIONSHIP_FRIENDS = 3
EAbilityFeatureType.EAF_RELATIONSHIP_LOVE = 4
EAbilityFeatureType.EAF_HOUSE_RENTING = 5
EAbilityFeatureType.EAF_HOUSE_BUYING = 6
EAbilityFeatureType.EAF_HOUSE_DECORATION = 7
EAbilityFeatureType.EAF_NPC_MARRIAGE = 8
EAbilityFeatureType.EAF_ADOPTION = 9
EAbilityFeatureType.EAF_CHILDREN = 10
EAbilityFeatureType.EAF_STEALING = 11
EAbilityFeatureType.EAF_SAFETY_MODE = 12
EAbilityFeatureType.EAF_HAND_HOLDING = 13
EAbilityFeatureType.EAF_HAGGLING = 14
EAbilityFeatureType.EAF_SHOP_BUYING = 15
EAbilityFeatureType.EAF_NUM_ABILITIES = 16

















