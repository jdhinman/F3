EAppearanceDescription = {}
EAppearanceDescription.EAD_FAT = 0
EAppearanceDescription.EAD_STRONG = 1
EAppearanceDescription.EAD_THIN = 2
EAppearanceDescription.EAD_BALD = 3
EAppearanceDescription.EAD_FACIALHAIR = 4
EAppearanceDescription.EAD_BEARD = 5
EAppearanceDescription.EAD_CLEANSHAVEN = 6
EAppearanceDescription.EAD_TATOOED = 7
EAppearanceDescription.EAD_GLASSES = 8
EAppearanceDescription.EAD_MONOCLE = 9
EAppearanceDescription.EAD_TALLHAT = 10
EAppearanceDescription.EAD_BUXOM = 11
EAppearanceDescription.EAD_PRETTY = 12
EAppearanceDescription.EAD_HANDSOME = 13
EAppearanceDescription.EAD_UGLY = 14
EAppearanceDescription.EAD_POSHCLOTHING = 15
EAppearanceDescription.EAD_POORCLOTHING = 16
EAppearanceDescription.EAD_BACKPACK = 17
EAppearanceDescription.EAD_MAX = 18



















