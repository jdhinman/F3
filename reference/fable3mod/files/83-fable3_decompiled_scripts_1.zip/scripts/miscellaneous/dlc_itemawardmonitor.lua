--clean for reasons..
QuestManager.NewQuestThread("DLC_ItemAwardMonitor")

function DLC_ItemAwardMonitor:Init()
	-- IsDLCMonitorScript = true
	-- Item = DLC_ItemGivingThreadBase:new()
	
	-- DLC_ItemGivingThread = {}
	-- Item:DLC_ItemGivingThread.ParentQuest(StartNewThread)
	
	-- QuestManager.AddQuestThread(DLC_ItemGivingThread, QuestManager.UpdateLists.MAIN_GAME)
	-- QuestManager.AddQuestThread(DLC_ItemGivingThread, QuestManager.UpdateLists.GUI)
	
	-- PendingItems = {}
	
end

function DLC_ItemAwardMonitor:Update()

	
end

function DLC_ItemAwardMonitor:WaitForCheckMessage()

end

function DLC_ItemAwardMonitor:SetOfferIDs()

end

function DLC_ItemAwardMonitor:WaitForOffersTable()

end

function DLC_ItemAwardMonitor:ProcessOffersTable()

end

QuestManager.NewQuestThread("DLC_ItemGivingThreadBase")

function DLC_ItemGivingThreadBase:Init()

end

function DLC_ItemGivingThreadBase:Update()

end

DLC_ItemAwardHelperFunctions = {}
DLC_ItemAwardHelperFunctions.CanGiveAnything = function()

end
DLC_ItemAwardHelperFunctions.CanGiveMeleeWeapons = function()

end
DLC_ItemAwardHelperFunctions.CanGiveRangedWeapons = function()

end
DLC_ItemAwardHelperFunctions.CanGiveClothing = function()

end
DLC_ItemAwardHelperFunctions.CanGiveDyes = function()

end
DLC_ItemAwardHelperFunctions.CanGivePotions = function()

end
DLC_ItemAwardHelperFunctions.GiveItemWithName_GiftQueue = function()

end
DLC_ItemAwardHelperFunctions.GiveItemWithName_InventoryDirect = function()

end




