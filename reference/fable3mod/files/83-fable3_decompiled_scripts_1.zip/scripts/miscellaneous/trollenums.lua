ETrollHealthStatus = {}
ETrollHealthStatus.TROLL_HEALTH_STATUS_100 = 0
ETrollHealthStatus.TROLL_HEALTH_STATUS_50 = 1
ETrollHealthStatus.TROLL_HEALTH_STATUS_25 = 2
ETrollHealthStatus.TROLL_HEALTH_STATUS_0 = 3

ETrollWeakSpotStatus = {}
ETrollWeakSpotStatus.WEAK_SPOT_STATUS_100 = 0
ETrollWeakSpotStatus.WEAK_SPOT_STATUS_50 = 1
ETrollWeakSpotStatus.WEAK_SPOT_STATUS_25 = 2
