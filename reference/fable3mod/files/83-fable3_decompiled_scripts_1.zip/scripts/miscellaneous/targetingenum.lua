ETargetImportance = {}
ETargetImportance.TI_INVALID = -1
ETargetImportance.TI_NORMAL = 0
ETargetImportance.TI_HIGH = 1
ETargetImportance.TI_HIGHEST = 2
