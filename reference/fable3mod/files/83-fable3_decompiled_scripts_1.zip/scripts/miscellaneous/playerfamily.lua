EFamilyState = {}
EFamilyState.EFS_NORMAL = 0
EFamilyState.EFS_ALMOSTWANTSDIVORCE = 1
EFamilyState.EFS_WANTSDIVORCE = 2
EFamilyState.EFS_WANTSSEX = 3
EFamilyState.EFS_HASGIFT = 4
