RumbleValues = {}
RumbleValues.LowStrength = 0.3
RumbleValues.MedStrength = 0.5
RumbleValues.HighStrength = 0.8

Player.LoadRumbleEventData = (
	{
		Event = ERumbleEvents.RUMBLE_EVENT_RANGED_NEW_TARGET,
		Smoothness = 0.5,
		MaxLevel = 0.3,
		AttackTime = 0,
		DecayTime = 0.25,
		Duration = 0.2,
		ID = ERumbleTypes.RUMBLE_TYPE_GENERIC,
		Additive = false
	}
)
Player.LoadRumbleEventData = (
	{
		Event = ERumbleEvents.RUMBLE_EVENT_RANGED_NEW_SUBTARGET,
		Smoothness = 1,
		MaxLevel = 0.3,
		AttackTime = 0,
		DecayTime = 0.25,
		Duration = 0.2,
		ID = ERumbleTypes.RUMBLE_TYPE_GENERIC,
		Additive = false
	}
)
Player.LoadRumbleEventData = (
	{
		Event = ERumbleEvents.RUMBLE_EVENT_RANGED_BUILD_PER_FRAME,
		Smoothness = 0,
		MaxLevel = 0,
		AttackTime = 0,
		DecayTime = 0,
		Duration = 0,
		ID = ERumbleTypes.RUMBLE_TYPE_PLAYER_CHARGING,
		Additive = true
	}
)
Player.LoadRumbleEventData = (
	{
		Event = ERumbleEvents.RUMBLE_EVENT_RANGED_SUBTARGET_LOCK_ON,
		Smoothness = 1,
		MaxLevel = 0.3,
		AttackTime = 0,
		DecayTime = 0.25,
		Duration = 0.2,
		ID = ERumbleTypes.RUMBLE_TYPE_GENERIC,
		Additive = false
	}
)
Player.LoadRumbleEventData = (
	{
		Event = ERumbleEvents.RUMBLE_EVENT_MELEE_IMPACT,
		Smoothness = 0,
		MaxLevel = 0,
		AttackTime = 0,
		DecayTime = 0,
		Duration = 0,
		ID = ERumbleTypes.RUMBLE_TYPE_GENERIC,
		Additive = false
	}
)
Player.LoadRumbleEventData = (
	{
		Event = ERumbleEvents.RUMBLE_EVENT_HIT_BY_ATTACK,
		Smoothness = 0.5,
		MaxLevel = 1,
		AttackTime = 0,
		DecayTime = 0.4,
		Duration = 0.2,
		ID = ERumbleTypes.RUMBLE_TYPE_GENERIC,
		Additive = false
	}
)
Player.LoadRumbleEventData = (
	{
		Event = ERumbleEvents.RUMBLE_EVENT_BLOCKING_ATTACK,
		Smoothness = 0.7,
		MaxLevel = 0.3,
		AttackTime = 0,
		DecayTime = 0.15000000596046,
		Duration = 0.25,
		ID = ERumbleTypes.RUMBLE_TYPE_GENERIC,
		Additive = false
	}
)
Player.LoadRumbleEventData = (
	{
		Event = ERumbleEvents.RUMBLE_EVENT_START_FLOURISH,
		Smoothness = 0.5,
		MaxLevel = 0.5,
		AttackTime = 0.35,
		DecayTime = 1,
		Duration = 0.5,
		ID = ERumbleTypes.RUMBLE_TYPE_PLAYER_RANGED_FLOURISH,
		Additive = false
	}
)
Player.LoadRumbleEventData = (
	{
		Event = ERumbleEvents.RUMBLE_EVENT_FLOURISH_PER_FRAME,
		Smoothness = 0.2,
		MaxLevel = 0.07,
		AttackTime = 0,
		DecayTime = 0.5,
		Duration = 0.25,
		ID = ERumbleTypes.RUMBLE_TYPE_PLAYER_RANGED_FLOURISH,
		Additive = true
		MaxAdditive = 0.3
	}
)
Player.LoadRumbleEventData = (
	{
		Event = ERumbleEvents.RUMBLE_EVENT_RANGED_FLOURISH_PER_FRAME,
		Smoothness = 0.2,
		MaxLevel = 0.07,
		AttackTime = 0.25,
		DecayTime = 0.5,
		Duration = 0.25,
		ID = ERumbleTypes.RUMBLE_TYPE_PLAYER_RANGED_FLOURISH,
		Additive = true,
		MaxAdditive = 0.3
	}
)
Player.LoadRumbleEventData = (
	{
		Event = ERumbleEvents.RUMBLE_EVENT_RANGED_FLOURISH_FULLY_CHARGED_PER_FR,
		Smoothness = 0.2,
		MaxLevel = 0.07,
		AttackTime = 0.25,
		DecayTime = 0.5,
		Duration = 0.25,
		ID = ERumbleTypes.RUMBLE_TYPE_PLAYER_RANGED_FLOURISH,
		Additive = true,
		MaxAdditive = 0.6
	}
)
Player.LoadRumbleEventData = (
	{
		Event = ERumbleEvents.RUMBLE_EVENT_SHOOT_PISTOL,
		Smoothness = 0.5,
		MaxLevel = 0.2,
		AttackTime = 0.2,
		DecayTime = 0.05,
		Duration = 0.2,
		ID = ERumbleTypes.RUMBLE_TYPE_GENERIC,
		Additive = false
	}
)
Player.LoadRumbleEventData = (
	{
		Event = ERumbleEvents.RUMBLE_EVENT_SHOOT_PISTOL_AIMED,
		Smoothness = 0.5,
		MaxLevel = 0.2,
		AttackTime = 0.2,
		DecayTime = 0.05,
		Duration = 0.2,
		ID = ERumbleTypes.RUMBLE_TYPE_GENERIC,
		Additive = false
	}
)
Player.LoadRumbleEventData = (
	{
		Event = ERumbleEvents.RUMBLE_EVENT_SHOOT_RIFLE,
		Smoothness = 0.5,
		MaxLevel = 0.5,
		AttackTime = 0.2,
		DecayTime = 0.05,
		Duration = 0.2,
		ID = ERumbleTypes.RUMBLE_TYPE_GENERIC,
		Additive = false
	}
)
Player.LoadRumbleEventData = (
	{
		Event = ERumbleEvents.RUMBLE_EVENT_SHOOT_RIFLE_AIMED,
		Smoothness = 0.5,
		MaxLevel = 0.5,
		AttackTime = 0.2,
		DecayTime = 0.05,
		Duration = 0.2,
		ID = ERumbleTypes.RUMBLE_TYPE_GENERIC,
		Additive = false
	}
)
Player.LoadRumbleEventData = (
	{
		Event = ERumbleEvents.RUMBLE_EVENT_SHOOT_CROSSBOW,
		Smoothness = 0.7,
		MaxLevel = 0.2,
		AttackTime = 0.2,
		DecayTime = 0.25,
		Duration = 0.2,
		ID = ERumbleTypes.RUMBLE_TYPE_GENERIC,
		Additive = false
	}
)
Player.LoadRumbleEventData = (
	{
		Event = ERumbleEvents.RUMBLE_EVENT_SHOOT_CROSSBOW_AIMED,
		Smoothness = 0.7,
		MaxLevel = 0.2,
		AttackTime = 0.2,
		DecayTime = 0.25,
		Duration = 0.2,
		ID = ERumbleTypes.RUMBLE_TYPE_GENERIC,
		Additive = false
	}
)
Player.LoadRumbleEventData = (
	{
		Event = ERumbleEvents.RUMBLE_EVENT_SHOOT_BLUNDERBUSS,
		Smoothness = 0.5,
		MaxLevel = 0.8,
		AttackTime = 0.2,
		DecayTime = 0.5,
		Duration = 0.2,
		ID = ERumbleTypes.RUMBLE_TYPE_GENERIC,
		Additive = false
	}
)
Player.LoadRumbleEventData = (
	{
		Event = ERumbleEvents.RUMBLE_EVENT_SHOOT_BLUNDERBUSS_AIMED,
		Smoothness = 0.5,
		MaxLevel = 0.8,
		AttackTime = 0.2,
		DecayTime = 0.5,
		Duration = 0.2,
		ID = ERumbleTypes.RUMBLE_TYPE_GENERIC,
		Additive = false
	}
)
Player.LoadRumbleEventData = (
	{
		Event = ERumbleEvents.RUMBLE_EVENT_SPELL_CHARGE_1,
		Smoothness = 0.1,
		MaxLevel = 0.1,
		AttackTime = 0.05,
		DecayTime = 0.2,
		Duration = 0.3,
		ID = ERumbleTypes.RUMBLE_TYPE_GENERIC,
		Additive = false
	}
)
Player.LoadRumbleEventData = (
	{
		Event = ERumbleEvents.RUMBLE_EVENT_SPELL_CHARGE_2,
		Smoothness = 0.1,
		MaxLevel = 0.3,
		AttackTime = 0.05,
		DecayTime = 0.2,
		Duration = 0.3,
		ID = ERumbleTypes.RUMBLE_TYPE_GENERIC,
		Additive = false
	}
)
Player.LoadRumbleEventData = (
	{
		Event = ERumbleEvents.RUMBLE_EVENT_SPELL_CHARGE_3,
		Smoothness = 0.1,
		MaxLevel = 0.5,
		AttackTime = 0.05,
		DecayTime = 0.2,
		Duration = 0.3,
		ID = ERumbleTypes.RUMBLE_TYPE_GENERIC,
		Additive = false
	}
)
Player.LoadRumbleEventData = (
	{
		Event = ERumbleEvents.RUMBLE_EVENT_SPELL_CHARGE_4,
		Smoothness = 0.1,
		MaxLevel = 0.7,
		AttackTime = 0.05,
		DecayTime = 0.2,
		Duration = 0.3,
		ID = ERumbleTypes.RUMBLE_TYPE_GENERIC,
		Additive = false
	}
)
Player.LoadRumbleEventData = (
	{
		Event = ERumbleEvents.RUMBLE_EVENT_SPELL_CHARGE_5,
		Smoothness = 0.1,
		MaxLevel = 0.9,
		AttackTime = 0.05,
		DecayTime = 0.2,
		Duration = 0.3,
		ID = ERumbleTypes.RUMBLE_TYPE_GENERIC,
		Additive = false
	}
)
Player.LoadRumbleEventData = (
	{
		Event = ERumbleEvents.RUMBLE_EVENT_SPELL_UNLEASH_1,
		Smoothness = 0.01,
		MaxLevel = 0.2,
		AttackTime = 0.05,
		DecayTime = 0.5,
		Duration = 1.5,
		ID = ERumbleTypes.RUMBLE_TYPE_GENERIC,
		Additive = false
	}
)
Player.LoadRumbleEventData = (
	{
		Event = ERumbleEvents.RUMBLE_EVENT_SPELL_UNLEASH_2,
		Smoothness = 0.01,
		MaxLevel = 0.4,
		AttackTime = 0.05,
		DecayTime = 0.8,
		Duration = 1.7,
		ID = ERumbleTypes.RUMBLE_TYPE_GENERIC,
		Additive = false
	}
)
Player.LoadRumbleEventData = (
	{
		Event = ERumbleEvents.RUMBLE_EVENT_SPELL_UNLEASH_3,
		Smoothness = 0.01,
		MaxLevel = 0.6,
		AttackTime = 0.05,
		DecayTime = 1,
		Duration = 1.8999999761581,
		ID = ERumbleTypes.RUMBLE_TYPE_GENERIC,
		Additive = false
	}
)
Player.LoadRumbleEventData = (
	{
		Event = ERumbleEvents.RUMBLE_EVENT_SPELL_UNLEASH_4,
		Smoothness = 0.01,
		MaxLevel = 0.8,
		AttackTime = 0.05,
		DecayTime = 1.3,
		Duration = 2,
		ID = ERumbleTypes.RUMBLE_TYPE_GENERIC,
		Additive = false
	}
)
Player.LoadRumbleEventData = (
	{
		Event = ERumbleEvents.RUMBLE_EVENT_SPELL_UNLEASH_5,
		Smoothness = 0.01,
		MaxLevel = 1,
		AttackTime = 0.05,
		DecayTime = 1.5,
		Duration = 2.2,
		ID = ERumbleTypes.RUMBLE_TYPE_GENERIC,
		Additive = false
	}
)
Player.LoadRumbleEventData = (
	{
		Event = ERumbleEvents.RUMBLE_EVENT_SPELL_ASSASSIN_RUSH,
		Smoothness = 0.9,
		MaxLevel = 0.21,
		AttackTime = 0.2,
		DecayTime = 2.5,
		Duration = 0.2,
		ID = ERumbleTypes.RUMBLE_TYPE_GENERIC,
		Additive = false
	}
)
Player.LoadRumbleEventData = (
	{
		Event = ERumbleEvents.RUMBLE_EVENT_LANDING_WATER,
		Smoothness = 0.1,
		MaxLevel = 1,
		AttackTime = 0,
		DecayTime = 1.5,
		Duration = 0.5,
		ID = ERumbleTypes.RUMBLE_TYPE_GENERIC,
		Additive = false
	}
)
Player.LoadRumbleEventData = (
	{
		Event = ERumbleEvents.RUMBLE_EVENT_LANDING_LIGHT,
		Smoothness = 0.8,
		MaxLevel = 0.3,
		AttackTime = 0,
		DecayTime = 0.3,
		Duration = 0.3,
		ID = ERumbleTypes.RUMBLE_TYPE_GENERIC,
		Additive = false
	}
)
Player.LoadRumbleEventData = (
	{
		Event = ERumbleEvents.RUMBLE_EVENT_LANDING_HEAVY,
		Smoothness = 0.1,
		MaxLevel = 0.9,
		AttackTime = 0,
		DecayTime = 0.5,
		Duration = 0.3,
		ID = ERumbleTypes.RUMBLE_TYPE_GENERIC,
		Additive = false
	}
)
Player.LoadRumbleEventData = (
	{
		Event = ERumbleEvents.RUMBLE_EVENT_HEARTBEAT_NEAR_DEATH,
		Smoothness = 0.5,
		MaxLevel = 0.5,
		AttackTime = 0.25,
		DecayTime = 0.25,
		Duration = 0.5,
		ID = ERumbleTypes.RUMBLE_TYPE_GENERIC,
		Additive = false
	}
)
Player.LoadRumbleEventData = (
	{
		Event = ERumbleEvents.RUMBLE_EVENT_SUCCESSFUL_EXPRESSION,
		Smoothness = 0.5,
		MaxLevel = 0.3,
		AttackTime = 0.05,
		DecayTime = 0.05,
		Duration = 0.2,
		ID = ERumbleTypes.RUMBLE_TYPE_GENERIC,
		Additive = false
	}
)
Player.LoadRumbleEventData = (
	{
		Event = ERumbleEvents.RUMBLE_EVENT_ORB_SUCK,
		Smoothness = 0.9,
		MaxLevel = 0.35,
		AttackTime = 0,
		DecayTime = 0.01,
		Duration = 0.090000003576279,
		ID = ERumbleTypes.RUMBLE_TYPE_PLAYER_CHARGING,
		Additive = true
	}
)
Player.LoadRumbleEventData = (
	{
		Event = ERumbleEvents.RUMBLE_EVENT_ORB_SUCK_POWER_UP,
		Smoothness = 0.5,
		MaxLevel = 0.7,
		AttackTime = 0,
		DecayTime = 0,
		Duration = 0.1,
		ID = ERumbleTypes.RUMBLE_TYPE_PLAYER_CHARGING,
		Additive = true
	}
)
Player.LoadRumbleEventData = (
	{
		Event = ERumbleEvents.RUMBLE_EVENT_BANGING_ON_FORT_DOOR,
		Smoothness = 0.1,
		MaxLevel = 0.9,
		AttackTime = 0,
		DecayTime = 0.5,
		Duration = 0.3,
		ID = ERumbleTypes.RUMBLE_TYPE_GENERIC,
		Additive = false
	}
)
Player.LoadRumbleEventData = (
	{
		Event = ERumbleEvents.RUMBLE_EVENT_KICK_DOOR_IN,
		Smoothness = 0.1,
		MaxLevel = 1,
		AttackTime = 0.1,
		Duration = 0.5,
		DecayTime = 0.1,
		ID = ERumbleTypes.RUMBLE_TYPE_GENERIC,
		Additive = false
	}
)
Player.LoadRumbleEventData = (
	{
		Event = ERumbleEvents.RUMBLE_EVENT_KICK_DOOR_LANDING,
		Smoothness = 0.1,
		MaxLevel = 1,
		AttackTime = 0.1,
		Duration = 1,
		DecayTime = 0.8,
		ID = ERumbleTypes.RUMBLE_TYPE_GENERIC,
		Additive = false
	}
)
Player.LoadRumbleEventData = (
	{
		Event = ERumbleEvents.RUMBLE_EVENT_CAGE_RASING,
		Smoothness = 0.5,
		MaxLevel = 0.3,
		AttackTime = 0.1,
		Duration = 8,
		DecayTime = 4,
		ID = ERumbleTypes.RUMBLE_TYPE_GENERIC,
		Additive = false
	}
)
Player.LoadRumbleEventData = (
	{
		Event = ERumbleEvents.RUMBLE_EVENT_TAKING_THE_SEAL,
		Smoothness = 0.1,
		MaxLevel = 0.9,
		AttackTime = 0.1,
		DecayTime = 2,
		Duration = 6,
		ID = ERumbleTypes.RUMBLE_TYPE_GENERIC,
		Additive = false
	}
)
Player.LoadRumbleEventData = (
	{
		Event = ERumbleEvents.RUMBLE_EVENT_SENTINEL_FOOTSTEP,
		Smoothness = 0.5,
		MaxLevel = 0.3,
		AttackTime = 0,
		DecayTime = 0.3,
		Duration = 0.3,
		ID = ERumbleTypes.RUMBLE_TYPE_QUAKE,
		Additive = false,
		DoCameraShake = true
	}
)

-- Debug.AddLuaDebugKeyFunc(EInputKey.KB_F9, function(RunScript("miscellaneous/RumbleEvents.lua")))
