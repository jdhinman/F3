ECrowdControlState = {}
ECrowdControlState.ECCS_IDLE = 0
ECrowdControlState.ECCS_BOO = 1
ECrowdControlState.ECCS_CHEER = 2
ECrowdControlState.ECCS_WINCE = 3
ECrowdControlState.ECCS_STRANGER_REACTION = 4
ECrowdControlState.ECCS_MAX = 5
