EBobTypeMoveEntity = {}
EBobTypeMoveEntity.MOVE_ENTITY_ALWAYS = 0
EBobTypeMoveEntity.MOVE_ENTITY_IF_NOT_NAVIGATING = 1
EBobTypeMoveEntity.MOVE_ENTITY_IF_NOT_ACTING_OR_MOVING = 2
EBobTypeMoveEntity.MOVE_ENTITY_NEVER = 3




