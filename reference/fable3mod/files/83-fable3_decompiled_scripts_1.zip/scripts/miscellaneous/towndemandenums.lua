ETownDemandConditionType = {}
ETownDemandConditionType.DEMAND_CONDITION_TOWN_WEALTH = 0
ETownDemandConditionType.DEMAND_CONDITION_RENOWN = 1
ETownDemandConditionType.DEMAND_CONDITION_HOUSE_MAINTENANCE = 2
ETownDemandConditionType.NUM_TOWN_DEMAND_CONDITIONS = 3

ETownDemandEffectType = {}
ETownDemandEffectType.DEMAND_EFFECT_MONEY = 0
ETownDemandEffectType.DEMAND_EFFECT_RENOWN = 1
ETownDemandEffectType.DEMAND_EFFECT_TOWN_WEALTH = 2
ETownDemandEffectType.DEMAND_EFFECT_HOUSE_CONDITION = 3
ETownDemandEffectType.DEMAND_EFFECT_SHOP_WEALTH = 4
ETownDemandEffectType.DEMAND_EFFECT_DISCOUNT = 5
ETownDemandEffectType.DEMAND_EFFECT_PROPERTY_PRICES = 6
ETownDemandEffectType.DEMAND_EFFECT_JOB_INCOME = 7
ETownDemandEffectType.DEMAND_EFFECT_MORALITY = 8
ETownDemandEffectType.DEMAND_EFFECT_PURITY = 9
ETownDemandEffectType.NUM_TOWN_DEMAND_EFFECTS = 10

ETownDemandStatus = {}
ETownDemandStatus.DEMAND_STATUS_INVALID = 0
ETownDemandStatus.DEMAND_STATUS_ACCEPTED = 1
ETownDemandStatus.DEMAND_STATUS_REJECTED = 2
ETownDemandStatus.DEMAND_STATUS_PENDING = 3

ETownDemandType = {}
ETownDemandType.DEMAND_RESIDENTIAL = 0
ETownDemandType.DEMAND_BUSINESS = 1
ETownDemandType.DEMAND_ORDER = 2
ETownDemandType.DEMAND_SOCIAL = 3
ETownDemandType.DEMAND_TAX = 4
ETownDemandType.DEMAND_EMPLOYMENT = 5
ETownDemandType.DEMAND_PROPERTY = 6
ETownDemandType.DEMAND_SOLDIERS = 7
ETownDemandType.NUM_TOWN_DEMANDS = 8
