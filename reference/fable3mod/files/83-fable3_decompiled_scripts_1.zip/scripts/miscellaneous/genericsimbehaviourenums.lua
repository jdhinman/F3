EGenericActionType = {}
EGenericActionType.EGA_SIMPLE = 0
EGenericActionType.EGA_LOOP_ACTION = 1
EGenericActionType.EGA_BATCH_ACTION = 2
EGenericActionType.EGA_WEIGHTED_ACTION = 3
