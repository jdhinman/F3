ELockRequestStatus = {}
ELockRequestStatus.ELR_FAIL = 0
ELockRequestStatus.ELR_SUCCESS = 1
ELockRequestStatus.ELR_PENDING = 2
