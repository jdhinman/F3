EHand = {}
EHand.HAND_RIGHT = 0
EHand.HAND_LEFT = 1
