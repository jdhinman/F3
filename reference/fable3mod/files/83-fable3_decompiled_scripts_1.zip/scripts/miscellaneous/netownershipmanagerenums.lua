EOwnershipRequestStatus {}
EOwnershipRequestStatus.EORR_FAIL 0
EOwnershipRequestStatus.EORR_SUCCESS 1
EOwnershipRequestStatus.EORR_PENDING 2
