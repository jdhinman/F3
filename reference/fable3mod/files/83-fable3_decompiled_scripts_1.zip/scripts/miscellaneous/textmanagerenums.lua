EGroupSelectionMethod = {}
EGroupSelectionMethod.GROUP_SELECT_NONE = 0
EGroupSelectionMethod.GROUP_SELECT_RANDOM = 1
EGroupSelectionMethod.GROUP_SELECT_RANDOM_NO_REPEAT = 2
EGroupSelectionMethod.GROUP_SELECT_SEQUENTIAL = 3
EGroupSelectionMethod.GROUP_SELECT_RANDOM_EACH_LINE_ONCE_ONLY = 4
