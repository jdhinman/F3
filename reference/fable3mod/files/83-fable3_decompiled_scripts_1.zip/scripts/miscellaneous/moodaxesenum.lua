EMoodAxes = {}
EMoodAxes.EMA_HAPPY = 0
EMoodAxes.EMA_SCARED = 1
EMoodAxes.EMA_MAX = 2

EMoodState = {}
EMoodState.EMS_NEUTRAL = 0
EMoodState.EMS_HAPPY = 1
EMoodState.EMS_ANGRY = 2
EMoodState.EMS_SAD = 3
EMoodState.EMS_SCARED = 4
EMoodState.EMS_MAX = 5
