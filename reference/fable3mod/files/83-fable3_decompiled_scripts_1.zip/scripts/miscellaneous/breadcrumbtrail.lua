Breadcrumber.SetNormalModeLength = 1
Breadcrumber.SetNormalModeFarBrightness = 0.3
Breadcrumber.SetNormalModeNearBrightness = 0.45
Breadcrumber.SetAttractModeLength = 1
Breadcrumber.SetAttractModeBrightness = 0.8
Breadcrumber.SetFollowModeLength = 1
Breadcrumber.SetFollowModeBrightness = 0.3
Breadcrumber.SetHiddenModeLength = 1
Breadcrumber.SetHiddenModeBrightness = 0.1
Breadcrumber.SetPulseLength = 3
Breadcrumber.SetHeroMovementAlphaCutoff = 5
Breadcrumber.SetAreaParticlesPerMetre = 2
Breadcrumber.SetTrailLength = 12
Breadcrumber.SetParticlesPerMetre = 1
Breadcrumber.SetMinLightingMult = 0.5

Breadcrumber.LevelsWithEarlyExitOverride = {
	{
		World = "Fable3",
		Level = "Albion\\BrightwallVillage"
	},
	{
		World = "Fable3",
		Level = "Albion\\CastleBattle"
	}
}

Breadcrumber.JourneyPlannerData = {
	{
		World = "Albion",
		Level = "Caves\\Westcliff\\PalaceCave",
		WithinLevel = "Westcliff",
		Exits = {
			{
				LevelBeyond = "Bloodstone",
				ExitToUse = "Door_Tomb_V_4"
			},
			{
				LevelBeyond = "WestcliffExterior",
				ExitToUse = "DoorStartToWC"
			}
		}
	},
	{
		World = "Albion",
		Level = "Caves\\Dunecrest\\HobbeCave",
		WithinLevel = "DunecrestNew",
		Exits = {
			{
				ExitToUse = "ObjectFurnitureStaticLadder12M_2"
			}
		}
	},
	{
		World = "Fable3",
		Level = "Aurora\\ShiftingSands",
		Exits = {
			{
				LevelBeyond = "Aurora\\BloodWeShare",
				ExitToUse = "MarkerLevelExit"
			},
			{
				LevelBeyond = "Aurora\\DesertPleasureCave",
				ExitToUse = "MarkerLevelExit_2"
			}
		}
	},
	{
		World = "Fable3",
		Level = "Albion\\BrightwallVillage",
		Exits = {
			{
				QuestName = "QC020_BecomingAHero",
				TargetEntity = "QC020_Trigger_ApproachLibrarian",
				ExitToUse = "ExitToLibrary"
			},
			{
				QuestName = "QO050_MissingPlay",
				TargetEntity = "QO050_TheBookMarker",
				ExitToUse = "ExitToLibrary"
			},
			{
				QuestName = "QOTA_BWV010",
				TargetLevel = "Albion\\CastleBattle",
				ExitToUse = "BW_ExitToMistpeakValley"
			},
			{
				QuestName = "QO010_BrightwallBooks",
				TargetLevel = "Albion\\CastleBattle",
				ExitToUse = "BW_ExitToMistpeakValley"
			}
		}
	},
	{
		World = "Fable3",
		Level = "Albion\\CastleBattle",
		Exits = {
			{
				QuestName = "QOTP_CAS010",
				LevelBeyond = "Albion\\BowerstoneCastle",
				ExitToUse = "ExitToBWSMarket"
			},
			{
				LevelBeyond = "Albion\\BowerstoneCastle",
				ExitToUse = "ExitToBWSMarket"
			}
		}
	},
	{
		World = "Fable3",
		Level = "Albion\\BowerstoneIndustrial",
		Exits = {
			{
				TargetEntity = "QC090_Trigger_EnteredResistanceHQ1",
				ExitToUse = "QC090_ResistanceHQDoor"
			},
			{
				TargetEntity = "QO160_Marker_BridgeEncounterQuestGiver",
				ExitToUse = "Cellar_Trapdoor_Temporary"
			},
			{
				LevelBeyond = "Albion\\Sewers",
				QuestName = "QC090_BowerstoneBoat",
				ExitToUse = "QC090_ResistanceHQDoor"
			},
			{
				LevelBeyond = "Albion\\Sewers",
				QuestName = "QC070_BowerstoneAndBalverines_Part_1",
				ExitToUse = "QC090_ResistanceHQDoor"
			},
			{
				LevelBeyond = "Albion\\Sewers",
				QuestName = "QOTF_BSI010",
				ExitToUse = "OptionalSewerEntrance"
			},
			{
				LevelBeyond = "Albion\\Sewers",
				QuestName = "QO170_SlaveTrade",
				ExitToUse = "QC090_ResistanceHQDoor"
			},
			{
				LevelBeyond = "Albion\\Sewers",
				ExitToUse = "QC090_ResistanceHQDoor"
			}
		}
	},
	{
		World = "Fable3",
		Level = "Albion\\TheHole",
		Exits = {
			{
				LevelBeyond = "Albion\\Mangroves",
				ExitToUse = "QC050_StationOnActionUseElevatorDown"
			}
		}
	},
	{
		World = "Fable3",
		Level = "Albion\\Sewers",
		Exits = {
			{
				LevelBeyond = "AlbionBowerstoneIndustrial",
				ExitToUse = "CellarEntranceToDock1New"
			},
			{
				LevelBeyond = "AlbionBowerstoneIndustrial",
				QuestName = "QC070_BowerstoneAndBalverines_Part_1",
				ExitToUse = "CellarEntranceToDock1New"
			},
			{
				LevelBeyond = "Albion\\BowerstoneIndustrial",
				QuestName = "QC090_BowerstoneBoat",
				ExitToUse = "Sewers_ExitToBWI"
			}
		}
	},
	{
		World = "Fable3",
		Level = "Albion\\BWSMarket",
		Exits = {
			{
				TargetEntity = "QO080_Jonathon",
				ExitToUse = "QO080_Cellar_Trapdoor_External"
			},
			{
				LevelBeyond = "Albion\\BowerstoneIndustrial",
				ExitToUse = "ExitToBWSIndustrial"
			},
			{
				LevelBeyond = "Optional\\Hideout",
				ExitToUse = "QO170_HideoutDoor_AfterActivation"
			}
		}
	},
	{
		World = "Fable3",
		Level = "Albion\\Mangroves",
		Exits = {
			{
				TargetLevel = "Albion\\NewMillFields",
				ExitToUse = "ExitToBWSIndustrial"
			}
		}
	},
	{
		World = "Fable3",
		Level = "Albion\\NewMillFields",
		Exits = {
			{
				LevelBeyond = "Optional\\MillfieldMines",
				QuestName = "QOTP_HOL010",
				ExitToUse = "ExitToMine2"
			},
			{
				LevelBeyond = "Albion\\HawneManorCellars",
				QuestName = "QV030_ReaverMansionOwnership",
				ExitToUse = "ExitToHawneManorCellars"
			}
		}
	},
	{
		World = "Fable3",
		Level = "Optional\\MillfieldMines",
		Exits = {
			{
				LevelBeyond = "Albion\\NewMillFields",
				QuestName = "QOTP_HOL010",
				ExitToUse = "ExitToMill2"
			},
			{
				LevelBeyond = "Albion\\NewMillFields",
				ExitToUse = "ExitToMill1"
			}
		}
	},
	{
		World = "Fable3",
		Level = "Optional\\BWSIndustrialCave",
		Exits = {
			{
				LevelBeyond = "Albion\\BowerstoneIndustrial",
				QuestName = "QO160_EliseElliot",
				ExitToUse = "QO0160_CellarReturnDoor"
			},
			{
				LevelBeyond = "Albion\\BowerstoneIndustrial",
				ExitToUse = "LevelExit_BWSIndustrial"
			}
		}
	},
	{
		World = "Fable3",
		Level = "Albion\\MistpeakValley",
		Exits = {
			{
				LevelBeyond = "Albion\\MistPeakCave",
				QuestName = "QOTP_MPC010",
				ExitToUse = "ExitToMistPeakCave4"
			},
			{
				LevelBeyond = "Albion\\MistPeakCave",
				QuestName = "QO010_BrightwallBooks",
				ExitToUse = "ExitToMistPeakCave1"
			},
			{
				LevelBeyond = "Optional\\TestLevelGrove",
				ExitToUse = "ExitToLCE"
			}
		}
	},
	{
		World = "Fable3",
		Level = "Episode1\\PrisonInterior",
		ExitToUse = "ExitToRavenscarExterior_2"
	},
	{
		World = "Fable3",
		Level = "Episode1\\RavenscarPrison",
		Exits = {
			{
				QuestName = "QC230_MastermindsTrap",
				ExitToUse = "RPI_ExitToPrisonEntrance"
			}
		}
	}
}



-- uncomment for debug
-- GUI.DisplayMessageBox("breadcrumbtrail.lua successfully loaded!")
-- while (GUI.IsDisplayBoxActive()) do
	-- coroutine.yield()
-- end

