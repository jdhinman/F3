EQuestType = {}
EQuestType.EQT_CORE = 0
EQuestType.EQT_OPTIONAL = 1
EQuestType.EQT_VIGNETTE = 2
EQuestType.EQT_GENERATED = 3
EQuestType.EQT_MASTER = 4
EQuestType.EQT_JOB = 5
