
HandHoldingDataDefault = {}
HandHoldingDataDefault.DraggingStyleMovement = false
HandHoldingDataDefault.CanSwitchHands = true
HandHoldingDataDefault.MaxStationaryDist = 0.01
HandHoldingDataDefault.VelocityLerpSpeedFacing = 0.8
HandHoldingDataDefault.VelocityLerpSpeedLateral = 0.4
HandHoldingDataDefault.Acceleration = 1
HandHoldingDataDefault.Deceleration = 1
HandHoldingDataDefault.MaxSpeedMultiplier = 1.2
HandHoldingDataDefault.Damping = 0.8
HandHoldingDataDefault.LerpSpeedToRest = 0.8
HandHoldingDataDefault.FacingAngleOffset = -0.3
HandHoldingDataDefault.FacingLerpSpeed = 0.6
HandHoldingDataDefault.PosLerpSpeed = 1
HandHoldingDataDefault.MaxAmountAhead = -0.1
HandHoldingDataDefault.MaxAmountBehind = -0.85

HandHoldingDataDragging = DeepCopyTable(HandHoldingDataDefault)
HandHoldingDataDragging.DraggingStyleMovement = true
HandHoldingDataDragging.FacingOffsetAngle = 0
HandHoldingDataDragging.PosLerpSpeed = 0.6
HandHoldingDataDragging.MaxAmountAhead = -0.9
HandHoldingDataDragging.MaxAmountBehind = -0.9

HandHoldingDataBeck = DeepCopyTable(HandHoldingDataDragging)
HandHoldingDataBeck.MaxSpeedMultiplier = 2
HandHoldingDataBeck.CanSwitchHands = false

HandHoldingDataChild = DeepCopyTable(HandHoldingDataDefault)
HandHoldingDataChild.MaxAmountAhead = 0.2
HandHoldingDataChild.MaxAmountBehind = -0.7

HandHoldingDataTypes = {
	"HandHoldingDataDefault",
	"HandHoldingDataDragging",
	"HandHoldingDataBeck",
	"HandHoldingDataChild"
}

-- uncomment for debug
-- GUI.DisplayMessageBox("handholdingdata.lua successfully loaded!")
-- while (GUI.IsDisplayBoxActive()) do
	-- coroutine.yield()
-- end