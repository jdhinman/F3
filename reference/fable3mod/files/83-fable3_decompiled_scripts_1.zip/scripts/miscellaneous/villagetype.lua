EVillageType = {}
EVillageType.VILLAGE_STANDARD = 0
EVillageType.VILLAGE_GYPSY = 1
EVillageType.VILLAGE_BANDIT = 2
EVillageType.VILLAGE_WESTCLIFF_CH2 = 3
