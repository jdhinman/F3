EConfinementType = {}
EConfinementType.CONFINED_NULL = 0
EConfinementType.CONFINED_FRONT = 1
EConfinementType.CONFINED_BACK = 2
EConfinementType.CONFINED_LEFT = 4
EConfinementType.CONFINED_RIGHT = 8
EConfinementType.CONFINED_BACK_CLIFF_EDGE = 16
EConfinementType.CONFINED_ALL = 31
