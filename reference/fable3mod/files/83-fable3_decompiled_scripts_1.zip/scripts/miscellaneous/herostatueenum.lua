EStatueHand = {}
EStatueHand.ESH_HAND_LEFT = 0
EStatueHand.ESH_HAND_RIGHT = 1
EStatueHand.ESH_HAND_BOTH = 2
