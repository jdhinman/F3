EScheduleTickboxState = {}
EScheduleTickboxState.ESTS_UNTICKED = 1
EScheduleTickboxState.ESTS_TICK = 2
EScheduleTickboxState.ESTS_ALREADY_TICKED = 3
EScheduleTickboxState.ESTS_HIDDEN = 4
