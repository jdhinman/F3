ENatalStatueMakerState = {}
ENatalStatueMakerState.NSM_STATE_NONE = 0
ENatalStatueMakerState.NSM_STATE_START = 1
ENatalStatueMakerState.NSM_STATE_COUNTDOWN = 2
ENatalStatueMakerState.NSM_STATE_CONFIRMATION = 3
ENatalStatueMakerState.NSM_STATE_FACE = 4
ENatalStatueMakerState.NSM_STATE_HANDS = 5
