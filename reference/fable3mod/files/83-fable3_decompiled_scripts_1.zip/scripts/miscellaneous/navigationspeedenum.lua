ENavigationSpeed = {}
ENavigationSpeed.NAV_SPEED_HALT = 0
ENavigationSpeed.NAV_SPEED_SLOW_WALK = 1
ENavigationSpeed.NAV_SPEED_WALK = 2
ENavigationSpeed.NAV_SPEED_FAST_WALK = 3
ENavigationSpeed.NAV_SPEED_SLOW_RUN = 4
ENavigationSpeed.NAV_SPEED_RUN = 5
ENavigationSpeed.NAV_SPEED_FAST_RUN = 6
ENavigationSpeed.NAV_SPEED_SPRINT = 7
ENavigationSpeed.NAV_SPEED_MAX = 8

ETemporaryDestinationSource = {}
ETemporaryDestinationSource.TEMPORARY_DESTINATION_SOURCE_NONE = 0
ETemporaryDestinationSource.TEMPORARY_DESTINATION_SOURCE_PATH_OBJECT = 1
ETemporaryDestinationSource.TEMPORARY_DESTINATION_SOURCE_DOG_STOPPING = 2
ETemporaryDestinationSource.TEMPORARY_DESTINATION_SOURCE_DOG_STEER_TO_PATH_OBJECT = 3
ETemporaryDestinationSource.TEMPORARY_DESTINATION_SOURCE_ACTION = 4
ETemporaryDestinationSource.TEMPORARY_DESTINATION_SOURCE_STEER_TO_ACTION = 5
