EGender = {}
EGender.EG_ANDROGYNOUS = 0
EGender.EG_FEMALE = 1
EGender.EG_MALE = 2
EGender.EG_NONE = 3
