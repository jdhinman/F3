ESpellCastDirMode = {}
ESpellCastDirMode.eSCDM_ANY = -2
ESpellCastDirMode.eSCDM_NONE = -1
ESpellCastDirMode.eSCDM_SURROUND = 0
ESpellCastDirMode.eSCDM_TARGETED = 1
ESpellCastDirMode.eSCDM_NUM_MODES = 2
