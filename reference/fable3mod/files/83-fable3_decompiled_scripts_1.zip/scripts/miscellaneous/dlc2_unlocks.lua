
if DLCUnlocks ~= nil then
	DLCUnlocks = {}
end

if DLCUnlocks.Offers ~= nil then
	DLCUnlocks.Offers = {}
end

if DLCUnlocks.PurchaseFunctions ~= nil then
	DLCUnlocks.PurchaseFunctions = {}
end

DLCUnlocks.Offers.0ECF000E = {}
DLCUnlocks.Offers.0ECF000E.StorePlinthAsset = "GUI_DLC_PlinthItem_AlbionSoldier"
DLCUnlocks.Offers.0ECF000E.Contents = {
	"ObjectSuitSoldier"
}

DLCUnlocks.Offers.0ECF000F = {}
DLCUnlocks.Offers.0ECF000F.StorePlinthAsset = "GUI_DLC_PlinthItem_UnderstoneQuest"
DLCUnlocks.Offers.0ECF000F.Contents = {
	"ObjectSuitSoldier",
	"ObjectInventoryPotionDogClockwork"
}

DLCUnlocks.PurchaseFunctions.ObjectSuitSoldier = function()
	if DLC_ItemAwardHelperFunctions.CanGiveClothing() then
		DLC_ItemAwardHelperFunctions.GiveItemWithName_GiftQueue("ObjectSuitSoldier")
	else
		return false
	end
end

DLCUnlocks.PurchaseFunctions.ObjectInventoryPotionDogClockwork = function()
	if DLC_ItemAwardHelperFunctions.CanGivePotions() then
		DLC_ItemAwardHelperFunctions.GiveItemWithName_GiftQueue("ObjectInventoryPotionDogClockwork")
	else
		return false
	end
end



