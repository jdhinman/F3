ENatalExpressionMakerState = {}
ENatalExpressionMakerState.NEM_STATE_NONE = 0
ENatalExpressionMakerState.NEM_STATE_START = 1
ENatalExpressionMakerState.NEM_STATE_RECORDING = 2
ENatalExpressionMakerState.NEM_STATE_CONFIRMATION = 3
ENatalExpressionMakerState.NEM_STATE_SIM_VALUES = 4
