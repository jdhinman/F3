EGenderPreference = {}
EGenderPreference.EGP_OPPOSITESEX = 0
EGenderPreference.EGP_SAMESEX = 1
EGenderPreference.EGP_EITHERSEX = 2
EGenderPreference.EGP_ASEXUAL = 3
EGenderPreference.EGP_MAX = 4

EOpinionAxes = {}
EOpinionAxes.EOA_LOVE = 0
EOpinionAxes.EOA_FEAR = 1
EOpinionAxes.EOA_ATTRACTIVENESS = 2
EOpinionAxes.EOA_MORALITY = 3
EOpinionAxes.EOA_RESPECT = 4
EOpinionAxes.EOA_MAX = 5

EOpinionReactionCategory = {}
EOpinionReactionCategory.EORC_SPEECH = 0
EOpinionReactionCategory.EORC_ANIMATED = 1
EOpinionReactionCategory.EORC_SPEECHANDANIMATION = 2
EOpinionReactionCategory.EORC_MAX = 3

EOpinionReactionType = {}
EOpinionReactionType.EORT_NONDIRECTED = 0
EOpinionReactionType.EORT_CONVERSATIONAL = 1
EOpinionReactionType.EORT_DEED = 2
EOpinionReactionType.EORT_DOG_DEED = 3
EOpinionReactionType.EORT_BORED_DEED = 4
EOpinionReactionType.EORT_MINI_DEED = 5
EOpinionReactionType.EORT_PROMPT_EXPRESSION = 6
EOpinionReactionType.EORT_DOG = 7
EOpinionReactionType.EORT_COMBAT = 8
EOpinionReactionType.EORT_GIFT = 9
EOpinionReactionType.EORT_BORED_GIFT = 10
EOpinionReactionType.EORT_GREETING = 11
EOpinionReactionType.EORT_SEX = 12
EOpinionReactionType.EORT_MAX = 13

EOpinionTarget = {}
EOpinionTarget.EOT_PLAYER = 0
EOpinionTarget.EOT_HENCHMAN = 1
EOpinionTarget.EOT_HERO_DOG = 2
EOpinionTarget.EOT_HENCHMAN_DOG = 3
EOpinionTarget.EOT_ALL = 4

EPersonalityBias = {}
EPersonalityBias.EPB_NEUTRAL = 0
EPersonalityBias.EPB_GOOD = 1
EPersonalityBias.EPB_EVIL = 2
EPersonalityBias.EPB_MAX = 3

ERelationshipQuestType = {}
ERelationshipQuestType.ERQT_NONE = 0
ERelationshipQuestType.ERQT_FIRST = 1
ERelationshipQuestType.ERQT_FETCH = 1
ERelationshipQuestType.ERQT_GIFT = 2
ERelationshipQuestType.ERQT_DATE = 4
ERelationshipQuestType.ERQT_COURIER = 8
ERelationshipQuestType.ERQT_LAST = 16
ERelationshipQuestType.ERQT_HOUSE_IMPROVEMENT = 16

ERelationshipStages = {}
ERelationshipStages.ERS_FEAR = 0
ERelationshipStages.ERS_HATE = 1
ERelationshipStages.ERS_NEUTRAL = 2
ERelationshipStages.ERS_FRIEND = 3
ERelationshipStages.ERS_LOVE = 4
ERelationshipStages.ERS_MAX = 5
ERelationshipStages.ERS_NONE = 6

ERelationshipTransitionDirections = {}
ERelationshipTransitionDirections.ERTD_UPWARDS = 0
ERelationshipTransitionDirections.ERTD_DOWNWARDS = 1
ERelationshipTransitionDirections.ERTD_MAX = 2

ERelationshipTransitionType = {}
ERelationshipTransitionType.ERTT_FEAR_TO_HATE = 0
ERelationshipTransitionType.ERTT_HATE_TO_NEUTRAL = 1
ERelationshipTransitionType.ERTT_NEUTRAL_TO_FRIENDS = 2
ERelationshipTransitionType.ERTT_FRIENDS_TO_LOVE_ROMANTIC = 3
ERelationshipTransitionType.ERTT_FRIENDS_TO_LOVE_BEST_FRIENDS = 4
ERelationshipTransitionType.ERTT_NUM_RELATIONSHIP_TRANSITIONS = 5
ERelationshipTransitionType.ERTT_NONE = 6

ESpouseRelationshipStatus = {}
ESpouseRelationshipStatus.ESRS_HAPPY = 0
ESpouseRelationshipStatus.ESRS_NEUTRAL = 1
ESpouseRelationshipStatus.ESRS_UNHAPPY = 2
ESpouseRelationshipStatus.ESRS_MAX = 3
ESpouseRelationshipStatus.ESRS_NONE = 4

ESuggestionType = {}
ESuggestionType.EST_EXPRESSION_SUGGESTION = 0
ESuggestionType.EST_GIFT_SUGGESTION = 1
ESuggestionType.EST_TRIP_SUGGESTION = 2
ESuggestionType.EST_APPEARANCE_SUGGESTION = 3
ESuggestionType.EST_MAX_SUGGESTION = 4
