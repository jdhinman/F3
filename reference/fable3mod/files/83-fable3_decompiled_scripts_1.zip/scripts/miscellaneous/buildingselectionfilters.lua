EBuildingSelectionFilters = {}
EBuildingSelectionFilters.FILTER_FAMILY_HOMES = 0
EBuildingSelectionFilters.FILTER_BUSINESSES = 1
EBuildingSelectionFilters.FILTER_RENTAL_PROPERTIES = 2
EBuildingSelectionFilters.FILTER_EXCLUDE_FAMILY_HOMES = 3
EBuildingSelectionFilters.FILTER_EXCLUDE_BUSINESSES = 4
EBuildingSelectionFilters.FILTER_EXCLUDE_RENTAL_PROPERTIES = 5
