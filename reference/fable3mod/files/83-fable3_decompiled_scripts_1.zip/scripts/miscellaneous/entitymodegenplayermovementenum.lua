EAnimBlendType = {}
EAnimBlendType.ANIM_BLEND_NULL = 0
EAnimBlendType.ANIM_BLEND_BLEND = 1
EAnimBlendType.ANIM_BLEND_MATCH_FOOTING = 2

ECombatState = {}
ECombatState.COMBAT_STATE_NULL = 0
ECombatState.COMBAT_STATE_NOT_SET = 1
ECombatState.COMBAT_STATE_SET = 2

EFootMatchType = {}
EFootMatchType.FOOT_MATCH_NULL = 0
EFootMatchType.FOOT_MATCH_ABSOLUTE = 1
EFootMatchType.FOOT_MATCH_RELATIVE = 2

ETransitionType = {}
ETransitionType.TRANSITION_NULL = 0
ETransitionType.TRANSITION_ROTATION = 1
ETransitionType.TRANSITION_TRANSLATION_ACCELERATE = 2
ETransitionType.TRANSITION_TRANSLATION_DECELERATE = 3
ETransitionType.TRANSITION_MATCH_FOOTING = 4
