ETargetingAttackType = {}
ETargetingAttackType.ETAT_NONE = 0
ETargetingAttackType.ETAT_RANGED = 1
ETargetingAttackType.ETAT_SPELL = 2
ETargetingAttackType.ETAT_REAVER_MULTISHOT = 3
ETargetingAttackType.ETAT_CORNELIUS_GRIM_RAISE = 4
