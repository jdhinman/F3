EBodyArea = {}
EBodyArea.EBA_NULL = 0
EBodyArea.EBA_HORNS = 1
EBodyArea.EBA_HAIR = 2
EBodyArea.EBA_HEAD = 4
EBodyArea.EBA_FACE = 8
EBodyArea.EBA_EYES = 16
EBodyArea.EBA_EARS = 32
EBodyArea.EBA_BEARD = 64
EBodyArea.EBA_MOUSTACHE = 128
EBodyArea.EBA_SIDEBURNS = 256
EBodyArea.EBA_NECK = 512
EBodyArea.EBA_BODY = 1024
EBodyArea.EBA_BODY_OUTER = 2048
EBodyArea.EBA_ARMS = 4096
EBodyArea.EBA_HANDS = 8192
EBodyArea.EBA_FINGERS = 16384
EBodyArea.EBA_ARSE = 32768
EBodyArea.EBA_WAIST = 65536
EBodyArea.EBA_LEGS = 131072
EBodyArea.EBA_FEET = 262144
EBodyArea.EBA_SPELL_GAUNTLET_L = 524288
EBodyArea.EBA_SPELL_GAUNTLET_R = 1048576






















