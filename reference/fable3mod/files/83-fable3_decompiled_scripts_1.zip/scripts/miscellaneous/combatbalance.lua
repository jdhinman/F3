
Combat.SetLooseProjectileHeroSearchRadius(1.75)
Combat.SetLooseProjectileMinDistanceToEnemy(2.7)
Combat.SetLooseProjectileEnforceRangeFromHero(false)
Combat.SetLooseProjectileSimpleRadiusCheck(false)
Combat.SetLooseProjectileHorizontalSpeed(15)
Combat.SetCloseAttackMinRange(-1)
Combat.SetCloseAttackMaxRange(-1)
Combat.SetFarAttackMinRange(-1)
Combat.SetFarAttackMaxRange(-1)
Combat.SetFlourishChargeTime(0.5)
Combat.SetMaxBlockDistance(1.85)
CombatTalk.SetCombatCommentTweenTime(4.5)

HeroCombatBalanceParams = {}
HeroCombatBalanceParams.FlourishChargeTime = 0.8
HeroCombatBalanceParams.FlourishChargeAnimationTime = 1
HeroCombatBalanceParams.MeleeAttackTargetArcDegrees = 90
HeroCombatBalanceParams.MeleeAttackTargetArcRange = 5
HeroCombatBalanceParams.MeleeParryWedgeAngle = 70
HeroCombatBalanceParams.MeleeParryInputWindowSeconds = 1
HeroCombatBalanceParams.MeleeParryRequireStickJab = 1
HeroCombatBalanceParams.EstimatedStrikeTime = 0.3
HeroCombatBalanceParams.MeleeStrikeMaxRange = 2
HeroCombatBalanceParams.BlockStrikeToleranceFrames = 4
HeroCombatBalanceParams.AbilityTargetingDeadZone = 0.2
HeroCombatBalanceParams.BlockPoseUseLinearTransition = 1
HeroCombatBalanceParams.BlockPoseLinearTransitionBlendInSeconds = 0.2
HeroCombatBalanceParams.BlockPoseLinearTransitionBlendOutSeconds = 0.2
HeroCombatBalanceParams.BlockPoseTanhTransitionFrequency = 5
HeroCombatBalanceParams.BlockPoseTanhTransitionPower = 6
HeroCombatBalanceParams.HeroCombatMeleeStrikeUpdateMultiplier = 0.8
HeroCombatBalanceParams.HeroCombatMeleeFlourishUpdateMultiplier = 0.8
HeroCombatBalanceParams.BlockModeDelayNumFrames = 4
HeroCombatBalanceParams.ConfinedMinHalfAngleWedgeFromPlaneNormalForTurnAround = 25.5
HeroCombatBalanceParams.LooseProjectileSnapHero = false
HeroCombatBalanceParams.SprintStrikeSpeedFractionStart = 0.8
HeroCombatBalanceParams.SprintStrikeSpeedFractionTerminate = 0.9
HeroCombatBalanceParams.HardBlockEnabled = 0
HeroCombatBalanceParams.BlockCancelTime = 1
HeroCombatBalanceParams.NoBlockOnButtonReleaseTimeSeconds = 0.5

PVPCombatBalanceParams = {}
PVPCombatBalanceParams.FlourishChargeTime = 1
PVPCombatBalanceParams.FlourishChargeAnimationTime = 1
PVPCombatBalanceParams.MeleeAttackTargetArcDegrees = 90
PVPCombatBalanceParams.MeleeAttackTargetArcRange = 5
PVPCombatBalanceParams.MeleeParryWedgeAngle = 70
PVPCombatBalanceParams.MeleeParryInputWindowSeconds = 1
PVPCombatBalanceParams.MeleeParryRequireStickJab = 1
PVPCombatBalanceParams.EstimatedStrikeTime = 0.3
PVPCombatBalanceParams.MeleeStrikeMaxRange = 2
PVPCombatBalanceParams.BlockStrikeToleranceFrames = 4
PVPCombatBalanceParams.AbilityTargetingDeadZone = 0.2
PVPCombatBalanceParams.BlockPoseUseLinearTransition = 0
PVPCombatBalanceParams.BlockPoseLinearTransitionBlendInSeconds = 0.2
PVPCombatBalanceParams.BlockPoseTanhTransitionFrequency = 5
PVPCombatBalanceParams.BlockPoseTanhTransitionPower = 6
PVPCombatBalanceParams.HeroCombatMeleeStrikeUpdateMultiplier = 0.8
PVPCombatBalanceParams.HeroCombatMeleeFlourishUpdateMultiplier = 0.8

KnockdownParamsCliffBash = {}
KnockdownParamsCliffBash.KnockdownImpactTimeForHalfWayBlend = 0.3
KnockdownParamsCliffBash.KnockdownLatencyTimeForCollision = 1.5

CombatBalanceParams = {}
CombatBalanceParams.StunnedTime = 0.5
CombatBalanceParams.MaxTimeForSoftBlock = 0.4

CombatBalanceParamsHero = {}
CombatBalanceParamsHero.KnockdownParams = "KnockdownParamsDefaultHero"
CombatBalanceParamsHero.RangedKnockedDownSeconds = 1.5
CombatBalanceParamsHero.OverrideKnockedDownFloppyOnGroundTime = 1
CombatBalanceParamsHero.OverrideKnockedDownDriveToRecoveryTime = 0.5
CombatBalanceParamsHero.OverrideKnockedDownDeadFloppyOnGroundTime = 4
CombatBalanceParamsHero.OverrideKnockedDownDeadDriveToRecoveryTime = 2
CombatBalanceParamsHero.StunnedTime = 3.5
CombatBalanceParamsHero.CombatRadius = 1.5

CombatBalanceParamsBalverineBase = {}
CombatBalanceParamsBalverineBase.KnockdownParams = "KnockdownParamsDefaultBalverine"
CombatBalanceParamsBalverineBase.RangedKnockedDownSeconds = 1.5
CombatBalanceParamsBalverineBase.StunnedTime = 2.5
CombatBalanceParamsBalverineBase.CombatRadius = 2.5

CombatBalanceParamsBalverineSire = {}
CombatBalanceParamsBalverineSire.KnockdownParams = "KnockdownParamsBalverineSire"
CombatBalanceParamsBalverineSire.RangedKnockedDownSeconds = 0.5
CombatBalanceParamsBalverineSire.StunnedTime = 1.5
CombatBalanceParamsBalverineSire.CombatRadius = 2.5

CombatBalanceParamsWolf = {}
CombatBalanceParamsWolf.KnockdownParams = "KnockdownParamsDefaultWolf"
CombatBalanceParamsWolf.RangedKnockedDownSeconds = 1.5
CombatBalanceParamsWolf.StunnedTime = 0.5
CombatBalanceParamsWolf.CombatRadius = 2.5

CombatBalanceParamsBanditBase = {}
CombatBalanceParamsBanditBase.KnockdownParams = "KnockdownParamsDefaultBandit"
CombatBalanceParamsBanditBase.RangedKnockedDownSeconds = 1.5
CombatBalanceParamsBanditBase.StunnedTime = 3.5
CombatBalanceParamsBanditBase.CombatRadius = 1.5

CombatBalanceParamsBanditElite = {}
CombatBalanceParamsBanditElite.KnockdownParams = "KnockdownParamsBanditElite"
CombatBalanceParamsBanditElite.RangedKnockedDownSeconds = 1
CombatBalanceParamsBanditElite.StunnedTime = 2.5
CombatBalanceParamsBanditElite.CombatRadius = 1.5

CombatBalanceParamsBeetleBase = {}
CombatBalanceParamsBeetleBase.KnockdownParams = "KnockdownParamsDefaultBeetle"
CombatBalanceParamsBeetleBase.RangedKnockedDownSeconds = 2
CombatBalanceParamsBeetleBase.StunnedTime = 2.5
CombatBalanceParamsBeetleBase.CombatRadius = 1.5

CombatBalanceParamsGuardBase = {}
CombatBalanceParamsGuardBase.KnockdownParams = "KnockdownParamsDefaultGuard"
CombatBalanceParamsGuardBase.RangedKnockedDownSeconds = 1.5
CombatBalanceParamsGuardBase.StunnedTime = 2.5
CombatBalanceParamsGuardBase.CombatRadius = 1.5

CombatBalanceParamsGuardElite = {}
CombatBalanceParamsGuardElite.KnockdownParams = "KnockdownParamsGuardElite"
CombatBalanceParamsGuardElite.RangedKnockedDownSeconds = 0.75
CombatBalanceParamsGuardElite.StunnedTime = 1.5
CombatBalanceParamsGuardElite.CombatRadius = 1.5

CombatBalanceParamsHighwaymanBase = {}
CombatBalanceParamsHighwaymanBase.KnockdownParams = "KnockdownParamsDefaultHighwayman"
CombatBalanceParamsHighwaymanBase.RangedKnockedDownSeconds = 1
CombatBalanceParamsHighwaymanBase.StunnedTime = 2
CombatBalanceParamsHighwaymanBase.CombatRadius = 1.5

CombatBalanceParamsHobbeBase = {}
CombatBalanceParamsHobbeBase.KnockdownParams = "KnockdownParamsDefaultHobbe"
CombatBalanceParamsHobbeBase.RangedKnockedDownSeconds = 2
CombatBalanceParamsHobbeBase.CombatRadius = 1.5
CombatBalanceParamsHobbeBase.StunnedTime = 3.5
CombatBalanceParamsHobbeBase.StunnedTimes = {}
CombatBalanceParamsHobbeBase.StunnedTimes.StrikeParriedLF = 3.5
CombatBalanceParamsHobbeBase.StunnedTimes.StrikeParriedRF = 3.5
CombatBalanceParamsHobbeBase.StunnedTimes.ResponseParryConfinedRight = 3.5
CombatBalanceParamsHobbeBase.StunnedTimes.ResponseParryConfinedLeft = 3.5
CombatBalanceParamsHobbeBase.StunnedTimes.ResponseParryConfinedBack = 3.5
CombatBalanceParamsHobbeBase.StunnedTimes.StrikeParriedBackLF = 3.5
CombatBalanceParamsHobbeBase.StunnedTimes.StrikeParriedBackRF = 3.5

CombatBalanceParamsHobbeElite = {}
CombatBalanceParamsHobbeElite.KnockdownParams = "KnockdownParamsHobbeElite"
CombatBalanceParamsHobbeElite.RangedKnockedDownSeconds = 1.5
CombatBalanceParamsHobbeElite.CombatRadius = 1.5
CombatBalanceParamsHobbeElite.StunnedTime = 2.5

CombatBalanceParamsHobbeBoss = {}
CombatBalanceParamsHobbeBoss.KnockdownParams = "KnockdownParamsHobbeBoss"
CombatBalanceParamsHobbeBoss.RangedKnockedDownSeconds = 0.5
CombatBalanceParamsHobbeBoss.CombatRadius = 1.5
CombatBalanceParamsHobbeBoss.StunnedTime = 1

CombatBalanceParamsHollowManBase = {}
CombatBalanceParamsHollowManBase.KnockdownParams = "KnockdownParamsDefaultHollowMan"
CombatBalanceParamsHollowManBase.RangedKnockedDownSeconds = 3
CombatBalanceParamsHollowManBase.StunnedTime = 4
CombatBalanceParamsHollowManBase.CombatRadius = 1.5

CombatBalanceParamsHollowManElite = {}
CombatBalanceParamsHollowManElite.KnockdownParams = "KnockdownParamsHollowManElite"
CombatBalanceParamsHollowManElite.RangedKnockedDownSeconds = 2
CombatBalanceParamsHollowManElite.StunnedTime = 2.5
CombatBalanceParamsHollowManElite.CombatRadius = 1.5

CombatBalanceParamsHollowManSoldier = {}
CombatBalanceParamsHollowManSoldier.KnockdownParams = "KnockdownParamsHollowManSoldier"
CombatBalanceParamsHollowManSoldier.RangedKnockedDownSeconds = 1.5
CombatBalanceParamsHollowManSoldier.StunnedTime = 2
CombatBalanceParamsHollowManSoldier.CombatRadius = 1.5

CombatBalanceParamsHumanBoss = {}
CombatBalanceParamsHumanBoss.KnockdownParams = "KnockdownParamsHumanBoss"
CombatBalanceParamsHumanBoss.RangedKnockedDownSeconds = 0.5
CombatBalanceParamsHumanBoss.StunnedTime = 1
CombatBalanceParamsHumanBoss.CombatRadius = 1.5

CombatBalanceParamsLuciensGuardBase = {}
CombatBalanceParamsLuciensGuardBase.KnockdownParams = "KnockdownParamsDefaultLuciensGuard"
CombatBalanceParamsLuciensGuardBase.RangedKnockedDownSeconds = 1.5
CombatBalanceParamsLuciensGuardBase.StunnedTime = 2.5
CombatBalanceParamsLuciensGuardBase.CombatRadius = 1.5

CombatBalanceParamsLuciensGuardElite = {}
CombatBalanceParamsLuciensGuardElite.KnockdownParams = "KnockdownParamsLuciensGuardElite"
CombatBalanceParamsLuciensGuardElite.RangedKnockedDownSeconds = 1
CombatBalanceParamsLuciensGuardElite.StunnedTime = 2
CombatBalanceParamsLuciensGuardElite.CombatRadius = 1.5

CombatBalanceParamsLuciensSoldierBase = {}
CombatBalanceParamsLuciensSoldierBase.KnockdownParams = "KnockdownParamsLuciensSoldier"
CombatBalanceParamsLuciensSoldierBase.RangedKnockedDownSeconds = 0.5
CombatBalanceParamsLuciensSoldierBase.StunnedTime = 1.5
CombatBalanceParamsLuciensSoldierBase.CombatRadius = 1.5

CombatBalanceParamsCombatCrowBase = {}
CombatBalanceParamsCombatCrowBase.CombatRadius = 3.5

Debug.SetAutoEquipSheatheWeaponSeconds(6)
Debug.SetExperienceOrbAbsorbSpeedMax(10)
Debug.SetExperienceOrbAbsorbSpeedMin(7)
Debug.SetExperienceOrbAbsorbSpeedSizeAttenuator(0.5)
Debug.SetExperienceOrbSuckingDamageMultiplier(1.5)
Debug.SetFlourishUseStick(true)

Debug.SetRangedCreatureTargetCircleMultiplier(1.75)
Debug.SetRangedCursorXSpeed(1.8)
Debug.SetRangedCursorYSpeed(1.5)
Debug.SetRangedLookatTriggersSubTargeting(true)
Debug.SetRangedReloadInSheatheTime(2.5)
Debug.SetRangedRememberSubTarget(true)
Debug.SetRangedTimeToHoldOut(0.4)
Debug.SetRangedTimeToLeaveAiming(1)

Debug.SetStrafeEndZLockRange(25)
Debug.SetStrafeGradientToTargetCheckDist(13)
Debug.SetStrafeGradientToTargetMax(0.35)
Debug.SetStrafeOnDownedEnemy(true)
Debug.SetStrafeRecentSpellVictimTime(5)
Debug.SetStrafeSearchRadiusMelee(10)
Debug.SetStrafeSearchRadiusRanged(13)
Debug.SetStrafeSphereEndStrafeParentMinRadius(5)
Debug.SetStrafeSphereEndStrafeTargetMinRadius(9)
Debug.SetStrafeSphereRunAwayTargetSphereShrinkMetresPerSecondAtMaxSpeed(2.5)
Debug.SetStrafeSphereRunAwayTargetSphereShrinkMinRadius(4)
Debug.SetStrafeSphereStartStrafeParentMinRadius(5)
Debug.SetStrafeSphereStartStrafeTargetMinRadius(15)
Debug.SetStrafeTargetingLockTimeOnLastTarget(0.5)
Debug.SetStrafeVeryCloseEndTime(0.5)
Debug.SetStrafeVeryCloseTime(0.5)



-- uncomment for debug
-- GUI.DisplayMessageBox("combatbalance.lua successfully loaded!")
-- while (GUI.IsDisplayBoxActive()) do
	-- coroutine.yield()
-- end