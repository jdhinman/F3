EAdjusterTypes = {}
EAdjusterTypes.ADJUSTER_TYPE_NONE = 0
EAdjusterTypes.ADJUSTER_TYPE_MONEY = 1
EAdjusterTypes.ADJUSTER_TYPE_PERCENTAGE = 2
