ESubTargetType = {}
ESubTargetType.STT_NONE = 0
ESubTargetType.STT_DEFAULT = 1
ESubTargetType.STT_HEAD = 2
ESubTargetType.STT_GROIN = 3
ESubTargetType.STT_LEGS = 4
ESubTargetType.STT_WEAPON_LEFT = 5
ESubTargetType.STT_WEAPON_RIGHT = 6
ESubTargetType.STT_INVALID = 7

ETargetColourType = {}
ETargetColourType.TARGET_COLOUR_GREEN = 0
ETargetColourType.TARGET_COLOUR_RED = 1
ETargetColourType.TARGET_COLOUR_PURPLE = 2
ETargetColourType.TARGET_COLOUR_ORANGE = 3
ETargetColourType.TARGET_COLOUR_WHITE = 4
ETargetColourType.TARGET_COLOUR_COUNT = 5
