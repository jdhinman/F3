ESaveGameValidity = {}
ESaveGameValidity.SAVE_GAME_INVALID = 0
ESaveGameValidity.SAVE_GAME_VALID = 1
ESaveGameValidity.SAVE_GAME_HERO_SAVE_ONLY = 2
ESaveGameValidity.SAVE_GAME_VERSION_MISMATCH = 3
ESaveGameValidity.SAVE_GAME_DLC_MISMATCH = 4
ESaveGameValidity.SAVE_GAME_PREMIUM_DLC_MISMATCH = 5
