EAlternateCombatSystemMode = {}
EAlternateCombatSystemMode.MELEE_MODE = 0
EAlternateCombatSystemMode.RANGED_MODE = 1
EAlternateCombatSystemMode.MAGIC_MODE = 2
EAlternateCombatSystemMode.NUM_COMBAT_MODES = 3




