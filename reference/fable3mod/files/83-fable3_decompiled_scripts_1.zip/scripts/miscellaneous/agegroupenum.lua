EAgeGroup = {}
EAgeGroup.EAGE_GROUP_BABY = 0
EAgeGroup.EAGE_GROUP_CHILD = 1
EAgeGroup.EAGE_GROUP_ADULT = 2
EAgeGroup.EAGE_GROUP_ELDER = 3
EAgeGroup.EAGE_GROUP_NONE = 4





