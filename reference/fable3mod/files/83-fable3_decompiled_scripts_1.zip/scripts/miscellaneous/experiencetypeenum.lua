EExperienceGainMethod = {}
EExperienceGainMethod.EXPERIENCE_GAIN_METHOD_GENERAL = 0
EExperienceGainMethod.EXPERIENCE_GAIN_METHOD_COMBAT = 1
EExperienceGainMethod.EXPERIENCE_GAIN_METHOD_INTERACTION = 2
EExperienceGainMethod.EXPERIENCE_GAIN_METHOD_RELATIONSHIP = 3
EExperienceGainMethod.EXPERIENCE_GAIN_METHOD_LOST = 4
EExperienceGainMethod.EXPERIENCE_GAIN_METHOD_COUNT = 5

EExperienceGuildSealColour = {}
EExperienceGuildSealColour.EXPERIENCE_GUILD_SEAL_BRONZE = 0
EExperienceGuildSealColour.EXPERIENCE_GUILD_SEAL_SILVER = 1
EExperienceGuildSealColour.EXPERIENCE_GUILD_SEAL_GOLD = 2
EExperienceGuildSealColour.EXPERIENCE_GUILD_SEAL_NONE = 3

EExperienceType = {}
EExperienceType.EXPERIENCE_GENERAL = 0
EExperienceType.EXPERIENCE_STRENGTH = 1
EExperienceType.EXPERIENCE_SKILL = 2
EExperienceType.EXPERIENCE_WILL = 3
EExperienceType.EXPERIENCE_FROM_CHEST = 4
EExperienceType.EXPERIENCE_LOST_ON_DEATH = 5
EExperienceType.EXPERIENCE_TYPE_COUNT = 6
