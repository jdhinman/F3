ENPCRewardType = {}
ENPCRewardType.NPC_REWARD_NULL = 0
ENPCRewardType.NPC_REWARD_GIFT = 1
ENPCRewardType.NPC_REWARD_QUEST = 2
ENPCRewardType.NPC_REWARD_HERO_TITLE = 3
ENPCRewardType.NPC_REWARD_HINT = 4
ENPCRewardType.NPC_REWARD_TRAINING = 5

ERewardGiftType = {}
ERewardGiftType.ERGT_NONE = 0
ERewardGiftType.ERGT_RELATIONSHIP = 1
ERewardGiftType.ERGT_RULER = 2
ERewardGiftType.ERGT_FAMILY = 3
