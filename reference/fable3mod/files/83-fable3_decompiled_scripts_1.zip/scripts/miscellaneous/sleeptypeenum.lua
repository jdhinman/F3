ESexType = {}
ESexType.SEX_NONE = -1
ESexType.SEX_UNPROTECTED = 0
ESexType.SEX_MAX = 1
ESexType.SEX_PROTECTED = 1

ESleepType = {}
ESleepType.SLEEP_NONE = -1
ESleepType.SLEEP_MORNING = 0
ESleepType.SLEEP_MIDDAY = 1
ESleepType.SLEEP_MAX = 2
ESleepType.SLEEP_MIDNIGHT = 2
