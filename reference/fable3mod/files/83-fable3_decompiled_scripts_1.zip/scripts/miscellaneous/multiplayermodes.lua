EMultiplayerMode = {}
EMultiplayerMode.MULTI_PLAYER_MODE_MULTI_PLAYER = 0
EMultiplayerMode.MULTI_PLAYER_MODE_SHARED_SCREEN = 1
EMultiplayerMode.MULTI_PLAYER_MODE_NULL = 2
