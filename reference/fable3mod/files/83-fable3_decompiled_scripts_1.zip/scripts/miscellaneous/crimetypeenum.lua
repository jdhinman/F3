ECrimeReportedBy = {}
ECrimeReportedBy.ECRB_VICTIM = 0
ECrimeReportedBy.ECRB_WITNESS = 1
ECrimeReportedBy.ECRB_EVERYONE = 2

ECrimeSeverity = {}
ECrimeSeverity.ECS_NOT_A_CRIME = 0
ECrimeSeverity.ECS_MINOR = 1
ECrimeSeverity.ECS_MODERATE = 2
ECrimeSeverity.ECS_SERIOUS = 3
ECrimeSeverity.ECS_VERY_SERIOUS = 4

ECrimeType = {}
ECrimeType.ECT_ATTEMPTED_MURDER = 0
ECrimeType.ECT_MURDER = 1
ECrimeType.ECT_DRUNK_DISORDERLY = 2
ECrimeType.ECT_EXTORTION = 3
ECrimeType.ECT_HARASSMENT = 4
ECrimeType.ECT_PAROLE_VIOLATION = 5
ECrimeType.ECT_RESISTING_ARREST = 6
ECrimeType.ECT_THEFT = 7
ECrimeType.ECT_TRESPASS = 8
ECrimeType.ECT_VAGRANCY = 9
ECrimeType.ECT_VANDALISM = 10
ECrimeType.ECT_GRAVE_ROBBING = 11
ECrimeType.ECT_MAX = 12
