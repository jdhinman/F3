EFollowerBarSlide = {}
EFollowerBarSlide.NONE = 0
EFollowerBarSlide.HIDE = 1
EFollowerBarSlide.NORMAL = 2
EFollowerBarSlide.RULER = 3
