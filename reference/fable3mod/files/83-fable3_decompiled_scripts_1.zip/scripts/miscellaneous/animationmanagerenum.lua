EAnimationHierarchyOrderingCanine = {}
EAnimationHierarchyOrderingCanine.AOP_CANINE_NULL = 0
EAnimationHierarchyOrderingCanine.AOP_CANINE_MAIN_ANIMATION = 1
EAnimationHierarchyOrderingCanine.AOP_CANINE_BACK_LEGS = 2
EAnimationHierarchyOrderingCanine.AOP_CANINE_FRONT_LEGS = 3
EAnimationHierarchyOrderingCanine.AOP_CANINE_HEAD_TURN = 4
EAnimationHierarchyOrderingCanine.AOP_CANINE_FACIAL_EXPRESSION = 5
EAnimationHierarchyOrderingCanine.AOP_CANINE_EARS = 6
EAnimationHierarchyOrderingCanine.AOP_CANINE_TAIL = 7

EAnimationHierarchyOrderingDefault = {}
EAnimationHierarchyOrderingDefault.AOP_DEFAULT_NULL = 0
EAnimationHierarchyOrderingDefault.AOP_DEFAULT_MAIN_ANIMATION = 1
EAnimationHierarchyOrderingDefault.AOP_DEFAULT_BODY_TURN = 2
EAnimationHierarchyOrderingDefault.AOP_DEFAULT_UPPER_BODY = 3
EAnimationHierarchyOrderingDefault.AOP_DEFAULT_DELTA_UPPER_BODY = 4
EAnimationHierarchyOrderingDefault.AOP_DEFAULT_WINGS = 5
EAnimationHierarchyOrderingDefault.AOP_DEFAULT_GESTURE = 6
EAnimationHierarchyOrderingDefault.AOP_DEFAULT_HEAD_TURN = 7
EAnimationHierarchyOrderingDefault.AOP_DEFAULT_FACIAL_EXPRESSION = 8
EAnimationHierarchyOrderingDefault.AOP_DEFAULT_LEFT_HAND_ANIMATION = 9
EAnimationHierarchyOrderingDefault.AOP_DEFAULT_RIGHT_HAND_ANIMATION = 10

