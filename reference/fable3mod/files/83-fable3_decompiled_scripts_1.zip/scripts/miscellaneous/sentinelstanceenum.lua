ESentinelStance = {}
ESentinelStance.SENTINEL_STATUE = 0
ESentinelStance.SENTINEL_ACTIVE = 1
ESentinelStance.SENTINEL_MAGIC_READY = 2
ESentinelStance.SENTINEL_STANCE_COUNT = 3
