EAnimationUsePriority = {}
EAnimationUsePriority.AUP_NULL = 0
EAnimationUsePriority.AUP_POSE = 1
EAnimationUsePriority.AUP_IDLE = 2
EAnimationUsePriority.AUP_SPEECH_IDLE = 4
EAnimationUsePriority.AUP_MOVEMENT = 8
EAnimationUsePriority.NUM_ANIM_USE_PRIORITIES = 10
EAnimationUsePriority.AUP_TURNING = 16
EAnimationUsePriority.AUP_BLOCK_POSE = 32
EAnimationUsePriority.AUP_CHARGE_STRIKE = 64
EAnimationUsePriority.AUP_NETWORK = 128
EAnimationUsePriority.AUP_ACTION = 256
EAnimationUsePriority.AUP_PAIRED_ACTION = 512
EAnimationUsePriority.AUP_ALL = 1023













