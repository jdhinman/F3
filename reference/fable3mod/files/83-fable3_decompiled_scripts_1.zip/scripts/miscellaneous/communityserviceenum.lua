ECommunityServiceStage = {}
ECommunityServiceStage.ECSS_INACTIVE = 0
ECommunityServiceStage.ECSS_ACTIVE = 1
ECommunityServiceStage.ECSS_SUCCEEDED = 2
ECommunityServiceStage.ECSS_FAILED = 3
ECommunityServiceStage.ECSS_BROKEPAROLE = 4
ECommunityServiceStage.ECSS_MAX = 5
