
-- Idle --
CombatSequences.Idle = {}
CombatSequences.Idle.Priority = SequencePriorities.Idle
CombatSequences.Idle.Zones = {}
CombatSequences.Idle.Zones[CombatZones.Middle] = true
CombatSequences.Idle.Actions = {
	{
		Anim = "CombatIdle"
	}
}

-- IdleLong --
CombatSequences.IdleLong = {}
CombatSequences.IdleLong.Priority = SequencePriorities.PreferredIdle
CombatSequences.IdleLong.MaxSecondsSinceAttack = 1
CombatSequences.IdleLong.Zones = {}
CombatSequences.IdleLong.Zones[CombatZones.Middle] = true
CombatSequences.IdleLong.Zones[CombatZones.OuterRing] = true
CombatSequences.IdleLong.Actions = {
	{
		Anim = "CombatIdleLong"
	}
}

-- FarIdle --
CombatSequences.FarIdle = {}
CombatSequences.FarIdle.Priority = SequencePriorities.Idle
CombatSequences.FarIdle.Zones = {}
CombatSequences.FarIdle.Zones[CombatZones.Far] = true
CombatSequences.FarIdle.Actions = {
	{
		Anim = "CombatIdle"
	}
}

-- OuterRingIdle --
CombatSequences.OuterRingIdle = {}
CombatSequences.OuterRingIdle.Priority = SequencePriorities.Idle
CombatSequences.OuterRingIdle.Zones = {}
CombatSequences.OuterRingIdle.Zones[CombatZones.OuterRing] = true
CombatSequences.OuterRingIdle.Actions = {
	{
		Anim = "CombatIdle"
	}
}

-- RangedIdle --
CombatSequences.RangedIdle = {}
CombatSequences.RangedIdle.Priority = SequencePriorities.Idle
CombatSequences.RangedIdle.Zones = {}
CombatSequences.RangedIdle.Zones[CombatZones.OuterRing] = true
CombatSequences.RangedIdle.Actions = {
	{
		Anim = "CombatIdle"
	}
}

-- IdleStrafe --
CombatSequences.IdleStrafe = {}
CombatSequences.IdleStrafe.Priority = SequencePriorities.Idle
CombatSequences.IdleStrafe.Zones = {}
CombatSequences.IdleStrafe.Zones[CombatZones.Middle] = true
CombatSequences.IdleStrafe.Actions = {
	{
		Type = EScriptableAction.STRAFE,
		Anim = "CombatStrafeLeft"
	},
	{
		Type = EScriptableAction.STRAFE,
		Anim = "CombatStrafeRight"
	}
}

-- IdleStrafeLeft --
CombatSequences.IdleStrafeLeft = {}
CombatSequences.IdleStrafeLeft.Priority = SequencePriorities.Idle
CombatSequences.IdleStrafeLeft.Zones = {}
CombatSequences.IdleStrafeLeft.Zones[CombatZones.Near] = true
CombatSequences.IdleStrafeLeft.Zones[CombatZones.Middle] = true
CombatSequences.IdleStrafeLeft.Zones[CombatZones.Far] = true
CombatSequences.IdleStrafeLeft.Actions = {
	{
		Type = EScriptableAction.STRAFE,
		Anim = "CombatStrafeLeft"
	}
}

-- IdleStrafeRight --
CombatSequences.IdleStrafeRight = {}
CombatSequences.IdleStrafeRight.Priority = SequencePriorities.Idle
CombatSequences.IdleStrafeRight.Zones = {}
CombatSequences.IdleStrafeRight.Zones[CombatZones.Near] = true
CombatSequences.IdleStrafeRight.Zones[CombatZones.Middle] = true
CombatSequences.IdleStrafeRight.Zones[CombatZones.Far] = true
CombatSequences.IdleStrafeRight.Actions = {
	{
		Type = EScriptableAction.STRAFE,
		Anim = "CombatStrafeRight"
	}
}

-- Advance --
CombatSequences.Advance = {}
CombatSequences.Advance.Priority = SequencePriorities.Movement
CombatSequences.Advance.Zones = {}
CombatSequences.Advance.Zones[CombatZones.Far] = true
CombatSequences.Advance.Actions = {
	{
		Type = EScriptableAction.STRAFE,
		Anim = "CombatStrafeForwards"
	}
}

-- BackOff --
CombatSequences.BackOff = {}
CombatSequences.BackOff.Priority = SequencePriorities.Movement
CombatSequences.BackOff.Zones = {}
CombatSequences.BackOff.Zones[CombatZones.Near] = true
CombatSequences.BackOff.Actions = {
	{
		Type = EScriptableAction.STRAFE,
		Anim = "CombatStrafeBackwards"
	}
}

-- BackOffToFar --
CombatSequences.BackOffToFar = {}
CombatSequences.BackOffToFar.Priority = SequencePriorities.Movement
CombatSequences.BackOffToFar.Zones = {}
CombatSequences.BackOffToFar.Zones[CombatZones.Middle] = true
CombatSequences.BackOffToFar.Actions = {
	{
		Type = EScriptableAction.STRAFE,
		Anim = "CombatStrafeBackwards"
	}
}

-- FastBackOff --
CombatSequences.FastBackOff = {}
CombatSequences.FastBackOff.Priority = SequencePriorities.Movement
CombatSequences.FastBackOff.Zones = {}
CombatSequences.FastBackOff.Zones[CombatZones.Near] = true
CombatSequences.FastBackOff.Actions = {
	{
		Type = EScriptableAction.STRAFE,
		Anim = "FastBackOff"
	}
}


-- uncomment for debug
-- GUI.DisplayMessageBox("CommonIdleAndMovementSequences.lua successfully loaded!")
-- while (GUI.IsDisplayBoxActive()) do
	-- coroutine.yield()
-- end