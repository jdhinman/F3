
-- HollowManAdvance --
CombatSequences.HollowManAdvance = {}
CombatSequences.HollowManAdvance.Priority = SequencePriorities.Movement
CombatSequences.HollowManAdvance.IsCombo = true
CombatSequences.HollowManAdvance.Zones = {}
CombatSequences.HollowManAdvance.Zones[CombatZones.Far] = true
CombatSequences.HollowManAdvance.Actions = {
	{
		Type = EScriptableAction.STRAFE,
		Anim = "CombatStrafeForwards"
	}
}

-- HollowmanCloseAttackCombo --
CombatSequences.HollowmanCloseAttackCombo = {}
CombatSequences.HollowmanCloseAttackCombo.Priority = SequencePriorities.Attack
CombatSequences.HollowmanCloseAttackCombo.IsCombo = true
CombatSequences.HollowmanCloseAttackCombo.Zones = {}
CombatSequences.HollowmanCloseAttackCombo.Zones[CombatZones.Near] = true
CombatSequences.HollowmanCloseAttackCombo.ZonesWhilePlaying = {}
CombatSequences.HollowmanCloseAttackCombo.ZonesWhilePlaying[CombatZones.Near] = true
CombatSequences.HollowmanCloseAttackCombo.ZonesWhilePlaying[CombatZones.Middle] = true
CombatSequences.HollowmanCloseAttackCombo.Actions = {
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "RunAttack",
		SpeedMultiplier = 1.1
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "AltStrike",
		SpeedMultiplier = 1.1
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "AltStrikeFollowUp",
		SpeedMultiplier = 1.1,
		IsComboBreak = true
	}
}

-- HollowmanAltCloseAttackCombo --
CombatSequences.HollowmanAltCloseAttackCombo = {}
CombatSequences.HollowmanAltCloseAttackCombo.Priority = SequencePriorities.Attack
CombatSequences.HollowmanAltCloseAttackCombo.IsCombo = true
CombatSequences.HollowmanAltCloseAttackCombo.Zones = {}
CombatSequences.HollowmanAltCloseAttackCombo.Zones[CombatZones.Near] = true
CombatSequences.HollowmanAltCloseAttackCombo.ZonesWhilePlaying = {}
CombatSequences.HollowmanAltCloseAttackCombo.ZonesWhilePlaying[CombatZones.Near] = true
CombatSequences.HollowmanAltCloseAttackCombo.ZonesWhilePlaying[CombatZones.Middle] = true
CombatSequences.HollowmanAltCloseAttackCombo.Actions = {
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "RunAttack",
		SpeedMultiplier = 1.1
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "TwinBladeCombo",
		SpeedMultiplier = 1.1
	}
}

-- HollowmanAttackCombo --
CombatSequences.HollowmanAttackCombo = {}
CombatSequences.HollowmanAttackCombo.Priority = SequencePriorities.Attack
CombatSequences.HollowmanAttackCombo.IsCombo = true
CombatSequences.HollowmanAttackCombo.Zones = {}
CombatSequences.HollowmanAttackCombo.Zones[CombatZones.Middle] = true
CombatSequences.HollowmanAttackCombo.ZonesWhilePlaying = {}
CombatSequences.HollowmanAttackCombo.ZonesWhilePlaying[CombatZones.Near] = true
CombatSequences.HollowmanAttackCombo.ZonesWhilePlaying[CombatZones.Middle] = true
CombatSequences.HollowmanAttackCombo.Actions = {
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "StrikeLeft",
		SpeedMultiplier = 1.1
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "StrikeRight",
		SpeedMultiplier = 1.1,
		IsComboBreak = true
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "AltStrike",
		SpeedMultiplier = 1.1
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "RunAttack",
		SpeedMultiplier = 1.1
	}
}

-- HollowmanAltAttackCombo --
CombatSequences.HollowmanAltAttackCombo = {}
CombatSequences.HollowmanAltAttackCombo.Priority = SequencePriorities.Attack
CombatSequences.HollowmanAltAttackCombo.IsCombo = true
CombatSequences.HollowmanAltAttackCombo.Zones = {}
CombatSequences.HollowmanAltAttackCombo.Zones[CombatZones.Middle] = true
CombatSequences.HollowmanAltAttackCombo.ZonesWhilePlaying = {}
CombatSequences.HollowmanAltAttackCombo.ZonesWhilePlaying[CombatZones.Near] = true
CombatSequences.HollowmanAltAttackCombo.ZonesWhilePlaying[CombatZones.Middle] = true
CombatSequences.HollowmanAltAttackCombo.Actions = {
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "StrikeLeft",
		SpeedMultiplier = 1.1
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "StrikeRight",
		SpeedMultiplier = 1.1,
		IsComboBreak = true
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "TwinBladeStrike",
		SpeedMultiplier = 1.1
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "RunAttack",
		SpeedMultiplier = 1.1
	}
}

-- HollowmanFarAttackCombo --
CombatSequences.HollowmanFarAttackCombo = {}
CombatSequences.HollowmanFarAttackCombo.Priority = SequencePriorities.Attack
CombatSequences.HollowmanFarAttackCombo.IsCombo = true
CombatSequences.HollowmanFarAttackCombo.Zones = {}
CombatSequences.HollowmanFarAttackCombo.Zones[CombatZones.Far] = true
CombatSequences.HollowmanFarAttackCombo.ZonesWhilePlaying = {}
CombatSequences.HollowmanFarAttackCombo.ZonesWhilePlaying[CombatZones.Near] = true
CombatSequences.HollowmanFarAttackCombo.ZonesWhilePlaying[CombatZones.Middle] = true
CombatSequences.HollowmanFarAttackCombo.ZonesWhilePlaying[CombatZones.Far] = true
CombatSequences.HollowmanFarAttackCombo.Actions = {
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "StrikeLeft",
		SpeedMultiplier = 1.1
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "StrikeRight",
		SpeedMultiplier = 1.1,
		IsComboBreak = true
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "AltStrike",
		SpeedMultiplier = 1.1
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "AltStrikeFollowUp",
		SpeedMultiplier = 1.1,
		IsComboBreak = true
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "StrikeLeft",
		SpeedMultiplier = 1.1
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "RunAttack",
		SpeedMultiplier = 1.1
	}
}

-- HollowmanAltFarAttackCombo --
CombatSequences.HollowmanAltFarAttackCombo = {}
CombatSequences.HollowmanAltFarAttackCombo.Priority = SequencePriorities.Attack
CombatSequences.HollowmanAltFarAttackCombo.IsCombo = true
CombatSequences.HollowmanAltFarAttackCombo.Zones = {}
CombatSequences.HollowmanAltFarAttackCombo.Zones[CombatZones.Far] = true
CombatSequences.HollowmanAltFarAttackCombo.ZonesWhilePlaying = {}
CombatSequences.HollowmanAltFarAttackCombo.ZonesWhilePlaying[CombatZones.Near] = true
CombatSequences.HollowmanAltFarAttackCombo.ZonesWhilePlaying[CombatZones.Middle] = true
CombatSequences.HollowmanAltFarAttackCombo.ZonesWhilePlaying[CombatZones.Far] = true
CombatSequences.HollowmanAltFarAttackCombo.Actions = {
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "StrikeLeft",
		SpeedMultiplier = 1.1
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "StrikeRight",
		SpeedMultiplier = 1.1,
		IsComboBreak = true
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "TwinBladeStrike",
		SpeedMultiplier = 1.1
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "AltStrike",
		SpeedMultiplier = 1.1
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "AltStrikeFollowUp",
		SpeedMultiplier = 1.1,
		IsComboBreak = true
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "TwinBladeCombo",
		SpeedMultiplier = 1.1
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "RunAttack",
		SpeedMultiplier = 1.1
	}
}

-- RunAttack --
CombatSequences.RunAttack = {}
CombatSequences.RunAttack.Priority = SequencePriorities.Attack
CombatSequences.RunAttack.Zones = {}
CombatSequences.RunAttack.Zones[CombatZones.Far] = true
CombatSequences.RunAttack.Actions = {
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "RunAttack",
		SpeedMultiplier = 1.1
	}
}

-- HollowmanShockCast --
CombatSequences.HollowmanShockCast = {}
CombatSequences.HollowmanShockCast.Priority = SequencePriorities.Attack
CombatSequences.HollowmanShockCast.Zones = {}
CombatSequences.HollowmanShockCast.Zones[CombatZones.Near] = true
CombatSequences.HollowmanShockCast.Zones[CombatZones.Middle] = true
CombatSequences.HollowmanShockCast.Zones[CombatZones.Far] = true
CombatSequences.HollowmanShockCast.Actions = {
	{
		Type = EScriptableAction.NPC_MAGIC_CHARGE,
		Anim = "CurseInto",
		SecondsToCharge = 0.5,
		SpellType = ESpellType.SPELL_LIGHTNING,
		Dummy = "Character.Focal.Mouth",
		ParticleScale = 0.75,
		ParticleAlpha = 1,
		StartParticle = true,
		PowerLevel = 1,
		Priority = EActionPriority.PRIORITY_COMBAT_MELEE_STRIKE,
		FaceTargetThroughout = true
	},
	{
		Type = EScriptableAction.NPC_MAGIC_QUICK_CAST,
		Anim = "CurseInto",
		SpellType = ESpellType.SPELL_LIGHTNING,
		SpellDirectionMode = ESpellCastDirMode.eSCDM_TARGETED,
		Dummy = "Character.Focal.Mouth",
		PowerLevel = 0,
		StopParticle = true,
		PowerLevel = 1,
		Priority = EActionPriority.PRIORITY_COMBAT_MELEE_STRIKE,
		FaceTargetThroughout = true
	}
}

-- HollowmanRearAttack --
CombatSequences.HollowmanRearAttack = {}
CombatSequences.HollowmanRearAttack.Priority = SequencePriorities.Attack
CombatSequences.HollowmanRearAttack.OverrideActionPriority = EActionPriority.PRIORITY_COMBAT_MELEE_STRIKE
CombatSequences.HollowmanRearAttack.CounterAttack = true
CombatSequences.HollowmanRearAttack.Zones = {}
CombatSequences.HollowmanRearAttack.Zones[CombatZones.Rear] = true
CombatSequences.HollowmanRearAttack.Actions = {
	{
		Type = EScriptableAction.NPC_MAGIC_CHARGE,
		Anim = "CurseInto",
		SecondsToCharge = 0.5,
		SpellType = ESpellType.SPELL_LIGHTNING,
		Dummy = "Character.Focal.Mouth",
		ParticleScale = 0.75,
		ParticleAlpha = 1,
		StartParticle = true,
		PowerLevel = 1,
		Priority = EActionPriority.PRIORITY_COMBAT_MELEE_STRIKE,
		FaceTargetThroughout = true
	},
	{
		Type = EScriptableAction.NPC_MAGIC_QUICK_CAST,
		Anim = "CurseInto",
		SpellType = ESpellType.SPELL_LIGHTNING,
		SpellDirectionMode = ESpellCastDirMode.eSCDM_SURROUND,
		Dummy = "Character.Focal.Mouth",
		PowerLevel = 0,
		StopParticle = true,
		Priority = EActionPriority.PRIORITY_COMBAT_MELEE_STRIKE,
		FaceTargetThroughout = true
	}
}

-- HollowmanFireCast --
CombatSequences.HollowmanFireCast = {}
CombatSequences.HollowmanFireCast.Priority = SequencePriorities.Attack
CombatSequences.HollowmanFireCast.Zones = {}
CombatSequences.HollowmanFireCast.Zones[CombatZones.Middle] = true
CombatSequences.HollowmanFireCast.Zones[CombatZones.Far] = true
CombatSequences.HollowmanFireCast.Actions = {
	{
		Type = EScriptableAction.NPC_MAGIC_CHARGE,
		Anim = "CurseInto",
		SecondsToCharge = 0.5,
		SpellType = ESpellType.SPELL_FIREBALL,
		Dummy = "Character.Focal.Mouth",
		ParticleScale = 0.75,
		ParticleAlpha = 1,
		StartParticle = true,
		PowerLevel = 4,
		Priority = EActionPriority.PRIORITY_COMBAT_MELEE_STRIKE,
		FaceTargetThroughout = true
	},
	{
		Type = EScriptableAction.NPC_MAGIC_QUICK_CAST,
		Anim = "CurseInto",
		SpeedMultiplier = 1.2,
		SpellType = ESpellType.SPELL_FIREBALL,
		SpellDirectionMode = ESpellCastDirMode.eSCDM_TARGETED,
		Dummy = "Character.Focal.Mouth",
		PowerLevel = 1,
		StopParticle = true,
		Priority = EActionPriority.PRIORITY_COMBAT_MELEE_STRIKE,
		FaceTargetThroughout = true
	}
}

-- HollowmanFireAoECast --
CombatSequences.HollowmanFireAoECast = {}
CombatSequences.HollowmanFireAoECast.Priority = SequencePriorities.Attack
CombatSequences.HollowmanFireAoECast.Zones = {}
CombatSequences.HollowmanFireAoECast.Zones[CombatZones.Near] = true
CombatSequences.HollowmanFireAoECast.Actions = {
	{
		Type = EScriptableAction.NPC_MAGIC_QUICK_CAST,
		Anim = "AoECast",
		SpellType = ESpellType.SPELL_FIREBALL,
		SpellDirectionMode = ESpellCastDirMode.eSCDM_SURROUND,
		Dummy = "Character.Focal.Chest",
		PowerLevel = 0,
		Priority = EActionPriority.PRIORITY_COMBAT_MELEE_STRIKE
	}
}

-- HollowmanFireRearAttack --
CombatSequences.HollowmanFireRearAttack = {}
CombatSequences.HollowmanFireRearAttack.Priority = SequencePriorities.Attack
CombatSequences.HollowmanFireRearAttack.OverrideActionPriority = EActionPriority.PRIORITY_COMBAT_UNINTERRUPTABLE_STRIKE
CombatSequences.HollowmanFireRearAttack.CounterAttack = true
CombatSequences.HollowmanFireRearAttack.Zones = {}
CombatSequences.HollowmanFireRearAttack.Zones[CombatZones.Rear] = true
CombatSequences.HollowmanFireRearAttack.Actions = {
	{
		Type = EScriptableAction.NPC_MAGIC_CHARGE,
		Anim = "CurseInto",
		SecondsToCharge = 0.5,
		SpellType = ESpellType.SPELL_FIREBALL,
		Dummy = "Character.Focal.Mouth",
		ParticleScale = 0.75,
		ParticleAlpha = 1,
		StartParticle = true,
		PowerLevel = 4,
		Priority = EActionPriority.PRIORITY_COMBAT_MELEE_STRIKE,
		FaceTargetThroughout = true
	},
	{
		Type = EScriptableAction.NPC_MAGIC_QUICK_CAST,
		Anim = "CurseInto",
		SpellType = ESpellType.SPELL_FIREBALL,
		SpellDirectionMode = ESpellCastDirMode.eSCDM_SURROUND,
		Dummy = "Character.Focal.Mouth",
		PowerLevel = 1,
		StopParticle = true,
		Priority = EActionPriority.PRIORITY_COMBAT_MELEE_STRIKE,
		FaceTargetThroughout = true
	}
}

-- HollowmanEliteCloseAttackCombo --
CombatSequences.HollowmanEliteCloseAttackCombo = {}
CombatSequences.HollowmanEliteCloseAttackCombo.Priority = SequencePriorities.Attack
CombatSequences.HollowmanEliteCloseAttackCombo.IsCombo = true
CombatSequences.HollowmanEliteCloseAttackCombo.Zones = {}
CombatSequences.HollowmanEliteCloseAttackCombo.Zones[CombatZones.Near] = true
CombatSequences.HollowmanEliteCloseAttackCombo.ZonesWhilePlaying = {}
CombatSequences.HollowmanEliteCloseAttackCombo.ZonesWhilePlaying[CombatZones.Near] = true
CombatSequences.HollowmanEliteCloseAttackCombo.ZonesWhilePlaying[CombatZones.Middle] = true
CombatSequences.HollowmanEliteCloseAttackCombo.Actions = {
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "AltStrike",
		SpeedMultiplier = 1.2
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "AltStrikeFollowUp",
		SpeedMultiplier = 1.2,
		IsComboBreak = true
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "StrikeLeft",
		SpeedMultiplier = 1.2,
		IsComboBreak = true
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "StrikeRight",
		SpeedMultiplier = 1.2
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "RunAttack",
		SpeedMultiplier = 1.2
	}
}

-- HollowmanAltEliteCloseAttackCombo --
CombatSequences.HollowmanAltEliteCloseAttackCombo = {}
CombatSequences.HollowmanAltEliteCloseAttackCombo.Priority = SequencePriorities.Attack
CombatSequences.HollowmanAltEliteCloseAttackCombo.IsCombo = true
CombatSequences.HollowmanAltEliteCloseAttackCombo.Zones = {}
CombatSequences.HollowmanAltEliteCloseAttackCombo.Zones[CombatZones.Near] = true
CombatSequences.HollowmanAltEliteCloseAttackCombo.ZonesWhilePlaying = {}
CombatSequences.HollowmanAltEliteCloseAttackCombo.ZonesWhilePlaying[CombatZones.Near] = true
CombatSequences.HollowmanAltEliteCloseAttackCombo.ZonesWhilePlaying[CombatZones.Middle] = true
CombatSequences.HollowmanAltEliteCloseAttackCombo.Actions = {
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "AltStrike",
		SpeedMultiplier = 1.2
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "AltStrikeFollowUp",
		SpeedMultiplier = 1.2,
		IsComboBreak = true
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "TwinBladeStrike",
		SpeedMultiplier = 1.2,
		IsComboBreak = true
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "RunAttack",
		SpeedMultiplier = 1.2
	}
}

-- HollowmanEliteAttackCombo --
CombatSequences.HollowmanEliteAttackCombo = {}
CombatSequences.HollowmanEliteAttackCombo.Priority = SequencePriorities.Attack
CombatSequences.HollowmanEliteAttackCombo.IsCombo = true
CombatSequences.HollowmanEliteAttackCombo.Zones = {}
CombatSequences.HollowmanEliteAttackCombo.Zones[CombatZones.Middle] = true
CombatSequences.HollowmanEliteAttackCombo.ZonesWhilePlaying = {}
CombatSequences.HollowmanEliteAttackCombo.ZonesWhilePlaying[CombatZones.Near] = true
CombatSequences.HollowmanEliteAttackCombo.ZonesWhilePlaying[CombatZones.Middle] = true
CombatSequences.HollowmanEliteAttackCombo.Actions = {
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "StrikeLeft",
		SpeedMultiplier = 1.2
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "StrikeRight",
		SpeedMultiplier = 1.2,
		IsComboBreak = true
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "AltStrike",
		SpeedMultiplier = 1.2
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "AltStrikeFollowUp",
		SpeedMultiplier = 1.2,
		IsComboBreak = true
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "StrikeLeft",
		SpeedMultiplier = 1.2,
		IsComboBreak = true
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "StrikeRight",
		SpeedMultiplier = 1.2
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "RunAttack",
		SpeedMultiplier = 1.2
	}
}

-- HollowmanAltEliteAttackCombo --
CombatSequences.HollowmanAltEliteAttackCombo = {}
CombatSequences.HollowmanAltEliteAttackCombo.Priority = SequencePriorities.Attack
CombatSequences.HollowmanAltEliteAttackCombo.IsCombo = true
CombatSequences.HollowmanAltEliteAttackCombo.Zones = {}
CombatSequences.HollowmanAltEliteAttackCombo.Zones[CombatZones.Middle] = true
CombatSequences.HollowmanAltEliteAttackCombo.ZonesWhilePlaying = {}
CombatSequences.HollowmanAltEliteAttackCombo.ZonesWhilePlaying[CombatZones.Near] = true
CombatSequences.HollowmanAltEliteAttackCombo.ZonesWhilePlaying[CombatZones.Middle] = true
CombatSequences.HollowmanAltEliteAttackCombo.Actions = {
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "StrikeLeft",
		SpeedMultiplier = 1.2
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "StrikeRight",
		SpeedMultiplier = 1.2,
		IsComboBreak = true
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "TwinBladeStrike",
		SpeedMultiplier = 1.2,
		IsComboBreak = true
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "StrikeLeft",
		SpeedMultiplier = 1.2,
		IsComboBreak = true
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "StrikeRight",
		SpeedMultiplier = 1.2
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "TwinBladeCombo",
		SpeedMultiplier = 1.2,
		IsComboBreak = true
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "RunAttack",
		SpeedMultiplier = 1.2
	}
}

-- HollowmanEliteFarAttackCombo --
CombatSequences.HollowmanEliteFarAttackCombo = {}
CombatSequences.HollowmanEliteFarAttackCombo.Priority = SequencePriorities.Attack
CombatSequences.HollowmanEliteFarAttackCombo.IsCombo = true
CombatSequences.HollowmanEliteFarAttackCombo.Zones = {}
CombatSequences.HollowmanEliteFarAttackCombo.Zones[CombatZones.Far] = true
CombatSequences.HollowmanEliteFarAttackCombo.ZonesWhilePlaying = {}
CombatSequences.HollowmanEliteFarAttackCombo.ZonesWhilePlaying[CombatZones.Near] = true
CombatSequences.HollowmanEliteFarAttackCombo.ZonesWhilePlaying[CombatZones.Middle] = true
CombatSequences.HollowmanEliteFarAttackCombo.ZonesWhilePlaying[CombatZones.Far] = true
CombatSequences.HollowmanEliteFarAttackCombo.Actions = {
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "StrikeLeft",
		SpeedMultiplier = 1.2
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "StrikeRight",
		SpeedMultiplier = 1.2,
		IsComboBreak = true
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "AltStrike",
		SpeedMultiplier = 1.2
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "AltStrikeFollowUp",
		SpeedMultiplier = 1.2,
		IsComboBreak = true
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "StrikeLeft",
		SpeedMultiplier = 1.2
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "StrikeRight",
		SpeedMultiplier = 1.2,
		IsComboBreak = true
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "AltStrike",
		SpeedMultiplier = 1.2,
		IsComboBreak = true
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "AltStrikeFollowUp",
		SpeedMultiplier = 1.2
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "RunAttack",
		SpeedMultiplier = 1.2
	}
}

-- HollowmanAltEliteFarAttackCombo --
CombatSequences.HollowmanAltEliteFarAttackCombo = {}
CombatSequences.HollowmanAltEliteFarAttackCombo.Priority = SequencePriorities.Attack
CombatSequences.HollowmanAltEliteFarAttackCombo.IsCombo = true
CombatSequences.HollowmanAltEliteFarAttackCombo.Zones = {}
CombatSequences.HollowmanAltEliteFarAttackCombo.Zones[CombatZones.Far] = true
CombatSequences.HollowmanAltEliteFarAttackCombo.ZonesWhilePlaying = {}
CombatSequences.HollowmanAltEliteFarAttackCombo.ZonesWhilePlaying[CombatZones.Near] = true
CombatSequences.HollowmanAltEliteFarAttackCombo.ZonesWhilePlaying[CombatZones.Middle] = true
CombatSequences.HollowmanAltEliteFarAttackCombo.ZonesWhilePlaying[CombatZones.Far] = true
CombatSequences.HollowmanAltEliteFarAttackCombo.Actions = {
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "StrikeLeft",
		SpeedMultiplier = 1.2
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "StrikeRight",
		SpeedMultiplier = 1.2,
		IsComboBreak = true
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "TwinBladeStrike",
		SpeedMultiplier = 1.2,
		IsComboBreak = true
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "StrikeLeft",
		SpeedMultiplier = 1.2
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "StrikeRight",
		SpeedMultiplier = 1.2,
		IsComboBreak = true
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "TwinBladeCombo",
		SpeedMultiplier = 1.2,
		IsComboBreak = true
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "AltStrike",
		SpeedMultiplier = 1.2,
		IsComboBreak = true
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "AltStrikeFollowUp",
		SpeedMultiplier = 1.2
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "RunAttack",
		SpeedMultiplier = 1.2
	}
}

-- HollowmanEliteOrbSuckingResponse --
CombatSequences.HollowmanEliteOrbSuckingResponse = {}
CombatSequences.HollowmanEliteOrbSuckingResponse.IsValid = Predicate.IsSuckModeActive
CombatSequences.HollowmanEliteOrbSuckingResponse.Priority = SequencePriorities.Attack
CombatSequences.HollowmanEliteOrbSuckingResponse.CounterAttack = true
CombatSequences.HollowmanEliteOrbSuckingResponse.Zones = {}
CombatSequences.HollowmanEliteOrbSuckingResponse.Zones[CombatZones.Near] = true
CombatSequences.HollowmanEliteOrbSuckingResponse.Zones[CombatZones.Middle] = true
CombatSequences.HollowmanEliteOrbSuckingResponse.Zones[CombatZones.Far] = true
CombatSequences.HollowmanEliteOrbSuckingResponse.Actions = {
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "AltStrike",
		SpeedMultiplier = 1.2,
		IsComboBreak = true
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "AltStrikeFollowUp",
		SpeedMultiplier = 1.2
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "RunAttack",
		SpeedMultiplier = 1.1
	}
}

-- HollowmanEliteShockCast --
CombatSequences.HollowmanEliteShockCast = {}
CombatSequences.HollowmanEliteShockCast.Priority = SequencePriorities.Attack
CombatSequences.HollowmanEliteShockCast.IsCombo = true
CombatSequences.HollowmanEliteShockCast.Zones = {}
CombatSequences.HollowmanEliteShockCast.Zones[CombatZones.Near] = true
CombatSequences.HollowmanEliteShockCast.Zones[CombatZones.Middle] = true
CombatSequences.HollowmanEliteShockCast.Zones[CombatZones.Far] = true
CombatSequences.HollowmanEliteShockCast.Actions = {
	{
		Type = EScriptableAction.NPC_MAGIC_CHARGE,
		Anim = "CurseInto",
		SecondsToCharge = 0.5,
		SpellType = ESpellType.SPELL_LIGHTNING,
		Dummy = "Character.Focal.Mouth",
		ParticleScale = 0.75,
		ParticleAlpha = 1,
		StartParticle = true,
		PowerLevel = 1,
		Priority = EActionPriority.PRIORITY_COMBAT_MELEE_STRIKE,
		FaceTargetThroughout = true
	},
	{
		Type = EScriptableAction.NPC_MAGIC_QUICK_CAST,
		Anim = "CurseInto",
		SpellType = ESpellType.SPELL_LIGHTNING,
		SpellDirectionMode = ESpellCastDirMode.eSCDM_TARGETED,
		Dummy = "Character.Focal.Mouth",
		PowerLevel = 1,
		StopParticle = true,
		Priority = EActionPriority.PRIORITY_COMBAT_MELEE_STRIKE,
		FaceTargetThroughout = true
	}
}

-- HollowmanEliteRearAttack --
CombatSequences.HollowmanEliteRearAttack = {}
CombatSequences.HollowmanEliteRearAttack.Priority = SequencePriorities.Attack
CombatSequences.HollowmanEliteRearAttack.OverrideActionPriority = EActionPriority.PRIORITY_COMBAT_UNINTERRUPTABLE_STRIKE
CombatSequences.HollowmanEliteRearAttack.CounterAttack = true
CombatSequences.HollowmanEliteRearAttack.Zones = {}
CombatSequences.HollowmanEliteRearAttack.Zones[CombatZones.Rear] = true
CombatSequences.HollowmanEliteRearAttack.Actions = {
	{
		Type = EScriptableAction.NPC_MAGIC_CHARGE,
		Anim = "CurseInto",
		SecondsToCharge = 0.5,
		SpellType = ESpellType.SPELL_LIGHTNING,
		Dummy = "Character.Focal.Mouth",
		ParticleScale = 0.75,
		ParticleAlpha = 1,
		StartParticle = true,
		PowerLevel = 1,
		Priority = EActionPriority.PRIORITY_COMBAT_MELEE_STRIKE,
		FaceTargetThroughout = true
	},
	{
		Type = EScriptableAction.NPC_MAGIC_QUICK_CAST,
		Anim = "CurseInto",
		SpellType = ESpellType.SPELL_LIGHTNING,
		SpellDirectionMode = ESpellCastDirMode.eSCDM_SURROUND,
		Dummy = "Character.Focal.Mouth",
		PowerLevel = 1,
		StopParticle = true,
		Priority = EActionPriority.PRIORITY_COMBAT_MELEE_STRIKE,
		FaceTargetThroughout = true
	}
}

-- HollowmanSummonerCloseAttackCombo --
CombatSequences.HollowmanSummonerCloseAttackCombo = {}
CombatSequences.HollowmanSummonerCloseAttackCombo.Priority = SequencePriorities.Attack
CombatSequences.HollowmanSummonerCloseAttackCombo.IsCombo = true
CombatSequences.HollowmanSummonerCloseAttackCombo.Zones = {}
CombatSequences.HollowmanSummonerCloseAttackCombo.Zones[CombatZones.Near] = true
CombatSequences.HollowmanSummonerCloseAttackCombo.Zones[CombatZones.Middle] = true
CombatSequences.HollowmanSummonerCloseAttackCombo.ZonesWhilePlaying = {}
CombatSequences.HollowmanSummonerCloseAttackCombo.ZonesWhilePlaying[CombatZones.Near] = true
CombatSequences.HollowmanSummonerCloseAttackCombo.ZonesWhilePlaying[CombatZones.Middle] = true
CombatSequences.HollowmanSummonerCloseAttackCombo.Actions = {
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "StrikeLeft"
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "StrikeRight",
		IsComboBreak = true
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "TwinBladeCombo",
		IsComboBreak = true
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "RunAttack"
	}
}

-- HollowmanSummonerAttackCombo --
CombatSequences.HollowmanSummonerAttackCombo = {}
CombatSequences.HollowmanSummonerAttackCombo.Priority = SequencePriorities.Attack
CombatSequences.HollowmanSummonerAttackCombo.IsCombo = true
CombatSequences.HollowmanSummonerAttackCombo.Zones = {}
CombatSequences.HollowmanSummonerAttackCombo.Zones[CombatZones.Middle] = true
CombatSequences.HollowmanSummonerAttackCombo.Zones[CombatZones.Far] = true
CombatSequences.HollowmanSummonerAttackCombo.ZonesWhilePlaying = {}
CombatSequences.HollowmanSummonerAttackCombo.ZonesWhilePlaying[CombatZones.Near] = true
CombatSequences.HollowmanSummonerAttackCombo.ZonesWhilePlaying[CombatZones.Middle] = true
CombatSequences.HollowmanSummonerAttackCombo.ZonesWhilePlaying[CombatZones.Far] = true
CombatSequences.HollowmanSummonerAttackCombo.Actions = {
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "StrikeLeft"
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "StrikeRight",
		IsComboBreak = true
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "TwinBladeCombo",
		IsComboBreak = true
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "StrikeLeft",
		IsComboBreak = true
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "StrikeRight"
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "RunAttack"
	}
}

-- HollowmanSummonerFarAttackCombo --
CombatSequences.HollowmanSummonerFarAttackCombo = {}
CombatSequences.HollowmanSummonerFarAttackCombo.Priority = SequencePriorities.Attack
CombatSequences.HollowmanSummonerFarAttackCombo.IsCombo = true
CombatSequences.HollowmanSummonerFarAttackCombo.Zones = {}
CombatSequences.HollowmanSummonerFarAttackCombo.Zones[CombatZones.Middle] = true
CombatSequences.HollowmanSummonerFarAttackCombo.Zones[CombatZones.Far] = true
CombatSequences.HollowmanSummonerFarAttackCombo.ZonesWhilePlaying = {}
CombatSequences.HollowmanSummonerFarAttackCombo.ZonesWhilePlaying[CombatZones.Near] = true
CombatSequences.HollowmanSummonerFarAttackCombo.ZonesWhilePlaying[CombatZones.Middle] = true
CombatSequences.HollowmanSummonerFarAttackCombo.ZonesWhilePlaying[CombatZones.Far] = true
CombatSequences.HollowmanSummonerFarAttackCombo.Actions = {
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "StrikeLeft"
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "StrikeRight",
		IsComboBreak = true
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "TwinBladeCombo",
		IsComboBreak = true
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "StrikeLeft"
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "StrikeRight",
		IsComboBreak = true
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "TwinBladeCombo",
		IsComboBreak = true
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "RunAttack"
	}
}

-- HollowmanSummonerAttackOutOfBlock --
CombatSequences.HollowmanSummonerAttackOutOfBlock = {}
CombatSequences.HollowmanSummonerAttackOutOfBlock.IsValid = Predicate.HasBlockedThisManyStrikesInCurrentMode(2)
CombatSequences.HollowmanSummonerAttackOutOfBlock.Priority = SequencePriorities.Attack
CombatSequences.HollowmanSummonerAttackOutOfBlock.CounterAttack = true
CombatSequences.HollowmanSummonerAttackOutOfBlock.OverrideActionPriority = EActionPriority.PRIORITY_COMBAT_UNINTERRUPTABLE_STRIKE
CombatSequences.HollowmanSummonerAttackOutOfBlock.Zones = {}
CombatSequences.HollowmanSummonerAttackOutOfBlock.Zones[CombatZones.Near] = true
CombatSequences.HollowmanSummonerAttackOutOfBlock.Zones[CombatZones.Middle] = true
CombatSequences.HollowmanSummonerAttackOutOfBlock.Actions = {
	{
		Type = EScriptableAction.NPC_MAGIC_CHARGE,
		Anim = "SpellCast",
		SecondsToCharge = 0.5,
		SpellType = ESpellType.SPELL_LIGHTNING,
		Dummy = "Character.Focal.Mouth",
		ParticleScale = 0.75,
		ParticleAlpha = 1,
		StartParticle = true,
		PowerLevel = 2,
		Priority = EActionPriority.PRIORITY_COMBAT_MELEE_STRIKE,
		FaceTargetThroughout = true
	},
	{
		Type = EScriptableAction.NPC_MAGIC_QUICK_CAST,
		Anim = "SpellCast",
		SpeedMultiplier = 1.5,
		SpellType = ESpellType.SPELL_LIGHTNING,
		SecondSpellType = ESpellType.SPELL_FORCE_PUSH,
		SpellDirectionMode = ESpellCastDirMode.eSCDM_SURROUND,
		Dummy = "Character.Focal.Mouth",
		PowerLevel = 2,
		StopParticle = true,
		Priority = EActionPriority.PRIORITY_COMBAT_MELEE_STRIKE
	}
}

-- HollowmanSummonerRangedCounter --
CombatSequences.HollowmanSummonerRangedCounter = {}
CombatSequences.HollowmanSummonerRangedCounter.IsValid = Predicate.CreateHaveIBeenStruckALotPredicate(2)
CombatSequences.HollowmanSummonerRangedCounter.Priority = SequencePriorities.Attack
CombatSequences.HollowmanSummonerRangedCounter.IsCombo = true
CombatSequences.HollowmanSummonerRangedCounter.OverrideActionPriority = EActionPriority.PRIORITY_COMBAT_UNINTERRUPTABLE_STRIKE
CombatSequences.HollowmanSummonerRangedCounter.Zones = {}
CombatSequences.HollowmanSummonerRangedCounter.Zones[CombatZones.Near] = true
CombatSequences.HollowmanSummonerRangedCounter.Zones[CombatZones.Middle] = true
CombatSequences.HollowmanSummonerRangedCounter.Zones[CombatZones.Far] = true
CombatSequences.HollowmanSummonerRangedCounter.Actions = {
	{
		Type = EScriptableAction.NPC_MAGIC_CHARGE,
		Anim = "SpellCast",
		SecondsToCharge = 0.5,
		SpellType = ESpellType.SPELL_LIGHTNING,
		Dummy = "Character.Focal.Mouth",
		ParticleScale = 0.75,
		ParticleAlpha = 1,
		StartParticle = true,
		PowerLevel = 1,
		Priority = EActionPriority.PRIORITY_COMBAT_MELEE_STRIKE,
		FaceTargetThroughout = true
	},
	{
		Type = EScriptableAction.NPC_MAGIC_QUICK_CAST,
		Anim = "SpellCast",
		SpellType = ESpellType.SPELL_LIGHTNING,
		SpellDirectionMode = ESpellCastDirMode.eSCDM_TARGETED,
		Dummy = "Character.Focal.Mouth",
		PowerLevel = 1,
		StopParticle = true,
		Priority = EActionPriority.PRIORITY_COMBAT_MELEE_STRIKE,
		FaceTargetThroughout = true
	}
}

-- HollowmanSummonerSpellCast --
CombatSequences.HollowmanSummonerSpellCast = {}
CombatSequences.HollowmanSummonerSpellCast.Priority = SequencePriorities.Attack
CombatSequences.HollowmanSummonerSpellCast.IsCombo = true
CombatSequences.HollowmanSummonerSpellCast.Zones = {}
CombatSequences.HollowmanSummonerSpellCast.Zones[CombatZones.Near] = true
CombatSequences.HollowmanSummonerSpellCast.Zones[CombatZones.Middle] = true
CombatSequences.HollowmanSummonerSpellCast.Zones[CombatZones.Far] = true
CombatSequences.HollowmanSummonerSpellCast.Actions = {
	{
		Type = EScriptableAction.NPC_MAGIC_CHARGE,
		Anim = "SpellCast",
		SecondsToCharge = 0.5,
		SpellType = ESpellType.SPELL_LIGHTNING,
		Dummy = "Character.Focal.Mouth",
		ParticleScale = 0.75,
		ParticleAlpha = 1,
		StartParticle = true,
		PowerLevel = 1,
		Priority = EActionPriority.PRIORITY_COMBAT_MELEE_STRIKE,
		FaceTargetThroughout = true
	},
	{
		Type = EScriptableAction.NPC_MAGIC_QUICK_CAST,
		Anim = "SpellCast",
		SpellType = ESpellType.SPELL_LIGHTNING,
		SpellDirectionMode = ESpellCastDirMode.eSCDM_TARGETED,
		Dummy = "Character.Focal.Mouth",
		PowerLevel = 1,
		StopParticle = true,
		Priority = EActionPriority.PRIORITY_COMBAT_MELEE_STRIKE,
		FaceTargetThroughout = true
	}
}

-- HollowmanSummonerBackAttack --
CombatSequences.HollowmanSummonerBackAttack = {}
CombatSequences.HollowmanSummonerBackAttack.Priority = SequencePriorities.Attack
CombatSequences.HollowmanSummonerBackAttack.OverrideActionPriority = EActionPriority.PRIORITY_COMBAT_UNINTERRUPTABLE_STRIKE
CombatSequences.HollowmanSummonerBackAttack.CounterAttack = true
CombatSequences.HollowmanSummonerBackAttack.Zones = {}
CombatSequences.HollowmanSummonerBackAttack.Zones[CombatZones.Rear] = true
CombatSequences.HollowmanSummonerBackAttack.Actions = {
	{
		Type = EScriptableAction.NPC_MAGIC_CHARGE,
		Anim = "SpellCast",
		SecondsToCharge = 0.5,
		SpellType = ESpellType.SPELL_LIGHTNING,
		Dummy = "Character.Focal.Mouth",
		ParticleScale = 0.75,
		ParticleAlpha = 1,
		StartParticle = true,
		PowerLevel = 2,
		Priority = EActionPriority.PRIORITY_COMBAT_MELEE_STRIKE,
		FaceTargetThroughout = true
	},
	{
		Type = EScriptableAction.NPC_MAGIC_QUICK_CAST,
		Anim = "SpellCast",
		SpeedMultiplier = 1.5,
		SpellType = ESpellType.SPELL_LIGHTNING,
		SecondSpellType = ESpellType.SPELL_FORCE_PUSH,
		SpellDirectionMode = ESpellCastDirMode.eSCDM_SURROUND,
		Dummy = "Character.Focal.Mouth",
		PowerLevel = 2,
		StopParticle = true,
		Priority = EActionPriority.PRIORITY_COMBAT_MELEE_STRIKE
	}
}

-- SimmonsAttackOutOfBlock --
CombatSequences.SimmonsAttackOutOfBlock = {}
CombatSequences.SimmonsAttackOutOfBlock.IsValid = Predicate.HasBlockedThisManyStrikesInCurrentMode(2)
CombatSequences.SimmonsAttackOutOfBlock.Priority = SequencePriorities.Attack
CombatSequences.SimmonsAttackOutOfBlock.CounterAttack = true
CombatSequences.SimmonsAttackOutOfBlock.OverrideActionPriority = EActionPriority.PRIORITY_COMBAT_UNINTERRUPTABLE_STRIKE
CombatSequences.SimmonsAttackOutOfBlock.Zones = {}
CombatSequences.SimmonsAttackOutOfBlock.Zones[CombatZones.Near] = true
CombatSequences.SimmonsAttackOutOfBlock.Zones[CombatZones.Middle] = true
CombatSequences.SimmonsAttackOutOfBlock.Actions = {
	{
		Type = EScriptableAction.NPC_MAGIC_CHARGE,
		Anim = "SpellCast",
		SecondsToCharge = 0.5,
		SpellType = ESpellType.SPELL_LIGHTNING,
		Dummy = "Character.Focal.Chest",
		ParticleScale = 0.75,
		ParticleAlpha = 1,
		StartParticle = true,
		PowerLevel = 2,
		Priority = EActionPriority.PRIORITY_COMBAT_MELEE_STRIKE,
		FaceTargetThroughout = true
	},
	{
		Type = EScriptableAction.NPC_MAGIC_QUICK_CAST,
		Anim = "SpellCast",
		SpeedMultiplier = 1.5,
		SpellType = ESpellType.SPELL_LIGHTNING,
		SecondSpellType = ESpellType.SPELL_FORCE_PUSH,
		SpellDirectionMode = ESpellCastDirMode.eSCDM_SURROUND,
		Dummy = "Character.Focal.Chest",
		PowerLevel = 3,
		StopParticle = true,
		Priority = EActionPriority.PRIORITY_COMBAT_MELEE_STRIKE
	}
}

-- SimmonsRangedCounter --
CombatSequences.SimmonsRangedCounter = {}
CombatSequences.SimmonsRangedCounter.IsValid = Predicate.CreateHaveIBeenStruckALotPredicate(2)
CombatSequences.SimmonsRangedCounter.Priority = SequencePriorities.Attack
CombatSequences.SimmonsRangedCounter.IsCombo = true
CombatSequences.SimmonsRangedCounter.OverrideActionPriority = EActionPriority.PRIORITY_COMBAT_UNINTERRUPTABLE_STRIKE
CombatSequences.SimmonsRangedCounter.Zones = {}
CombatSequences.SimmonsRangedCounter.Zones[CombatZones.Near] = true
CombatSequences.SimmonsRangedCounter.Zones[CombatZones.Middle] = true
CombatSequences.SimmonsRangedCounter.Zones[CombatZones.Far] = true
CombatSequences.SimmonsRangedCounter.Actions = {
	{
		Type = EScriptableAction.NPC_MAGIC_CHARGE,
		Anim = "SpellCast",
		SecondsToCharge = 0.5,
		SpellType = ESpellType.SPELL_SWORDS,
		Dummy = "Character.Focal.Chest",
		ParticleScale = 0.75,
		ParticleAlpha = 1,
		StartParticle = true,
		PowerLevel = 2,
		Priority = EActionPriority.PRIORITY_COMBAT_MELEE_STRIKE,
		FaceTargetThroughout = true
	},
	{
		Type = EScriptableAction.NPC_MAGIC_QUICK_CAST,
		Anim = "SpellCast",
		SpellType = ESpellType.SPELL_SWORDS,
		SecondSpellType = ESpellType.SPELL_LIGHTNING,
		SpellDirectionMode = ESpellCastDirMode.eSCDM_TARGETED,
		Dummy = "Character.Focal.Chest",
		PowerLevel = 1,
		StopParticle = true,
		Priority = EActionPriority.PRIORITY_COMBAT_MELEE_STRIKE,
		FaceTargetThroughout = true
	}
}

-- SimmonsSpellCast --
CombatSequences.SimmonsSpellCast = {}
CombatSequences.SimmonsSpellCast.Priority = SequencePriorities.Attack
CombatSequences.SimmonsSpellCast.OverrideActionPriority = EActionPriority.PRIORITY_COMBAT_UNINTERRUPTABLE_STRIKE
CombatSequences.SimmonsSpellCast.IsCombo = true
CombatSequences.SimmonsSpellCast.Zones = {}
CombatSequences.SimmonsSpellCast.Zones[CombatZones.Near] = true
CombatSequences.SimmonsSpellCast.Zones[CombatZones.Middle] = true
CombatSequences.SimmonsSpellCast.Zones[CombatZones.Far] = true
CombatSequences.SimmonsSpellCast.Actions = {
	{
		Type = EScriptableAction.NPC_MAGIC_CHARGE,
		Anim = "SpellCast",
		SecondsToCharge = 0.5,
		SpellType = ESpellType.SPELL_LIGHTNING,
		Dummy = "Character.Focal.Chest",
		ParticleScale = 0.75,
		ParticleAlpha = 1,
		StartParticle = true,
		PowerLevel = 2,
		Priority = EActionPriority.PRIORITY_COMBAT_MELEE_STRIKE,
		FaceTargetThroughout = true
	},
	{
		Type = EScriptableAction.NPC_MAGIC_QUICK_CAST,
		Anim = "SpellCast",
		SpellType = ESpellType.SPELL_SWORDS,
		SecondSpellType = ESpellType.SPELL_LIGHTNING,
		SpellDirectionMode = ESpellCastDirMode.eSCDM_SURROUND,
		Dummy = "Character.Focal.Chest",
		PowerLevel = 2,
		StopParticle = true,
		Priority = EActionPriority.PRIORITY_COMBAT_MELEE_STRIKE,
		FaceTargetThroughout = true
	}
}

-- SimmonsBackAttack --
CombatSequences.SimmonsBackAttack = {}
CombatSequences.SimmonsBackAttack.Priority = SequencePriorities.Attack
CombatSequences.SimmonsBackAttack.OverrideActionPriority = EActionPriority.PRIORITY_COMBAT_UNINTERRUPTABLE_STRIKE
CombatSequences.SimmonsBackAttack.CounterAttack = true
CombatSequences.SimmonsBackAttack.Zones = {}
CombatSequences.SimmonsBackAttack.Zones[CombatZones.Rear] = true
CombatSequences.SimmonsBackAttack.Actions = {
	{
		Type = EScriptableAction.NPC_MAGIC_CHARGE,
		Anim = "SpellCast",
		SecondsToCharge = 0.5,
		SpellType = ESpellType.SPELL_LIGHTNING,
		Dummy = "Character.Focal.Chest",
		ParticleScale = 0.75,
		ParticleAlpha = 1,
		StartParticle = true,
		PowerLevel = 2,
		Priority = EActionPriority.PRIORITY_COMBAT_MELEE_STRIKE,
		FaceTargetThroughout = true
	},
	{
		Type = EScriptableAction.NPC_MAGIC_QUICK_CAST,
		Anim = "SpellCast",
		SpeedMultiplier = 1.5,
		SpellType = ESpellType.SPELL_LIGHTNING,
		SecondSpellType = ESpellType.SPELL_FORCE_PUSH,
		SpellDirectionMode = ESpellCastDirMode.eSCDM_SURROUND,
		Dummy = "Character.Focal.Chest",
		PowerLevel = 2,
		StopParticle = true,
		Priority = EActionPriority.PRIORITY_COMBAT_MELEE_STRIKE
	}
}

-- SoldierCloseAttackCombo --
CombatSequences.SoldierCloseAttackCombo = {}
CombatSequences.SoldierCloseAttackCombo.Priority = SequencePriorities.Attack
CombatSequences.SoldierCloseAttackCombo.IsCombo = true
CombatSequences.SoldierCloseAttackCombo.Zones = {}
CombatSequences.SoldierCloseAttackCombo.Zones[CombatZones.Near] = true
CombatSequences.SoldierCloseAttackCombo.ZonesWhilePlaying = {}
CombatSequences.SoldierCloseAttackCombo.ZonesWhilePlaying[CombatZones.Near] = true
CombatSequences.SoldierCloseAttackCombo.Actions = {
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "AltStrike",
		SpeedMultiplier = 1.4
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "AltStrikeFollowUp",
		SpeedMultiplier = 1.4,
		IsComboBreak = true
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "StrikeLeft",
		SpeedMultiplier = 1.4
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "StrikeRight",
		SpeedMultiplier = 1.4,
		IsComboBreak = true
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "RunAttack",
		SpeedMultiplier = 1.4
	}
}

-- SoldierAltCloseAttackCombo --
CombatSequences.SoldierAltCloseAttackCombo = {}
CombatSequences.SoldierAltCloseAttackCombo.Priority = SequencePriorities.Attack
CombatSequences.SoldierAltCloseAttackCombo.IsCombo = true
CombatSequences.SoldierAltCloseAttackCombo.Zones = {}
CombatSequences.SoldierAltCloseAttackCombo.Zones[CombatZones.Near] = true
CombatSequences.SoldierAltCloseAttackCombo.ZonesWhilePlaying = {}
CombatSequences.SoldierAltCloseAttackCombo.ZonesWhilePlaying[CombatZones.Near] = true
CombatSequences.SoldierAltCloseAttackCombo.Actions = {
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "AltStrike",
		SpeedMultiplier = 1.4
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "AltStrikeFollowUp",
		SpeedMultiplier = 1.4,
		IsComboBreak = true
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "TwinBladeStrike",
		SpeedMultiplier = 1.4,
		IsComboBreak = true
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "RunAttack",
		SpeedMultiplier = 1.4
	}
}

-- SoldierAttackCombo --
CombatSequences.SoldierAttackCombo = {}
CombatSequences.SoldierAttackCombo.Priority = SequencePriorities.Attack
CombatSequences.SoldierAttackCombo.IsCombo = true
CombatSequences.SoldierAttackCombo.Zones = {}
CombatSequences.SoldierAttackCombo.Zones[CombatZones.Middle] = true
CombatSequences.SoldierAttackCombo.ZonesWhilePlaying = {}
CombatSequences.SoldierAttackCombo.ZonesWhilePlaying[CombatZones.Near] = true
CombatSequences.SoldierAttackCombo.ZonesWhilePlaying[CombatZones.Middle] = true
CombatSequences.SoldierAttackCombo.Actions = {
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "StrikeLeft",
		SpeedMultiplier = 1.4
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "StrikeRight",
		SpeedMultiplier = 1.4,
		IsComboBreak = true
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "AltStrike",
		SpeedMultiplier = 1.4
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "AltStrikeFollowUp",
		SpeedMultiplier = 1.4,
		IsComboBreak = true
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "StrikeLeft",
		SpeedMultiplier = 1.4
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "StrikeRight",
		SpeedMultiplier = 1.4,
		IsComboBreak = true
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "RunAttack",
		SpeedMultiplier = 1.4
	}
}

-- SoldierAltAttackCombo --
CombatSequences.SoldierAltAttackCombo = {}
CombatSequences.SoldierAltAttackCombo.Priority = SequencePriorities.Attack
CombatSequences.SoldierAltAttackCombo.IsCombo = true
CombatSequences.SoldierAltAttackCombo.Zones = {}
CombatSequences.SoldierAltAttackCombo.Zones[CombatZones.Middle] = true
CombatSequences.SoldierAltAttackCombo.ZonesWhilePlaying = {}
CombatSequences.SoldierAltAttackCombo.ZonesWhilePlaying[CombatZones.Near] = true
CombatSequences.SoldierAltAttackCombo.ZonesWhilePlaying[CombatZones.Middle] = true
CombatSequences.SoldierAltAttackCombo.Actions = {
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "StrikeLeft",
		SpeedMultiplier = 1.4
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "StrikeRight",
		SpeedMultiplier = 1.4,
		IsComboBreak = true
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "TwinBladeStrike",
		SpeedMultiplier = 1.4,
		IsComboBreak = true
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "StrikeLeft",
		SpeedMultiplier = 1.4
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "StrikeRight",
		SpeedMultiplier = 1.4,
		IsComboBreak = true
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "TwinBladeCombo",
		SpeedMultiplier = 1.4,
		IsComboBreak = true
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "RunAttack",
		SpeedMultiplier = 1.4
	}
}

-- SoldierFarAttackCombo --
CombatSequences.SoldierFarAttackCombo = {}
CombatSequences.SoldierFarAttackCombo.Priority = SequencePriorities.Attack
CombatSequences.SoldierFarAttackCombo.IsCombo = true
CombatSequences.SoldierFarAttackCombo.Zones = {}
CombatSequences.SoldierFarAttackCombo.Zones[CombatZones.Middle] = true
CombatSequences.SoldierFarAttackCombo.ZonesWhilePlaying = {}
CombatSequences.SoldierFarAttackCombo.ZonesWhilePlaying[CombatZones.Near] = true
CombatSequences.SoldierFarAttackCombo.ZonesWhilePlaying[CombatZones.Middle] = true
CombatSequences.SoldierFarAttackCombo.Actions = {
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "StrikeLeft",
		SpeedMultiplier = 1.4
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "StrikeRight",
		SpeedMultiplier = 1.4,
		IsComboBreak = true
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "AltStrike",
		SpeedMultiplier = 1.4
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "AltStrikeFollowUp",
		SpeedMultiplier = 1.4,
		IsComboBreak = true
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "StrikeLeft",
		SpeedMultiplier = 1.4
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "StrikeRight",
		SpeedMultiplier = 1.4,
		IsComboBreak = true
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "RunAttack",
		SpeedMultiplier = 1.4
	}
}

-- SoldierAltFarAttackCombo --
CombatSequences.SoldierAltFarAttackCombo = {}
CombatSequences.SoldierAltFarAttackCombo.Priority = SequencePriorities.Attack
CombatSequences.SoldierAltFarAttackCombo.IsCombo = true
CombatSequences.SoldierAltFarAttackCombo.Zones = {}
CombatSequences.SoldierAltFarAttackCombo.Zones[CombatZones.Middle] = true
CombatSequences.SoldierAltFarAttackCombo.ZonesWhilePlaying = {}
CombatSequences.SoldierAltFarAttackCombo.ZonesWhilePlaying[CombatZones.Near] = true
CombatSequences.SoldierAltFarAttackCombo.ZonesWhilePlaying[CombatZones.Middle] = true
CombatSequences.SoldierAltFarAttackCombo.Actions = {
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "StrikeLeft",
		SpeedMultiplier = 1.4
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "StrikeRight",
		SpeedMultiplier = 1.4,
		IsComboBreak = true
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "TwinBladeStrike",
		SpeedMultiplier = 1.4,
		IsComboBreak = true
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "AltStrike",
		SpeedMultiplier = 1.4
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "AltStrikeFollowUp",
		SpeedMultiplier = 1.4,
		IsComboBreak = true
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "TwinBladeCombo",
		SpeedMultiplier = 1.4,
		IsComboBreak = true
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "RunAttack",
		SpeedMultiplier = 1.4
	}
}

-- SoldierShockCast --
CombatSequences.SoldierShockCast = {}
CombatSequences.SoldierShockCast.Priority = SequencePriorities.Attack
CombatSequences.SoldierShockCast.IsCombo = true
CombatSequences.SoldierShockCast.Zones = {}
CombatSequences.SoldierShockCast.Zones[CombatZones.Near] = true
CombatSequences.SoldierShockCast.Zones[CombatZones.Middle] = true
CombatSequences.SoldierShockCast.Zones[CombatZones.Far] = true
CombatSequences.SoldierShockCast.Actions = {
	{
		Type = EScriptableAction.NPC_MAGIC_CHARGE,
		Anim = "CurseInto",
		SecondsToCharge = 1,
		SpellType = ESpellType.SPELL_LIGHTNING,
		Dummy = "Character.Focal.Mouth",
		ParticleScale = 0.3,
		ParticleAlpha = 0.5,
		StartParticle = true,
		PowerLevel = 2,
		Priority = EActionPriority.PRIORITY_COMBAT_MELEE_STRIKE,
		FaceTargetThroughout = true
	},
	{
		Type = EScriptableAction.NPC_MAGIC_CHARGE,
		Anim = "CurseLoop",
		SecondsToCharge = 1,
		ParticleScale = 0.75,
		ParticleAlpha = 1,
		ChangeParticle = true,
		Priority = EActionPriority.PRIORITY_COMBAT_MELEE_STRIKE,
		FaceTargetThroughout = true
	},
	{
		Type = EScriptableAction.NPC_MAGIC_QUICK_CAST,
		Anim = "CurseOutOf",
		SpellType = ESpellType.SPELL_LIGHTNING,
		SpellDirectionMode = ESpellCastDirMode.eSCDM_TARGETED,
		Dummy = "Character.Focal.Mouth",
		PowerLevel = 1,
		StopParticle = true,
		Priority = EActionPriority.PRIORITY_COMBAT_MELEE_STRIKE,
		FaceTargetThroughout = true
	}
}

-- HollowManAttackBreak --
CombatSequences.HollowManAttackBreak = {}
CombatSequences.HollowManAttackBreak.Priority = SequencePriorities.Attack
CombatSequences.HollowManAttackBreak.CounterAttack = true
CombatSequences.HollowManAttackBreak.Zones = {}
CombatSequences.HollowManAttackBreak.Zones[CombatZones.Near] = true
CombatSequences.HollowManAttackBreak.Zones[CombatZones.Middle] = true
CombatSequences.HollowManAttackBreak.Zones[CombatZones.Far] = true
CombatSequences.HollowManAttackBreak.Actions = {
	{
		Type = EScriptableAction.NPC_MAGIC_QUICK_CAST,
		Anim = "CurseInto",
		SpeedMultiplier = 3.5,
		Dummy = "Character.Focal.Mouth",
		SpellType = ESpellType.SPELL_FORCE_PUSH,
		SpellDirectionMode = ESpellCastDirMode.eSCDM_SURROUND,
		PowerLevel = 1,
		Priority = EActionPriority.PRIORITY_COMBAT_MELEE_STRIKE
	},
	{
		Type = EScriptableAction.PLAY_ANIMATION,
		Anim = "CurseOutOf",
		SpeedMultiplier = 3.5,
		Priority = EActionPriority.PRIORITY_COMBAT_MELEE_STRIKE
	}
}

-- HollowmanSoldierHeroFlourishResponse --
CombatSequences.HollowmanSoldierHeroFlourishResponse = {}
CombatSequences.HollowmanSoldierHeroFlourishResponse.IsValid = Predicate.IsChargingFlourish
CombatSequences.HollowmanSoldierHeroFlourishResponse.Priority = SequencePriorities.PreferredAttack
CombatSequences.HollowmanSoldierHeroFlourishResponse.CounterAttack = true
CombatSequences.HollowmanSoldierHeroFlourishResponse.Zones = {}
CombatSequences.HollowmanSoldierHeroFlourishResponse.Zones[CombatZones.Near] = true
CombatSequences.HollowmanSoldierHeroFlourishResponse.Zones[CombatZones.Middle] = true
CombatSequences.HollowmanSoldierHeroFlourishResponse.Zones[CombatZones.Far] = true
CombatSequences.HollowmanSoldierHeroFlourishResponse.ZonesWhilePlaying = {}
CombatSequences.HollowmanSoldierHeroFlourishResponse.ZonesWhilePlaying[CombatZones.Near] = true
CombatSequences.HollowmanSoldierHeroFlourishResponse.ZonesWhilePlaying[CombatZones.Middle] = true
CombatSequences.HollowmanSoldierHeroFlourishResponse.ZonesWhilePlaying[CombatZones.Far] = true
CombatSequences.HollowmanSoldierHeroFlourishResponse.Actions = {
	{
		Type = EScriptableAction.NPC_MAGIC_QUICK_CAST,
		Anim = "CurseInto",
		SpeedMultiplier = 6,
		Dummy = "Character.Focal.Mouth",
		SpellType = ESpellType.SPELL_FORCE_PUSH,
		SpellDirectionMode = ESpellCastDirMode.eSCDM_SURROUND,
		PowerLevel = 1,
		Priority = EActionPriority.PRIORITY_COMBAT_MELEE_STRIKE
	},
	{
		Type = EScriptableAction.PLAY_ANIMATION,
		Anim = "CurseOutOf",
		SpeedMultiplier = 6,
		Priority = EActionPriority.PRIORITY_COMBAT_MELEE_STRIKE
	}
}

-- SoldierShotTooMuch --
CombatSequences.SoldierShotTooMuch = {}
CombatSequences.SoldierShotTooMuch.IsValid = Predicate.CreateHasTakenThisMuchDamageOfTypeInTimePredicate(10, EAttackType.ATTACK_RANGED, 6)
CombatSequences.SoldierShotTooMuch.Priority = SequencePriorities.Attack
CombatSequences.SoldierShotTooMuch.CounterAttack = true
CombatSequences.SoldierShotTooMuch.Zones = {}
CombatSequences.SoldierShotTooMuch.Zones[CombatZones.Near] = true
CombatSequences.SoldierShotTooMuch.Zones[CombatZones.Middle] = true
CombatSequences.SoldierShotTooMuch.Zones[CombatZones.Far] = true
CombatSequences.SoldierShotTooMuch.Zones[CombatZones.OuterRing] = true
CombatSequences.SoldierShotTooMuch.Actions = {
	{
		Type = EScriptableAction.NPC_MAGIC_CHARGE,
		Anim = "CurseInto",
		SecondsToCharge = 1,
		SpellType = ESpellType.SPELL_LIGHTNING,
		Dummy = "Character.Focal.Mouth",
		ParticleScale = 0.3,
		ParticleAlpha = 0.5,
		StartParticle = true,
		PowerLevel = 2,
		Priority = EActionPriority.PRIORITY_COMBAT_MELEE_STRIKE,
		FaceTargetThroughout = true
	},
	{
		Type = EScriptableAction.NPC_MAGIC_CHARGE,
		Anim = "CurseLoop",
		SecondsToCharge = 1,
		ParticleScale = 0.75,
		ParticleAlpha = 1,
		ChangeParticle = true,
		Priority = EActionPriority.PRIORITY_COMBAT_MELEE_STRIKE,
		FaceTargetThroughout = true
	},
	{
		Type = EScriptableAction.NPC_MAGIC_QUICK_CAST,
		Anim = "CurseOutOf",
		SpellType = ESpellType.SPELL_LIGHTNING,
		SpellDirectionMode = ESpellCastDirMode.eSCDM_TARGETED,
		Dummy = "Character.Focal.Mouth",
		PowerLevel = 2,
		StopParticle = true,
		Priority = EActionPriority.PRIORITY_COMBAT_MELEE_STRIKE,
		FaceTargetThroughout = true
	}
}

-- SoldierMagicedTooMuch --
CombatSequences.SoldierMagicedTooMuch = {}
CombatSequences.SoldierMagicedTooMuch.IsValid = Predicate.CreateHasTakenThisMuchDamageOfTypeInTimePredicate(10, EAttackType.ATTACK_SPELL, 6)
CombatSequences.SoldierMagicedTooMuch.Priority = SequencePriorities.Attack
CombatSequences.SoldierMagicedTooMuch.CounterAttack = true
CombatSequences.SoldierMagicedTooMuch.Zones = {}
CombatSequences.SoldierMagicedTooMuch.Zones[CombatZones.Near] = true
CombatSequences.SoldierMagicedTooMuch.Zones[CombatZones.Middle] = true
CombatSequences.SoldierMagicedTooMuch.Zones[CombatZones.Far] = true
CombatSequences.SoldierMagicedTooMuch.Zones[CombatZones.OuterRing] = true
CombatSequences.SoldierMagicedTooMuch.Actions = {
	{
		Type = EScriptableAction.NPC_MAGIC_CHARGE,
		Anim = "CurseInto",
		SecondsToCharge = 1,
		SpellType = ESpellType.SPELL_LIGHTNING,
		Dummy = "Character.Focal.Mouth",
		ParticleScale = 0.3,
		ParticleAlpha = 0.5,
		StartParticle = true,
		PowerLevel = 2,
		Priority = EActionPriority.PRIORITY_COMBAT_MELEE_STRIKE,
		FaceTargetThroughout = true
	},
	{
		Type = EScriptableAction.NPC_MAGIC_CHARGE,
		Anim = "CurseLoop",
		SecondsToCharge = 1,
		ParticleScale = 0.75,
		ParticleAlpha = 1,
		ChangeParticle = true,
		Priority = EActionPriority.PRIORITY_COMBAT_MELEE_STRIKE,
		FaceTargetThroughout = true
	},
	{
		Type = EScriptableAction.NPC_MAGIC_QUICK_CAST,
		Anim = "CurseOutOf",
		SpellType = ESpellType.SPELL_LIGHTNING,
		SpellDirectionMode = ESpellCastDirMode.eSCDM_TARGETED,
		Dummy = "Character.Focal.Mouth",
		PowerLevel = 2,
		StopParticle = true,
		Priority = EActionPriority.PRIORITY_COMBAT_MELEE_STRIKE,
		FaceTargetThroughout = true
	}
}

-- HollowmanSoldierOrbSuckingResponse --
CombatSequences.HollowmanSoldierOrbSuckingResponse = {}
CombatSequences.HollowmanSoldierOrbSuckingResponse.IsValid = Predicate.IsSuckModeActive
CombatSequences.HollowmanSoldierOrbSuckingResponse.Priority = SequencePriorities.Attack
CombatSequences.HollowmanSoldierOrbSuckingResponse.CounterAttack = true
CombatSequences.HollowmanSoldierOrbSuckingResponse.Zones = {}
CombatSequences.HollowmanSoldierOrbSuckingResponse.Zones[CombatZones.Near] = true
CombatSequences.HollowmanSoldierOrbSuckingResponse.Zones[CombatZones.Middle] = true
CombatSequences.HollowmanSoldierOrbSuckingResponse.Zones[CombatZones.Far] = true
CombatSequences.HollowmanSoldierOrbSuckingResponse.Actions = {
	{
		Type = EScriptableAction.NPC_MAGIC_QUICK_CAST,
		Anim = "CurseInto",
		SpeedMultiplier = 6,
		Dummy = "Character.Focal.Mouth",
		SpellType = ESpellType.SPELL_FORCE_PUSH,
		SpellDirectionMode = ESpellCastDirMode.eSCDM_SURROUND,
		PowerLevel = 1,
		Priority = EActionPriority.PRIORITY_COMBAT_MELEE_STRIKE
	}
}

-- SoldierEliteShockCast --
CombatSequences.SoldierEliteShockCast = {}
CombatSequences.SoldierEliteShockCast.Priority = SequencePriorities.Attack
CombatSequences.SoldierEliteShockCast.IsCombo = true
CombatSequences.SoldierEliteShockCast.Zones = {}
CombatSequences.SoldierEliteShockCast.Zones[CombatZones.Near] = true
CombatSequences.SoldierEliteShockCast.Zones[CombatZones.Middle] = true
CombatSequences.SoldierEliteShockCast.Zones[CombatZones.Far] = true
CombatSequences.SoldierEliteShockCast.Actions = {
	{
		Type = EScriptableAction.NPC_MAGIC_CHARGE,
		Anim = "CurseInto",
		SecondsToCharge = 1,
		SpellType = ESpellType.SPELL_LIGHTNING,
		Dummy = "Character.Focal.Mouth",
		ParticleScale = 0.3,
		ParticleAlpha = 0.5,
		StartParticle = true,
		PowerLevel = 2,
		Priority = EActionPriority.PRIORITY_COMBAT_MELEE_STRIKE,
		FaceTargetThroughout = true
	},
	{
		Type = EScriptableAction.NPC_MAGIC_CHARGE,
		Anim = "CurseLoop",
		SecondsToCharge = 1,
		ParticleScale = 0.75,
		ParticleAlpha = 1,
		ChangeParticle = true,
		Priority = EActionPriority.PRIORITY_COMBAT_MELEE_STRIKE,
		FaceTargetThroughout = true
	},
	{
		Type = EScriptableAction.NPC_MAGIC_QUICK_CAST,
		Anim = "CurseOutOf",
		SpellType = ESpellType.SPELL_LIGHTNING,
		SpellDirectionMode = ESpellCastDirMode.eSCDM_TARGETED,
		Dummy = "Character.Focal.Mouth",
		PowerLevel = 3,
		StopParticle = true,
		Priority = EActionPriority.PRIORITY_COMBAT_MELEE_STRIKE,
		FaceTargetThroughout = true
	}
}

-- SoldierEliteShotTooMuch --
CombatSequences.SoldierEliteShotTooMuch = {}
CombatSequences.SoldierEliteShotTooMuch.IsValid = Predicate.CreateHasTakenThisMuchDamageOfTypeInTimePredicate(40, EAttackType.ATTACK_RANGED, 6)
CombatSequences.SoldierEliteShotTooMuch.Priority = SequencePriorities.Attack
CombatSequences.SoldierEliteShotTooMuch.CounterAttack = true
CombatSequences.SoldierEliteShotTooMuch.Zones = {}
CombatSequences.SoldierEliteShotTooMuch.Zones[CombatZones.Near] = true
CombatSequences.SoldierEliteShotTooMuch.Zones[CombatZones.Middle] = true
CombatSequences.SoldierEliteShotTooMuch.Zones[CombatZones.Far] = true
CombatSequences.SoldierEliteShotTooMuch.Actions = {
	{
		Type = EScriptableAction.NPC_MAGIC_CHARGE,
		Anim = "CurseInto",
		SecondsToCharge = 1,
		SpellType = ESpellType.SPELL_LIGHTNING,
		Dummy = "Character.Focal.Mouth",
		ParticleScale = 0.3,
		ParticleAlpha = 0.5,
		StartParticle = true,
		PowerLevel = 2,
		Priority = EActionPriority.PRIORITY_COMBAT_MELEE_STRIKE,
		FaceTargetThroughout = true
	},
	{
		Type = EScriptableAction.NPC_MAGIC_CHARGE,
		Anim = "CurseLoop",
		SecondsToCharge = 1,
		ParticleScale = 0.75,
		ParticleAlpha = 1,
		ChangeParticle = true,
		Priority = EActionPriority.PRIORITY_COMBAT_MELEE_STRIKE,
		FaceTargetThroughout = true
	},
	{
		Type = EScriptableAction.NPC_MAGIC_QUICK_CAST,
		Anim = "CurseOutOf",
		SpellType = ESpellType.SPELL_LIGHTNING,
		SpellDirectionMode = ESpellCastDirMode.eSCDM_TARGETED,
		Dummy = "Character.Focal.Mouth",
		PowerLevel = 3,
		StopParticle = true,
		Priority = EActionPriority.PRIORITY_COMBAT_MELEE_STRIKE,
		FaceTargetThroughout = true
	}
}

-- SoldierEliteMagicedTooMuch --
CombatSequences.SoldierEliteMagicedTooMuch = {}
CombatSequences.SoldierEliteMagicedTooMuch.IsValid = Predicate.CreateHasTakenThisMuchDamageOfTypeInTimePredicate(40, EAttackType.ATTACK_SPELL, 6)
CombatSequences.SoldierEliteMagicedTooMuch.Priority = SequencePriorities.Attack
CombatSequences.SoldierEliteMagicedTooMuch.CounterAttack = true
CombatSequences.SoldierEliteMagicedTooMuch.Zones = {}
CombatSequences.SoldierEliteMagicedTooMuch.Zones[CombatZones.Near] = true
CombatSequences.SoldierEliteMagicedTooMuch.Zones[CombatZones.Middle] = true
CombatSequences.SoldierEliteMagicedTooMuch.Zones[CombatZones.Far] = true
CombatSequences.SoldierEliteMagicedTooMuch.Actions = {
	{
		Type = EScriptableAction.NPC_MAGIC_CHARGE,
		Anim = "CurseInto",
		SecondsToCharge = 1,
		SpellType = ESpellType.SPELL_LIGHTNING,
		Dummy = "Character.Focal.Mouth",
		ParticleScale = 0.3,
		ParticleAlpha = 0.5,
		StartParticle = true,
		PowerLevel = 2,
		Priority = EActionPriority.PRIORITY_COMBAT_MELEE_STRIKE,
		FaceTargetThroughout = true
	},
	{
		Type = EScriptableAction.NPC_MAGIC_CHARGE,
		Anim = "CurseLoop",
		SecondsToCharge = 1,
		ParticleScale = 0.75,
		ParticleAlpha = 1,
		ChangeParticle = true,
		Priority = EActionPriority.PRIORITY_COMBAT_MELEE_STRIKE,
		FaceTargetThroughout = true
	},
	{
		Type = EScriptableAction.NPC_MAGIC_QUICK_CAST,
		Anim = "CurseOutOf",
		SpellType = ESpellType.SPELL_LIGHTNING,
		SpellDirectionMode = ESpellCastDirMode.eSCDM_TARGETED,
		Dummy = "Character.Focal.Mouth",
		PowerLevel = 3,
		StopParticle = true,
		Priority = EActionPriority.PRIORITY_COMBAT_MELEE_STRIKE,
		FaceTargetThroughout = true
	}
}

-- HeadlessHollowmanMeleeAoECast --
CombatSequences.HeadlessHollowmanMeleeAoECast = {}
CombatSequences.HeadlessHollowmanMeleeAoECast.IsValid = Predicate.CreateHasTakenThisMuchDamageOfTypeInTimePredicate(1, EAttackType.ATTACK_MELEE, 5)
CombatSequences.HeadlessHollowmanMeleeAoECast.Priority = SequencePriorities.Attack
CombatSequences.HeadlessHollowmanMeleeAoECast.CounterAttack = true
CombatSequences.HeadlessHollowmanMeleeAoECast.OverrideActionPriority = EActionPriority.PRIORITY_COMBAT_UNINTERRUPTABLE_STRIKE
CombatSequences.HeadlessHollowmanMeleeAoECast.Zones = {}
CombatSequences.HeadlessHollowmanMeleeAoECast.Zones[CombatZones.Near] = true
CombatSequences.HeadlessHollowmanMeleeAoECast.Zones[CombatZones.Middle] = true
CombatSequences.HeadlessHollowmanMeleeAoECast.Zones[CombatZones.Far] = true
CombatSequences.HeadlessHollowmanMeleeAoECast.Zones[CombatZones.Left] = true
CombatSequences.HeadlessHollowmanMeleeAoECast.Zones[CombatZones.Right] = true
CombatSequences.HeadlessHollowmanMeleeAoECast.Zones[CombatZones.Rear] = true
CombatSequences.HeadlessHollowmanMeleeAoECast.Actions = {
	{
		Type = EScriptableAction.NPC_MAGIC_CHARGE,
		Anim = "CurseInto",
		SecondsToCharge = 0.5,
		SpellType = ESpellType.SPELL_LIGHTNING,
		Dummy = "Character.Focal.Mouth",
		ParticleScale = 0.3,
		ParticleAlpha = 0.5,
		StartParticle = true,
		PowerLevel = 1,
		Priority = EActionPriority.PRIORITY_COMBAT_MELEE_STRIKE
	},
	{
		Type = EScriptableAction.NPC_MAGIC_CHARGE,
		Anim = "CurseLoop",
		SecondsToCharge = 0.75,
		ParticleScale = 1,
		ParticleAlpha = 1,
		ChangeParticle = true,
		Priority = EActionPriority.PRIORITY_COMBAT_MELEE_STRIKE
	},
	{
		Type = EScriptableAction.NPC_MAGIC_QUICK_CAST,
		Anim = "CurseOutOf",
		SpellType = ESpellType.SPELL_LIGHTNING,
		SpellDirectionMode = ESpellCastDirMode.eSCDM_SURROUND,
		Dummy = "Character.Focal.Mouth",
		PowerLevel = 1,
		StopParticle = true,
		Priority = EActionPriority.PRIORITY_COMBAT_MELEE_STRIKE
	}
}

-- HollowmanLeaderQO815CloseAttackCombo --
CombatSequences.HollowmanLeaderQO815CloseAttackCombo = {}
CombatSequences.HollowmanLeaderQO815CloseAttackCombo.Priority = SequencePriorities.Attack
CombatSequences.HollowmanLeaderQO815CloseAttackCombo.IsCombo = true
CombatSequences.HollowmanLeaderQO815CloseAttackCombo.Zones = {}
CombatSequences.HollowmanLeaderQO815CloseAttackCombo.Zones[CombatZones.Near] = true
CombatSequences.HollowmanLeaderQO815CloseAttackCombo.ZonesWhilePlaying = {}
CombatSequences.HollowmanLeaderQO815CloseAttackCombo.ZonesWhilePlaying[CombatZones.Near] = true
CombatSequences.HollowmanLeaderQO815CloseAttackCombo.ZonesWhilePlaying[CombatZones.Middle] = true
CombatSequences.HollowmanLeaderQO815CloseAttackCombo.Actions = {
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "RunAttack",
		SpeedMultiplier = 1.3,
		Priority = EActionPriority.PRIORITY_COMBAT_UNINTERRUPTABLE_STRIKE,
		HitOutsideAttackArc = true
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "AltStrike",
		SpeedMultiplier = 1.3,
		Priority = EActionPriority.PRIORITY_COMBAT_UNINTERRUPTABLE_STRIKE,
		HitOutsideAttackArc = true
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "AltStrikeFollowUp",
		SpeedMultiplier = 1.3,
		Priority = EActionPriority.PRIORITY_COMBAT_UNINTERRUPTABLE_STRIKE,
		IsComboBreak = true,
		HitOutsideAttackArc = true
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "StrikeLeft",
		SpeedMultiplier = 1.3,
		Priority = EActionPriority.PRIORITY_COMBAT_UNINTERRUPTABLE_STRIKE,
		HitOutsideAttackArc = trueIs,
		ComboBreak = true
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "StrikeRight",
		SpeedMultiplier = 1.3,
		Priority = EActionPriority.PRIORITY_COMBAT_UNINTERRUPTABLE_STRIKE,
		HitOutsideAttackArc = true
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "RunAttack",
		SpeedMultiplier = 1.3,
		Priority = EActionPriority.PRIORITY_COMBAT_UNINTERRUPTABLE_STRIKE,
		HitOutsideAttackArc = true
	}
}

-- HollowmanLeaderQO815AttackCombo --
CombatSequences.HollowmanLeaderQO815AttackCombo = {}
CombatSequences.HollowmanLeaderQO815AttackCombo.Priority = SequencePriorities.Attack
CombatSequences.HollowmanLeaderQO815AttackCombo.IsCombo = true
CombatSequences.HollowmanLeaderQO815AttackCombo.Zones = {}
CombatSequences.HollowmanLeaderQO815AttackCombo.Zones[CombatZones.Middle] = true
CombatSequences.HollowmanLeaderQO815AttackCombo.ZonesWhilePlaying = {}
CombatSequences.HollowmanLeaderQO815AttackCombo.ZonesWhilePlaying[CombatZones.Near] = true
CombatSequences.HollowmanLeaderQO815AttackCombo.ZonesWhilePlaying[CombatZones.Middle] = true
CombatSequences.HollowmanLeaderQO815AttackCombo.Actions = {
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "RunAttack",
		SpeedMultiplier = 1.3,
		Priority = EActionPriority.PRIORITY_COMBAT_UNINTERRUPTABLE_STRIKE,
		HitOutsideAttackArc = true
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "StrikeLeft",
		SpeedMultiplier = 1.3,
		Priority = EActionPriority.PRIORITY_COMBAT_UNINTERRUPTABLE_STRIKE,
		HitOutsideAttackArc = true
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "StrikeRight",
		SpeedMultiplier = 1.3,
		Priority = EActionPriority.PRIORITY_COMBAT_UNINTERRUPTABLE_STRIKE,
		IsComboBreak = true,
		HitOutsideAttackArc = true
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "AltStrike",
		SpeedMultiplier = 1.3,
		Priority = EActionPriority.PRIORITY_COMBAT_UNINTERRUPTABLE_STRIKE,
		HitOutsideAttackArc = true
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "AltStrikeFollowUp",
		SpeedMultiplier = 1.3,
		Priority = EActionPriority.PRIORITY_COMBAT_UNINTERRUPTABLE_STRIKE,
		HitOutsideAttackArc = true,
		IsComboBreak = true
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "StrikeLeft",
		SpeedMultiplier = 1.3,
		Priority = EActionPriority.PRIORITY_COMBAT_UNINTERRUPTABLE_STRIKE,
		HitOutsideAttackArc = true,
		IsComboBreak = true
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "StrikeRight",
		SpeedMultiplier = 1.3,
		Priority = EActionPriority.PRIORITY_COMBAT_UNINTERRUPTABLE_STRIKE,
		HitOutsideAttackArc = true
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "RunAttack",
		SpeedMultiplier = 1.3,
		Priority = EActionPriority.PRIORITY_COMBAT_UNINTERRUPTABLE_STRIKE,
		HitOutsideAttackArc = true
	}
}

-- HollowmanLeaderQO815FarAttackCombo --
CombatSequences.HollowmanLeaderQO815FarAttackCombo = {}
CombatSequences.HollowmanLeaderQO815FarAttackCombo.Priority = SequencePriorities.Attack
CombatSequences.HollowmanLeaderQO815FarAttackCombo.IsCombo = true
CombatSequences.HollowmanLeaderQO815FarAttackCombo.Zones = {}
CombatSequences.HollowmanLeaderQO815FarAttackCombo.Zones[CombatZones.Far] = true
CombatSequences.HollowmanLeaderQO815FarAttackCombo.ZonesWhilePlaying = {}
CombatSequences.HollowmanLeaderQO815FarAttackCombo.ZonesWhilePlaying[CombatZones.Near] = true
CombatSequences.HollowmanLeaderQO815FarAttackCombo.ZonesWhilePlaying[CombatZones.Middle] = true
CombatSequences.HollowmanLeaderQO815FarAttackCombo.ZonesWhilePlaying[CombatZones.Far] = true
CombatSequences.HollowmanLeaderQO815FarAttackCombo.Actions = {
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "RunAttack",
		SpeedMultiplier = 1.3,
		Priority = EActionPriority.PRIORITY_COMBAT_UNINTERRUPTABLE_STRIKE,
		HitOutsideAttackArc = true
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "StrikeLeft",
		SpeedMultiplier = 1.3,
		Priority = EActionPriority.PRIORITY_COMBAT_UNINTERRUPTABLE_STRIKE,
		HitOutsideAttackArc = true
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "StrikeRight",
		SpeedMultiplier = 1.3,
		Priority = EActionPriority.PRIORITY_COMBAT_UNINTERRUPTABLE_STRIKE,
		IsComboBreak = true,
		HitOutsideAttackArc = true
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "AltStrike",
		SpeedMultiplier = 1.3,
		Priority = EActionPriority.PRIORITY_COMBAT_UNINTERRUPTABLE_STRIKE,
		HitOutsideAttackArc = true
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "AltStrikeFollowUp",
		SpeedMultiplier = 1.3,
		Priority = EActionPriority.PRIORITY_COMBAT_UNINTERRUPTABLE_STRIKE,
		HitOutsideAttackArc = true,
		IsComboBreak = true
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "StrikeLeft",
		SpeedMultiplier = 1.3,
		Priority = EActionPriority.PRIORITY_COMBAT_UNINTERRUPTABLE_STRIKE,
		HitOutsideAttackArc = true,
		IsComboBreak = true
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "StrikeRight",
		SpeedMultiplier = 1.3,
		Priority = EActionPriority.PRIORITY_COMBAT_UNINTERRUPTABLE_STRIKE,
		HitOutsideAttackArc = true
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "StrikeLeft",
		SpeedMultiplier = 1.3,
		Priority = EActionPriority.PRIORITY_COMBAT_UNINTERRUPTABLE_STRIKE,
		HitOutsideAttackArc = true,
		IsComboBreak = true
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "StrikeRight",
		SpeedMultiplier = 1.3,
		Priority = EActionPriority.PRIORITY_COMBAT_UNINTERRUPTABLE_STRIKE,
		HitOutsideAttackArc = true
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "RunAttack",
		SpeedMultiplier = 1.3,
		Priority = EActionPriority.PRIORITY_COMBAT_UNINTERRUPTABLE_STRIKE,
		HitOutsideAttackArc = true
	}
}

-- HollowmanLeaderQO815AttackBreak --
CombatSequences.HollowmanLeaderQO815AttackBreak = {}
CombatSequences.HollowmanLeaderQO815AttackBreak.IsValid = Predicate.HasBlockedThisManyStrikesInCurrentMode(1)
CombatSequences.HollowmanLeaderQO815AttackBreak.Priority = SequencePriorities.Attack
CombatSequences.HollowmanLeaderQO815AttackBreak.CounterAttack = true
CombatSequences.HollowmanLeaderQO815AttackBreak.Zones = {}
CombatSequences.HollowmanLeaderQO815AttackBreak.Zones[CombatZones.Near] = true
CombatSequences.HollowmanLeaderQO815AttackBreak.Zones[CombatZones.Middle] = true
CombatSequences.HollowmanLeaderQO815AttackBreak.Zones[CombatZones.Far] = true
CombatSequences.HollowmanLeaderQO815AttackBreak.ZonesWhilePlaying = {}
CombatSequences.HollowmanLeaderQO815AttackBreak.ZonesWhilePlaying[CombatZones.Near] = true
CombatSequences.HollowmanLeaderQO815AttackBreak.ZonesWhilePlaying[CombatZones.Middle] = true
CombatSequences.HollowmanLeaderQO815AttackBreak.ZonesWhilePlaying[CombatZones.Far] = true
CombatSequences.HollowmanLeaderQO815AttackBreak.Actions = {
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "RunAttack",
		SpeedMultiplier = 1.5,
		Priority = EActionPriority.PRIORITY_COMBAT_UNINTERRUPTABLE_STRIKE,
		HitOutsideAttackArc = true,
		IsComboBreak = true
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "RunAttack",
		SpeedMultiplier = 1.5,
		Priority = EActionPriority.PRIORITY_COMBAT_UNINTERRUPTABLE_STRIKE,
		HitOutsideAttackArc = true,
		IsComboBreak = true
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "RunAttack",
		SpeedMultiplier = 1.5,
		Priority = EActionPriority.PRIORITY_COMBAT_UNINTERRUPTABLE_STRIKE,
		HitOutsideAttackArc = true,
		IsComboBreak = true
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "RunAttack",
		SpeedMultiplier = 1.5,
		Priority = EActionPriority.PRIORITY_COMBAT_UNINTERRUPTABLE_STRIKE,
		HitOutsideAttackArc = true,
		IsComboBreak = true
	}
}

-- HollowmanLeaderQO815OrbSuckingResponse --
CombatSequences.HollowmanLeaderQO815OrbSuckingResponse = {}
CombatSequences.HollowmanLeaderQO815OrbSuckingResponse.IsValid = Predicate.IsSuckModeActive
CombatSequences.HollowmanLeaderQO815OrbSuckingResponse.Priority = SequencePriorities.Attack
CombatSequences.HollowmanLeaderQO815OrbSuckingResponse.CounterAttack = true
CombatSequences.HollowmanLeaderQO815OrbSuckingResponse.Zones = {}
CombatSequences.HollowmanLeaderQO815OrbSuckingResponse.Zones[CombatZones.Near] = true
CombatSequences.HollowmanLeaderQO815OrbSuckingResponse.Zones[CombatZones.Middle] = true
CombatSequences.HollowmanLeaderQO815OrbSuckingResponse.Zones[CombatZones.Far] = true
CombatSequences.HollowmanLeaderQO815OrbSuckingResponse.Actions = {
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "AltStrike",
		SpeedMultiplier = 1.3,
		HitOutsideAttackArc = true,
		IsComboBreak = true
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "AltStrikeFollowUp",
		SpeedMultiplier = 1.3,
		HitOutsideAttackArc = true
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "RunAttack",
		SpeedMultiplier = 1.3,
		HitOutsideAttackArc = true
	}
}

-- HollowManRangedCloseAttack --
CombatSequences.HollowManRangedCloseAttack = {}
CombatSequences.HollowManRangedCloseAttack.Priority = SequencePriorities.Attack
CombatSequences.HollowManRangedCloseAttack.IsCombo = false
CombatSequences.HollowManRangedCloseAttack.Zones = {}
CombatSequences.HollowManRangedCloseAttack.Zones[CombatZones.Near] = true
CombatSequences.HollowManRangedCloseAttack.Actions = {
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "MeleeStrikeWithRifle"
	}
}

-- HollowManRangedMidAttack --
CombatSequences.HollowManRangedMidAttack = {}
CombatSequences.HollowManRangedMidAttack.Priority = SequencePriorities.Attack
CombatSequences.HollowManRangedMidAttack.IsCombo = false
CombatSequences.HollowManRangedMidAttack.Zones = {}
CombatSequences.HollowManRangedMidAttack.Zones[CombatZones.Middle] = true
CombatSequences.HollowManRangedMidAttack.Actions = {
	{
		Type = EScriptableAction.STRAFE,
		Anim = "Walk"
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "MeleeStrikeWithRifle"
	}
}

-- DLC2HollowmanSummonerRangedCounter --
CombatSequences.DLC2HollowmanSummonerRangedCounter = {}
CombatSequences.DLC2HollowmanSummonerRangedCounter.IsValid = Predicate.CreateHaveIBeenStruckALotPredicate(2)
CombatSequences.DLC2HollowmanSummonerRangedCounter.Priority = SequencePriorities.Attack
CombatSequences.DLC2HollowmanSummonerRangedCounter.OverrideActionPriority = EActionPriority.PRIORITY_COMBAT_UNINTERRUPTABLE_STRIKE
CombatSequences.DLC2HollowmanSummonerRangedCounter.Zones = {}
CombatSequences.DLC2HollowmanSummonerRangedCounter.Zones[CombatZones.Near] = true
CombatSequences.DLC2HollowmanSummonerRangedCounter.Zones[CombatZones.Middle] = true
CombatSequences.DLC2HollowmanSummonerRangedCounter.Zones[CombatZones.Far] = true
CombatSequences.DLC2HollowmanSummonerRangedCounter.Actions = {
	{
		Type = EScriptableAction.NPC_MAGIC_CHARGE,
		Anim = "SpellCast",
		SecondsToCharge = 0.5,
		SpellType = ESpellType.SPELL_FIREBALL,
		Dummy = "Character.Focal.Chest",
		ParticleScale = 1.1,
		ParticleAlpha = 1,
		StartParticle = true,
		PowerLevel = 4,
		Priority = EActionPriority.PRIORITY_COMBAT_MELEE_STRIKE,
		FaceTargetThroughout = true
	},
	{
		Type = EScriptableAction.NPC_MAGIC_QUICK_CAST,
		Anim = "SpellCast",
		SpellType = ESpellType.SPELL_FIREBALL,
		SpellDirectionMode = ESpellCastDirMode.eSCDM_TARGETED,
		Dummy = "Character.Focal.Mouth",
		PowerLevel = 1,
		StopParticle = true,
		Priority = EActionPriority.PRIORITY_COMBAT_MELEE_STRIKE,
		FaceTargetThroughout = true
	}
}

-- DLC2HollowmanSummonerBackAttack --
CombatSequences.DLC2HollowmanSummonerBackAttack = {}
CombatSequences.DLC2HollowmanSummonerBackAttack.Priority = SequencePriorities.Attack
CombatSequences.DLC2HollowmanSummonerBackAttack.OverrideActionPriority = EActionPriority.PRIORITY_COMBAT_UNINTERRUPTABLE_STRIKE
CombatSequences.DLC2HollowmanSummonerBackAttack.CounterAttack = true
CombatSequences.DLC2HollowmanSummonerBackAttack.Zones = {}
CombatSequences.DLC2HollowmanSummonerBackAttack.Zones[CombatZones.Rear] = true
CombatSequences.DLC2HollowmanSummonerBackAttack.Actions = {
	{
		Type = EScriptableAction.NPC_MAGIC_CHARGE,
		Anim = "SpellCast",
		SecondsToCharge = 0.5,
		SpellType = ESpellType.SPELL_FIREBALL,
		Dummy = "Character.Focal.Chest",
		ParticleScale = 1.1,
		ParticleAlpha = 1,
		StartParticle = true,
		PowerLevel = 4,
		Priority = EActionPriority.PRIORITY_COMBAT_MELEE_STRIKE,
		FaceTargetThroughout = true
	},
	{
		Type = EScriptableAction.NPC_MAGIC_QUICK_CAST,
		Anim = "SpellCast",
		SpeedMultiplier = 1.5,
		SpellType = ESpellType.SPELL_FIREBALL,
		SecondSpellType = ESpellType.SPELL_FORCE_PUSH,
		SpellDirectionMode = ESpellCastDirMode.eSCDM_SURROUND,
		Dummy = "Character.Focal.Mouth",
		PowerLevel = 2,
		StopParticle = true,
		Priority = EActionPriority.PRIORITY_COMBAT_MELEE_STRIKE
	}
}

-- DLC2HollowmanSummonerAttackOutOfBlock --
CombatSequences.DLC2HollowmanSummonerAttackOutOfBlock = {}
CombatSequences.DLC2HollowmanSummonerAttackOutOfBlock.IsValid = Predicate.HasBlockedThisManyStrikesInCurrentMode(2)
CombatSequences.DLC2HollowmanSummonerAttackOutOfBlock.Priority = SequencePriorities.Attack
CombatSequences.DLC2HollowmanSummonerAttackOutOfBlock.CounterAttack = true
CombatSequences.DLC2HollowmanSummonerAttackOutOfBlock.Zones = {}
CombatSequences.DLC2HollowmanSummonerAttackOutOfBlock.Zones[CombatZones.Near] = true
CombatSequences.DLC2HollowmanSummonerAttackOutOfBlock.Zones[CombatZones.Middle] = true
CombatSequences.DLC2HollowmanSummonerAttackOutOfBlock.Actions = {
	{
		Type = EScriptableAction.NPC_MAGIC_CHARGE,
		Anim = "SpellCast",
		SecondsToCharge = 0.5,
		SpellType = ESpellType.SPELL_FIREBALL,
		Dummy = "Character.Focal.Chest",
		ParticleScale = 1.1,
		ParticleAlpha = 1,
		StartParticle = true,
		PowerLevel = 4,
		Priority = EActionPriority.PRIORITY_COMBAT_MELEE_STRIKE,
		FaceTargetThroughout = true
	},
	{
		Type = EScriptableAction.NPC_MAGIC_QUICK_CAST,
		Anim = "SpellCast",
		SpeedMultiplier = 1.5,
		SpellType = ESpellType.SPELL_FIREBALL,
		SecondSpellType = ESpellType.SPELL_FORCE_PUSH,
		SpellDirectionMode = ESpellCastDirMode.eSCDM_SURROUND,
		Dummy = "Character.Focal.Mouth",
		PowerLevel = 2,
		StopParticle = true,
		Priority = EActionPriority.PRIORITY_COMBAT_MELEE_STRIKE
	}
}

-- DLC2HollowmanSummonerSpellCast --
CombatSequences.DLC2HollowmanSummonerSpellCast = {}
CombatSequences.DLC2HollowmanSummonerSpellCast.Priority = SequencePriorities.Attack
CombatSequences.DLC2HollowmanSummonerSpellCast.Zones = {}
CombatSequences.DLC2HollowmanSummonerSpellCast.Zones[CombatZones.Near] = true
CombatSequences.DLC2HollowmanSummonerSpellCast.Zones[CombatZones.Middle] = true
CombatSequences.DLC2HollowmanSummonerSpellCast.Zones[CombatZones.Far] = true
CombatSequences.DLC2HollowmanSummonerSpellCast.Actions = {
	{
		Type = EScriptableAction.NPC_MAGIC_CHARGE,
		Anim = "SpellCast",
		SecondsToCharge = 0.5,
		SpellType = ESpellType.SPELL_FIREBALL,
		Dummy = "Character.Focal.Chest",
		ParticleScale = 1.1,
		ParticleAlpha = 1,
		StartParticle = true,
		PowerLevel = 4,
		Priority = EActionPriority.PRIORITY_COMBAT_MELEE_STRIKE,
		FaceTargetThroughout = true
	},
	{
		Type = EScriptableAction.NPC_MAGIC_QUICK_CAST,
		Anim = "SpellCast",
		SpellType = ESpellType.SPELL_FIREBALL,
		SpellDirectionMode = ESpellCastDirMode.eSCDM_SURROUND,
		Dummy = "Character.Focal.Mouth",
		PowerLevel = 2,
		StopParticle = true,
		Priority = EActionPriority.PRIORITY_COMBAT_MELEE_STRIKE,
		FaceTargetThroughout = true
	}
}



-- uncomment for debug
-- GUI.DisplayMessageBox("HollowmanSequences.lua successfully loaded!")
-- while (GUI.IsDisplayBoxActive()) do
	-- coroutine.yield()
-- end
