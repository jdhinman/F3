
-- AttackLeft --
CombatSequences.AttackLeft = {}
CombatSequences.AttackLeft.Priority = SequencePriorities.Attack
CombatSequences.AttackLeft.Zones = {}
CombatSequences.AttackLeft.Zones[CombatZones.Middle] = true
CombatSequences.AttackLeft.Actions = {
	{
		Type = EScriptableAction.STRAFE,
		Anim = "StrafeForwardOneStep"
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "StrikeLeft"
	}
}

-- AttackRight --
CombatSequences.AttackRight = {}
CombatSequences.AttackRight.Priority = SequencePriorities.Attack
CombatSequences.AttackRight.Zones = {}
CombatSequences.AttackRight.Zones[CombatZones.Middle] = true
CombatSequences.AttackRight.Actions = {
	{
		Type = EScriptableAction.STRAFE,
		Anim = "StrafeForwardOneStep"
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "StrikeRight"
	}
}

-- AttackComboLeftRight --
CombatSequences.AttackComboLeftRight = {}
CombatSequences.AttackComboLeftRight.Priority = SequencePriorities.Attack
CombatSequences.AttackComboLeftRight.IsCombo = true
CombatSequences.AttackComboLeftRight.Zones = {}
CombatSequences.AttackComboLeftRight.Zones[CombatZones.Middle] = true
CombatSequences.AttackComboLeftRight.Actions = {
	{
		Type = EScriptableAction.STRAFE,
		Anim = "StrafeForwardOneStep"
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "StrikeLeft"
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "StrikeRight"
	}
}

-- AttackComboLeftRightNoStep --
CombatSequences.AttackComboLeftRightNoStep = {}
CombatSequences.AttackComboLeftRightNoStep.Priority = SequencePriorities.Attack
CombatSequences.AttackComboLeftRightNoStep.IsCombo = true
CombatSequences.AttackComboLeftRightNoStep.Zones = {}
CombatSequences.AttackComboLeftRightNoStep.Zones[CombatZones.Middle] = true
CombatSequences.AttackComboLeftRightNoStep.Actions = {
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "StrikeLeft"
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "StrikeRight"
	}
}

-- AttackComboAlternative --
CombatSequences.AttackComboAlternative = {}
CombatSequences.AttackComboAlternative.Priority = SequencePriorities.Attack
CombatSequences.AttackComboAlternative.IsCombo = true
CombatSequences.AttackComboAlternative.Zones = {}
CombatSequences.AttackComboAlternative.Zones[CombatZones.Middle] = true
CombatSequences.AttackComboAlternative.Actions = {
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "AltStrike"
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "AltStrikeFollowUp"
	}
}

-- AttackComboLeftRightFastStep --
CombatSequences.AttackComboLeftRightFastStep = {}
CombatSequences.AttackComboLeftRightFastStep.Priority = SequencePriorities.Attack
CombatSequences.AttackComboLeftRightFastStep.IsCombo = true
CombatSequences.AttackComboLeftRightFastStep.Zones = {}
CombatSequences.AttackComboLeftRightFastStep.Zones[CombatZones.Middle] = true
CombatSequences.AttackComboLeftRightFastStep.Actions = {
	{
		Type = EScriptableAction.STRAFE,
		Anim = "StrafeForwardOneStep"
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "StrikeLeft"
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "StrikeRight"
	}
}

-- AttackComboRightLeft --
CombatSequences.AttackComboRightLeft = {}
CombatSequences.AttackComboRightLeft.Priority = SequencePriorities.Attack
CombatSequences.AttackComboRightLeft.IsCombo = true
CombatSequences.AttackComboRightLeft.Zones = {}
CombatSequences.AttackComboRightLeft.Zones[CombatZones.Middle] = true
CombatSequences.AttackComboRightLeft.Actions = {
	{
		Type = EScriptableAction.STRAFE,
		Anim = "StrafeForwardOneStep"
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "StrikeRight"
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "StrikeLeft"
	}
}

-- CloseAttackLeftRight --
CombatSequences.CloseAttackLeftRight = {}
CombatSequences.CloseAttackLeftRight.Priority = SequencePriorities.Attack
CombatSequences.CloseAttackLeftRight.IsCombo = true
CombatSequences.CloseAttackLeftRight.Zones = {}
CombatSequences.CloseAttackLeftRight.Zones[CombatZones.Near] = true
CombatSequences.CloseAttackLeftRight.Actions = {
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "StrikeLeft"
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "StrikeRight"
	}
}

-- AssassinRush --
CombatSequences.AssassinRush = {}
CombatSequences.AssassinRush.Priority = SequencePriorities.Attack
CombatSequences.AssassinRush.IsCombo = true
CombatSequences.AssassinRush.Zones = {}
CombatSequences.AssassinRush.Zones[CombatZones.Middle] = true
CombatSequences.AssassinRush.Actions = {
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "StrikeAssassinRush"
	},
	{
		Type = EScriptableAction.STRAFE,
		Anim = "CombatStrafeBackwards"
	}
}

-- CloseFlourishStepBack --
CombatSequences.CloseFlourishStepBack = {}
CombatSequences.CloseFlourishStepBack.Priority = SequencePriorities.Attack
CombatSequences.CloseFlourishStepBack.IsCombo = true
CombatSequences.CloseFlourishStepBack.Zones = {}
CombatSequences.CloseFlourishStepBack.Zones[CombatZones.Near] = true
CombatSequences.CloseFlourishStepBack.Actions = {
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "DoubleStrikeA"
	},
	{
		Type = EScriptableAction.STRAFE,
		Anim = "StepBack"
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "DoubleStrikeB"
	}
}

-- FlourishLeft --
CombatSequences.FlourishLeft = {}
CombatSequences.FlourishLeft.Priority = SequencePriorities.Attack
CombatSequences.FlourishLeft.IsCombo = true
CombatSequences.FlourishLeft.Zones = {}
CombatSequences.FlourishLeft.Zones[CombatZones.Middle] = true
CombatSequences.FlourishLeft.Actions = {
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "FlourishLeft"
	}
}

-- CloseAttack --
CombatSequences.CloseAttack = {}
CombatSequences.CloseAttack.Priority = SequencePriorities.Attack
CombatSequences.CloseAttack.IsCombo = true
CombatSequences.CloseAttack.Zones = {}
CombatSequences.CloseAttack.Zones[CombatZones.Near] = true
CombatSequences.CloseAttack.Actions = {
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "CloseAttack"
	},
	{
		Type = EScriptableAction.STRAFE,
		Anim = "StepBack"
	}
}

-- UnarmedLeftAttack --
CombatSequences.UnarmedLeftAttack = {}
CombatSequences.UnarmedLeftAttack.Priority = SequencePriorities.Attack
CombatSequences.UnarmedLeftAttack.Zones = {}
CombatSequences.UnarmedLeftAttack.Zones[CombatZones.Left] = true
CombatSequences.UnarmedLeftAttack.Actions = {
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "StrikeLeft",
		FaceTarget = false,
		AdditionalTurning = true,
		HitOutsideAttackArc = true
	}
}

-- UnarmedRightAttack --
CombatSequences.UnarmedRightAttack = {}
CombatSequences.UnarmedRightAttack.Priority = SequencePriorities.Attack
CombatSequences.UnarmedRightAttack.Zones = {}
CombatSequences.UnarmedRightAttack.Zones[CombatZones.Right] = true
CombatSequences.UnarmedRightAttack.Actions = {
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "StrikeRight",
		FaceTarget = false,
		AdditionalTurning = true,
		HitOutsideAttackArc = true
	}
}

-- UnarmedRearAttack --
CombatSequences.UnarmedRearAttack = {}
CombatSequences.UnarmedRearAttack.Priority = SequencePriorities.Attack
CombatSequences.UnarmedRearAttack.IsCombo = true
CombatSequences.UnarmedRearAttack.Zones = {}
CombatSequences.UnarmedRearAttack.Zones[CombatZones.Rear] = true
CombatSequences.UnarmedRearAttack.Actions = {
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "StrikeLeft",
		FaceTarget = false,
		AdditionalTurning = true,
		HitOutsideAttackArc = true
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "StrikeRight"
	}
}

-- NearRifleStrikeOne --
CombatSequences.NearRifleStrikeOne = {}
CombatSequences.NearRifleStrikeOne.Priority = SequencePriorities.Attack
CombatSequences.NearRifleStrikeOne.Zones = {}
CombatSequences.NearRifleStrikeOne.Zones[CombatZones.Near] = true
CombatSequences.NearRifleStrikeOne.Actions = {
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "RifleStrikeOne"
	}
}

-- NearRifleStrikeTwo --
CombatSequences.NearRifleStrikeTwo = {}
CombatSequences.NearRifleStrikeTwo.Priority = SequencePriorities.Attack
CombatSequences.NearRifleStrikeTwo.Zones = {}
CombatSequences.NearRifleStrikeTwo.Zones[CombatZones.Near] = true
CombatSequences.NearRifleStrikeTwo.Actions = {
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "RifleStrikeTwo"
	}
}

-- MidRifleStrikeOne --
CombatSequences.MidRifleStrikeOne = {}
CombatSequences.MidRifleStrikeOne.Priority = SequencePriorities.Attack
CombatSequences.MidRifleStrikeOne.Zones = {}
CombatSequences.MidRifleStrikeOne.Zones[CombatZones.Middle] = true
CombatSequences.MidRifleStrikeOne.Actions = {
	{
		Type = EScriptableAction.STRAFE,
		Anim = "CombatStrafeForwards"
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "RifleStrikeOne"
	}
}

-- MidRifleStrikeTwo --
CombatSequences.MidRifleStrikeTwo = {}
CombatSequences.MidRifleStrikeTwo.Priority = SequencePriorities.Attack
CombatSequences.MidRifleStrikeTwo.Zones = {}
CombatSequences.MidRifleStrikeTwo.Zones[CombatZones.Middle] = true
CombatSequences.MidRifleStrikeTwo.Actions = {
	{
		Type = EScriptableAction.STRAFE,
		Anim = "CombatStrafeForwards"
	},
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "RifleStrikeTwo"
	}
}


-- uncomment for debug
-- GUI.DisplayMessageBox("CommonStrikeSequences.lua successfully loaded!")
-- while (GUI.IsDisplayBoxActive()) do
	-- coroutine.yield()
-- end