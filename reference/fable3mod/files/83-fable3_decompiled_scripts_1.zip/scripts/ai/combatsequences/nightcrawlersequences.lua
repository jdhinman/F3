
-- NightCrawlerSpamResponse --
CombatSequences.NightCrawlerSpamResponse = {}
CombatSequences.NightCrawlerSpamResponse.IsValid = Predicate.CreateHaveIBeenStruckALotPredicate(2)
CombatSequences.NightCrawlerSpamResponse.Priority = SequencePriorities.PreferredAttack
CombatSequences.NightCrawlerSpamResponse.CounterAttack = true
CombatSequences.NightCrawlerSpamResponse.Zones = {}
CombatSequences.NightCrawlerSpamResponse.Zones[CombatZones.Near] = true
CombatSequences.NightCrawlerSpamResponse.ZonesWhilePlaying = {}
CombatSequences.NightCrawlerSpamResponse.ZonesWhilePlaying[CombatZones.Near] = true
CombatSequences.NightCrawlerSpamResponse.ZonesWhilePlaying[CombatZones.Middle] = true
CombatSequences.NightCrawlerSpamResponse.Actions = {
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "PushAwayStrike",
		Priority = EActionPriority.PRIORITY_COMBAT_UNINTERRUPTABLE_STRIKE,
		PushBackStrike = 4
	}
}

-- NightCrawlerClawAttack --
CombatSequences.NightCrawlerClawAttack = {}
CombatSequences.NightCrawlerClawAttack.Priority = SequencePriorities.Attack
CombatSequences.NightCrawlerClawAttack.CounterAttack = true
CombatSequences.NightCrawlerClawAttack.Zones = {}
CombatSequences.NightCrawlerClawAttack.Zones[CombatZones.Near] = true
CombatSequences.NightCrawlerClawAttack.ZonesWhilePlaying = {}
CombatSequences.NightCrawlerClawAttack.ZonesWhilePlaying[CombatZones.Near] = true
CombatSequences.NightCrawlerClawAttack.ZonesWhilePlaying[CombatZones.Middle] = true
CombatSequences.NightCrawlerClawAttack.Actions = {
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "PushAwayStrike",
		Priority = EActionPriority.PRIORITY_COMBAT_UNINTERRUPTABLE_STRIKE
	}
}

-- NightCrawlerClawAttackLeft --
CombatSequences.NightCrawlerClawAttackLeft = {}
CombatSequences.NightCrawlerClawAttackLeft.Priority = SequencePriorities.Attack
CombatSequences.NightCrawlerClawAttackLeft.CounterAttack = true
CombatSequences.NightCrawlerClawAttackLeft.Zones = {}
CombatSequences.NightCrawlerClawAttackLeft.Zones[CombatZones.Left] = true
CombatSequences.NightCrawlerClawAttackLeft.Actions = {
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "PushAwayStrike",
		Priority = EActionPriority.PRIORITY_COMBAT_UNINTERRUPTABLE_STRIKE,
		FaceTarget = false,
		AdditionalTurning = true,
		HitOutsideAttackArc = true,
		BlendOutTime = 0.3
	}
}

-- NightCrawlerClawAttackRight --
CombatSequences.NightCrawlerClawAttackRight = {}
CombatSequences.NightCrawlerClawAttackRight.Priority = SequencePriorities.Attack
CombatSequences.NightCrawlerClawAttackRight.CounterAttack = true
CombatSequences.NightCrawlerClawAttackRight.Zones = {}
CombatSequences.NightCrawlerClawAttackRight.Zones[CombatZones.Right] = true
CombatSequences.NightCrawlerClawAttackRight.Actions = {
	{
		Type = EScriptableAction.MELEE_STRIKE,
		Anim = "PushAwayStrike",
		Priority = EActionPriority.PRIORITY_COMBAT_UNINTERRUPTABLE_STRIKE,
		FaceTarget = false,
		AdditionalTurning = true,
		HitOutsideAttackArc = true,
		BlendOutTime = 0.3
	}
}



-- uncomment for debug
-- GUI.DisplayMessageBox("NightcrawlerSequences.lua successfully loaded!")
-- while (GUI.IsDisplayBoxActive()) do
	-- coroutine.yield()
-- end