
CombatStyles = {}
CombatGroupNames = {
	"None",
	"HobbeLike",
	"BanditLike",
	"HighwaymanLike",
	"BeetleLike",
	"BalverineLike",
	"HollowManLike",
	"WolfLike"
}

CombatGroupTypes = CreateEnum(CombatGroupNames)

CombatStyles.GetStyleForCreature = function()

end

CombatStyles.ShootingBalanceDataDefault = {}
CombatStyles.ShootingBalanceDataDefault.StartingChanceToHitWithFirearm = 0
CombatStyles.ShootingBalanceDataDefault.MaxChanceToHitWithFirearmCap = 1
CombatStyles.ShootingBalanceDataDefault.ChanceToHitModBonusRangeDistance = 9
CombatStyles.ShootingBalanceDataDefault.ChanceToHitModSegmentLength = 0.3
CombatStyles.ShootingBalanceDataDefault.ChanceToHitModPercentageIncrease = 0.02
CombatStyles.ShootingBalanceDataDefault.ChanceToHitModConsecutiveShotPercentageIncrease = 0.1
CombatStyles.ShootingBalanceDataDefault.ChanceToHitModConsecutiveShotsTimeFrame = 10
CombatStyles.ShootingBalanceDataDefault.ChanceToHitModPercentageDecreasePerOneSpeed = 0.05
CombatStyles.ShootingBalanceDataDefault.ChanceToHitModTargetInCoverPercentageMultiplier = 0.5
CombatStyles.ShootingBalanceDataDefault.ChanceToHitModOffScreenPercentageMultiplier = 0.05

CombatStyles.StandardMeleeCombatStates = {
	"AntiSpamCheck",
	"WaitForActionToFinish",
	"LaughAtKnockdown",
	"UpdateWeapon",
	"CheckForBetterTarget",
	"OuterRingKeepDistance",
	"OuterRingSpreadOut",
	"PlayBanterCombatComment",
	"PlayCombatSequence",
	"MoveToFormationPos",
	"FaceTarget"
}

CombatStyles.StandardRangedCombatStates = {
	"AntiSpamCheck",
	"WaitForActionToFinish",
	"UpdateAim",
	"UpdateWeapon",
	"CheckForBetterTarget",
	"GetTargetInSights",
	"FireRangedWeapon",
	"OuterRingKeepDistance",
	"OuterRingSpreadOut",
	"PlayBanterCombatComment",
	"PlayCombatSequence",
	"MoveToFormationPos",
	"FaceTarget",
	"IdleWithRangedWeapon"
}

CombatStyles.StandardBlockingCombatStates = {
	"WaitForActionToFinish",
	"PlayCombatSequence",
	"MoveToFormationPos"
}

CombatStyles.StandardGroupOrderStates = {
	"WaitForActionToFinish",
	"PlayCombatSequence",
	"MoveToFormationPos"
}

CombatStyles.StandardMeleeCombatStates = {
	"WaitForActionToFinish",
	"PlayCombatSequence",
	"MoveToFormationPos"
}

CombatStyles.StandardCombatStates = {}
CombatStyles.StandardCombatStates[CombatSituations.Melee] = CombatStyles.StandardMeleeCombatStates
CombatStyles.StandardCombatStates[CombatSituations.Ranged] = CombatStyles.StandardRangedCombatStates
CombatStyles.StandardCombatStates[CombatSituations.SoftBlocking] = CombatStyles.StandardBlockingCombatStates
CombatStyles.StandardCombatStates[CombatSituations.HardBlocking] = CombatStyles.StandardBlockingCombatStates
CombatStyles.StandardCombatStates[CombatSituations.Dodging] = CombatStyles.StandardBlockingCombatStates
CombatStyles.StandardCombatStates[CombatSituations.GroupOrders] = CombatStyles.StandardGroupOrderStates

Debug.DumpStyleSequences = function()

end



