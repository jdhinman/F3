
CombatSequences = {}
CombatSequences.DebugHighlightSequences = {}

CombatZoneNames = {
	"None",
	"Near",
	"Middle",
	"Far",
	"Left",
	"Right",
	"Rear",
	"OuterRing",
	"LeftFar",
	"RightFar",
	"RearFar"
}
CombatZones = CreateEnum(CombatZoneNames)

AngleToleranceNames = {
	"LeftFar_Min",
	"LeftFar_Max",
	"RightFar_Min",
	"RightFar_Max",
	"RearFar_Min",
	"RearFar_Max"
}
AngleToleranceZones = CreateEnum(AngleToleranceNames)

SequencePriorityNames = {
	"Idle",
	"PreferredIdle",
	"Movement",
	"Attack",
	"PreferredAttack"
}

SequencePriorities = CreateEnum(SequencePriorityNames)

CombatSequences.PlaySequenceInfo = function()
end
CombatSequences.GetSequenceInfo = function()
end
CombatSequences.ScoreSequence = function()
end
CombatSequences.FindBestSequence = function()
end
CombatSequences.GetAttackZones = function()
end
CombatSequences.DebugHighlightSequence = function()
end



