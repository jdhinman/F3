
-- Wolf --
CombatStyles.Wolf = {}
CombatStyles.Wolf.CombatGroupType = CombatGroupTypes.WolfLike
CombatStyles.Wolf.MinSecondsBetweenMeleeAttacks = 1
CombatStyles.Wolf.SecondsToWaitAfterTargetIsHit = 1.5
CombatStyles.Wolf.SecondsToWaitAfterTargetIsAttacked = 1.5
CombatStyles.Wolf.CanStrafe = false
CombatStyles.Wolf.NonFormation = true
CombatStyles.Wolf.CanFightUnarmed = true
CombatStyles.Wolf.IsWolf = true
CombatStyles.Wolf.WolfPreferredRange = 1.5
CombatStyles.Wolf.WolfMaxCircleRange = 6
CombatStyles.Wolf.WolfRingSpacing = 1.3
CombatStyles.Wolf.WolfPercentChanceOfDistanceAttack = 60
CombatStyles.Wolf.MinTimeBetweenTaunts = 6
CombatStyles.Wolf.MaxTimeBetweenTaunts = 15
CombatStyles.Wolf.PreferredRange = 0
CombatStyles.Wolf.DoSpotTargetAnim = true
CombatStyles.Wolf.TurnToFaceTolerance = 180
CombatStyles.Wolf.Limits = {}
CombatStyles.Wolf.Limits[CombatZones.Near] = 1
CombatStyles.Wolf.Limits[CombatZones.Middle] = 3
CombatStyles.Wolf.Limits[CombatZones.Far] = 5
CombatStyles.Wolf.Limits[CombatZones.Left] = 4
CombatStyles.Wolf.Limits[CombatZones.Right] = 4
CombatStyles.Wolf.Limits[CombatZones.Rear] = 1
CombatStyles.Wolf.Sequences = {}
CombatStyles.Wolf.Sequences[CombatSituations.Melee] = {}
CombatStyles.Wolf.ValidStates = {}
CombatStyles.Wolf.ValidStates[CombatSituations.Melee] = {
	"WolfRetreat",
	"WaitForActionToFinish",
	"CheckForBetterTarget",
	"WolfAttack",
	"WolfCircle"
}


-- Wolf Hollow --
CombatStyles.HollowWolf = {}
CombatStyles.HollowWolf.CombatGroupType = CombatGroupTypes.WolfLike
CombatStyles.HollowWolf.MinSecondsBetweenMeleeAttacks = 0.5
CombatStyles.HollowWolf.SecondsToWaitAfterTargetIsHit = 1
CombatStyles.HollowWolf.SecondsToWaitAfterTargetIsAttacked = 1
CombatStyles.HollowWolf.CanStrafe = false
CombatStyles.HollowWolf.NonFormation = true
CombatStyles.HollowWolf.CanFightUnarmed = true
CombatStyles.HollowWolf.IsWolf = true
CombatStyles.HollowWolf.WolfPreferredRange = 1.5
CombatStyles.HollowWolf.WolfMaxCircleRange = 6
CombatStyles.HollowWolf.WolfRingSpacing = 1.3
CombatStyles.HollowWolf.WolfPercentChanceOfDistanceAttack = 80
CombatStyles.HollowWolf.MinTimeBetweenTaunts = 6
CombatStyles.HollowWolf.MaxTimeBetweenTaunts = 15
CombatStyles.HollowWolf.PreferredRange = 0
CombatStyles.HollowWolf.DoSpotTargetAnim = true
CombatStyles.HollowWolf.TurnToFaceTolerance = 180
CombatStyles.HollowWolf.Limits = {}
CombatStyles.HollowWolf.Limits[CombatZones.Near] = 1
CombatStyles.HollowWolf.Limits[CombatZones.Middle] = 3
CombatStyles.HollowWolf.Limits[CombatZones.Far] = 6
CombatStyles.HollowWolf.Limits[CombatZones.Left] = 4
CombatStyles.HollowWolf.Limits[CombatZones.Right] = 4
CombatStyles.HollowWolf.Limits[CombatZones.Rear] = 3
CombatStyles.HollowWolf.Sequences = {}
CombatStyles.HollowWolf.Sequences[CombatSituations.Melee] = {
	{"HollowWolfCloseCast", 10},
	{"HollowWolfFarCast", 10}
}
CombatStyles.HollowWolf.ValidStates = {}
CombatStyles.HollowWolf.ValidStates[CombatSituations.Melee] = {
	"WolfRetreat",
	"WaitForActionToFinish",
	"CheckForBetterTarget",
	"WolfAttack",
	"PlayCombatSequence",
	"WolfCircle"
}


-- uncomment for debug
-- GUI.DisplayMessageBox("wolfcombatstyles.lua successfully loaded!")
-- while (GUI.IsDisplayBoxActive()) do
	-- coroutine.yield()
-- end



