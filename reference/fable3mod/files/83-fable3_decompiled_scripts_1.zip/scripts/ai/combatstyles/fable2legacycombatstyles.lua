
-- BansheeChild --
CombatStyles.BansheeChild = {}
CombatStyles.BansheeChild.CombatGroupType = CombatGroupTypes.HollowManLike
CombatStyles.BansheeChild.CanSheatheWeapon = false
CombatStyles.BansheeChild.DualWieldMeleeSlot = DummyObjects.HAND_LEFT
CombatStyles.BansheeChild.NonFormation = true
CombatStyles.BansheeChild.TurnToFaceTolerance = 15
CombatStyles.BansheeChild.PreferredRange = 1.5
CombatStyles.BansheeChild.CanFightUnarmed = true
CombatStyles.BansheeChild.Limits = {}
CombatStyles.BansheeChild.Limits[CombatZones.Near] = 1.4
CombatStyles.BansheeChild.Limits[CombatZones.Middle] = 2.5
CombatStyles.BansheeChild.Limits[CombatZones.Far] = 5
CombatStyles.BansheeChild.Limits[CombatZones.Left] = 1
CombatStyles.BansheeChild.Limits[CombatZones.Right] = 1
CombatStyles.BansheeChild.Limits[CombatZones.Rear] = 1
CombatStyles.BansheeChild.MinSecondsBetweenMeleeAttacks = 0
CombatStyles.BansheeChild.SecondsToWaitAfterTargetIsHit = 0
CombatStyles.BansheeChild.MaxNavSpeed = ENavigationSpeed.NAV_SPEED_WALK
CombatStyles.BansheeChild.HollowManParams = {}
CombatStyles.BansheeChild.HollowManParams.WispSpeed = 1.5
CombatStyles.BansheeChild.HollowManParams.MinimumSpawnDist = 1.75
CombatStyles.BansheeChild.HollowManParams.SpawnDistRandom = 1.25
CombatStyles.BansheeChild.HollowManParams.TargetSpeedToDistMultiplier = 1.2
CombatStyles.BansheeChild.HollowManParams.DistForMove = 6
CombatStyles.BansheeChild.HollowManParams.ReturnUndergroundDist = 10
CombatStyles.BansheeChild.HollowManParams.RiseAttackPercentageChance = 100
CombatStyles.BansheeChild.HollowManParams.RunPercentageChance = 0
CombatStyles.BansheeChild.HollowManParams.RunPercentageChanceAgainstRanged = 100
CombatStyles.BansheeChild.HollowManParams.RunAttackPercentageChance = 0
CombatStyles.BansheeChild.Sequences = {}
CombatStyles.BansheeChild.Sequences[CombatSituations.Melee] = {
	"BansheeChildOrbSuckingResponse",
	"BansheeChildCloseAttackCombo",
	"BansheeChildAttackCombo",
	"IdleLong",
	"IdleStrafeLeft",
	"IdleStrafeRight",
	"BackOff",
	"HollowManAdvance"
}
CombatStyles.BansheeChild.ValidStates = {}
CombatStyles.BansheeChild.ValidStates[CombatSituations.Melee] = {
	"WaitForActionToFinish",
	"HollowManBuggerOffAndDie",
	"CheckForBetterTarget",
	"PlayCombatSequence",
	"HollowManCharge",
	"HollowManWispMove",
	"HollowManMove",
	"MoveToFormationPos",
	"FaceTarget"
}


-- Troll --
CombatStyles.Troll = {}
CombatStyles.Troll.TurnToFaceTolerance = 25
CombatStyles.Troll.NonFormation = true
CombatStyles.Troll.IsTroll = true
CombatStyles.Troll.CanFightUnarmed = true
CombatStyles.Troll.UsesHealthBar = true
CombatStyles.Troll.Limits = {}
CombatStyles.Troll.Limits[CombatZones.Near] = 1
CombatStyles.Troll.Limits[CombatZones.Middle] = 3
CombatStyles.Troll.Limits[CombatZones.Far] = 5
CombatStyles.Troll.Limits[CombatZones.Left] = 1
CombatStyles.Troll.Limits[CombatZones.Right] = 1
CombatStyles.Troll.Limits[CombatZones.Rear] = 1
CombatStyles.Troll.Sequences = {}
CombatStyles.Troll.Sequences[CombatSituations.Melee] = {
	"Idle"
}
CombatStyles.Troll.ValidStates = {}
CombatStyles.Troll.ValidStates[CombatSituations.Melee] = {
	"WaitForActionToFinish",
	"CheckForBetterTarget",
	"PlayCombatSequence",
	"FaceTarget"
}
CombatStyles.Troll.Balance = {}
CombatStyles.Troll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_100] = {}
CombatStyles.Troll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_100].PoundAnimSpeedMultiplier = 1
CombatStyles.Troll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_100].SecondsToWaitAfterHittingTarget = 6
CombatStyles.Troll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_100].NumberOfShockwaves = 1
CombatStyles.Troll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_100].TimeBetweenShockwaves = 2
CombatStyles.Troll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_100].NumberOfTremors = 1
CombatStyles.Troll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_100].ShockwaveSpeed = 0.8
CombatStyles.Troll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_100].ShockwaveDamage = 10
CombatStyles.Troll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_100].NumberOfRocks = 1
CombatStyles.Troll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_100].ThrowAnimSpeedMultiplier = 1
CombatStyles.Troll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_100].ThrowRange = {}
CombatStyles.Troll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_100].ThrowRange.Max = 25
CombatStyles.Troll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_100].ThrowRange.Min = 5
CombatStyles.Troll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_100].ThrowAngle = 15
CombatStyles.Troll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_100].ProjectileDamage = 20
CombatStyles.Troll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_100].RateOfFire = 7
CombatStyles.Troll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_50] = {}
CombatStyles.Troll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_50].PoundAnimSpeedMultiplier = 1
CombatStyles.Troll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_50].SecondsToWaitAfterHittingTarget = 6
CombatStyles.Troll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_50].NumberOfShockwaves = 1
CombatStyles.Troll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_50].TimeBetweenShockwaves = 2
CombatStyles.Troll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_50].NumberOfTremors = 2
CombatStyles.Troll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_50].ShockwaveSpeed = 0.9
CombatStyles.Troll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_50].ShockwaveDamage = 15
CombatStyles.Troll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_50].NumberOfRocks = 2
CombatStyles.Troll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_50].ThrowAnimSpeedMultiplier = 1
CombatStyles.Troll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_50].ThrowRange = {}
CombatStyles.Troll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_50].ThrowRange.Max = 25
CombatStyles.Troll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_50].ThrowRange.Min = 5
CombatStyles.Troll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_50].ThrowAngle = 20
CombatStyles.Troll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_50].ProjectileDamage = 20
CombatStyles.Troll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_50].RateOfFire = 5
CombatStyles.Troll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_25] = {}
CombatStyles.Troll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_25].PoundAnimSpeedMultiplier = 1
CombatStyles.Troll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_25].SecondsToWaitAfterHittingTarget = 6
CombatStyles.Troll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_25].NumberOfShockwaves = 2
CombatStyles.Troll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_25].TimeBetweenShockwaves = 2
CombatStyles.Troll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_25].NumberOfTremors = 2
CombatStyles.Troll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_25].ShockwaveSpeed = 1.1
CombatStyles.Troll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_25].ShockwaveDamage = 20
CombatStyles.Troll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_25].NumberOfRocks = 2
CombatStyles.Troll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_25].ThrowAnimSpeedMultiplier = 1
CombatStyles.Troll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_25].ThrowRange = {}
CombatStyles.Troll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_25].ThrowRange.Max = 25
CombatStyles.Troll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_25].ThrowRange.Min = 5
CombatStyles.Troll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_25].ThrowAngle = 15
CombatStyles.Troll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_25].ProjectileDamage = 20
CombatStyles.Troll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_25].RateOfFire = 3.5
CombatStyles.Troll.WeakSpots = {
	1,
	2,
	3,
	4,
	5,
	6
}
CombatStyles.Troll.FootstepFX = "FX_Forest_Troll_Footstep"
CombatStyles.Troll.BurrowFX = "FX_Forest_Troll_Burrow"
CombatStyles.Troll.PoundExplosionType = "ExplosionTrollGroundPound"
CombatStyles.Troll.StompExplosionType = "ExplosionTrollStomp"
CombatStyles.Troll.RightRock = "ProjectileTrollRight"
CombatStyles.Troll.LeftRock = "ProjectileTrollLeft"
CombatStyles.Troll.RiseFX = "ExplosionTrollRise"
CombatStyles.Troll.FastRiseFX = "ExplosionTrollRiseFast"
CombatStyles.Troll.IdleTimeBeforeReturnUnderground = 15
CombatStyles.Troll.RangedHitsBeforeReact = 2
CombatStyles.Troll.ChanceOfGettingStuck = 0.5


-- Troll Rock --
CombatStyles.RockTroll = {}
CombatStyles.RockTroll.TurnToFaceTolerance = 25
CombatStyles.RockTroll.NonFormation = true
CombatStyles.RockTroll.IsTroll = true
CombatStyles.RockTroll.CanFightUnarmed = true
CombatStyles.RockTroll.UsesHealthBar = true
CombatStyles.RockTroll.Limits = {}
CombatStyles.RockTroll.Limits[CombatZones.Near] = 1
CombatStyles.RockTroll.Limits[CombatZones.Middle] = 3
CombatStyles.RockTroll.Limits[CombatZones.Far] = 5
CombatStyles.RockTroll.Limits[CombatZones.Left] = 1
CombatStyles.RockTroll.Limits[CombatZones.Right] = 1
CombatStyles.RockTroll.Limits[CombatZones.Rear] = 1
CombatStyles.RockTroll.Sequences = {}
CombatStyles.RockTroll.Sequences[CombatSituations.Melee] = {
	"Idle"
}
CombatStyles.RockTroll.ValidStates = {}
CombatStyles.RockTroll.ValidStates[CombatSituations.Melee] = {
	"WaitForActionToFinish",
	"CheckForBetterTarget",
	"PlayCombatSequence",
	"FaceTarget"
}
CombatStyles.RockTroll.Balance = {}
CombatStyles.RockTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_100] = {}
CombatStyles.RockTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_100].PoundAnimSpeedMultiplier = 1
CombatStyles.RockTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_100].SecondsToWaitAfterHittingTarget = 6
CombatStyles.RockTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_100].NumberOfShockwaves = 1
CombatStyles.RockTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_100].TimeBetweenShockwaves = 2
CombatStyles.RockTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_100].NumberOfTremors = 1
CombatStyles.RockTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_100].ShockwaveSpeed = 1.1
CombatStyles.RockTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_100].ShockwaveDamage = 15
CombatStyles.RockTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_100].NumberOfRocks = 1
CombatStyles.RockTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_100].ThrowAnimSpeedMultiplier = 1.2
CombatStyles.RockTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_100].ThrowRange = {}
CombatStyles.RockTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_100].ThrowRange.Max = 25
CombatStyles.RockTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_100].ThrowRange.Min = 5
CombatStyles.RockTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_100].ThrowAngle = 10
CombatStyles.RockTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_100].ProjectileDamage = 30
CombatStyles.RockTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_100].RateOfFire = 6
CombatStyles.RockTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_50] = {}
CombatStyles.RockTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_50].PoundAnimSpeedMultiplier = 1
CombatStyles.RockTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_50].SecondsToWaitAfterHittingTarget = 6
CombatStyles.RockTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_50].NumberOfShockwaves = 2
CombatStyles.RockTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_50].TimeBetweenShockwaves = 2
CombatStyles.RockTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_50].NumberOfTremors = 1
CombatStyles.RockTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_50].ShockwaveSpeed = 1.1
CombatStyles.RockTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_50].ShockwaveDamage = 20
CombatStyles.RockTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_50].NumberOfRocks = 2
CombatStyles.RockTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_50].ThrowAnimSpeedMultiplier = 1.2
CombatStyles.RockTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_50].ThrowRange = {}
CombatStyles.RockTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_50].ThrowRange.Max = 25
CombatStyles.RockTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_50].ThrowRange.Min = 5
CombatStyles.RockTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_50].ThrowAngle = 15
CombatStyles.RockTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_50].ProjectileDamage = 30
CombatStyles.RockTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_50].RateOfFire = 5
CombatStyles.RockTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_25] = {}
CombatStyles.RockTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_25].PoundAnimSpeedMultiplier = 1
CombatStyles.RockTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_25].SecondsToWaitAfterHittingTarget = 6
CombatStyles.RockTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_25].NumberOfShockwaves = 3
CombatStyles.RockTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_25].TimeBetweenShockwaves = 2
CombatStyles.RockTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_25].NumberOfTremors = 2
CombatStyles.RockTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_25].ShockwaveSpeed = 1.2
CombatStyles.RockTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_25].ShockwaveDamage = 25
CombatStyles.RockTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_25].NumberOfRocks = 3
CombatStyles.RockTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_25].ThrowAnimSpeedMultiplier = 1.2
CombatStyles.RockTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_25].ThrowRange = {}
CombatStyles.RockTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_25].ThrowRange.Max = 25
CombatStyles.RockTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_25].ThrowRange.Min = 5
CombatStyles.RockTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_25].ThrowAngle = 15
CombatStyles.RockTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_25].ProjectileDamage = 30
CombatStyles.RockTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_25].RateOfFire = 4
CombatStyles.RockTroll.WeakSpots = {
	1,
	2,
	3,
	4,
	5,
	6,
	7
}
CombatStyles.RockTroll.FootstepFX = "FX_Rock_Troll_Footstep"
CombatStyles.RockTroll.BurrowFX = "FX_Rock_Troll_Burrow"
CombatStyles.RockTroll.PoundExplosionType = "ExplosionRockTrollGroundPound"
CombatStyles.RockTroll.StompExplosionType = "ExplosionTrollStomp"
CombatStyles.RockTroll.RightRock = "ProjectileRockTrollRight"
CombatStyles.RockTroll.LeftRock = "ProjectileRockTrollLeft"
CombatStyles.RockTroll.RiseFX = "ExplosionRockTrollRise"
CombatStyles.RockTroll.FastRiseFX = "ExplosionTrollRiseFast"
CombatStyles.RockTroll.IdleTimeBeforeReturnUnderground = 15
CombatStyles.RockTroll.RangedHitsBeforeReact = 2
CombatStyles.RockTroll.ChanceOfGettingStuck = 1


-- Troll Swamp --
CombatStyles.SwampTroll = {}
CombatStyles.SwampTroll.TurnToFaceTolerance = 25
CombatStyles.SwampTroll.NonFormation = true
CombatStyles.SwampTroll.IsTroll = true
CombatStyles.SwampTroll.CanFightUnarmed = true
CombatStyles.SwampTroll.UsesHealthBar = true
CombatStyles.SwampTroll.Limits = {}
CombatStyles.SwampTroll.Limits[CombatZones.Near] = 1
CombatStyles.SwampTroll.Limits[CombatZones.Middle] = 3
CombatStyles.SwampTroll.Limits[CombatZones.Far] = 5
CombatStyles.SwampTroll.Limits[CombatZones.Left] = 1
CombatStyles.SwampTroll.Limits[CombatZones.Right] = 1
CombatStyles.SwampTroll.Limits[CombatZones.Rear] = 1
CombatStyles.SwampTroll.Sequences = {}
CombatStyles.SwampTroll.Sequences[CombatSituations.Melee] = {
	"Idle"
}
CombatStyles.SwampTroll.ValidStates = {}
CombatStyles.SwampTroll.ValidStates[CombatSituations.Melee] = {
	"WaitForActionToFinish",
	"CheckForBetterTarget",
	"PlayCombatSequence",
	"FaceTarget"
}
CombatStyles.SwampTroll.Balance = {}
CombatStyles.SwampTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_100] = {}
CombatStyles.SwampTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_100].PoundAnimSpeedMultiplier = 1
CombatStyles.SwampTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_100].SecondsToWaitAfterHittingTarget = 6
CombatStyles.SwampTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_100].NumberOfShockwaves = 2
CombatStyles.SwampTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_100].TimeBetweenShockwaves = 2
CombatStyles.SwampTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_100].NumberOfTremors = 1
CombatStyles.SwampTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_100].ShockwaveSpeed = 1.1
CombatStyles.SwampTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_100].ShockwaveDamage = 25
CombatStyles.SwampTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_100].NumberOfRocks = 2
CombatStyles.SwampTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_100].ThrowAnimSpeedMultiplier = 1.3
CombatStyles.SwampTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_100].ThrowRange = {}
CombatStyles.SwampTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_100].ThrowRange.Max = 25
CombatStyles.SwampTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_100].ThrowRange.Min = 5
CombatStyles.SwampTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_100].ThrowAngle = 10
CombatStyles.SwampTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_100].ProjectileDamage = 50
CombatStyles.SwampTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_100].RateOfFire = 6
CombatStyles.SwampTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_50] = {}
CombatStyles.SwampTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_50].PoundAnimSpeedMultiplier = 1
CombatStyles.SwampTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_50].SecondsToWaitAfterHittingTarget = 6
CombatStyles.SwampTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_50].NumberOfShockwaves = 3
CombatStyles.SwampTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_50].TimeBetweenShockwaves = 2
CombatStyles.SwampTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_50].NumberOfTremors = 3
CombatStyles.SwampTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_50].ShockwaveSpeed = 1.2
CombatStyles.SwampTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_50].ShockwaveDamage = 30
CombatStyles.SwampTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_50].NumberOfRocks = 3
CombatStyles.SwampTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_50].ThrowAnimSpeedMultiplier = 1.3
CombatStyles.SwampTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_50].ThrowRange = {}
CombatStyles.SwampTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_50].ThrowRange.Max = 25
CombatStyles.SwampTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_50].ThrowRange.Min = 5
CombatStyles.SwampTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_50].ThrowAngle = 15
CombatStyles.SwampTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_50].ProjectileDamage = 50
CombatStyles.SwampTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_50].RateOfFire = 5
CombatStyles.SwampTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_25] = {}
CombatStyles.SwampTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_25].PoundAnimSpeedMultiplier = 1
CombatStyles.SwampTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_25].SecondsToWaitAfterHittingTarget = 6
CombatStyles.SwampTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_25].NumberOfShockwaves = 3
CombatStyles.SwampTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_25].TimeBetweenShockwaves = 2
CombatStyles.SwampTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_25].NumberOfTremors = 3
CombatStyles.SwampTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_25].ShockwaveSpeed = 1.3
CombatStyles.SwampTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_25].ShockwaveDamage = 35
CombatStyles.SwampTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_25].NumberOfRocks = 4
CombatStyles.SwampTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_25].ThrowAnimSpeedMultiplier = 1.3
CombatStyles.SwampTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_25].ThrowRange = {}
CombatStyles.SwampTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_25].ThrowRange.Max = 25
CombatStyles.SwampTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_25].ThrowRange.Min = 5
CombatStyles.SwampTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_25].ThrowAngle = 15
CombatStyles.SwampTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_25].ProjectileDamage = 50
CombatStyles.SwampTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_25].RateOfFire = 4
CombatStyles.SwampTroll.WeakSpots = {
	1,
	2,
	3,
	4,
	5,
	6,
	7,
	8,
	9
}
CombatStyles.SwampTroll.FootstepFX = "FX_Swamp_Troll_Footstep"
CombatStyles.SwampTroll.BurrowFX = "FX_Swamp_Troll_Burrow"
CombatStyles.SwampTroll.PoundExplosionType = "ExplosionSwampTrollGroundPound"
CombatStyles.SwampTroll.StompExplosionType = "ExplosionTrollStomp"
CombatStyles.SwampTroll.RightRock = "ProjectileSwampTrollRight"
CombatStyles.SwampTroll.LeftRock = "ProjectileSwampTrollRight"
CombatStyles.SwampTroll.RiseFX = "ExplosionSwampTrollRise"
CombatStyles.SwampTroll.FastRiseFX = "ExplosionTrollRiseFast"
CombatStyles.SwampTroll.IdleTimeBeforeReturnUnderground = 15
CombatStyles.SwampTroll.RangedHitsBeforeReact = 2
CombatStyles.SwampTroll.ChanceOfGettingStuck = 1



-- Beetle Melee --
CombatStyles.BeetleMelee = {}
CombatStyles.BeetleMelee.CombatGroupType = CombatGroupTypes.BeetleLike
CombatStyles.BeetleMelee.NonFormation = true
CombatStyles.BeetleMelee.PreferredRange = 2.3
CombatStyles.BeetleMelee.CanFightUnarmed = true
CombatStyles.BeetleMelee.Limits = {}
CombatStyles.BeetleMelee.Limits[CombatZones.Near] = 1.8
CombatStyles.BeetleMelee.Limits[CombatZones.Middle] = 2.7
CombatStyles.BeetleMelee.Limits[CombatZones.Far] = 5
CombatStyles.BeetleMelee.Limits[CombatZones.Left] = 1
CombatStyles.BeetleMelee.Limits[CombatZones.Right] = 1
CombatStyles.BeetleMelee.Limits[CombatZones.Rear] = 1
CombatStyles.BeetleMelee.Sequences = {}
CombatStyles.BeetleMelee.Sequences[CombatSituations.Melee] = {
	"IdleLong",
	"BeetleAttack",
	"BeetleCloseAttack",
	"BeetleTakeOffAtFar",
	"BeetleLandWhenOutOfRange"
}
CombatStyles.BeetleMelee.MinSecondsBetweenMeleeAttacks = 6
CombatStyles.BeetleMelee.ValidStates = {}
CombatStyles.BeetleMelee.ValidStates[CombatSituations.Melee] = {
	"WaitForActionToFinish",
	"CheckForBetterTarget",
	"BeetleAdjustAltitude",
	"PlayCombatSequence",
	"MoveToFormationPos",
	"FaceTarget"
}


-- Beetle Spitter Weak --
CombatStyles.BeetleSpitterWeak = {}
CombatStyles.BeetleSpitterWeak.CombatGroupType = CombatGroupTypes.BeetleLike
CombatStyles.BeetleSpitterWeak.NonFormation = true
CombatStyles.BeetleSpitterWeak.TurnToFaceTolerance = 20
CombatStyles.BeetleSpitterWeak.Limits = {}
CombatStyles.BeetleSpitterWeak.Limits[CombatZones.Near] = 1.5
CombatStyles.BeetleSpitterWeak.Limits[CombatZones.Middle] = 2
CombatStyles.BeetleSpitterWeak.Limits[CombatZones.Far] = 8
CombatStyles.BeetleSpitterWeak.Limits[CombatZones.Left] = 1
CombatStyles.BeetleSpitterWeak.Limits[CombatZones.Right] = 1
CombatStyles.BeetleSpitterWeak.Limits[CombatZones.Rear] = 1
CombatStyles.BeetleSpitterWeak.Sequences = {}
CombatStyles.BeetleSpitterWeak.Sequences[CombatSituations.Melee] = {
	"IdleLong",
	"BeetleAttack",
	"BeetleCloseAttack",
	"BeetleTakeOffOnlyWhenClose",
	"BeetleLandAtFar"
}
CombatStyles.BeetleSpitterWeak.MinSecondsBetweenMeleeAttacks = 5
CombatStyles.BeetleSpitterWeak.MinSecondsBetweenRangedAttacks = 10
CombatStyles.BeetleSpitterWeak.ValidStates = {}
CombatStyles.BeetleSpitterWeak.ValidStates[CombatSituations.Melee] = {
	"WaitForActionToFinish",
	"CheckForBetterTarget",
	"BeetleAdjustAltitude",
	"BeetleSpit",
	"PlayCombatSequence",
	"NonFormationKeepDistanceMovement",
	"FaceTarget"
}
CombatStyles.BeetleSpitterWeak.SpitDamage = 2


-- Beetle Hugger --
CombatStyles.BeetleHugger = {}
CombatStyles.BeetleHugger.CombatGroupType = CombatGroupTypes.BeetleLike
CombatStyles.BeetleHugger.NonFormation = true
CombatStyles.BeetleHugger.PreferredRange = 2
CombatStyles.BeetleHugger.CanFightUnarmed = true
CombatStyles.BeetleHugger.Limits = {}
CombatStyles.BeetleHugger.Limits[CombatZones.Near] = 1.5
CombatStyles.BeetleHugger.Limits[CombatZones.Middle] = 2.4
CombatStyles.BeetleHugger.Limits[CombatZones.Far] = 8
CombatStyles.BeetleHugger.Limits[CombatZones.Left] = 1
CombatStyles.BeetleHugger.Limits[CombatZones.Right] = 1
CombatStyles.BeetleHugger.Limits[CombatZones.Rear] = 1
CombatStyles.BeetleHugger.Sequences = {}
CombatStyles.BeetleHugger.Sequences[CombatSituations.Melee] = {
	"IdleLong",
	"BeetleAttack",
	"BeetleCloseAttack",
	"BeetleTakeOffAtFar",
	"BeetleLandWhenOutOfRange"
}
CombatStyles.BeetleHugger.MinSecondsBetweenMeleeAttacks = 3.5
CombatStyles.BeetleHugger.MinSecondsBetweenRangedAttacks = 5
CombatStyles.BeetleHugger.ValidStates = {}
CombatStyles.BeetleHugger.ValidStates[CombatSituations.Melee] = {
	"WaitForActionToFinish",
	"CheckForBetterTarget",
	"BeetleAdjustAltitude",
	"BeetleHug",
	"PlayCombatSequence",
	"MoveToFormationPos",
	"FaceTarget"
}
CombatStyles.BeetleHugger.HugBalancing = {}
CombatStyles.BeetleHugger.HugBalancing.DamagePerSecondWhileHugging = -3
CombatStyles.BeetleHugger.HugBalancing.TimeBetweenBeetleHugs = 5.5
CombatStyles.BeetleHugger.HugBalancing.TimeSpentHugging = 2.8
CombatStyles.BeetleHugger.HugBalancing.HugTimeReductionWhenButtonBashing = 1.8


-- Beetle Spitter --
CombatStyles.BeetleSpitter = {}
CombatStyles.BeetleSpitter.CombatGroupType = CombatGroupTypes.BeetleLike
CombatStyles.BeetleSpitter.NonFormation = true
CombatStyles.BeetleSpitter.TurnToFaceTolerance = 20
CombatStyles.BeetleSpitter.CanFightUnarmed = true
CombatStyles.BeetleSpitter.Limits = {}
CombatStyles.BeetleSpitter.Limits[CombatZones.Near] = 1.5
CombatStyles.BeetleSpitter.Limits[CombatZones.Middle] = 2
CombatStyles.BeetleSpitter.Limits[CombatZones.Far] = 8
CombatStyles.BeetleSpitter.Limits[CombatZones.Left] = 1
CombatStyles.BeetleSpitter.Limits[CombatZones.Right] = 1
CombatStyles.BeetleSpitter.Limits[CombatZones.Rear] = 1
CombatStyles.BeetleSpitter.Sequences = {}
CombatStyles.BeetleSpitter.Sequences[CombatSituations.Melee] = {
	"IdleLong",
	"BeetleAttack",
	"BeetleCloseAttack",
	"BeetleTakeOffOnlyWhenClose",
	"BeetleLandAtFar"
}
CombatStyles.BeetleSpitter.MinSecondsBetweenMeleeAttacks = 4.5
CombatStyles.BeetleSpitter.MinSecondsBetweenRangedAttacks = 9
CombatStyles.BeetleSpitter.ValidStates = {}
CombatStyles.BeetleSpitter.ValidStates[CombatSituations.Melee] = {
	"WaitForActionToFinish",
	"CheckForBetterTarget",
	"BeetleAdjustAltitude",
	"BeetleSpit",
	"PlayCombatSequence",
	"NonFormationKeepDistanceMovement",
	"FaceTarget"
}
CombatStyles.BeetleSpitter.SpitDamage = 5


-- Beetle Hugger OnlyHugs --
CombatStyles.BeetleHuggerOnlyHugs = DeepCopyTable(CombatStyles.BeetleHugger)
CombatStyles.BeetleHuggerOnlyHugs.Sequences = {}
CombatStyles.BeetleHuggerOnlyHugs.Sequences[CombatSituations.Melee] = {
	"IdleLong",
	"BeetleTakeOffAtFar",
	"BeetleLandWhenOutOfRange"
}


-- Beetle Hugger Nocturnal --
CombatStyles.BeetleHuggerNocturnal = {}
CombatStyles.BeetleHuggerNocturnal.CombatGroupType = CombatGroupTypes.BeetleLike
CombatStyles.BeetleHuggerNocturnal.NonFormation = true
CombatStyles.BeetleHuggerNocturnal.CanFightUnarmed = true
CombatStyles.BeetleHuggerNocturnal.Limits = {}
CombatStyles.BeetleHuggerNocturnal.Limits[CombatZones.Near] = 1.1
CombatStyles.BeetleHuggerNocturnal.Limits[CombatZones.Middle] = 1.75
CombatStyles.BeetleHuggerNocturnal.Limits[CombatZones.Far] = 8
CombatStyles.BeetleHuggerNocturnal.Limits[CombatZones.Left] = 1
CombatStyles.BeetleHuggerNocturnal.Limits[CombatZones.Right] = 1
CombatStyles.BeetleHuggerNocturnal.Limits[CombatZones.Rear] = 1
CombatStyles.BeetleHuggerNocturnal.Sequences = {}
CombatStyles.BeetleHuggerNocturnal.Sequences[CombatSituations.Melee] = {
	"IdleLong",
	"BeetleAttack",
	"BeetleCloseAttack",
	"BeetleTakeOffAtFar",
	"BeetleLandWhenOutOfRange"
}
CombatStyles.BeetleHuggerNocturnal.MinSecondsBetweenMeleeAttacks = 1.5
CombatStyles.BeetleHuggerNocturnal.MinSecondsBetweenRangedAttacks = 5
CombatStyles.BeetleHuggerNocturnal.ValidStates = {}
CombatStyles.BeetleHuggerNocturnal.ValidStates[CombatSituations.Melee] = {
	"WaitForActionToFinish",
	"CheckForBetterTarget",
	"BeetleAdjustAltitude",
	"BeetleExplode",
	"BeetleHug",
	"PlayCombatSequence",
	"MoveToFormationPos",
	"FaceTarget"
}
CombatStyles.BeetleHuggerNocturnal.HugBalancing = {}
CombatStyles.BeetleHuggerNocturnal.HugBalancing.DamagePerSecondWhileHugging = -15
CombatStyles.BeetleHuggerNocturnal.HugBalancing.TimeBetweenBeetleHugs = 3.5
CombatStyles.BeetleHuggerNocturnal.HugBalancing.TimeSpentHugging = 3.2
CombatStyles.BeetleHuggerNocturnal.HugBalancing.HugTimeReductionWhenButtonBashing = 2.2


-- Beetle Spitter Nocturnal --
CombatStyles.BeetleSpitterNocturnal = {}
CombatStyles.BeetleSpitterNocturnal.CombatGroupType = CombatGroupTypes.BeetleLike
CombatStyles.BeetleSpitterNocturnal.NonFormation = true
CombatStyles.BeetleSpitterNocturnal.TurnToFaceTolerance = 20
CombatStyles.BeetleSpitterNocturnal.CanFightUnarmed = true
CombatStyles.BeetleSpitterNocturnal.Limits = {}
CombatStyles.BeetleSpitterNocturnal.Limits[CombatZones.Near] = 1.5
CombatStyles.BeetleSpitterNocturnal.Limits[CombatZones.Middle] = 2
CombatStyles.BeetleSpitterNocturnal.Limits[CombatZones.Far] = 8
CombatStyles.BeetleSpitterNocturnal.Limits[CombatZones.Left] = 1
CombatStyles.BeetleSpitterNocturnal.Limits[CombatZones.Right] = 1
CombatStyles.BeetleSpitterNocturnal.Limits[CombatZones.Rear] = 1
CombatStyles.BeetleSpitterNocturnal.Sequences = {}
CombatStyles.BeetleSpitterNocturnal.Sequences[CombatSituations.Melee] = {
	"IdleLong",
	"BeetleAttack",
	"BeetleCloseAttack",
	"BeetleTakeOffOnlyWhenClose",
	"BeetleLandAtFar"
}
CombatStyles.BeetleSpitterNocturnal.MinSecondsBetweenMeleeAttacks = 3
CombatStyles.BeetleSpitterNocturnal.MinSecondsBetweenRangedAttacks = 7
CombatStyles.BeetleSpitterNocturnal.ValidStates = {}
CombatStyles.BeetleSpitterNocturnal.ValidStates[CombatSituations.Melee] = {
	"WaitForActionToFinish",
	"CheckForBetterTarget",
	"BeetleAdjustAltitude",
	"BeetleExplode",
	"BeetleSpit",
	"PlayCombatSequence",
	"NonFormationKeepDistanceMovement",
	"FaceTarget"
}
CombatStyles.BeetleSpitterNocturnal.SpitDamage = 20


-- Beetle Melee Super --
CombatStyles.BeetleMeleeSuper = {}
CombatStyles.BeetleMeleeSuper.CombatGroupType = CombatGroupTypes.BeetleLike
CombatStyles.BeetleMeleeSuper.NonFormation = true
CombatStyles.BeetleMeleeSuper.CanFightUnarmed = true
CombatStyles.BeetleMeleeSuper.Limits = {}
CombatStyles.BeetleMeleeSuper.Limits[CombatZones.Near] = 1.5
CombatStyles.BeetleMeleeSuper.Limits[CombatZones.Middle] = 2
CombatStyles.BeetleMeleeSuper.Limits[CombatZones.Far] = 5
CombatStyles.BeetleMeleeSuper.Limits[CombatZones.Left] = 1
CombatStyles.BeetleMeleeSuper.Limits[CombatZones.Right] = 1
CombatStyles.BeetleMeleeSuper.Limits[CombatZones.Rear] = 1
CombatStyles.BeetleMeleeSuper.Sequences = {}
CombatStyles.BeetleMeleeSuper.Sequences[CombatSituations.Melee] = {
	"IdleLong",
	{"SuperBeetleAssassinCharge", 5},
	"BeetleAttack",
	"BeetleCloseAttack",
	"BeetleTakeOffAtFar",
	"BeetleLandWhenOutOfRange"
}
CombatStyles.BeetleMeleeSuper.MinSecondsBetweenMeleeAttacks = 1.5
CombatStyles.BeetleMeleeSuper.ValidStates = {}
CombatStyles.BeetleMeleeSuper.ValidStates[CombatSituations.Melee] = {
	"WaitForActionToFinish",
	"CheckForBetterTarget",
	"BeetleAdjustAltitude",
	"PlayCombatSequence",
	"MoveToFormationPos",
	"FaceTarget"
}


-- Beetle Clockwork --
CombatStyles.ClockworkBeetle = {}
CombatStyles.ClockworkBeetle.CombatGroupType = CombatGroupTypes.BeetleLike
CombatStyles.ClockworkBeetle.NonFormation = true
CombatStyles.ClockworkBeetle.PreferredRange = 2.3
CombatStyles.ClockworkBeetle.CanFightUnarmed = true
CombatStyles.ClockworkBeetle.Limits = {}
CombatStyles.ClockworkBeetle.Limits[CombatZones.Near] = 1.8
CombatStyles.ClockworkBeetle.Limits[CombatZones.Middle] = 2.7
CombatStyles.ClockworkBeetle.Limits[CombatZones.Far] = 16
CombatStyles.ClockworkBeetle.Limits[CombatZones.Left] = 1
CombatStyles.ClockworkBeetle.Limits[CombatZones.Right] = 1
CombatStyles.ClockworkBeetle.Limits[CombatZones.Rear] = 1
CombatStyles.ClockworkBeetle.Sequences = {}
CombatStyles.ClockworkBeetle.Sequences[CombatSituations.Melee] = {
	"ClockworkBeetleAssassinCharge",
	"BeetleAttack",
	"BeetleCloseAttack",
	"BeetleTakeOffAtFar"
}
CombatStyles.ClockworkBeetle.MinSecondsBetweenMeleeAttacks = 0.5
CombatStyles.ClockworkBeetle.ValidStates = {}
CombatStyles.ClockworkBeetle.ValidStates[CombatSituations.Melee] = {
	"WaitForActionToFinish",
	"CheckForBetterTarget",
	"BeetleAdjustAltitude",
	"PlayCombatSequence",
	"MoveToFormationPos",
	"FaceTarget"
}


-- Bandit Leader Thag --
CombatStyles.BanditLeaderThag = {}
CombatStyles.BanditLeaderThag.CombatGroupType = CombatGroupTypes.BanditLike
CombatStyles.BanditLeaderThag.CanStrafe = true
CombatStyles.BanditLeaderThag.DesiredRange = 4
CombatStyles.BanditLeaderThag.MovementTolerance = 0.45
CombatStyles.BanditLeaderThag.StrafeActionSpeed = 1
CombatStyles.BanditLeaderThag.PreferOuterRing = true
CombatStyles.BanditLeaderThag.IsLeaderType = true
CombatStyles.BanditLeaderThag.EnterRangedStrafeDist = 10
CombatStyles.BanditLeaderThag.CanSheatheWeapon = true
CombatStyles.BanditLeaderThag.Limits = {}
CombatStyles.BanditLeaderThag.Limits[CombatZones.Near] = 1.5
CombatStyles.BanditLeaderThag.Limits[CombatZones.Middle] = 2.5
CombatStyles.BanditLeaderThag.Limits[CombatZones.Far] = 5
CombatStyles.BanditLeaderThag.Limits[CombatZones.Left] = 2
CombatStyles.BanditLeaderThag.Limits[CombatZones.Right] = 2
CombatStyles.BanditLeaderThag.Limits[CombatZones.Rear] = 3
CombatStyles.BanditLeaderThag.CanFlee = false
CombatStyles.BanditLeaderThag.FleeAnim = "Flee"
CombatStyles.BanditLeaderThag.FleeIntoAnim = "FleeInto"
CombatStyles.BanditLeaderThag.FleeOutOfAnim = "FleeOutOf"
CombatStyles.BanditLeaderThag.CombatStyleWhenDisarmed = "BasicUnarmed"
CombatStyles.BanditLeaderThag.LaughAtKnockdown = {}
CombatStyles.BanditLeaderThag.LaughAtKnockdown.Anim = "ReactLaugh"
CombatStyles.BanditLeaderThag.LaughAtKnockdown.MinSecondsBetween = 8
CombatStyles.BanditLeaderThag.LaughAtKnockdown.OnlyIfIKnockedTargetDown = false
CombatStyles.BanditLeaderThag.Sequences = {}
CombatStyles.BanditLeaderThag.Sequences[CombatSituations.Melee] = {
	"BanditLeaderInteruptSpellMelee",
	"BanditLeaderShotCausedFlourish",
	"BanditLeaderOrbSuckingResponse",
	"BanditGoad",
	"BanditOuterGoad",
	"Idle",
	"BanditLeaderAttackCombo",
	{"BanditLeaderFlourishLeft", 10},
	"BanditLeaderCloseAttackCombo",
	"BanditLeftAttack",
	"BanditRightAttack",
	"BanditRearAttack"
}
CombatStyles.BanditLeaderThag.Sequences[CombatSituations.Ranged] = {
	"BanditLeaderInteruptSpellRanged",
	"BanditOuterGoad",
	"RangedIdle"
}
CombatStyles.BanditLeaderThag.Sequences[CombatSituations.HardBlocking] = {
	"BanditLeaderAttackOutOfBlock",
	"BanditLeaderAttackOutOfBlockShort"
}
CombatStyles.BanditLeaderThag.Sequences[CombatSituations.GroupOrders] = {
	"BanditGroupRifleShooting",
	"BanditGroupMeleeAttack",
	"BanditGoad",
	"BanditOuterGoad"
}
CombatStyles.BanditLeaderThag.FastWeaponChanges = {
	"SheatheOneHandedWeaponThenUnsheatheRifle",
	"SheatheRifleThenUnsheatheOneHandedWeapon"
}
CombatStyles.BanditLeaderThag.MinSecondsBetweenMeleeAttacks = 2
CombatStyles.BanditLeaderThag.SecondsToWaitAfterTargetIsHit = 2
CombatStyles.BanditLeaderThag.MinSecondsBetweenRangedAttacks = 5
CombatStyles.BanditLeaderThag.LaughAtKnockdown = {}
CombatStyles.BanditLeaderThag.LaughAtKnockdown.Anim = "ReactLaugh"
CombatStyles.BanditLeaderThag.LaughAtKnockdown.MinSecondsBetween = 8
CombatStyles.BanditLeaderThag.LaughAtKnockdown.OnlyIfIKnockedTargetDown = false
CombatStyles.BanditLeaderThag.CanBlock = true
CombatStyles.BanditLeaderThag.BlockData = {}
CombatStyles.BanditLeaderThag.BlockData.PrimaryBlockType = EBlockType.BLOCK_TYPE_PUSHED_BACK
CombatStyles.BanditLeaderThag.BlockData.SecondsForSuccessiveHitsToPrimaryBlock = 6
CombatStyles.BanditLeaderThag.BlockData.NumberOfHitsToForcePrimaryBlock = 3
CombatStyles.BanditLeaderThag.BlockData.PrimaryBlockType = EBlockType.BLOCK_TYPE_STATIC
CombatStyles.BanditLeaderThag.BlockData.SecondsForSuccessiveHitsToSecondaryBlock = 8
CombatStyles.BanditLeaderThag.BlockData.NumberOfHitsToForceSecondaryBlock = 2
CombatStyles.BanditLeaderThag.BlockData.SecondsToBlockFor = 3
CombatStyles.BanditLeaderThag.CanEvadeShots = true
CombatStyles.BanditLeaderThag.EvadeShotsData = {}
CombatStyles.BanditLeaderThag.EvadeShotsData.TimeToCheckFor = 7
CombatStyles.BanditLeaderThag.EvadeShotsData.TimeToEvadeFor = 3
CombatStyles.BanditLeaderThag.EvadeShotsData.HitsToStartEvading = 4
CombatStyles.BanditLeaderThag.EvadeAnimations = {
	"DodgeLeft",
    "DodgeRight"
}
CombatStyles.BanditLeaderThag.OuterRingPercentAsRanged = 0.5
CombatStyles.BanditLeaderThag.ValidStates = {}
CombatStyles.BanditLeaderThag.ValidStates[CombatSituations.Melee] = {
	"AntiSpamCheck",
	"PlayBanterCombatComment",
	"WaitForActionToFinish",
	"UpdateWeapon",
	"CheckForBetterTarget",
	"RetreatFromFlourish",
	"OuterRingKeepDistance",
	"OuterRingSpreadOut",
	"PlayCombatSequence",
	"MoveToFormationPos",
	"FaceTarget"
}
CombatStyles.BanditLeaderThag.ValidStates[CombatSituations.Ranged] = {
	"AntiSpamCheck",
	"PlayBanterCombatComment",
	"WaitForActionToFinish",
	"UpdateWeapon",
	"CheckForBetterTarget",
	"RetreatFromFlourish",
	"GetTargetInSights",
	"FireRangedWeapon",
	"OuterRingKeepDistance",
	"OuterRingSpreadOut",
	"PlayCombatSequence",
	"MoveToFormationPos",
	"FaceTarget",
	"IdleWithRangedWeapon"
}
CombatStyles.BanditLeaderThag.ValidStates[CombatSituations.HardBlocking] = CombatStyles.StandardBlockingCombatStates
CombatStyles.BanditLeaderThag.ValidStates[CombatSituations.SoftBlocking] = CombatStyles.StandardBlockingCombatStates
CombatStyles.BanditLeaderThag.ValidStates[CombatSituations.Dodging] = CombatStyles.StandardBlockingCombatStates
CombatStyles.BanditLeaderThag.ValidStates[CombatSituations.GroupOrders] = CombatStyles.StandardGroupOrderStates
CombatStyles.BanditLeaderThag.ShootingBalanceData = {}
CombatStyles.BanditLeaderThag.ShootingBalanceData.StartingChanceToHitWithFirearm = 0
CombatStyles.BanditLeaderThag.ShootingBalanceData.MaxChanceToHitWithFirearmCap = 0.6
CombatStyles.BanditLeaderThag.ShootingBalanceData.ChanceToHitModBonusRangeDistance = 9
CombatStyles.BanditLeaderThag.ShootingBalanceData.ChanceToHitModSegmentLength = 3
CombatStyles.BanditLeaderThag.ShootingBalanceData.ChanceToHitModPercentageIncrease = 0.05
CombatStyles.BanditLeaderThag.ShootingBalanceData.ChanceToHitModConsecutiveShotPercentageIncrease = 0.8
CombatStyles.BanditLeaderThag.ShootingBalanceData.ChanceToHitModConsecutiveShotsTimeFrame = 25
CombatStyles.BanditLeaderThag.ShootingBalanceData.ChanceToHitModPercentageDecreasePerOneSpeed = 0.9
CombatStyles.BanditLeaderThag.ShootingBalanceData.ChanceToHitModTargetInCoverPercentageMultiplier = 0.9
CombatStyles.BanditLeaderThag.ShootingBalanceData.ChanceToHitModOffScreenPercentageMultiplier = 0.05


-- Bandit Leader Ripper --
CombatStyles.BanditLeaderRipper = {}
CombatStyles.BanditLeaderRipper.CombatGroupType = CombatGroupTypes.BanditLike
CombatStyles.BanditLeaderRipper.CanStrafe = true
CombatStyles.BanditLeaderRipper.DesiredRange = 4
CombatStyles.BanditLeaderRipper.MovementTolerance = 0.45
CombatStyles.BanditLeaderRipper.StrafeActionSpeed = 1
CombatStyles.BanditLeaderRipper.PreferOuterRing = true
CombatStyles.BanditLeaderRipper.IsLeaderType = true
CombatStyles.BanditLeaderRipper.CanSheatheWeapon = true
CombatStyles.BanditLeaderRipper.EnterRangedStrafeDist = 10
CombatStyles.BanditLeaderRipper.Limits = {}
CombatStyles.BanditLeaderRipper.Limits[CombatZones.Near] = 1.5
CombatStyles.BanditLeaderRipper.Limits[CombatZones.Middle] = 2.5
CombatStyles.BanditLeaderRipper.Limits[CombatZones.Far] = 5.5
CombatStyles.BanditLeaderRipper.Limits[CombatZones.Left] = 2
CombatStyles.BanditLeaderRipper.Limits[CombatZones.Right] = 2
CombatStyles.BanditLeaderRipper.Limits[CombatZones.Rear] = 3
CombatStyles.BanditLeaderRipper.CanFlee = false
CombatStyles.BanditLeaderRipper.FleeAnim = "Flee"
CombatStyles.BanditLeaderRipper.FleeIntoAnim = "FleeInto"
CombatStyles.BanditLeaderRipper.FleeOutOfAnim = "FleeOutOf"
CombatStyles.BanditLeaderRipper.CombatStyleWhenDisarmed = "BasicUnarmed"
CombatStyles.BanditLeaderRipper.Sequences = {}
CombatStyles.BanditLeaderRipper.Sequences[CombatSituations.Melee] = {
	"BanditLeaderInteruptSpellMelee",
	"BanditLeaderHeroFlourishResponse",
	"BanditLeaderRipperGettingShotResponse",
	"BanditLeaderRipperOrbSuckingResponse",
	"BanditOuterGoad",
	{"RipperAssassinCharge", 20},
	"BanditLeaderRipperAttackCombo",
	"BanditLeaderRipperFlourishLeft",
	"BanditLeaderRipperCloseAttackCombo",
	"Idle",
	"BanditLeftAttack",
	"BanditRightAttack",
	"BanditRearAttack",
}
CombatStyles.BanditLeaderRipper.Sequences[CombatSituations.Ranged] = {
	"BanditLeaderInteruptSpellRanged",
	"BanditOuterGoad",
	"RangedIdle"
}
CombatStyles.BanditLeaderRipper.Sequences[CombatSituations.Dodging] = {
	"BanditLeaderRipperAttackOutOfBlockShort",
	"BanditLeaderRipperAttackOutOfBlock"
}
CombatStyles.BanditLeaderRipper.Sequences[CombatSituations.GroupOrders] = {
	"BanditGroupRifleShooting",
	"BanditGroupMeleeAttack",
	"BanditGoad",
	"BanditOuterGoad"
}
CombatStyles.BanditLeaderRipper.FastWeaponChanges = {
	"SheatheOneHandedWeaponThenUnsheatheRifle",
	"SheatheRifleThenUnsheatheOneHandedWeapon"
}
CombatStyles.BanditLeaderRipper.MinSecondsBetweenMeleeAttacks = 0
CombatStyles.BanditLeaderRipper.SecondsToWaitAfterTargetIsHit = 0
CombatStyles.BanditLeaderRipper.MinSecondsBetweenRangedAttacks = 5
CombatStyles.BanditLeaderRipper.CanStandOffAndShoot = "Aggressive"
CombatStyles.BanditLeaderRipper.CanBlock = true
CombatStyles.BanditLeaderRipper.BlockData = {}
CombatStyles.BanditLeaderRipper.BlockData.PrimaryBlockType = EBlockType.BLOCK_TYPE_PUSHED_BACK
CombatStyles.BanditLeaderRipper.BlockData.SecondsForSuccessiveHitsToPrimaryBlock = 6
CombatStyles.BanditLeaderRipper.BlockData.NumberOfHitsToForcePrimaryBlock = 2
CombatStyles.BanditLeaderRipper.BlockData.PrimaryBlockType = EBlockType.BLOCK_TYPE_DODGE_MELEE
CombatStyles.BanditLeaderRipper.BlockData.SecondsForSuccessiveHitsToSecondaryBlock = 8
CombatStyles.BanditLeaderRipper.BlockData.NumberOfHitsToForceSecondaryBlock = 2
CombatStyles.BanditLeaderRipper.BlockData.SecondsToBlockFor = 5
CombatStyles.BanditLeaderRipper.DodgeAnimations = {
	"DodgeLeft",
    "DodgeRight"
}
CombatStyles.BanditLeaderRipper.CanEvadeShots = true
CombatStyles.BanditLeaderRipper.EvadeShotsData = {}
CombatStyles.BanditLeaderRipper.EvadeShotsData.TimeToCheckFor = 7
CombatStyles.BanditLeaderRipper.EvadeShotsData.TimeToEvadeFor = 4
CombatStyles.BanditLeaderRipper.EvadeShotsData.HitsToStartEvading = 2
CombatStyles.BanditLeaderRipper.EvadeAnimations = {
	"DodgeLeft",
    "DodgeRight"
}
CombatStyles.BanditLeaderRipper.AntiSpamData = {}
CombatStyles.BanditLeaderRipper.AntiSpamData.TimeToCheckFor = 5
CombatStyles.BanditLeaderRipper.AntiSpamData.ShotsToTrigger = 3
CombatStyles.BanditLeaderRipper.AntiSpamData.SpellsToTrigger = 2
CombatStyles.BanditLeaderRipper.AntiSpamData.TimeToAggroFor = 15
CombatStyles.BanditLeaderRipper.OuterRingPercentAsRanged = 0.5
CombatStyles.BanditLeaderRipper.ValidStates = {}
CombatStyles.BanditLeaderRipper.ValidStates[CombatSituations.Melee] = {
	"AntiSpamCheck",
	"PlayBanterCombatComment",
	"WaitForActionToFinish",
	"UpdateWeapon",
	"CheckForBetterTarget",
	"OuterRingKeepDistance",
	"OuterRingSpreadOut",
	"PlayCombatSequence",
	"MoveToFormationPos",
	"FaceTarget"
}
CombatStyles.BanditLeaderRipper.ValidStates[CombatSituations.Ranged] = {
	"AntiSpamCheck",
	"PlayBanterCombatComment",
	"WaitForActionToFinish",
	"UpdateWeapon",
	"CheckForBetterTarget",
	"GetTargetInSights",
	"FireRangedWeapon",
	"OuterRingKeepDistance",
	"OuterRingSpreadOut",
	"PlayCombatSequence",
	"MoveToFormationPos",
	"FaceTarget",
	"IdleWithRangedWeapon"
}
CombatStyles.BanditLeaderRipper.ValidStates[CombatSituations.HardBlocking] = CombatStyles.StandardBlockingCombatStates
CombatStyles.BanditLeaderRipper.ValidStates[CombatSituations.SoftBlocking] = CombatStyles.StandardBlockingCombatStates
CombatStyles.BanditLeaderRipper.ValidStates[CombatSituations.Dodging] = CombatStyles.StandardBlockingCombatStates
CombatStyles.BanditLeaderRipper.ValidStates[CombatSituations.GroupOrders] = CombatStyles.StandardGroupOrderStates
CombatStyles.BanditLeaderRipper.ShootingBalanceData = {}
CombatStyles.BanditLeaderRipper.ShootingBalanceData.StartingChanceToHitWithFirearm = 0
CombatStyles.BanditLeaderRipper.ShootingBalanceData.MaxChanceToHitWithFirearmCap = 0.7
CombatStyles.BanditLeaderRipper.ShootingBalanceData.ChanceToHitModBonusRangeDistance = 9
CombatStyles.BanditLeaderRipper.ShootingBalanceData.ChanceToHitModSegmentLength = 3
CombatStyles.BanditLeaderRipper.ShootingBalanceData.ChanceToHitModPercentageIncrease = 0.05
CombatStyles.BanditLeaderRipper.ShootingBalanceData.ChanceToHitModConsecutiveShotPercentageIncrease = 0.1
CombatStyles.BanditLeaderRipper.ShootingBalanceData.ChanceToHitModConsecutiveShotsTimeFrame = 35
CombatStyles.BanditLeaderRipper.ShootingBalanceData.ChanceToHitModPercentageDecreasePerOneSpeed = 0.6
CombatStyles.BanditLeaderRipper.ShootingBalanceData.ChanceToHitModTargetInCoverPercentageMultiplier = 0.7
CombatStyles.BanditLeaderRipper.ShootingBalanceData.ChanceToHitModOffScreenPercentageMultiplier = 0.05
CombatStyles.BanditLeaderRipper.SecondsBetweenGroupActions = 30
CombatStyles.BanditLeaderRipper.PercentChanceThatGroupActionIsShoot = 25


-- CaptainDread QO170 --
CombatStyles.CaptainDreadQO170 = {}
CombatStyles.CaptainDreadQO170.CombatGroupType = CombatGroupTypes.BanditLike
CombatStyles.CaptainDreadQO170.CanStrafe = true
CombatStyles.CaptainDreadQO170.DesiredRange = 4
CombatStyles.CaptainDreadQO170.MovementTolerance = 0.45
CombatStyles.CaptainDreadQO170.StrafeActionSpeed = 1
CombatStyles.CaptainDreadQO170.PreferOuterRing = true
CombatStyles.CaptainDreadQO170.IsLeaderType = true
CombatStyles.CaptainDreadQO170.CanSheatheWeapon = true
CombatStyles.CaptainDreadQO170.EnterRangedStrafeDist = 10
CombatStyles.CaptainDreadQO170.Limits = {}
CombatStyles.CaptainDreadQO170.Limits[CombatZones.Near] = 1.5
CombatStyles.CaptainDreadQO170.Limits[CombatZones.Middle] = 2.5
CombatStyles.CaptainDreadQO170.Limits[CombatZones.Far] = 5.5
CombatStyles.CaptainDreadQO170.Limits[CombatZones.Left] = 2
CombatStyles.CaptainDreadQO170.Limits[CombatZones.Right] = 2
CombatStyles.CaptainDreadQO170.Limits[CombatZones.Rear] = 3
CombatStyles.CaptainDreadQO170.CanFlee = false
CombatStyles.CaptainDreadQO170.FleeAnim = "Flee"
CombatStyles.CaptainDreadQO170.FleeIntoAnim = "FleeInto"
CombatStyles.CaptainDreadQO170.FleeOutOfAnim = "FleeOutOf"
CombatStyles.CaptainDreadQO170.CombatStyleWhenDisarmed = "BasicUnarmed"
CombatStyles.CaptainDreadQO170.Sequences = {}
CombatStyles.CaptainDreadQO170.Sequences[CombatSituations.Melee] = {
	"BanditLeaderInteruptSpellMelee",
	"BanditLeaderHeroFlourishResponse",
	"CaptainDreadGettingShotResponse",
	"CaptainDreadOrbSuckingResponse",
	{"CaptainDreadVortex", 20},
	"BanditOuterGoad",
	"Idle",
	"CaptainDreadAttackCombo",
	"CaptainDreadFlourishLeft",
	"CaptainDreadCloseAttackCombo",
	"BanditLeftAttack",
	"BanditRightAttack",
	"BanditRearAttack"
}
CombatStyles.CaptainDreadQO170.Sequences[CombatSituations.Ranged] = {
	"CaptainDreadInteruptSpellRanged",
	"BanditOuterGoad",
	"RangedIdle"
}
CombatStyles.CaptainDreadQO170.Sequences[CombatSituations.Dodging] = {
	"CaptainDreadAttackOutOfBlockShort",
	"CaptainDreadAttackOutOfBlock"
}
CombatStyles.CaptainDreadQO170.Sequences[CombatSituations.GroupOrders] = {
	"BanditGroupRifleShooting",
	"BanditGroupMeleeAttack",
	"BanditGoad",
	"BanditOuterGoad"
}
CombatStyles.CaptainDreadQO170.FastWeaponChanges = {
	"SheatheOneHandedWeaponThenUnsheatheRifle",
	"SheatheRifleThenUnsheatheOneHandedWeapon"
}
CombatStyles.CaptainDreadQO170.MinSecondsBetweenMeleeAttacks = 0
CombatStyles.CaptainDreadQO170.SecondsToWaitAfterTargetIsHit = 0
CombatStyles.CaptainDreadQO170.MinSecondsBetweenRangedAttacks = 5
CombatStyles.CaptainDreadQO170.CanStandOffAndShoot = "Aggressive"
CombatStyles.CaptainDreadQO170.CanBlock = true
CombatStyles.CaptainDreadQO170.BlockData = {}
CombatStyles.CaptainDreadQO170.BlockData.PrimaryBlockType = EBlockType.BLOCK_TYPE_STATIC
CombatStyles.CaptainDreadQO170.BlockData.SecondsForSuccessiveHitsToPrimaryBlock = 6
CombatStyles.CaptainDreadQO170.BlockData.NumberOfHitsToForcePrimaryBlock = 2
CombatStyles.CaptainDreadQO170.BlockData.PrimaryBlockType = EBlockType.BLOCK_TYPE_DODGE_MELEE
CombatStyles.CaptainDreadQO170.BlockData.SecondsForSuccessiveHitsToSecondaryBlock = 8
CombatStyles.CaptainDreadQO170.BlockData.NumberOfHitsToForceSecondaryBlock = 2
CombatStyles.CaptainDreadQO170.BlockData.SecondsToBlockFor = 5
CombatStyles.CaptainDreadQO170.DodgeAnimations = {
	"DodgeLeft",
    "DodgeRight"
}
CombatStyles.CaptainDreadQO170.CanEvadeShots = true
CombatStyles.CaptainDreadQO170.EvadeShotsData = {}
CombatStyles.CaptainDreadQO170.EvadeShotsData.TimeToCheckFor = 7
CombatStyles.CaptainDreadQO170.EvadeShotsData.TimeToEvadeFor = 4
CombatStyles.CaptainDreadQO170.EvadeShotsData.HitsToStartEvading = 2
CombatStyles.CaptainDreadQO170.EvadeAnimations = {
	"DodgeLeft",
    "DodgeRight"
}
CombatStyles.CaptainDreadQO170.AntiSpamData = {}
CombatStyles.CaptainDreadQO170.AntiSpamData.TimeToCheckFor = 5
CombatStyles.CaptainDreadQO170.AntiSpamData.ShotsToTrigger = 2
CombatStyles.CaptainDreadQO170.AntiSpamData.SpellsToTrigger = 2
CombatStyles.CaptainDreadQO170.AntiSpamData.TimeToAggroFor = 15
CombatStyles.CaptainDreadQO170.OuterRingPercentAsRanged = 0.5
CombatStyles.CaptainDreadQO170.ValidStates = {}
CombatStyles.CaptainDreadQO170.ValidStates[CombatSituations.Melee] = {
	"AntiSpamCheck",
	"PlayBanterCombatComment",
	"WaitForActionToFinish",
	"UpdateWeapon",
	"CheckForBetterTarget",
	"OuterRingKeepDistance",
	"OuterRingSpreadOut",
	"PlayCombatSequence",
	"MoveToFormationPos",
	"FaceTarget"
}
CombatStyles.CaptainDreadQO170.ValidStates[CombatSituations.Ranged] = {
	"AntiSpamCheck",
	"PlayBanterCombatComment",
	"WaitForActionToFinish",
	"UpdateWeapon",
	"CheckForBetterTarget",
	"GetTargetInSights",
	"FireRangedWeapon",
	"OuterRingKeepDistance",
	"OuterRingSpreadOut",
	"PlayCombatSequence",
	"MoveToFormationPos",
	"FaceTarget",
	"IdleWithRangedWeapon"
}
CombatStyles.CaptainDreadQO170.ValidStates[CombatSituations.HardBlocking] = CombatStyles.StandardBlockingCombatStates
CombatStyles.CaptainDreadQO170.ValidStates[CombatSituations.SoftBlocking] = CombatStyles.StandardBlockingCombatStates
CombatStyles.CaptainDreadQO170.ValidStates[CombatSituations.Dodging] = CombatStyles.StandardBlockingCombatStates
CombatStyles.CaptainDreadQO170.ValidStates[CombatSituations.GroupOrders] = CombatStyles.StandardGroupOrderStates
CombatStyles.CaptainDreadQO170.ShootingBalanceData = {}
CombatStyles.CaptainDreadQO170.ShootingBalanceData.StartingChanceToHitWithFirearm = 0
CombatStyles.CaptainDreadQO170.ShootingBalanceData.MaxChanceToHitWithFirearmCap = 0.7
CombatStyles.CaptainDreadQO170.ShootingBalanceData.ChanceToHitModBonusRangeDistance = 9
CombatStyles.CaptainDreadQO170.ShootingBalanceData.ChanceToHitModSegmentLength = 3
CombatStyles.CaptainDreadQO170.ShootingBalanceData.ChanceToHitModPercentageIncrease = 0.05
CombatStyles.CaptainDreadQO170.ShootingBalanceData.ChanceToHitModConsecutiveShotPercentageIncrease = 0.1
CombatStyles.CaptainDreadQO170.ShootingBalanceData.ChanceToHitModConsecutiveShotsTimeFrame = 35
CombatStyles.CaptainDreadQO170.ShootingBalanceData.ChanceToHitModPercentageDecreasePerOneSpeed = 0.6
CombatStyles.CaptainDreadQO170.ShootingBalanceData.ChanceToHitModTargetInCoverPercentageMultiplier = 0.7
CombatStyles.CaptainDreadQO170.ShootingBalanceData.ChanceToHitModOffScreenPercentageMultiplier = 0.05
CombatStyles.CaptainDreadQO170.SecondsBetweenGroupActions = 30
CombatStyles.CaptainDreadQO170.PercentChanceThatGroupActionIsShoot = 25


-- Bandit Leader Fairfax QO800 --
CombatStyles.BanditLeaderFairfaxQO800 = {}
CombatStyles.BanditLeaderFairfaxQO800.CombatGroupType = CombatGroupTypes.BanditLike
CombatStyles.BanditLeaderFairfaxQO800.CanStrafe = true
CombatStyles.BanditLeaderFairfaxQO800.DesiredRange = 4
CombatStyles.BanditLeaderFairfaxQO800.MovementTolerance = 0.45
CombatStyles.BanditLeaderFairfaxQO800.StrafeActionSpeed = 1
CombatStyles.BanditLeaderFairfaxQO800.PreferOuterRing = true
CombatStyles.BanditLeaderFairfaxQO800.IsLeaderType = true
CombatStyles.BanditLeaderFairfaxQO800.CanSheatheWeapon = true
CombatStyles.BanditLeaderFairfaxQO800.EnterRangedStrafeDist = 10
CombatStyles.BanditLeaderFairfaxQO800.CombatStyleWhenDisarmed = "BasicUnarmed"
CombatStyles.BanditLeaderFairfaxQO800.Limits = {}
CombatStyles.BanditLeaderFairfaxQO800.Limits[CombatZones.Near] = 1.5
CombatStyles.BanditLeaderFairfaxQO800.Limits[CombatZones.Middle] = 2.5
CombatStyles.BanditLeaderFairfaxQO800.Limits[CombatZones.Far] = 5.5
CombatStyles.BanditLeaderFairfaxQO800.Limits[CombatZones.Left] = 2
CombatStyles.BanditLeaderFairfaxQO800.Limits[CombatZones.Right] = 2
CombatStyles.BanditLeaderFairfaxQO800.Limits[CombatZones.Rear] = 3
CombatStyles.BanditLeaderFairfaxQO800.Sequences = {}
CombatStyles.BanditLeaderFairfaxQO800.Sequences[CombatSituations.Melee] = {
	"BanditLeaderInteruptSpellMelee",
	"BanditLeaderHeroFlourishResponse",
	"BanditLeaderFairfaxGettingShotResponse",
	"BanditLeaderFairfaxOrbSuckingResponse",
	"BanditLeaderFairfaxAttackCombo",
	"BanditLeaderFairfaxFlourishLeft",
	"BanditLeaderFairfaxCloseAttackCombo",
	"Idle",
	"BanditLeftAttack",
	"BanditRightAttack",
	"BanditRearAttack"
}
CombatStyles.BanditLeaderFairfaxQO800.Sequences[CombatSituations.Ranged] = {
	"BanditLeaderInteruptSpellRanged",
	"RangedIdle"
}
CombatStyles.BanditLeaderFairfaxQO800.Sequences[CombatSituations.Dodging] = {
	"BanditLeaderFairfaxAssassinChargeCounter",
	"BanditLeaderFairfaxAttackOutOfBlockShort",
	"BanditLeaderFairfaxAttackOutOfBlock"
}
CombatStyles.BanditLeaderFairfaxQO800.Sequences[CombatSituations.GroupOrders] = {
	"BanditGroupRifleShooting",
	"BanditGroupMeleeAttack",
	"BanditGoad",
	"BanditOuterGoad"
}
CombatStyles.BanditLeaderFairfaxQO800.FastWeaponChanges = {
	"SheatheOneHandedWeaponThenUnsheatheRifle",
	"SheatheRifleThenUnsheatheOneHandedWeapon"
}
CombatStyles.BanditLeaderFairfaxQO800.MinSecondsBetweenMeleeAttacks = 0
CombatStyles.BanditLeaderFairfaxQO800.SecondsToWaitAfterTargetIsHit = 0
CombatStyles.BanditLeaderFairfaxQO800.MinSecondsBetweenRangedAttacks = 3
CombatStyles.BanditLeaderFairfaxQO800.CanStandOffAndShoot = "Aggressive"
CombatStyles.BanditLeaderFairfaxQO800.CanBlock = true
CombatStyles.BanditLeaderFairfaxQO800.BlockData = {}
CombatStyles.BanditLeaderFairfaxQO800.BlockData.PrimaryBlockType = EBlockType.BLOCK_TYPE_STATIC
CombatStyles.BanditLeaderFairfaxQO800.BlockData.SecondsForSuccessiveHitsToPrimaryBlock = 6
CombatStyles.BanditLeaderFairfaxQO800.BlockData.NumberOfHitsToForcePrimaryBlock = 1
CombatStyles.BanditLeaderFairfaxQO800.BlockData.PrimaryBlockType = EBlockType.BLOCK_TYPE_DODGE_MELEE
CombatStyles.BanditLeaderFairfaxQO800.BlockData.SecondsForSuccessiveHitsToSecondaryBlock = 8
CombatStyles.BanditLeaderFairfaxQO800.BlockData.NumberOfHitsToForceSecondaryBlock = 1
CombatStyles.BanditLeaderFairfaxQO800.BlockData.SecondsToBlockFor = 6
CombatStyles.BanditLeaderFairfaxQO800.DodgeAnimations = {
	"DodgeLeft",
    "DodgeRight"
}
CombatStyles.BanditLeaderFairfaxQO800.CanEvadeShots = true
CombatStyles.BanditLeaderFairfaxQO800.EvadeShotsData = {}
CombatStyles.BanditLeaderFairfaxQO800.EvadeShotsData.TimeToCheckFor = 8
CombatStyles.BanditLeaderFairfaxQO800.EvadeShotsData.TimeToEvadeFor = 4
CombatStyles.BanditLeaderFairfaxQO800.EvadeShotsData.HitsToStartEvading = 1
CombatStyles.BanditLeaderFairfaxQO800.EvadeAnimations = {
	"DodgeLeft",
    "DodgeRight"
}
CombatStyles.BanditLeaderFairfaxQO800.AntiSpamData = {}
CombatStyles.BanditLeaderFairfaxQO800.AntiSpamData.TimeToCheckFor = 5
CombatStyles.BanditLeaderFairfaxQO800.AntiSpamData.ShotsToTrigger = 3
CombatStyles.BanditLeaderFairfaxQO800.AntiSpamData.SpellsToTrigger = 2
CombatStyles.BanditLeaderFairfaxQO800.AntiSpamData.TimeToAggroFor = 15
CombatStyles.BanditLeaderFairfaxQO800.OuterRingPercentAsRanged = 0.5
CombatStyles.BanditLeaderFairfaxQO800.ValidStates = {}
CombatStyles.BanditLeaderFairfaxQO800.ValidStates[CombatSituations.Melee] = {
	"AntiSpamCheck",
	"PlayBanterCombatComment",
	"WaitForActionToFinish",
	"UpdateWeapon",
	"CheckForBetterTarget",
	"OuterRingKeepDistance",
	"OuterRingSpreadOut",
	"PlayCombatSequence",
	"MoveToFormationPos",
	"FaceTarget"
}
CombatStyles.BanditLeaderFairfaxQO800.ValidStates[CombatSituations.Ranged] = {
	"AntiSpamCheck",
	"PlayBanterCombatComment",
	"WaitForActionToFinish",
	"UpdateWeapon",
	"CheckForBetterTarget",
	"GetTargetInSights",
	"FireRangedWeapon",
	"OuterRingKeepDistance",
	"OuterRingSpreadOut",
	"PlayCombatSequence",
	"MoveToFormationPos",
	"FaceTarget",
	"IdleWithRangedWeapon"
}
CombatStyles.BanditLeaderFairfaxQO800.ValidStates[CombatSituations.HardBlocking] = CombatStyles.StandardBlockingCombatStates
CombatStyles.BanditLeaderFairfaxQO800.ValidStates[CombatSituations.SoftBlocking] = CombatStyles.StandardBlockingCombatStates
CombatStyles.BanditLeaderFairfaxQO800.ValidStates[CombatSituations.Dodging] = CombatStyles.StandardBlockingCombatStates
CombatStyles.BanditLeaderFairfaxQO800.ValidStates[CombatSituations.GroupOrders] = CombatStyles.StandardGroupOrderStates
CombatStyles.BanditLeaderFairfaxQO800.ShootingBalanceData = {}
CombatStyles.BanditLeaderFairfaxQO800.ShootingBalanceData.StartingChanceToHitWithFirearm = 0
CombatStyles.BanditLeaderFairfaxQO800.ShootingBalanceData.MaxChanceToHitWithFirearmCap = 0.7
CombatStyles.BanditLeaderFairfaxQO800.ShootingBalanceData.ChanceToHitModBonusRangeDistance = 9
CombatStyles.BanditLeaderFairfaxQO800.ShootingBalanceData.ChanceToHitModSegmentLength = 3
CombatStyles.BanditLeaderFairfaxQO800.ShootingBalanceData.ChanceToHitModPercentageIncrease = 0.05
CombatStyles.BanditLeaderFairfaxQO800.ShootingBalanceData.ChanceToHitModConsecutiveShotPercentageIncrease = 0.1
CombatStyles.BanditLeaderFairfaxQO800.ShootingBalanceData.ChanceToHitModConsecutiveShotsTimeFrame = 35
CombatStyles.BanditLeaderFairfaxQO800.ShootingBalanceData.ChanceToHitModPercentageDecreasePerOneSpeed = 0.6
CombatStyles.BanditLeaderFairfaxQO800.ShootingBalanceData.ChanceToHitModTargetInCoverPercentageMultiplier = 0.7
CombatStyles.BanditLeaderFairfaxQO800.ShootingBalanceData.ChanceToHitModOffScreenPercentageMultiplier = 0.05
CombatStyles.BanditLeaderFairfaxQO800.SecondsBetweenGroupActions = 10
CombatStyles.BanditLeaderFairfaxQO800.PercentChanceThatGroupActionIsShoot = 25


-- LuciensGuard --
CombatStyles.LuciensGuard = {}
CombatStyles.LuciensGuard.CombatGroupType = CombatGroupTypes.BanditLike
CombatStyles.LuciensGuard.CanStrafe = true
CombatStyles.LuciensGuard.CanSheatheWeapon = true
CombatStyles.LuciensGuard.EnterRangedStrafeDist = 10
CombatStyles.LuciensGuard.StrafeActionSpeed = 1
CombatStyles.LuciensGuard.Limits = {}
CombatStyles.LuciensGuard.Limits[CombatZones.Near] = 1.5
CombatStyles.LuciensGuard.Limits[CombatZones.Middle] = 2.5
CombatStyles.LuciensGuard.Limits[CombatZones.Far] = 4.5
CombatStyles.LuciensGuard.Limits[CombatZones.Left] = 2
CombatStyles.LuciensGuard.Limits[CombatZones.Right] = 2
CombatStyles.LuciensGuard.Limits[CombatZones.Rear] = 3
CombatStyles.LuciensGuard.FleeAnim = "Flee"
CombatStyles.LuciensGuard.FleeIntoAnim = "FleeInto"
CombatStyles.LuciensGuard.FleeOutOfAnim = "FleeOutOf"
CombatStyles.LuciensGuard.CombatStyleWhenDisarmed = "BasicUnarmed"
CombatStyles.LuciensGuard.Sequences = {}
CombatStyles.LuciensGuard.Sequences[CombatSituations.Melee] = {
	"LuciensGuardOrbSuckingResponse",
	"LuciensGuardFarAttack",
	"LuciensGuardCloseAttack",
	"LuciensGuardAttack",
	"FastBackOff",
	"BanditOuterGoad",
	"BanditLeftAttack",
	"BanditRightAttack",
	"BanditRearAttack",
	"Idle"
}
CombatStyles.LuciensGuard.Sequences[CombatSituations.Ranged] = {
	"FastBackOff",
	"RangedIdle"
}
CombatStyles.LuciensGuard.Sequences[CombatSituations.GroupOrders] = {
	"BanditGroupRifleShooting",
	"BanditGroupMeleeAttack"
}
CombatStyles.LuciensGuard.FastWeaponChanges = {
	"SheatheOneHandedWeaponThenUnsheathePistol",
	"SheathePistolThenUnsheatheOneHandedWeapon"
}
CombatStyles.LuciensGuard.MinSecondsBetweenMeleeAttacks = 2
CombatStyles.LuciensGuard.SecondsToWaitAfterTargetIsHit = 4
CombatStyles.LuciensGuard.MinSecondsBetweenRangedAttacks = 6
CombatStyles.LuciensGuard.CanStandOffAndShoot = "Aggressive"
CombatStyles.LuciensGuard.CanBlock = true
CombatStyles.LuciensGuard.BlockData = {}
CombatStyles.LuciensGuard.BlockData.PrimaryBlockType = EBlockType.BLOCK_TYPE_PUSHED_BACK
CombatStyles.LuciensGuard.BlockData.SecondsForSuccessiveHitsToPrimaryBlock = 6
CombatStyles.LuciensGuard.BlockData.NumberOfHitsToForcePrimaryBlock = 4
CombatStyles.LuciensGuard.BlockData.SecondsToBlockFor = 2
CombatStyles.LuciensGuard.CanEvadeShots = false
CombatStyles.LuciensGuard.EvadeShotsData = {}
CombatStyles.LuciensGuard.EvadeShotsData.TimeToCheckFor = 6
CombatStyles.LuciensGuard.EvadeShotsData.TimeToEvadeFor = 3
CombatStyles.LuciensGuard.EvadeShotsData.HitsToStartEvading = 4
CombatStyles.LuciensGuard.EvadeAnimations = {
	"DodgeLeft",
    "DodgeRight"
}
CombatStyles.LuciensGuard.OuterRingPercentAsRanged = 0.75
CombatStyles.LuciensGuard.ValidStates = {}
CombatStyles.LuciensGuard.ValidStates[CombatSituations.Melee] = {
	 "PlayBanterCombatComment",
	 "WaitForActionToFinish",
	 "LaughAtKnockdown",
	 "UpdateWeapon",
	 "CheckForBetterTarget",
	 "RetreatFromFlourish",
	 "OuterRingKeepDistance",
	 "OuterRingSpreadOut",
	 "PlayCombatSequence",
	 "MoveToFormationPos",
	 "FaceTarget"
}
CombatStyles.LuciensGuard.ValidStates[CombatSituations.Ranged] = {
	"AntiSpamCheck",
	"PlayBanterCombatComment",
	"WaitForActionToFinish",
	"UpdateWeapon",
	"CheckForBetterTarget",
	"RetreatFromFlourish",
	"GetTargetInSights",
	"FireRangedWeapon",
	"OuterRingKeepDistance",
	"OuterRingSpreadOut",
	"PlayCombatSequence",
	"MoveToFormationPos",
	"FaceTarget",
	"IdleWithRangedWeapon"
}
CombatStyles.LuciensGuard.ValidStates[CombatSituations.HardBlocking] = CombatStyles.StandardBlockingCombatStates
CombatStyles.LuciensGuard.ValidStates[CombatSituations.SoftBlocking] = CombatStyles.StandardBlockingCombatStates
CombatStyles.LuciensGuard.ValidStates[CombatSituations.Dodging] = CombatStyles.StandardBlockingCombatStates
CombatStyles.LuciensGuard.ValidStates[CombatSituations.GroupOrders] = CombatStyles.StandardGroupOrderStates
CombatStyles.LuciensGuard.ShootingBalanceData = {}
CombatStyles.LuciensGuard.ShootingBalanceData.StartingChanceToHitWithFirearm = 0
CombatStyles.LuciensGuard.ShootingBalanceData.MaxChanceToHitWithFirearmCap = 0.5
CombatStyles.LuciensGuard.ShootingBalanceData.ChanceToHitModBonusRangeDistance = 9
CombatStyles.LuciensGuard.ShootingBalanceData.ChanceToHitModSegmentLength = 3
CombatStyles.LuciensGuard.ShootingBalanceData.ChanceToHitModPercentageIncrease = 0.05
CombatStyles.LuciensGuard.ShootingBalanceData.ChanceToHitModConsecutiveShotPercentageIncrease = 0.8
CombatStyles.LuciensGuard.ShootingBalanceData.ChanceToHitModConsecutiveShotsTimeFrame = 24
CombatStyles.LuciensGuard.ShootingBalanceData.ChanceToHitModPercentageDecreasePerOneSpeed = 0.9
CombatStyles.LuciensGuard.ShootingBalanceData.ChanceToHitModTargetInCoverPercentageMultiplier = 0.9


-- LuciensGuard Melee --
CombatStyles.LuciensGuardMelee = {}
CombatStyles.LuciensGuardMelee.CombatGroupType = CombatGroupTypes.BanditLike
CombatStyles.LuciensGuardMelee.CanStrafe = true
CombatStyles.LuciensGuardMelee.CanSheatheWeapon = true
CombatStyles.LuciensGuardMelee.EnterRangedStrafeDist = 10
CombatStyles.LuciensGuardMelee.StrafeActionSpeed = 1
CombatStyles.LuciensGuardMelee.Limits = {}
CombatStyles.LuciensGuardMelee.Limits[CombatZones.Near] = 1.5
CombatStyles.LuciensGuardMelee.Limits[CombatZones.Middle] = 2.5
CombatStyles.LuciensGuardMelee.Limits[CombatZones.Far] = 4.5
CombatStyles.LuciensGuardMelee.Limits[CombatZones.Left] = 2
CombatStyles.LuciensGuardMelee.Limits[CombatZones.Right] = 2
CombatStyles.LuciensGuardMelee.Limits[CombatZones.Rear] = 3
CombatStyles.LuciensGuardMelee.FleeAnim = "Flee"
CombatStyles.LuciensGuardMelee.FleeIntoAnim = "FleeInto"
CombatStyles.LuciensGuardMelee.FleeOutOfAnim = "FleeOutOf"
CombatStyles.LuciensGuardMelee.CombatStyleWhenDisarmed = "BasicUnarmed"
CombatStyles.LuciensGuardMelee.Sequences = {}
CombatStyles.LuciensGuardMelee.Sequences[CombatSituations.Melee] = {
	"LuciensGuardOrbSuckingResponse",
	"LuciensGuardFarAttack",
	"LuciensGuardCloseAttack",
	"LuciensGuardAttack",
	"FastBackOff",
	"BanditOuterGoad",
	"BanditLeftAttack",
	"BanditRightAttack",
	"BanditRearAttack",
	"Idle"
}
CombatStyles.LuciensGuardMelee.Sequences[CombatSituations.GroupOrders] = {
	"BanditGroupMeleeAttack"
}
CombatStyles.LuciensGuardMelee.FastWeaponChanges = {
	"SheatheOneHandedWeaponThenUnsheathePistol",
	"SheathePistolThenUnsheatheOneHandedWeapon"
}
CombatStyles.LuciensGuardMelee.MinSecondsBetweenMeleeAttacks = 2
CombatStyles.LuciensGuardMelee.SecondsToWaitAfterTargetIsHit = 4
CombatStyles.LuciensGuardMelee.MinSecondsBetweenRangedAttacks = 6
CombatStyles.LuciensGuardMelee.CanStandOffAndShoot = "Aggressive"
CombatStyles.LuciensGuardMelee.CanBlock = true
CombatStyles.LuciensGuardMelee.BlockData = {}
CombatStyles.LuciensGuardMelee.BlockData.PrimaryBlockType = EBlockType.BLOCK_TYPE_PUSHED_BACK
CombatStyles.LuciensGuardMelee.BlockData.SecondsForSuccessiveHitsToPrimaryBlock = 6
CombatStyles.LuciensGuardMelee.BlockData.NumberOfHitsToForcePrimaryBlock = 4
CombatStyles.LuciensGuardMelee.BlockData.SecondsToBlockFor = 2
CombatStyles.LuciensGuardMelee.CanEvadeShots = false
CombatStyles.LuciensGuardMelee.EvadeShotsData = {}
CombatStyles.LuciensGuardMelee.EvadeShotsData.TimeToCheckFor = 6
CombatStyles.LuciensGuardMelee.EvadeShotsData.TimeToEvadeFor = 3
CombatStyles.LuciensGuardMelee.EvadeShotsData.HitsToStartEvading = 4
CombatStyles.LuciensGuardMelee.EvadeAnimations = {
	"DodgeLeft",
    "DodgeRight"
}
CombatStyles.LuciensGuardMelee.ValidStates = {}
CombatStyles.LuciensGuardMelee.ValidStates[CombatSituations.Melee] = {
	 "PlayBanterCombatComment",
	 "WaitForActionToFinish",
	 "LaughAtKnockdown",
	 "UpdateWeapon",
	 "CheckForBetterTarget",
	 "RetreatFromFlourish",
	 "OuterRingKeepDistance",
	 "OuterRingSpreadOut",
	 "PlayCombatSequence",
	 "MoveToFormationPos",
	 "FaceTarget"
}
CombatStyles.LuciensGuardMelee.ValidStates[CombatSituations.HardBlocking] = CombatStyles.StandardBlockingCombatStates
CombatStyles.LuciensGuardMelee.ValidStates[CombatSituations.SoftBlocking] = CombatStyles.StandardBlockingCombatStates
CombatStyles.LuciensGuardMelee.ValidStates[CombatSituations.Dodging] = CombatStyles.StandardBlockingCombatStates
CombatStyles.LuciensGuardMelee.ValidStates[CombatSituations.GroupOrders] = CombatStyles.StandardGroupOrderStates
CombatStyles.LuciensGuardMelee.ShootingBalanceData = {}
CombatStyles.LuciensGuardMelee.ShootingBalanceData.StartingChanceToHitWithFirearm = 0
CombatStyles.LuciensGuardMelee.ShootingBalanceData.MaxChanceToHitWithFirearmCap = 0.5
CombatStyles.LuciensGuardMelee.ShootingBalanceData.ChanceToHitModBonusRangeDistance = 9
CombatStyles.LuciensGuardMelee.ShootingBalanceData.ChanceToHitModSegmentLength = 3
CombatStyles.LuciensGuardMelee.ShootingBalanceData.ChanceToHitModPercentageIncrease = 0.05
CombatStyles.LuciensGuardMelee.ShootingBalanceData.ChanceToHitModConsecutiveShotPercentageIncrease = 0.8
CombatStyles.LuciensGuardMelee.ShootingBalanceData.ChanceToHitModConsecutiveShotsTimeFrame = 24
CombatStyles.LuciensGuardMelee.ShootingBalanceData.ChanceToHitModPercentageDecreasePerOneSpeed = 0.9
CombatStyles.LuciensGuardMelee.ShootingBalanceData.ChanceToHitModTargetInCoverPercentageMultiplier = 0.9


-- LuciensGuard Defensive --
CombatStyles.LuciensGuardDefensive = DeepCopyTable(CombatStyles.LuciensGuard)
CombatStyles.LuciensGuardDefensive.CanStandOffAndShoot = "Defensive"


-- LuciensGuard Turret --
CombatStyles.LuciensGuardTurret = DeepCopyTable(CombatStyles.LuciensGuard)
CombatStyles.LuciensGuardDefensive.CanStandOffAndShoot = "Turret"
CombatStyles.LuciensGuardTurret.MinTimeToReturnToFiringPos = 20
CombatStyles.LuciensGuardTurret.CombatStyleWhenDisarmed = "BasicUnarmed"
CombatStyles.LuciensGuardTurret.TurretBalanceData = {}
CombatStyles.LuciensGuardTurret.TurretBalanceData.DistanceToMoveBackToShootingPosition = 1
CombatStyles.LuciensGuardTurret.TurretBalanceData.DistanceOverWhichToFindNewShootingPosition = 5
CombatStyles.LuciensGuardTurret.TurretBalanceData.NonTurretCombatStyle = "LuciensGuard"
CombatStyles.LuciensGuardTurret.Limits = {}
CombatStyles.LuciensGuardTurret.Limits[CombatZones.Near] = 1.5
CombatStyles.LuciensGuardTurret.Limits[CombatZones.Middle] = 2.5
CombatStyles.LuciensGuardTurret.Limits[CombatZones.Far] = 5
CombatStyles.LuciensGuardTurret.Limits[CombatZones.Left] = 1
CombatStyles.LuciensGuardTurret.Limits[CombatZones.Right] = 1
CombatStyles.LuciensGuardTurret.Limits[CombatZones.Rear] = 1
CombatStyles.LuciensGuardTurret.Sequences = {}
CombatStyles.LuciensGuardTurret.Sequences[CombatSituations.Melee] = {
	"LuciensGuardCloseAttack",
	"LuciensGuardAttack",
	"FastBackOff",
	"BanditOuterGoad",
	"Idle"
}
CombatStyles.LuciensGuardTurret.Sequences[CombatSituations.Ranged] = {
	"Idle",
	"FarIdle"
}
CombatStyles.LuciensGuardTurret.ValidStates = {}
CombatStyles.LuciensGuardTurret.ValidStates[CombatSituations.Ranged] = {
	 "AntiSpamCheck",
	 "PlayBanterCombatComment",
	 "WaitForActionToFinish",
	 "TurretUpdateWeapon",
	 "CheckForBetterTarget",
	 "MoveToFiringPosition",
	 "FireRangedWeapon",
	 "OuterRingKeepDistance",
	 "OuterRingSpreadOut",
	 "PlayCombatSequence",
	 "MoveToFormationPos",
	 "FaceTarget"
}
CombatStyles.LuciensGuardTurret.ValidStates[CombatSituations.Melee] = {
	 "AntiSpamCheck",
	 "PlayBanterCombatComment",
	 "WaitForActionToFinish",
	 "TurretUpdateWeapon",
	 "CheckForBetterTarget",
	 "OuterRingKeepDistance",
	 "OuterRingSpreadOut",
	 "PlayCombatSequence",
	 "MoveToFormationPos",
	 "FaceTarget"
}


-- LuciensGuard Turret NoWait --
CombatStyles.LuciensGuardTurretNoWait = DeepCopyTable(CombatStyles.LuciensGuardTurret)
CombatStyles.LuciensGuardTurretNoWait.MoveToFiringPosNoWait = true


-- LuciensGuard Elite --
CombatStyles.LuciensGuardElite = {}
CombatStyles.LuciensGuardElite.CombatGroupType = CombatGroupTypes.BanditLike
CombatStyles.LuciensGuardElite.CanStrafe = true
CombatStyles.LuciensGuardElite.CanSheatheWeapon = true
CombatStyles.LuciensGuardElite.EnterRangedStrafeDist = 10
CombatStyles.LuciensGuardElite.StrafeActionSpeed = 1
CombatStyles.LuciensGuardElite.Limits = {}
CombatStyles.LuciensGuardElite.Limits[CombatZones.Near] = 1.5
CombatStyles.LuciensGuardElite.Limits[CombatZones.Middle] = 2.5
CombatStyles.LuciensGuardElite.Limits[CombatZones.Far] = 4.5
CombatStyles.LuciensGuardElite.Limits[CombatZones.Left] = 2
CombatStyles.LuciensGuardElite.Limits[CombatZones.Right] = 2
CombatStyles.LuciensGuardElite.Limits[CombatZones.Rear] = 3
CombatStyles.LuciensGuardElite.FleeAnim = "Flee"
CombatStyles.LuciensGuardElite.FleeIntoAnim = "FleeInto"
CombatStyles.LuciensGuardElite.FleeOutOfAnim = "FleeOutOf"
CombatStyles.LuciensGuardElite.CombatStyleWhenDisarmed = "BasicUnarmed"
CombatStyles.LuciensGuardElite.Sequences = {}
CombatStyles.LuciensGuardElite.Sequences[CombatSituations.Melee] = {
	"LuciensGuardOrbSuckingResponse",
	"LuciensGuardCloseAttack",
	"LuciensGuardAttack",
	"FastBackOff",
	"BanditOuterGoad",
	"BanditLeftAttack",
	"BanditRightAttack",
	"BanditRearAttack",
	"Idle"
}
CombatStyles.LuciensGuardElite.Sequences[CombatSituations.Ranged] = {
	"FastBackOff",
	"RangedIdle"
}
CombatStyles.LuciensGuardElite.Sequences[CombatSituations.GroupOrders] = {
	"BanditGroupRifleShooting",
	"BanditGroupMeleeAttack"
}
CombatStyles.LuciensGuardElite.FastWeaponChanges = {
	"SheatheOneHandedWeaponThenUnsheathePistol",
	"SheathePistolThenUnsheatheOneHandedWeapon"
}
CombatStyles.LuciensGuardElite.MinSecondsBetweenMeleeAttacks = 2
CombatStyles.LuciensGuardElite.SecondsToWaitAfterTargetIsHit = 2
CombatStyles.LuciensGuardElite.MinSecondsBetweenRangedAttacks = 4
CombatStyles.LuciensGuardElite.CanStandOffAndShoot = "Aggressive"
CombatStyles.LuciensGuardElite.CanBlock = true
CombatStyles.LuciensGuardElite.BlockData = {}
CombatStyles.LuciensGuardElite.BlockData.PrimaryBlockType = EBlockType.BLOCK_TYPE_PUSHED_BACK
CombatStyles.LuciensGuardElite.BlockData.SecondsForSuccessiveHitsToPrimaryBlock = 6
CombatStyles.LuciensGuardElite.BlockData.NumberOfHitsToForcePrimaryBlock = 4
CombatStyles.LuciensGuardElite.BlockData.SecondsToBlockFor = 2
CombatStyles.LuciensGuardElite.CanEvadeShots = false
CombatStyles.LuciensGuardElite.EvadeShotsData = {}
CombatStyles.LuciensGuardElite.EvadeShotsData.TimeToCheckFor = 6
CombatStyles.LuciensGuardElite.EvadeShotsData.TimeToEvadeFor = 3
CombatStyles.LuciensGuardElite.EvadeShotsData.HitsToStartEvading = 3
CombatStyles.LuciensGuardElite.EvadeAnimations = {
	"DodgeLeft",
    "DodgeRight"
}
CombatStyles.LuciensGuardElite.AntiSpamData = {}
CombatStyles.LuciensGuardElite.AntiSpamData.TimeToCheckFor = 5
CombatStyles.LuciensGuardElite.AntiSpamData.ShotsToTrigger = 3
CombatStyles.LuciensGuardElite.AntiSpamData.SpellsToTrigger = 3
CombatStyles.LuciensGuardElite.AntiSpamData.TimeToAggroFor = 15
CombatStyles.LuciensGuardElite.OuterRingPercentAsRanged = 0.75
CombatStyles.LuciensGuardElite.ValidStates = {}
CombatStyles.LuciensGuardElite.ValidStates[CombatSituations.Melee] = {
	 "AntiSpamCheck",
	 "PlayBanterCombatComment",
	 "WaitForActionToFinish",
	 "LaughAtKnockdown",
	 "UpdateWeapon",
	 "CheckForBetterTarget",
	 "RetreatFromFlourish",
	 "OuterRingKeepDistance",
	 "OuterRingSpreadOut",
	 "PlayCombatSequence",
	 "MoveToFormationPos",
	 "FaceTarget"
}
CombatStyles.LuciensGuardElite.ValidStates[CombatSituations.Ranged] = {
	"AntiSpamCheck",
	"PlayBanterCombatComment",
	"WaitForActionToFinish",
	"UpdateWeapon",
	"CheckForBetterTarget",
	"RetreatFromFlourish",
	"GetTargetInSights",
	"FireRangedWeapon",
	"OuterRingKeepDistance",
	"OuterRingSpreadOut",
	"PlayCombatSequence",
	"MoveToFormationPos",
	"FaceTarget",
	"IdleWithRangedWeapon"
}
CombatStyles.LuciensGuardElite.ValidStates[CombatSituations.HardBlocking] = CombatStyles.StandardBlockingCombatStates
CombatStyles.LuciensGuardElite.ValidStates[CombatSituations.SoftBlocking] = CombatStyles.StandardBlockingCombatStates
CombatStyles.LuciensGuardElite.ValidStates[CombatSituations.Dodging] = CombatStyles.StandardBlockingCombatStates
CombatStyles.LuciensGuardElite.ValidStates[CombatSituations.GroupOrders] = CombatStyles.StandardGroupOrderStates
CombatStyles.LuciensGuardElite.ShootingBalanceData = {}
CombatStyles.LuciensGuardElite.ShootingBalanceData.StartingChanceToHitWithFirearm = 0
CombatStyles.LuciensGuardElite.ShootingBalanceData.MaxChanceToHitWithFirearmCap = 0.5
CombatStyles.LuciensGuardElite.ShootingBalanceData.ChanceToHitModBonusRangeDistance = 9
CombatStyles.LuciensGuardElite.ShootingBalanceData.ChanceToHitModSegmentLength = 3
CombatStyles.LuciensGuardElite.ShootingBalanceData.ChanceToHitModPercentageIncrease = 0.05
CombatStyles.LuciensGuardElite.ShootingBalanceData.ChanceToHitModConsecutiveShotPercentageIncrease = 0.8
CombatStyles.LuciensGuardElite.ShootingBalanceData.ChanceToHitModConsecutiveShotsTimeFrame = 24
CombatStyles.LuciensGuardElite.ShootingBalanceData.ChanceToHitModPercentageDecreasePerOneSpeed = 0.9
CombatStyles.LuciensGuardElite.ShootingBalanceData.ChanceToHitModTargetInCoverPercentageMultiplier = 0.9


-- LuciensGuard Lieutenant --
CombatStyles.LuciensGuardLieutenant = {}
CombatStyles.LuciensGuardLieutenant.CombatGroupType = CombatGroupTypes.BanditLike
CombatStyles.LuciensGuardLieutenant.CanStrafe = true
CombatStyles.LuciensGuardLieutenant.CanSheatheWeapon = true
CombatStyles.LuciensGuardLieutenant.PreferOuterRing = true
CombatStyles.LuciensGuardLieutenant.IsLeaderType = true
CombatStyles.LuciensGuardLieutenant.StrafeActionSpeed = 1
CombatStyles.LuciensGuardLieutenant.Limits = {}
CombatStyles.LuciensGuardLieutenant.Limits[CombatZones.Near] = 1.5
CombatStyles.LuciensGuardLieutenant.Limits[CombatZones.Middle] = 2.5
CombatStyles.LuciensGuardLieutenant.Limits[CombatZones.Far] = 5
CombatStyles.LuciensGuardLieutenant.Limits[CombatZones.Left] = 2
CombatStyles.LuciensGuardLieutenant.Limits[CombatZones.Right] = 2
CombatStyles.LuciensGuardLieutenant.Limits[CombatZones.Rear] = 3
CombatStyles.LuciensGuardLieutenant.FleeAnim = "Flee"
CombatStyles.LuciensGuardLieutenant.FleeIntoAnim = "FleeInto"
CombatStyles.LuciensGuardLieutenant.FleeOutOfAnim = "FleeOutOf"
CombatStyles.LuciensGuardLieutenant.CombatStyleWhenDisarmed = "BasicUnarmed"
CombatStyles.LuciensGuardLieutenant.Sequences = {}
CombatStyles.LuciensGuardLieutenant.Sequences[CombatSituations.Melee] = {
	"BanditLeaderInteruptSpellMelee",
	"LuciensGuardLieutenantOrbSuckingResponse",
	"LuciensGuardLieutenantCloseAttack",
	"LuciensGuardLieutenantAttack",
	"BanditLeftAttack",
	"BanditRightAttack",
	"BanditRearAttack",
	"Idle"
}
CombatStyles.LuciensGuardLieutenant.Sequences[CombatSituations.Ranged] = {
	"BanditLeaderInteruptSpellRanged",
	"RangedIdle"
}
CombatStyles.LuciensGuardLieutenant.Sequences[CombatSituations.HardBlocking] = {
	"LuciensGuardLieutenantAttackOutOfBlockShort",
	"LuciensGuardLieutenantAttackOutOfBlock"
}
CombatStyles.LuciensGuardLieutenant.Sequences[CombatSituations.GroupOrders] = {
	"BanditGroupRifleShooting",
	"BanditGroupMeleeAttack"
}
CombatStyles.LuciensGuardLieutenant.FastWeaponChanges = {
	"SheatheOneHandedWeaponThenUnsheathePistol",
	"SheathePistolThenUnsheatheOneHandedWeapon"
}
CombatStyles.LuciensGuardLieutenant.MinSecondsBetweenMeleeAttacks = 1.5
CombatStyles.LuciensGuardLieutenant.SecondsToWaitAfterTargetIsHit = 2
CombatStyles.LuciensGuardLieutenant.MinSecondsBetweenRangedAttacks = 6
CombatStyles.LuciensGuardLieutenant.CanStandOffAndShoot = "Aggressive"
CombatStyles.LuciensGuardLieutenant.CanBlock = true
CombatStyles.LuciensGuardLieutenant.BlockData = {}
CombatStyles.LuciensGuardLieutenant.BlockData.PrimaryBlockType = EBlockType.BLOCK_TYPE_STATIC
CombatStyles.LuciensGuardLieutenant.BlockData.SecondsForSuccessiveHitsToPrimaryBlock = 6
CombatStyles.LuciensGuardLieutenant.BlockData.NumberOfHitsToForcePrimaryBlock = 4
CombatStyles.LuciensGuardLieutenant.BlockData.SecondsToBlockFor = 2
CombatStyles.LuciensGuardLieutenant.CanEvadeShots = false
CombatStyles.LuciensGuardLieutenant.EvadeShotsData = {}
CombatStyles.LuciensGuardLieutenant.EvadeShotsData.TimeToCheckFor = 6
CombatStyles.LuciensGuardLieutenant.EvadeShotsData.TimeToEvadeFor = 3
CombatStyles.LuciensGuardLieutenant.EvadeShotsData.HitsToStartEvading = 3
CombatStyles.LuciensGuardLieutenant.EvadeAnimations = {
	"DodgeLeft",
    "DodgeRight"
}
CombatStyles.LuciensGuardLieutenant.AntiSpamData = {}
CombatStyles.LuciensGuardLieutenant.AntiSpamData.TimeToCheckFor = 5
CombatStyles.LuciensGuardLieutenant.AntiSpamData.ShotsToTrigger = 3
CombatStyles.LuciensGuardLieutenant.AntiSpamData.SpellsToTrigger = 3
CombatStyles.LuciensGuardLieutenant.AntiSpamData.TimeToAggroFor = 15
CombatStyles.LuciensGuardLieutenant.OuterRingPercentAsRanged = 0.75
CombatStyles.LuciensGuardLieutenant.ValidStates = {}
CombatStyles.LuciensGuardLieutenant.ValidStates[CombatSituations.Melee] = {
	 "AntiSpamCheck",
	 "PlayBanterCombatComment",
	 "WaitForActionToFinish",
	 "LaughAtKnockdown",
	 "UpdateWeapon",
	 "CheckForBetterTarget",
	 "RetreatFromFlourish",
	 "OuterRingKeepDistance",
	 "OuterRingSpreadOut",
	 "PlayCombatSequence",
	 "MoveToFormationPos",
	 "FaceTarget"
}
CombatStyles.LuciensGuardLieutenant.ValidStates[CombatSituations.Ranged] = {
	"AntiSpamCheck",
	"PlayBanterCombatComment",
	"WaitForActionToFinish",
	"UpdateWeapon",
	"CheckForBetterTarget",
	"RetreatFromFlourish",
	"GetTargetInSights",
	"FireRangedWeapon",
	"OuterRingKeepDistance",
	"OuterRingSpreadOut",
	"PlayCombatSequence",
	"MoveToFormationPos",
	"FaceTarget",
	"IdleWithRangedWeapon"
}
CombatStyles.LuciensGuardLieutenant.ValidStates[CombatSituations.HardBlocking] = CombatStyles.StandardBlockingCombatStates
CombatStyles.LuciensGuardLieutenant.ValidStates[CombatSituations.SoftBlocking] = CombatStyles.StandardBlockingCombatStates
CombatStyles.LuciensGuardLieutenant.ValidStates[CombatSituations.Dodging] = CombatStyles.StandardBlockingCombatStates
CombatStyles.LuciensGuardLieutenant.ValidStates[CombatSituations.GroupOrders] = CombatStyles.StandardGroupOrderStates
CombatStyles.LuciensGuardLieutenant.ShootingBalanceData = {}
CombatStyles.LuciensGuardLieutenant.ShootingBalanceData.StartingChanceToHitWithFirearm = 0
CombatStyles.LuciensGuardLieutenant.ShootingBalanceData.MaxChanceToHitWithFirearmCap = 0.6
CombatStyles.LuciensGuardLieutenant.ShootingBalanceData.ChanceToHitModBonusRangeDistance = 9
CombatStyles.LuciensGuardLieutenant.ShootingBalanceData.ChanceToHitModSegmentLength = 3
CombatStyles.LuciensGuardLieutenant.ShootingBalanceData.ChanceToHitModPercentageIncrease = 0.05
CombatStyles.LuciensGuardLieutenant.ShootingBalanceData.ChanceToHitModConsecutiveShotPercentageIncrease = 0.8
CombatStyles.LuciensGuardLieutenant.ShootingBalanceData.ChanceToHitModConsecutiveShotsTimeFrame = 25
CombatStyles.LuciensGuardLieutenant.ShootingBalanceData.ChanceToHitModPercentageDecreasePerOneSpeed = 0.9
CombatStyles.LuciensGuardLieutenant.ShootingBalanceData.ChanceToHitModTargetInCoverPercentageMultiplier = 0.9
CombatStyles.LuciensGuardLieutenant.ShootingBalanceData.ChanceToHitModOffScreenPercentageMultiplier = 0.5
CombatStyles.LuciensGuardLieutenant.SecondsBetweenGroupActions = 20
CombatStyles.LuciensGuardLieutenant.PercentChanceThatGroupActionIsShoot = 25


-- LuciensGuard Lieutenant Elite --
CombatStyles.LuciensGuardLieutenantElite = {}
CombatStyles.LuciensGuardLieutenantElite.CombatGroupType = CombatGroupTypes.BanditLike
CombatStyles.LuciensGuardLieutenantElite.CanStrafe = true
CombatStyles.LuciensGuardLieutenantElite.CanSheatheWeapon = true
CombatStyles.LuciensGuardLieutenantElite.PreferOuterRing = true
CombatStyles.LuciensGuardLieutenantElite.IsLeaderType = true
CombatStyles.LuciensGuardLieutenantElite.StrafeActionSpeed = 1
CombatStyles.LuciensGuardLieutenantElite.Limits = {}
CombatStyles.LuciensGuardLieutenantElite.Limits[CombatZones.Near] = 1.5
CombatStyles.LuciensGuardLieutenantElite.Limits[CombatZones.Middle] = 2.5
CombatStyles.LuciensGuardLieutenantElite.Limits[CombatZones.Far] = 5
CombatStyles.LuciensGuardLieutenantElite.Limits[CombatZones.Left] = 2
CombatStyles.LuciensGuardLieutenantElite.Limits[CombatZones.Right] = 2
CombatStyles.LuciensGuardLieutenantElite.Limits[CombatZones.Rear] = 3
CombatStyles.LuciensGuardLieutenantElite.FleeAnim = "Flee"
CombatStyles.LuciensGuardLieutenantElite.FleeIntoAnim = "FleeInto"
CombatStyles.LuciensGuardLieutenantElite.FleeOutOfAnim = "FleeOutOf"
CombatStyles.LuciensGuardLieutenantElite.CombatStyleWhenDisarmed = "BasicUnarmed"
CombatStyles.LuciensGuardLieutenantElite.Sequences = {}
CombatStyles.LuciensGuardLieutenantElite.Sequences[CombatSituations.Melee] = {
	"BanditLeaderInteruptSpellMelee",
	"LuciensGuardLieutenantOrbSuckingResponse",
	"LuciensGuardLieutenantCloseAttack",
	"LuciensGuardLieutenantAttack",
	"BanditLeftAttack",
	"BanditRightAttack",
	"BanditRearAttack",
	"Idle"
}
CombatStyles.LuciensGuardLieutenantElite.Sequences[CombatSituations.Ranged] = {
	"BanditLeaderInteruptSpellRanged",
	"RangedIdle"
}
CombatStyles.LuciensGuardLieutenantElite.Sequences[CombatSituations.HardBlocking] = {
	"LuciensGuardLieutenantAttackOutOfBlockShort",
	"LuciensGuardLieutenantAttackOutOfBlock"
}
CombatStyles.LuciensGuardLieutenantElite.Sequences[CombatSituations.GroupOrders] = {
	"BanditGroupRifleShooting",
	"BanditGroupMeleeAttack"
}
CombatStyles.LuciensGuardLieutenantElite.FastWeaponChanges = {
	"SheatheOneHandedWeaponThenUnsheathePistol",
	"SheathePistolThenUnsheatheOneHandedWeapon"
}
CombatStyles.LuciensGuardLieutenantElite.MinSecondsBetweenMeleeAttacks = 1
CombatStyles.LuciensGuardLieutenantElite.SecondsToWaitAfterTargetIsHit = 2
CombatStyles.LuciensGuardLieutenantElite.MinSecondsBetweenRangedAttacks = 6
CombatStyles.LuciensGuardLieutenantElite.CanStandOffAndShoot = "Aggressive"
CombatStyles.LuciensGuardLieutenantElite.CanBlock = true
CombatStyles.LuciensGuardLieutenantElite.BlockData = {}
CombatStyles.LuciensGuardLieutenantElite.BlockData.PrimaryBlockType = EBlockType.BLOCK_TYPE_STATIC
CombatStyles.LuciensGuardLieutenantElite.BlockData.SecondsForSuccessiveHitsToPrimaryBlock = 6
CombatStyles.LuciensGuardLieutenantElite.BlockData.NumberOfHitsToForcePrimaryBlock = 3
CombatStyles.LuciensGuardLieutenantElite.BlockData.SecondsToBlockFor = 2
CombatStyles.LuciensGuardLieutenantElite.CanEvadeShots = false
CombatStyles.LuciensGuardLieutenantElite.EvadeShotsData = {}
CombatStyles.LuciensGuardLieutenantElite.EvadeShotsData.TimeToCheckFor = 6
CombatStyles.LuciensGuardLieutenantElite.EvadeShotsData.TimeToEvadeFor = 3
CombatStyles.LuciensGuardLieutenantElite.EvadeShotsData.HitsToStartEvading = 3
CombatStyles.LuciensGuardLieutenantElite.EvadeAnimations = {
	"DodgeLeft",
    "DodgeRight"
}
CombatStyles.LuciensGuardLieutenantElite.AntiSpamData = {}
CombatStyles.LuciensGuardLieutenantElite.AntiSpamData.TimeToCheckFor = 5
CombatStyles.LuciensGuardLieutenantElite.AntiSpamData.ShotsToTrigger = 3
CombatStyles.LuciensGuardLieutenantElite.AntiSpamData.SpellsToTrigger = 3
CombatStyles.LuciensGuardLieutenantElite.AntiSpamData.TimeToAggroFor = 15
CombatStyles.LuciensGuardLieutenantElite.OuterRingPercentAsRanged = 0.75
CombatStyles.LuciensGuardLieutenantElite.ValidStates = {}
CombatStyles.LuciensGuardLieutenantElite.ValidStates[CombatSituations.Melee] = {
	 "AntiSpamCheck",
	 "PlayBanterCombatComment",
	 "WaitForActionToFinish",
	 "LaughAtKnockdown",
	 "UpdateWeapon",
	 "CheckForBetterTarget",
	 "RetreatFromFlourish",
	 "OuterRingKeepDistance",
	 "OuterRingSpreadOut",
	 "PlayCombatSequence",
	 "MoveToFormationPos",
	 "FaceTarget"
}
CombatStyles.LuciensGuardLieutenantElite.ValidStates[CombatSituations.Ranged] = {
	"AntiSpamCheck",
	"PlayBanterCombatComment",
	"WaitForActionToFinish",
	"UpdateWeapon",
	"CheckForBetterTarget",
	"RetreatFromFlourish",
	"GetTargetInSights",
	"FireRangedWeapon",
	"OuterRingKeepDistance",
	"OuterRingSpreadOut",
	"PlayCombatSequence",
	"MoveToFormationPos",
	"FaceTarget",
	"IdleWithRangedWeapon"
}
CombatStyles.LuciensGuardLieutenantElite.ValidStates[CombatSituations.HardBlocking] = CombatStyles.StandardBlockingCombatStates
CombatStyles.LuciensGuardLieutenantElite.ValidStates[CombatSituations.SoftBlocking] = CombatStyles.StandardBlockingCombatStates
CombatStyles.LuciensGuardLieutenantElite.ValidStates[CombatSituations.Dodging] = CombatStyles.StandardBlockingCombatStates
CombatStyles.LuciensGuardLieutenantElite.ValidStates[CombatSituations.GroupOrders] = CombatStyles.StandardGroupOrderStates
CombatStyles.LuciensGuardLieutenantElite.ShootingBalanceData = {}
CombatStyles.LuciensGuardLieutenantElite.ShootingBalanceData.StartingChanceToHitWithFirearm = 0
CombatStyles.LuciensGuardLieutenantElite.ShootingBalanceData.MaxChanceToHitWithFirearmCap = 0.6
CombatStyles.LuciensGuardLieutenantElite.ShootingBalanceData.ChanceToHitModBonusRangeDistance = 9
CombatStyles.LuciensGuardLieutenantElite.ShootingBalanceData.ChanceToHitModSegmentLength = 3
CombatStyles.LuciensGuardLieutenantElite.ShootingBalanceData.ChanceToHitModPercentageIncrease = 0.05
CombatStyles.LuciensGuardLieutenantElite.ShootingBalanceData.ChanceToHitModConsecutiveShotPercentageIncrease = 0.8
CombatStyles.LuciensGuardLieutenantElite.ShootingBalanceData.ChanceToHitModConsecutiveShotsTimeFrame = 25
CombatStyles.LuciensGuardLieutenantElite.ShootingBalanceData.ChanceToHitModPercentageDecreasePerOneSpeed = 0.9
CombatStyles.LuciensGuardLieutenantElite.ShootingBalanceData.ChanceToHitModTargetInCoverPercentageMultiplier = 0.9
CombatStyles.LuciensGuardLieutenantElite.ShootingBalanceData.ChanceToHitModOffScreenPercentageMultiplier = 0.5
CombatStyles.LuciensGuardLieutenantElite.SecondsBetweenGroupActions = 30
CombatStyles.LuciensGuardLieutenantElite.PercentChanceThatGroupActionIsShoot = 25


-- LuciensSoldier --
CombatStyles.LuciensSoldier = {}
CombatStyles.LuciensSoldier.CombatGroupType = CombatGroupTypes.BanditLike
CombatStyles.LuciensSoldier.CanSheatheWeapon = false
CombatStyles.LuciensSoldier.MovementTolerance = 0.45
CombatStyles.LuciensSoldier.TurnToFaceTolerance = 15
CombatStyles.LuciensSoldier.IsLeaderType = true
CombatStyles.LuciensSoldier.PreferOuterRing = true
CombatStyles.LuciensSoldier.BalverineJumpDist = 2
CombatStyles.LuciensSoldier.ActionModifiers = {}
CombatStyles.LuciensSoldier.ActionModifiers.MinDistToTarget = 0.75
CombatStyles.LuciensSoldier.NonFormation = true
CombatStyles.LuciensSoldier.Limits = {}
CombatStyles.LuciensSoldier.Limits[CombatZones.Near] = 1.8
CombatStyles.LuciensSoldier.Limits[CombatZones.Middle] = 2.8
CombatStyles.LuciensSoldier.Limits[CombatZones.Far] = 6
CombatStyles.LuciensSoldier.Limits[CombatZones.Left] = 1.5
CombatStyles.LuciensSoldier.Limits[CombatZones.Right] = 1.5
CombatStyles.LuciensSoldier.Limits[CombatZones.Rear] = 1.5
CombatStyles.LuciensSoldier.Sequences = {}
CombatStyles.LuciensSoldier.Sequences[CombatSituations.Melee] = {
	"LuciensSoldierShotTooMuch",
	"LuciensSoldierMagicedTooMuch",
	"LuciensSoldierOrbSuckingResponse",
	"LuciensHeroFlourishResponse",
	"LuciensSoldierAttack",
	"LuciensSoldierCloseAttack",
	"FastBackOff"
}
CombatStyles.LuciensSoldier.Sequences[CombatSituations.GroupOrders] = {
	"LuciensSoldierGroupSpellAttack",
	"LuciensSoldierGroupAttack"
}
CombatStyles.LuciensSoldier.Sequences[CombatSituations.HardBlocking] = {
	"LuciensSoldierAttackOutOfBlock"
}
CombatStyles.LuciensSoldier.MinSecondsBetweenMeleeAttacks = 3
CombatStyles.LuciensSoldier.SecondsToWaitAfterTargetIsHit = 3
CombatStyles.LuciensSoldier.MinSecondsBetweenRangedAttacks = 10
CombatStyles.LuciensSoldier.CanBlock = true
CombatStyles.LuciensSoldier.BlockData = {}
CombatStyles.LuciensSoldier.BlockData.PrimaryBlockType = EBlockType.BLOCK_TYPE_STATIC
CombatStyles.LuciensSoldier.BlockData.SecondsForSuccessiveHitsToPrimaryBlock = 6
CombatStyles.LuciensSoldier.BlockData.NumberOfHitsToForcePrimaryBlock = 3
CombatStyles.LuciensSoldier.BlockData.SecondsToBlockFor = 3
CombatStyles.LuciensSoldier.DodgeAnimations = {
	"DodgeLeft",
    "DodgeRight"
}
CombatStyles.LuciensSoldier.CanEvadeShots = true
CombatStyles.LuciensSoldier.EvadeShotsData = {}
CombatStyles.LuciensSoldier.EvadeShotsData.TimeToCheckFor = 5
CombatStyles.LuciensSoldier.EvadeShotsData.TimeToEvadeFor = 3
CombatStyles.LuciensSoldier.EvadeShotsData.HitsToStartEvading = 3
CombatStyles.LuciensSoldier.EvadeAnimations = {
	"DodgeLeft",
    "DodgeRight"
}
CombatStyles.LuciensSoldier.AntiSpamData = {}
CombatStyles.LuciensSoldier.AntiSpamData.TimeToCheckFor = 5
CombatStyles.LuciensSoldier.AntiSpamData.ShotsToTrigger = 3
CombatStyles.LuciensSoldier.AntiSpamData.SpellsToTrigger = 3
CombatStyles.LuciensSoldier.AntiSpamData.TimeToAggroFor = 15
CombatStyles.LuciensSoldier.ValidStates = {}
CombatStyles.LuciensSoldier.ValidStates[CombatSituations.Melee] = {
	"AntiSpamCheck",
	"PlayBanterCombatComment",
	"WaitForActionToFinish",
	"UpdateWeapon",
	"CheckForBetterTarget",
	"LuciensSoldierSpellCasting",
	"PlayCombatSequence",
	"LuciensSoldierMoveToFormationPos",
	"FaceTarget",
	"LuciensSoldierWaitMenacingly"
}
CombatStyles.LuciensSoldier.ValidStates[CombatSituations.HardBlocking] = CombatStyles.StandardBlockingCombatStates
CombatStyles.LuciensSoldier.ValidStates[CombatSituations.SoftBlocking] = CombatStyles.StandardBlockingCombatStates
CombatStyles.LuciensSoldier.ValidStates[CombatSituations.Dodging] = CombatStyles.StandardBlockingCombatStates
CombatStyles.LuciensSoldier.ValidStates[CombatSituations.GroupOrders] = CombatStyles.StandardGroupOrderStates
CombatStyles.LuciensSoldier.SecondsBetweenGroupActions = 40
CombatStyles.LuciensSoldier.PercentChanceThatGroupActionIsShoot = 25
CombatStyles.LuciensSoldier.MoveFunction = function(self, dest_pos, face_target)

	local params = {speed = ENavigationSpeed.NAV_SPEED_SPRINT, reset_constraints = false}
	
	if face_target then
		self:SetNavigationConstraints({destination_target_entity = self.Target})
	else
		params.reset_constraints = true
	end
	
	if self.CombatInfo.Zone and self.CombatInfo.Zone ~= CombatZones.None then
		params.speed = ENavigationSpeed.NAV_SPEED_WALK
	end
	
	if self:MoveToPositionNoWait(dest_pos, params) then
		coroutine.yield()
		if not Navigation.HasFailed(self.Entity) then
			return true
		end
	end
	
	self.NavFailPos = dest_pos
	
	return false
end


-- LuciensSoldier Elite --
CombatStyles.LuciensSoldierElite = {}
CombatStyles.LuciensSoldierElite.CombatGroupType = CombatGroupTypes.BanditLike
CombatStyles.LuciensSoldierElite.CanSheatheWeapon = false
CombatStyles.LuciensSoldierElite.MovementTolerance = 0.45
CombatStyles.LuciensSoldierElite.TurnToFaceTolerance = 15
CombatStyles.LuciensSoldierElite.IsLeaderType = true
CombatStyles.LuciensSoldierElite.PreferOuterRing = true
CombatStyles.LuciensSoldierElite.ActionModifiers = {}
CombatStyles.LuciensSoldierElite.ActionModifiers.MinDistToTarget = 0.75
CombatStyles.LuciensSoldierElite.MoveFunction = CombatStyles.LuciensSoldier.MoveFunction
CombatStyles.LuciensSoldierElite.NonFormation = true
CombatStyles.LuciensSoldierElite.Limits = {}
CombatStyles.LuciensSoldierElite.Limits[CombatZones.Near] = 1.8
CombatStyles.LuciensSoldierElite.Limits[CombatZones.Middle] = 2.8
CombatStyles.LuciensSoldierElite.Limits[CombatZones.Far] = 6
CombatStyles.LuciensSoldierElite.Limits[CombatZones.Left] = 1.5
CombatStyles.LuciensSoldierElite.Limits[CombatZones.Right] = 1.5
CombatStyles.LuciensSoldierElite.Limits[CombatZones.Rear] = 1.5
CombatStyles.LuciensSoldierElite.Sequences = {}
CombatStyles.LuciensSoldierElite.Sequences[CombatSituations.Melee] = {
	"LuciensSoldierShotTooMuch",
	"LuciensSoldierMagicedTooMuch",
	"LuciensHeroFlourishResponse",
	"LuciensSoldierOrbSuckingResponse",
	"LuciensSoldierLieutenantCloseAttack",
	"LuciensSoldierLieutenantAttack",
	"FastBackOff"
}
CombatStyles.LuciensSoldierElite.Sequences[CombatSituations.HardBlocking] = {
	"LuciensSoldierLieutenantAttackOutOfBlock"
}
CombatStyles.LuciensSoldierElite.MinSecondsBetweenMeleeAttacks = 0.5
CombatStyles.LuciensSoldierElite.SecondsToWaitAfterTargetIsHit = 1
CombatStyles.LuciensSoldierElite.MinSecondsBetweenRangedAttacks = 7
CombatStyles.LuciensSoldierElite.CanBlock = true
CombatStyles.LuciensSoldierElite.BlockData = {}
CombatStyles.LuciensSoldierElite.BlockData.PrimaryBlockType = EBlockType.BLOCK_TYPE_STATIC
CombatStyles.LuciensSoldierElite.BlockData.SecondsForSuccessiveHitsToPrimaryBlock = 6
CombatStyles.LuciensSoldierElite.BlockData.NumberOfHitsToForcePrimaryBlock = 3
CombatStyles.LuciensSoldierElite.BlockData.SecondsToBlockFor = 3
CombatStyles.LuciensSoldierElite.CanEvadeShots = true
CombatStyles.LuciensSoldierElite.EvadeShotsData = {}
CombatStyles.LuciensSoldierElite.EvadeShotsData.TimeToCheckFor = 5
CombatStyles.LuciensSoldierElite.EvadeShotsData.TimeToEvadeFor = 2.5
CombatStyles.LuciensSoldierElite.EvadeShotsData.HitsToStartEvading = 3
CombatStyles.LuciensSoldierElite.EvadeAnimations = {
	"DodgeLeft",
    "DodgeRight"
}
CombatStyles.LuciensSoldierElite.AntiSpamData = {}
CombatStyles.LuciensSoldierElite.AntiSpamData.TimeToCheckFor = 5
CombatStyles.LuciensSoldierElite.AntiSpamData.ShotsToTrigger = 3
CombatStyles.LuciensSoldierElite.AntiSpamData.SpellsToTrigger = 3
CombatStyles.LuciensSoldierElite.AntiSpamData.TimeToAggroFor = 15
CombatStyles.LuciensSoldierElite.ValidStates = {}
CombatStyles.LuciensSoldierElite.ValidStates[CombatSituations.Melee] = {
	"AntiSpamCheck",
	"PlayBanterCombatComment",
	"WaitForActionToFinish",
	"UpdateWeapon",
	"CheckForBetterTarget",
	"LuciensSoldierSpellCasting",
	"PlayCombatSequence",
	"LuciensSoldierLieutenantOrbSuckingResponse",
	"LuciensSoldierMoveToFormationPos",
	"FaceTarget",
	"LuciensSoldierWaitMenacingly"
}
CombatStyles.LuciensSoldierElite.ValidStates[CombatSituations.HardBlocking] = CombatStyles.StandardBlockingCombatStates
CombatStyles.LuciensSoldierElite.ValidStates[CombatSituations.SoftBlocking] = CombatStyles.StandardBlockingCombatStates
CombatStyles.LuciensSoldierElite.ValidStates[CombatSituations.Dodging] = CombatStyles.StandardBlockingCombatStates
CombatStyles.LuciensSoldierElite.ValidStates[CombatSituations.GroupOrders] = CombatStyles.StandardGroupOrderStates
CombatStyles.LuciensSoldierElite.SecondsBetweenGroupActions = 30
CombatStyles.LuciensSoldierElite.PercentChanceThatGroupActionIsShoot = 25


-- Commandant --
CombatStyles.Commandant = {}
CombatStyles.Commandant.CombatGroupType = CombatGroupTypes.BanditLike
CombatStyles.Commandant.CanSheatheWeapon = false
CombatStyles.Commandant.MovementTolerance = 0.45
CombatStyles.Commandant.TurnToFaceTolerance = 15
CombatStyles.Commandant.IsLeaderType = true
CombatStyles.Commandant.PreferOuterRing = true
CombatStyles.Commandant.BalverineJumpDist = 2
CombatStyles.Commandant.ActionModifiers = {}
CombatStyles.Commandant.ActionModifiers.MinDistToTarget = 0.75
CombatStyles.Commandant.NonFormation = true
CombatStyles.Commandant.Limits = {}
CombatStyles.Commandant.Limits[CombatZones.Near] = 1.8
CombatStyles.Commandant.Limits[CombatZones.Middle] = 2.8
CombatStyles.Commandant.Limits[CombatZones.Far] = 6
CombatStyles.Commandant.Limits[CombatZones.Left] = 1.5
CombatStyles.Commandant.Limits[CombatZones.Right] = 1.5
CombatStyles.Commandant.Limits[CombatZones.Rear] = 1.5
CombatStyles.Commandant.Sequences = {}
CombatStyles.Commandant.Sequences[CombatSituations.Melee] = {
	{"LuciensSoldierShotTooMuch", 4},
	{"LuciensSoldierMagicedTooMuch", 4},
	"LuciensHeroFlourishResponse",
	"LuciensSoldierOrbSuckingResponse",
	"LuciensSoldierAttack",
	"LuciensSoldierCloseAttack",
	"FastBackOff"
}
CombatStyles.Commandant.Sequences[CombatSituations.GroupOrders] = {
	"LuciensSoldierGroupSpellAttack",
	"LuciensSoldierGroupAttack"
}
CombatStyles.Commandant.Sequences[CombatSituations.HardBlocking] = {
	"LuciensSoldierAttackOutOfBlock"
}
CombatStyles.Commandant.MinSecondsBetweenMeleeAttacks = 3
CombatStyles.Commandant.SecondsToWaitAfterTargetIsHit = 3
CombatStyles.Commandant.MinSecondsBetweenRangedAttacks = 10
CombatStyles.Commandant.CanBlock = true
CombatStyles.Commandant.BlockData = {}
CombatStyles.Commandant.BlockData.PrimaryBlockType = EBlockType.BLOCK_TYPE_STATIC
CombatStyles.Commandant.BlockData.SecondsForSuccessiveHitsToPrimaryBlock = 6
CombatStyles.Commandant.BlockData.NumberOfHitsToForcePrimaryBlock = 3
CombatStyles.Commandant.BlockData.SecondsToBlockFor = 3
CombatStyles.Commandant.DodgeAnimations = {
	"DodgeLeft",
    "DodgeRight"
}
CombatStyles.Commandant.CanEvadeShots = true
CombatStyles.Commandant.EvadeShotsData = {}
CombatStyles.Commandant.EvadeShotsData.TimeToCheckFor = 5
CombatStyles.Commandant.EvadeShotsData.TimeToEvadeFor = 3
CombatStyles.Commandant.EvadeShotsData.HitsToStartEvading = 4
CombatStyles.Commandant.EvadeAnimations = {
	"DodgeLeft",
    "DodgeRight"
}
CombatStyles.Commandant.ValidStates = {}
CombatStyles.Commandant.ValidStates[CombatSituations.Melee] = {
	"AntiSpamCheck",
	"PlayBanterCombatComment",
	"WaitForActionToFinish",
	"UpdateWeapon",
	"CheckForBetterTarget",
	"LuciensSoldierSpellCasting",
	"PlayCombatSequence",
	"LuciensSoldierMoveToFormationPos",
	"FaceTarget",
	"LuciensSoldierWaitMenacingly"
}
CombatStyles.Commandant.ValidStates[CombatSituations.SoftBlocking] = CombatStyles.StandardBlockingCombatStates
CombatStyles.Commandant.ValidStates[CombatSituations.HardBlocking] = CombatStyles.StandardBlockingCombatStates
CombatStyles.Commandant.ValidStates[CombatSituations.Dodging] = CombatStyles.StandardBlockingCombatStates
CombatStyles.Commandant.ValidStates[CombatSituations.GroupOrders] = CombatStyles.StandardGroupOrderStates
CombatStyles.Commandant.SecondsBetweenGroupActions = 40
CombatStyles.Commandant.PercentChanceThatGroupActionIsShoot = 25


-- Highwayman Darius QO250 --
CombatStyles.HighwaymanDariusQO250 = {}
CombatStyles.HighwaymanDariusQO250.CombatGroupType = CombatGroupTypes.HighwaymanLike
CombatStyles.HighwaymanDariusQO250.CanStrafe = true
CombatStyles.HighwaymanDariusQO250.CanSheatheWeapon = false
CombatStyles.HighwaymanDariusQO250.MovementTolerance = 0.45
CombatStyles.HighwaymanDariusQO250.PreferredRange = 4
CombatStyles.HighwaymanDariusQO250.ActionModifiers = {}
CombatStyles.HighwaymanDariusQO250.ActionModifiers.MinDistToTarget = 0.5
CombatStyles.HighwaymanDariusQO250.IsLeaderType = true
CombatStyles.HighwaymanDariusQO250.Limits = {}
CombatStyles.HighwaymanDariusQO250.Limits[CombatZones.Near] = 1.5
CombatStyles.HighwaymanDariusQO250.Limits[CombatZones.Middle] = 2.5
CombatStyles.HighwaymanDariusQO250.Limits[CombatZones.Far] = 5
CombatStyles.HighwaymanDariusQO250.Limits[CombatZones.Left] = 2
CombatStyles.HighwaymanDariusQO250.Limits[CombatZones.Right] = 2
CombatStyles.HighwaymanDariusQO250.Limits[CombatZones.Rear] = 2.5
CombatStyles.HighwaymanDariusQO250.StrafeActionSpeed = 1
CombatStyles.HighwaymanDariusQO250.EnterStrafeDist = 5
CombatStyles.HighwaymanDariusQO250.LeaveStrafeDelta = 2
CombatStyles.HighwaymanDariusQO250.FleeAnim = "Flee"
CombatStyles.HighwaymanDariusQO250.FleeIntoAnim = "FleeInto"
CombatStyles.HighwaymanDariusQO250.FleeOutOfAnim = "FleeOutOf"
CombatStyles.HighwaymanDariusQO250.Sequences = {}
CombatStyles.HighwaymanDariusQO250.Sequences[CombatSituations.Melee] = {
	"HighwaymanDariusMagicedTooMuch",
	"HighwaymanDariusShotTooMuch",
	"HighwaymanDariusFlourishResponse",
	{"HighwaymanDariusTeleportAttack", 5},
	"HighwaymanLeftAttack",
	"HighwaymanRightAttack",
	"HighwaymanRearAttack",
	"Idle"
}
CombatStyles.HighwaymanDariusQO250.Sequences[CombatSituations.Dodging] = {
	"HighwaymanDariusTeleportDodgeAttack"
}
CombatStyles.HighwaymanDariusQO250.RunIntoAttack = "RunIntoAttack"
CombatStyles.HighwaymanDariusQO250.MinSecondsBetweenMeleeAttacks = 0.5
CombatStyles.HighwaymanDariusQO250.SecondsToWaitAfterTargetIsHit = 1
CombatStyles.HighwaymanDariusQO250.MinSecondsBetweenRangedAttacks = 3
CombatStyles.HighwaymanDariusQO250.TimeAfterBeingStruckWithinWhichWeCanShoot = 2
CombatStyles.HighwaymanDariusQO250.CanBlock = true
CombatStyles.HighwaymanDariusQO250.BlockData = {}
CombatStyles.HighwaymanDariusQO250.BlockData.PrimaryBlockType = EBlockType.BLOCK_TYPE_DODGE_MELEE
CombatStyles.HighwaymanDariusQO250.BlockData.SecondsForSuccessiveHitsToPrimaryBlock = 8
CombatStyles.HighwaymanDariusQO250.BlockData.NumberOfHitsToForcePrimaryBlock = 2
CombatStyles.HighwaymanDariusQO250.BlockData.SecondsToBlockFor = 4
CombatStyles.HighwaymanDariusQO250.DodgeAnimations = {
	"RollLeft",
    "RollRight"
}
CombatStyles.HighwaymanDariusQO250.CanEvadeShots = false
CombatStyles.HighwaymanDariusQO250.AntiSpamData = {}
CombatStyles.HighwaymanDariusQO250.AntiSpamData.TimeToCheckFor = 5
CombatStyles.HighwaymanDariusQO250.AntiSpamData.ShotsToTrigger = 3
CombatStyles.HighwaymanDariusQO250.AntiSpamData.SpellsToTrigger = 2
CombatStyles.HighwaymanDariusQO250.AntiSpamData.TimeToAggroFor = 15
CombatStyles.HighwaymanDariusQO250.ValidStates = {}
CombatStyles.HighwaymanDariusQO250.ValidStates[CombatSituations.Melee] = {
	"AntiSpamCheck",
	"PlayBanterCombatComment",
	"WaitForActionToFinish",
	"UpdateWeapon",
	"OuterRingKeepDistance",
	"OuterRingSpreadOut",
	"PlayCombatSequence",
	"MoveToFormationPos",
	"FaceTarget"
}
CombatStyles.HighwaymanDariusQO250.ValidStates[CombatSituations.SoftBlocking] = CombatStyles.StandardBlockingCombatStates
CombatStyles.HighwaymanDariusQO250.ValidStates[CombatSituations.HardBlocking] = CombatStyles.StandardBlockingCombatStates
CombatStyles.HighwaymanDariusQO250.ValidStates[CombatSituations.Dodging] = CombatStyles.StandardBlockingCombatStates
CombatStyles.HighwaymanDariusQO250.ValidStates[CombatSituations.GroupOrders] = CombatStyles.StandardGroupOrderStates
CombatStyles.HighwaymanDariusQO250.ShootingBalanceData = {}
CombatStyles.HighwaymanDariusQO250.ShootingBalanceData.StartingChanceToHitWithFirearm = 0
CombatStyles.HighwaymanDariusQO250.ShootingBalanceData.MaxChanceToHitWithFirearmCap = 1
CombatStyles.HighwaymanDariusQO250.ShootingBalanceData.ChanceToHitModBonusRangeDistance = 9
CombatStyles.HighwaymanDariusQO250.ShootingBalanceData.ChanceToHitModSegmentLength = 3
CombatStyles.HighwaymanDariusQO250.ShootingBalanceData.ChanceToHitModPercentageIncrease = 0.05
CombatStyles.HighwaymanDariusQO250.ShootingBalanceData.ChanceToHitModConsecutiveShotPercentageIncrease = 0.08
CombatStyles.HighwaymanDariusQO250.ShootingBalanceData.ChanceToHitModConsecutiveShotsTimeFrame = 25
CombatStyles.HighwaymanDariusQO250.ShootingBalanceData.ChanceToHitModPercentageDecreasePerOneSpeed = 0.9
CombatStyles.HighwaymanDariusQO250.ShootingBalanceData.ChanceToHitModTargetInCoverPercentageMultiplier = 0.9
CombatStyles.HighwaymanDariusQO250.ShootingBalanceData.ChanceToHitModOffScreenPercentageMultiplier = 0.05
CombatStyles.HighwaymanDariusQO250.SecondsBetweenGroupActions = 30
CombatStyles.HighwaymanDariusQO250.PercentChanceThatGroupActionIsShoot = 25



-- uncomment for debug
-- GUI.DisplayMessageBox("fable2legacycombatstyles.lua successfully loaded!")
-- while (GUI.IsDisplayBoxActive()) do
	-- coroutine.yield()
-- end