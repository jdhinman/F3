
-- Minion --
CombatStyles.Minion = {}
CombatStyles.Minion.CombatGroupType = CombatGroupTypes.BanditLike
CombatStyles.Minion.CanSheatheWeapon = false
CombatStyles.Minion.CanStrafe = true
CombatStyles.Minion.EnterStrafeDist = 4.9
CombatStyles.Minion.TurnToFaceTolerance = 20
CombatStyles.Minion.MaxNavSpeed = ENavigationSpeed.NAV_SPEED_RUN
CombatStyles.Minion.DoRunIntoStrafe = true
CombatStyles.Minion.Limits = {}
CombatStyles.Minion.Limits[CombatZones.Near] = 1.95
CombatStyles.Minion.Limits[CombatZones.Middle] = 3.25
CombatStyles.Minion.Limits[CombatZones.Far] = 6.5
CombatStyles.Minion.Limits[CombatZones.Left] = 3.25
CombatStyles.Minion.Limits[CombatZones.Right] = 3.25
CombatStyles.Minion.Limits[CombatZones.Rear] = 3.25
CombatStyles.Minion.Sequences = {}
CombatStyles.Minion.Sequences[CombatSituations.Melee] = {
	"MinionHeroFlourishResponse",
	"MinionAttackOne",
	"MinionStepAttackTwo",
	"MinionNearAttackTwo",
	"MinionLeftAttack",
	"MinionRightAttack",
	{"MinionComboOne", 2},
	{"MinionPinningComboTwo", 10},
	{"MinionFlourish", 15},
	{"MinionSurrounded", 20},
    "MinionRearFlourish",
    "Advance",
    "BackOff",
	{"IdleStrafe", 5},
    "Idle",
	"OuterRingIdle"
}
CombatStyles.Minion.Sequences[CombatSituations.HardBlocking] = {
	"MinionAttackOutOfBlock"
}
CombatStyles.Minion.MinSecondsBetweenMeleeAttacks = 1.5
CombatStyles.Minion.SecondsToWaitAfterTargetIsHit = 2
CombatStyles.Minion.ValidStates = {}
CombatStyles.Minion.ValidStates[CombatSituations.Melee] = {
	"WaitForActionToFinish",
	"CheckForBetterTarget",
	"OuterRingKeepDistance",
	"OuterRingSpreadOut",
	"PlayCombatSequence",
	"MoveToFormationPos",
	"FaceTarget"
}
CombatStyles.Minion.ValidStates[CombatSituations.HardBlocking] = CombatStyles.StandardBlockingCombatStates
CombatStyles.Minion.CanBlock = true
CombatStyles.Minion.BlockData = {}
CombatStyles.Minion.BlockData.PrimaryBlockType = EBlockType.BLOCK_TYPE_STATIC
CombatStyles.Minion.BlockData.SecondsForSuccessiveHitsToPrimaryBlock = 6
CombatStyles.Minion.BlockData.NumberOfHitsToForcePrimaryBlock = 3
CombatStyles.Minion.BlockData.SecondsToBlockFor = 1.2
CombatStyles.Minion.CanEvadeShots = true
CombatStyles.Minion.EvadeShotsData = {}
CombatStyles.Minion.EvadeShotsData.TimeToCheckFor = 5
CombatStyles.Minion.EvadeShotsData.TimeToEvadeFor = 3
CombatStyles.Minion.EvadeShotsData.HitsToStartEvading = 3
CombatStyles.Minion.EvadeAnimations = {
	"CombatStrafeLeft",
    "CombatStrafeRight"
}



-- Minion Ranged --
CombatStyles.MinionRanged = {}
CombatStyles.MinionRanged.CombatGroupType = CombatGroupTypes.BanditLike
CombatStyles.MinionRanged.CanSheatheWeapon = false
CombatStyles.MinionRanged.ShootsInMelee = true
CombatStyles.MinionRanged.CanStrafe = true
CombatStyles.MinionRanged.EnterStrafeDist = 4.55
CombatStyles.MinionRanged.TurnToFaceTolerance = 20
CombatStyles.MinionRanged.PreferOuterRing = true
CombatStyles.MinionRanged.MaxNavSpeed = ENavigationSpeed.NAV_SPEED_RUN
CombatStyles.MinionRanged.DoRunIntoStrafe = true
CombatStyles.MinionRanged.Limits = {}
CombatStyles.MinionRanged.Limits[CombatZones.Near] = 1.95
CombatStyles.MinionRanged.Limits[CombatZones.Middle] = 3.9
CombatStyles.MinionRanged.Limits[CombatZones.Far] = 6.5
CombatStyles.MinionRanged.Limits[CombatZones.Left] = 3.25
CombatStyles.MinionRanged.Limits[CombatZones.Right] = 3.25
CombatStyles.MinionRanged.Limits[CombatZones.Rear] = 3.25
CombatStyles.MinionRanged.Sequences = {}
CombatStyles.MinionRanged.Sequences[CombatSituations.Melee] = {
	"MinionHeroFlourishResponse",
	"MinionAttackOne",
	"MinionStepAttackTwo",
	"MinionNearAttackTwo",
	"MinionLeftAttack",
	"MinionRightAttack",
	{"MinionComboOne", 2},
	{"MinionPinningComboTwo", 10},
	{"MinionFlourish", 15},
	{"MinionSurrounded", 20},
    "MinionRearFlourish",
    "Advance",
    "BackOff",
	{"IdleStrafe", 5},
    "Idle",
	"OuterRingIdle"
}
CombatStyles.MinionRanged.Sequences[CombatSituations.HardBlocking] = {
	"MinionAttackOutOfBlock"
}
CombatStyles.MinionRanged.MinSecondsBetweenMeleeAttacks = 1
CombatStyles.MinionRanged.SecondsToWaitAfterTargetIsHit = 2
CombatStyles.MinionRanged.MinSecondsBetweenRangedAttacks = 15
CombatStyles.MinionRanged.ValidStates = {}
CombatStyles.MinionRanged.ValidStates[CombatSituations.Melee] = {
	"WaitForActionToFinish",
	"CheckForBetterTarget",
	"GetTargetInSights",
	"OuterRingKeepDistance",
	"OuterRingSpreadOut",
	"MinionFireRangedWeapon",
	"PlayCombatSequence",
	"MoveToFormationPos",
	"FaceTarget"
}
CombatStyles.MinionRanged.ValidStates[CombatSituations.HardBlocking] = CombatStyles.StandardBlockingCombatStates
CombatStyles.MinionRanged.CanBlock = true
CombatStyles.MinionRanged.BlockData = {}
CombatStyles.MinionRanged.BlockData.PrimaryBlockType = EBlockType.BLOCK_TYPE_STATIC
CombatStyles.MinionRanged.BlockData.SecondsForSuccessiveHitsToPrimaryBlock = 6
CombatStyles.MinionRanged.BlockData.NumberOfHitsToForcePrimaryBlock = 3
CombatStyles.MinionRanged.BlockData.SecondsToBlockFor = 3
CombatStyles.MinionRanged.CanEvadeShots = true
CombatStyles.MinionRanged.EvadeShotsData = {}
CombatStyles.MinionRanged.EvadeShotsData.TimeToCheckFor = 5
CombatStyles.MinionRanged.EvadeShotsData.TimeToEvadeFor = 3
CombatStyles.MinionRanged.EvadeShotsData.HitsToStartEvading = 3
CombatStyles.MinionRanged.EvadeAnimations = {
	"CombatStrafeLeft",
    "CombatStrafeRight"
}
CombatStyles.MinionRanged.ShootingBalanceData = {}
CombatStyles.MinionRanged.ShootingBalanceData.StartingChanceToHitWithFirearm = 0
CombatStyles.MinionRanged.ShootingBalanceData.MaxChanceToHitWithFirearmCap = 0.35
CombatStyles.MinionRanged.ShootingBalanceData.ChanceToHitModBonusRangeDistance = 9
CombatStyles.MinionRanged.ShootingBalanceData.ChanceToHitModSegmentLength = 3
CombatStyles.MinionRanged.ShootingBalanceData.ChanceToHitModPercentageIncrease = 0.01
CombatStyles.MinionRanged.ShootingBalanceData.ChanceToHitModConsecutiveShotPercentageIncrease = 0.05
CombatStyles.MinionRanged.ShootingBalanceData.ChanceToHitModConsecutiveShotsTimeFrame = 21
CombatStyles.MinionRanged.ShootingBalanceData.ChanceToHitModPercentageDecreasePerOneSpeed = 0.5
CombatStyles.MinionRanged.ShootingBalanceData.ChanceToHitModTargetInCoverPercentageMultiplier = 0.9
CombatStyles.MinionRanged.ShootingBalanceData.ChanceToHitModOffScreenPercentageMultiplier = 0.15


-- RoboMinion --
CombatStyles.RoboMinion = {}
CombatStyles.RoboMinion.CombatGroupType = CombatGroupTypes.BanditLike
CombatStyles.RoboMinion.CanSheatheWeapon = false
CombatStyles.RoboMinion.CanStrafe = false
CombatStyles.RoboMinion.EnterStrafeDist = 0.001
CombatStyles.RoboMinion.TurnToFaceTolerance = 20
CombatStyles.RoboMinion.PreferOuterRing = true
CombatStyles.RoboMinion.MaxNavSpeed = ENavigationSpeed.NAV_SPEED_WALK
CombatStyles.RoboMinion.DoRunIntoStrafe = false
CombatStyles.RoboMinion.Limits = {}
CombatStyles.RoboMinion.Limits[CombatZones.Near] = 1.95
CombatStyles.RoboMinion.Limits[CombatZones.Middle] = 3.9
CombatStyles.RoboMinion.Limits[CombatZones.Far] = 6.5
CombatStyles.RoboMinion.Limits[CombatZones.Left] = 3.25
CombatStyles.RoboMinion.Limits[CombatZones.Right] = 3.25
CombatStyles.RoboMinion.Limits[CombatZones.Rear] = 3.25
CombatStyles.RoboMinion.Sequences = {}
CombatStyles.RoboMinion.Sequences[CombatSituations.Melee] = {
	{"RoboMinionFlourish", 10},
	"RoboMinionAttackOne",
	"RoboMinionStepAttackTwo",
	"RoboMinionNearAttackTwo",
	"RoboMinionRearFlourish",
	"Idle"
}
CombatStyles.RoboMinion.Sequences[CombatSituations.HardBlocking] = {
	"RoboMinionAttackOutOfBlock"
}
CombatStyles.RoboMinion.MinSecondsBetweenMeleeAttacks = 0.1
CombatStyles.RoboMinion.SecondsToWaitAfterTargetIsHit = 0.5
CombatStyles.RoboMinion.ValidStates = {}
CombatStyles.RoboMinion.ValidStates[CombatSituations.Melee] = {
	"WaitForActionToFinish",
	"CheckForBetterTarget",
	"GetTargetInSights",
	"RoboMinionSpamResponse",
	"PlayCombatSequence",
	"RoboMinionRapidDistanceClosing",
	"MoveToFormationPos",
	"FaceTarget"
}
CombatStyles.RoboMinion.ValidStates[CombatSituations.HardBlocking] = CombatStyles.StandardBlockingCombatStates
CombatStyles.RoboMinion.CanBlock = true
CombatStyles.RoboMinion.BlockData = {}
CombatStyles.RoboMinion.BlockData.PrimaryBlockType = EBlockType.BLOCK_TYPE_STATIC
CombatStyles.RoboMinion.BlockData.SecondsForSuccessiveHitsToPrimaryBlock = 6
CombatStyles.RoboMinion.BlockData.NumberOfHitsToForcePrimaryBlock = 2
CombatStyles.RoboMinion.BlockData.SecondsToBlockFor = 2
CombatStyles.RoboMinion.CanEvadeShots = true
CombatStyles.RoboMinion.EvadeShotsData = {}
CombatStyles.RoboMinion.EvadeShotsData.TimeToCheckFor = 5
CombatStyles.RoboMinion.EvadeShotsData.TimeToEvadeFor = 3
CombatStyles.RoboMinion.EvadeShotsData.HitsToStartEvading = 3
CombatStyles.RoboMinion.EvadeAnimations = {
	"CombatStrafeLeft",
    "CombatStrafeRight"
}


-- Colckwork Soldier DLC2 --
CombatStyles.DLC2ColckworkSoldier = {}
CombatStyles.DLC2ColckworkSoldier.CombatGroupType = CombatGroupTypes.BanditLike
CombatStyles.DLC2ColckworkSoldier.CanSheatheWeapon = false
CombatStyles.DLC2ColckworkSoldier.CanFightUnarmed = true
CombatStyles.DLC2ColckworkSoldier.CanStrafe = false
CombatStyles.DLC2ColckworkSoldier.EnterStrafeDist = 0.001
CombatStyles.DLC2ColckworkSoldier.TurnToFaceTolerance = 20
CombatStyles.DLC2ColckworkSoldier.PreferOuterRing = true
CombatStyles.DLC2ColckworkSoldier.MaxNavSpeed = ENavigationSpeed.NAV_SPEED_WALK
CombatStyles.DLC2ColckworkSoldier.DoRunIntoStrafe = false
CombatStyles.DLC2ColckworkSoldier.Limits = {}
CombatStyles.DLC2ColckworkSoldier.Limits[CombatZones.Near] = 1.95
CombatStyles.DLC2ColckworkSoldier.Limits[CombatZones.Middle] = 3.9
CombatStyles.DLC2ColckworkSoldier.Limits[CombatZones.Far] = 6.5
CombatStyles.DLC2ColckworkSoldier.Limits[CombatZones.Left] = 3.25
CombatStyles.DLC2ColckworkSoldier.Limits[CombatZones.Right] = 3.25
CombatStyles.DLC2ColckworkSoldier.Limits[CombatZones.Rear] = 3.25
CombatStyles.DLC2ColckworkSoldier.Sequences = {}
CombatStyles.DLC2ColckworkSoldier.Sequences[CombatSituations.Melee] = {
	"RoboMinionAttackOne",
	"ClockworkSoldierAttackTwo",
	"ClockworkSoldierAttackOneTwo",
	"ClockworkSoldierFlourish",
	"ClockworkSoldierRearFlourish",
	"Idle"
}
CombatStyles.DLC2ColckworkSoldier.Sequences[CombatSituations.HardBlocking] = {
	"ClockworkSoldierAttackOutOfBlock"
}
CombatStyles.DLC2ColckworkSoldier.MinSecondsBetweenMeleeAttacks = 0.1
CombatStyles.DLC2ColckworkSoldier.SecondsToWaitAfterTargetIsHit = 0.5
CombatStyles.DLC2ColckworkSoldier.ValidStates = {}
CombatStyles.DLC2ColckworkSoldier.ValidStates[CombatSituations.Melee] = {
	"WaitForActionToFinish",
	"CheckForBetterTarget",
	"GetTargetInSights",
	"ClockworkSoldierSpamResponse",
	"PlayCombatSequence",
	"MoveToFormationPos",
	"FaceTarget"
}
CombatStyles.DLC2ColckworkSoldier.ValidStates[CombatSituations.HardBlocking] = CombatStyles.StandardBlockingCombatStates
CombatStyles.DLC2ColckworkSoldier.CanBlock = true
CombatStyles.DLC2ColckworkSoldier.BlockData = {}
CombatStyles.DLC2ColckworkSoldier.BlockData.PrimaryBlockType = EBlockType.BLOCK_TYPE_STATIC
CombatStyles.DLC2ColckworkSoldier.BlockData.SecondsForSuccessiveHitsToPrimaryBlock = 6
CombatStyles.DLC2ColckworkSoldier.BlockData.NumberOfHitsToForcePrimaryBlock = 2
CombatStyles.DLC2ColckworkSoldier.BlockData.SecondsToBlockFor = 2
CombatStyles.DLC2ColckworkSoldier.CanEvadeShots = true
CombatStyles.DLC2ColckworkSoldier.EvadeShotsData = {}
CombatStyles.DLC2ColckworkSoldier.EvadeShotsData.TimeToCheckFor = 5
CombatStyles.DLC2ColckworkSoldier.EvadeShotsData.TimeToEvadeFor = 3
CombatStyles.DLC2ColckworkSoldier.EvadeShotsData.HitsToStartEvading = 3
CombatStyles.DLC2ColckworkSoldier.EvadeAnimations = {
	"CombatStrafeLeft",
    "CombatStrafeRight"
}



-- Minion Ranged Turret --
CombatStyles.MinionRangedTurret = DeepCopyTable(CombatStyles.MinionRanged)
CombatStyles.MinionRangedTurret.CombatGroupType = CombatGroupTypes.BanditLike
CombatStyles.MinionRangedTurret.NonFormation = true
CombatStyles.MinionRangedTurret.CanStandOffAndShoot = "Turret"
CombatStyles.MinionRangedTurret.ValidStates = {}
CombatStyles.MinionRangedTurret.ValidStates[CombatSituations.Melee] = {
	"WaitForActionToFinish",
	"TurretCheckTargetProximity",
	"CheckForBetterTarget",
	"MoveToFiringPosition",
	"MinionFireRangedWeapon",
	"PlayCombatSequence",
	"FaceTarget",
	"IdleWithRangedWeapon"
}
CombatStyles.MinionRangedTurret.TurretBalanceData = {}
CombatStyles.MinionRangedTurret.TurretBalanceData.DistanceToMoveBackToShootingPosition = 1.3
CombatStyles.MinionRangedTurret.TurretBalanceData.DistanceOverWhichToFindNewShootingPosition = 6.5
CombatStyles.MinionRangedTurret.TurretBalanceData.NonTurretCombatStyle = "MinionRanged"

-- Minion Ranged Turret NoWait --
CombatStyles.MinionRangedTurretNoWait = DeepCopyTable(CombatStyles.MinionRangedTurret)
CombatStyles.MinionRangedTurretNoWait.MoveToFiringPosNoWait = true



-- uncomment for debug
-- GUI.DisplayMessageBox("minioncombatstyles.lua successfully loaded!")
-- while (GUI.IsDisplayBoxActive()) do
	-- coroutine.yield()
-- end