
-- HollowMan Easy --
CombatStyles.HollowManEasy = {}
CombatStyles.HollowManEasy.CombatGroupType = CombatGroupTypes.HollowManLike
CombatStyles.HollowManEasy.CanSheatheWeapon = false
CombatStyles.HollowManEasy.DualWieldMeleeSlot = DummyObjects.HAND_LEFT
CombatStyles.HollowManEasy.NonFormation = true
CombatStyles.HollowManEasy.TurnToFaceTolerance = 15
CombatStyles.HollowManEasy.PreferredRange = 1.5
CombatStyles.HollowManEasy.CanFightUnarmed = true
CombatStyles.HollowManEasy.NoWispMove = true
CombatStyles.HollowManEasy.Limits = {}
CombatStyles.HollowManEasy.Limits[CombatZones.Near] = 1.3
CombatStyles.HollowManEasy.Limits[CombatZones.Middle] = 2.5
CombatStyles.HollowManEasy.Limits[CombatZones.Far] = 5
CombatStyles.HollowManEasy.Limits[CombatZones.Left] = 1
CombatStyles.HollowManEasy.Limits[CombatZones.Right] = 1
CombatStyles.HollowManEasy.Limits[CombatZones.Rear] = 1
CombatStyles.HollowManEasy.MinSecondsBetweenMeleeAttacks = 3
CombatStyles.HollowManEasy.SecondsToWaitAfterTargetIsHit = 3
CombatStyles.HollowManEasy.SecondsToWaitAfterTargetIsAttacked = 1.5
CombatStyles.HollowManEasy.MaxNavSpeed = ENavigationSpeed.NAV_SPEED_WALK
CombatStyles.HollowManEasy.HollowManParams = {}
CombatStyles.HollowManEasy.HollowManParams.WispSpeed = 1.3
CombatStyles.HollowManEasy.HollowManParams.MinimumSpawnDist = 1.75
CombatStyles.HollowManEasy.HollowManParams.SpawnDistRandom = 1.25
CombatStyles.HollowManEasy.HollowManParams.TargetSpeedToDistMultiplier = 1.2
CombatStyles.HollowManEasy.HollowManParams.DistForMove = 6
CombatStyles.HollowManEasy.HollowManParams.ReturnUndergroundDist = 10
CombatStyles.HollowManEasy.HollowManParams.RiseAttackPercentageChance = 0
CombatStyles.HollowManEasy.HollowManParams.RunPercentageChance = 0
CombatStyles.HollowManEasy.HollowManParams.RunPercentageChanceAgainstRanged = 0
CombatStyles.HollowManEasy.HollowManParams.RunAttackPercentageChance = 0
CombatStyles.HollowManEasy.Sequences = {}
CombatStyles.HollowManEasy.Sequences[CombatSituations.Melee] = {
	"HollowmanCloseAttackCombo",
	"HollowmanFarAttackCombo",
	"HollowmanAttackCombo",
	"IdleLong",
	"IdleStrafeLeft",
	"IdleStrafeRight",
	"BackOff",
	"HollowManAdvance"
}
CombatStyles.HollowManEasy.ValidStates = {}
CombatStyles.HollowManEasy.ValidStates[CombatSituations.Melee] = {
	"WaitForActionToFinish",
	"HollowManBuggerOffAndDie",
	"CheckForBetterTarget",
	"PlayCombatSequence",
	"HollowManCharge",
	"HollowManMove",
	"MoveToFormationPos",
	"FaceTarget"
}


-- HollowMan Easy NoWisp --
CombatStyles.HollowManEasyNoWisp = {}
CombatStyles.HollowManEasyNoWisp.CombatGroupType = CombatGroupTypes.HollowManLike
CombatStyles.HollowManEasyNoWisp.CanSheatheWeapon = false
CombatStyles.HollowManEasyNoWisp.DualWieldMeleeSlot = DummyObjects.HAND_LEFT
CombatStyles.HollowManEasyNoWisp.NonFormation = true
CombatStyles.HollowManEasyNoWisp.TurnToFaceTolerance = 15
CombatStyles.HollowManEasyNoWisp.PreferredRange = 1.5
CombatStyles.HollowManEasyNoWisp.CanFightUnarmed = true
CombatStyles.HollowManEasyNoWisp.NoWispMove = true
CombatStyles.HollowManEasyNoWisp.NoWispSpawn = true
CombatStyles.HollowManEasyNoWisp.Limits = {}
CombatStyles.HollowManEasyNoWisp.Limits[CombatZones.Near] = 1.3
CombatStyles.HollowManEasyNoWisp.Limits[CombatZones.Middle] = 2.5
CombatStyles.HollowManEasyNoWisp.Limits[CombatZones.Far] = 5
CombatStyles.HollowManEasyNoWisp.Limits[CombatZones.Left] = 1
CombatStyles.HollowManEasyNoWisp.Limits[CombatZones.Right] = 1
CombatStyles.HollowManEasyNoWisp.Limits[CombatZones.Rear] = 1
CombatStyles.HollowManEasyNoWisp.MinSecondsBetweenMeleeAttacks = 3
CombatStyles.HollowManEasyNoWisp.SecondsToWaitAfterTargetIsHit = 3
CombatStyles.HollowManEasyNoWisp.SecondsToWaitAfterTargetIsAttacked = 1.5
CombatStyles.HollowManEasyNoWisp.MaxNavSpeed = ENavigationSpeed.NAV_SPEED_WALK
CombatStyles.HollowManEasyNoWisp.HollowManParams = {}
CombatStyles.HollowManEasyNoWisp.HollowManParams.WispSpeed = 1.3
CombatStyles.HollowManEasyNoWisp.HollowManParams.MinimumSpawnDist = 1.75
CombatStyles.HollowManEasyNoWisp.HollowManParams.SpawnDistRandom = 1.25
CombatStyles.HollowManEasyNoWisp.HollowManParams.TargetSpeedToDistMultiplier = 1.2
CombatStyles.HollowManEasyNoWisp.HollowManParams.DistForMove = 6
CombatStyles.HollowManEasyNoWisp.HollowManParams.ReturnUndergroundDist = 10
CombatStyles.HollowManEasyNoWisp.HollowManParams.RiseAttackPercentageChance = 0
CombatStyles.HollowManEasyNoWisp.HollowManParams.RunPercentageChance = 100
CombatStyles.HollowManEasyNoWisp.HollowManParams.RunPercentageChanceAgainstRanged = 100
CombatStyles.HollowManEasyNoWisp.HollowManParams.RunAttackPercentageChance = 0
CombatStyles.HollowManEasyNoWisp.Sequences = {}
CombatStyles.HollowManEasyNoWisp.Sequences[CombatSituations.Melee] = {
	"HollowmanCloseAttackCombo",
	"HollowmanFarAttackCombo",
	"HollowmanAttackCombo",
	"IdleLong",
	"IdleStrafeLeft",
	"IdleStrafeRight",
	"BackOff",
	"HollowManAdvance"
}
CombatStyles.HollowManEasyNoWisp.ValidStates = {}
CombatStyles.HollowManEasyNoWisp.ValidStates[CombatSituations.Melee] = {
	"WaitForActionToFinish",
	"HollowManBuggerOffAndDie",
	"CheckForBetterTarget",
	"PlayCombatSequence",
	"HollowManCharge",
	"HollowManMove",
	"MoveToFormationPos",
	"FaceTarget"
}


-- HollowMan --
CombatStyles.HollowMan = {}
CombatStyles.HollowMan.CombatGroupType = CombatGroupTypes.HollowManLike
CombatStyles.HollowMan.CanSheatheWeapon = false
CombatStyles.HollowMan.DualWieldMeleeSlot = DummyObjects.HAND_LEFT
CombatStyles.HollowMan.NonFormation = true
CombatStyles.HollowMan.TurnToFaceTolerance = 15
CombatStyles.HollowMan.PreferredRange = 1.5
CombatStyles.HollowMan.CanFightUnarmed = true
CombatStyles.HollowMan.NoWispMove = true
CombatStyles.HollowMan.Limits = {}
CombatStyles.HollowMan.Limits[CombatZones.Near] = 1.3
CombatStyles.HollowMan.Limits[CombatZones.Middle] = 2.5
CombatStyles.HollowMan.Limits[CombatZones.Far] = 5
CombatStyles.HollowMan.Limits[CombatZones.Left] = 1
CombatStyles.HollowMan.Limits[CombatZones.Right] = 1
CombatStyles.HollowMan.Limits[CombatZones.Rear] = 1
CombatStyles.HollowMan.MinSecondsBetweenMeleeAttacks = 2
CombatStyles.HollowMan.SecondsToWaitAfterTargetIsHit = 2
CombatStyles.HollowMan.SecondsToWaitAfterTargetIsAttacked = 1.5
CombatStyles.HollowMan.MaxNavSpeed = ENavigationSpeed.NAV_SPEED_WALK
CombatStyles.HollowMan.HollowManParams = {}
CombatStyles.HollowMan.HollowManParams.WispSpeed = 1.5
CombatStyles.HollowMan.HollowManParams.MinimumSpawnDist = 1.75
CombatStyles.HollowMan.HollowManParams.SpawnDistRandom = 1.25
CombatStyles.HollowMan.HollowManParams.TargetSpeedToDistMultiplier = 1.2
CombatStyles.HollowMan.HollowManParams.DistForMove = 6
CombatStyles.HollowMan.HollowManParams.ReturnUndergroundDist = 10
CombatStyles.HollowMan.HollowManParams.RiseAttackPercentageChance = 0
CombatStyles.HollowMan.HollowManParams.RunPercentageChance = 100
CombatStyles.HollowMan.HollowManParams.RunPercentageChanceAgainstRanged = 100
CombatStyles.HollowMan.HollowManParams.RunAttackPercentageChance = 0
CombatStyles.HollowMan.Sequences = {}
CombatStyles.HollowMan.Sequences[CombatSituations.Melee] = {
	"HollowmanCloseAttackCombo",
	"HollowmanFarAttackCombo",
	"HollowmanAttackCombo",
	"HollowmanAltCloseAttackCombo",
	"HollowmanAltFarAttackCombo",
	"HollowmanAltAttackCombo",
	"IdleLong",
	"IdleStrafeLeft",
	"IdleStrafeRight",
	"BackOff",
	"HollowManAdvance"
}
CombatStyles.HollowMan.ValidStates = {}
CombatStyles.HollowMan.ValidStates[CombatSituations.Melee] = {
	"WaitForActionToFinish",
	"HollowManBuggerOffAndDie",
	"CheckForBetterTarget",
	"PlayCombatSequence",
	"HollowManCharge",
	"HollowManMove",
	"MoveToFormationPos",
	"FaceTarget"
}


-- HollowMan WithSpell --
CombatStyles.HollowManWithSpell = {}
CombatStyles.HollowManWithSpell.CombatGroupType = CombatGroupTypes.HollowManLike
CombatStyles.HollowManWithSpell.CanSheatheWeapon = false
CombatStyles.HollowManWithSpell.DualWieldMeleeSlot = DummyObjects.HAND_LEFT
CombatStyles.HollowManWithSpell.NonFormation = true
CombatStyles.HollowManWithSpell.TurnToFaceTolerance = 15
CombatStyles.HollowManWithSpell.PreferredRange = 1.5
CombatStyles.HollowManWithSpell.CanFightUnarmed = true
CombatStyles.HollowManWithSpell.NoWispMove = true
CombatStyles.HollowManWithSpell.Limits = {}
CombatStyles.HollowManWithSpell.Limits[CombatZones.Near] = 1.3
CombatStyles.HollowManWithSpell.Limits[CombatZones.Middle] = 2.5
CombatStyles.HollowManWithSpell.Limits[CombatZones.Far] = 5
CombatStyles.HollowManWithSpell.Limits[CombatZones.Left] = 1
CombatStyles.HollowManWithSpell.Limits[CombatZones.Right] = 1
CombatStyles.HollowManWithSpell.Limits[CombatZones.Rear] = 2
CombatStyles.HollowManWithSpell.MinSecondsBetweenMeleeAttacks = 2
CombatStyles.HollowManWithSpell.SecondsToWaitAfterTargetIsHit = 2
CombatStyles.HollowManWithSpell.SecondsToWaitAfterTargetIsAttacked = 1.5
CombatStyles.HollowManWithSpell.MaxNavSpeed = ENavigationSpeed.NAV_SPEED_WALK
CombatStyles.HollowManWithSpell.HollowManParams = {}
CombatStyles.HollowManWithSpell.HollowManParams.WispSpeed = 1.5
CombatStyles.HollowManWithSpell.HollowManParams.MinimumSpawnDist = 1.75
CombatStyles.HollowManWithSpell.HollowManParams.SpawnDistRandom = 1.25
CombatStyles.HollowManWithSpell.HollowManParams.TargetSpeedToDistMultiplier = 1.2
CombatStyles.HollowManWithSpell.HollowManParams.DistForMove = 6
CombatStyles.HollowManWithSpell.HollowManParams.ReturnUndergroundDist = 10
CombatStyles.HollowManWithSpell.HollowManParams.RiseAttackPercentageChance = 0
CombatStyles.HollowManWithSpell.HollowManParams.RunPercentageChance = 100
CombatStyles.HollowManWithSpell.HollowManParams.RunPercentageChanceAgainstRanged = 100
CombatStyles.HollowManWithSpell.HollowManParams.RunAttackPercentageChance = 0
CombatStyles.HollowManWithSpell.Sequences = {}
CombatStyles.HollowManWithSpell.Sequences[CombatSituations.Melee] = {
	{"HollowmanShockCast", 10},
	{"HollowmanRearAttack", 5},
	"HollowmanCloseAttackCombo",
	"HollowmanFarAttackCombo",
	"HollowmanAttackCombo",
	"HollowmanAltCloseAttackCombo",
	"HollowmanAltFarAttackCombo",
	"HollowmanAltAttackCombo",
	"IdleLong",
	"IdleStrafeLeft",
	"IdleStrafeRight",
	"BackOff",
	"HollowManAdvance"
}
CombatStyles.HollowManWithSpell.ValidStates = {}
CombatStyles.HollowManWithSpell.ValidStates[CombatSituations.Melee] = {
	"WaitForActionToFinish",
	"HollowManBuggerOffAndDie",
	"CheckForBetterTarget",
	"PlayCombatSequence",
	"HollowManCharge",
	"HollowManMove",
	"MoveToFormationPos",
	"FaceTarget"
}


-- HollowMan WithFireSpell --
CombatStyles.HollowManWithFireSpell = {}
CombatStyles.HollowManWithFireSpell.CombatGroupType = CombatGroupTypes.HollowManLike
CombatStyles.HollowManWithFireSpell.CanSheatheWeapon = false
CombatStyles.HollowManWithFireSpell.DualWieldMeleeSlot = DummyObjects.HAND_LEFT
CombatStyles.HollowManWithFireSpell.NonFormation = true
CombatStyles.HollowManWithFireSpell.TurnToFaceTolerance = 15
CombatStyles.HollowManWithFireSpell.PreferredRange = 1.5
CombatStyles.HollowManWithFireSpell.CanFightUnarmed = true
CombatStyles.HollowManWithFireSpell.NoWispMove = true
CombatStyles.HollowManWithFireSpell.Limits = {}
CombatStyles.HollowManWithFireSpell.Limits[CombatZones.Near] = 1.3
CombatStyles.HollowManWithFireSpell.Limits[CombatZones.Middle] = 2.5
CombatStyles.HollowManWithFireSpell.Limits[CombatZones.Far] = 5
CombatStyles.HollowManWithFireSpell.Limits[CombatZones.Left] = 1
CombatStyles.HollowManWithFireSpell.Limits[CombatZones.Right] = 1
CombatStyles.HollowManWithFireSpell.Limits[CombatZones.Rear] = 2
CombatStyles.HollowManWithFireSpell.MinSecondsBetweenMeleeAttacks = 2
CombatStyles.HollowManWithFireSpell.SecondsToWaitAfterTargetIsHit = 2
CombatStyles.HollowManWithFireSpell.SecondsToWaitAfterTargetIsAttacked = 1.5
CombatStyles.HollowManWithFireSpell.MaxNavSpeed = ENavigationSpeed.NAV_SPEED_WALK
CombatStyles.HollowManWithFireSpell.HollowManParams = {}
CombatStyles.HollowManWithFireSpell.HollowManParams.WispSpeed = 1.5
CombatStyles.HollowManWithFireSpell.HollowManParams.MinimumSpawnDist = 1.75
CombatStyles.HollowManWithFireSpell.HollowManParams.SpawnDistRandom = 1.25
CombatStyles.HollowManWithFireSpell.HollowManParams.TargetSpeedToDistMultiplier = 1.2
CombatStyles.HollowManWithFireSpell.HollowManParams.DistForMove = 6
CombatStyles.HollowManWithFireSpell.HollowManParams.ReturnUndergroundDist = 10
CombatStyles.HollowManWithFireSpell.HollowManParams.RiseAttackPercentageChance = 0
CombatStyles.HollowManWithFireSpell.HollowManParams.RunPercentageChance = 100
CombatStyles.HollowManWithFireSpell.HollowManParams.RunPercentageChanceAgainstRanged = 100
CombatStyles.HollowManWithFireSpell.HollowManParams.RunAttackPercentageChance = 0
CombatStyles.HollowManWithFireSpell.Sequences = {}
CombatStyles.HollowManWithFireSpell.Sequences[CombatSituations.Melee] = {
	"HollowmanFireAoECast",
	"HollowmanFireCast",
	"HollowmanFireRearAttack",
	"HollowmanCloseAttackCombo",
	"HollowmanFarAttackCombo",
	"HollowmanAttackCombo",
	"HollowmanAltCloseAttackCombo",
	"HollowmanAltFarAttackCombo",
	"HollowmanAltAttackCombo",
	"IdleLong",
	"IdleStrafeLeft",
	"IdleStrafeRight",
	"BackOff",
	"HollowManAdvance"
}
CombatStyles.HollowManWithFireSpell.ValidStates = {}
CombatStyles.HollowManWithFireSpell.ValidStates[CombatSituations.Melee] = {
	"WaitForActionToFinish",
	"HollowManBuggerOffAndDie",
	"CheckForBetterTarget",
	"PlayCombatSequence",
	"HollowManCharge",
	"HollowManMove",
	"MoveToFormationPos",
	"FaceTarget"
}


-- HollowMan WithFireSpell NoWisp --
CombatStyles.HollowManWithFireSpellNoWisp = {}
CombatStyles.HollowManWithFireSpellNoWisp.CombatGroupType = CombatGroupTypes.HollowManLike
CombatStyles.HollowManWithFireSpellNoWisp.CanSheatheWeapon = false
CombatStyles.HollowManWithFireSpellNoWisp.DualWieldMeleeSlot = DummyObjects.HAND_LEFT
CombatStyles.HollowManWithFireSpellNoWisp.NonFormation = true
CombatStyles.HollowManWithFireSpellNoWisp.TurnToFaceTolerance = 15
CombatStyles.HollowManWithFireSpellNoWisp.PreferredRange = 1.5
CombatStyles.HollowManWithFireSpellNoWisp.CanFightUnarmed = true
CombatStyles.HollowManWithFireSpellNoWisp.NoWispMove = true
CombatStyles.HollowManWithFireSpellNoWisp.NoWispSpawn = true
CombatStyles.HollowManWithFireSpellNoWisp.Limits = {}
CombatStyles.HollowManWithFireSpellNoWisp.Limits[CombatZones.Near] = 1.3
CombatStyles.HollowManWithFireSpellNoWisp.Limits[CombatZones.Middle] = 2.5
CombatStyles.HollowManWithFireSpellNoWisp.Limits[CombatZones.Far] = 5
CombatStyles.HollowManWithFireSpellNoWisp.Limits[CombatZones.Left] = 1
CombatStyles.HollowManWithFireSpellNoWisp.Limits[CombatZones.Right] = 1
CombatStyles.HollowManWithFireSpellNoWisp.Limits[CombatZones.Rear] = 2
CombatStyles.HollowManWithFireSpellNoWisp.MinSecondsBetweenMeleeAttacks = 2
CombatStyles.HollowManWithFireSpellNoWisp.SecondsToWaitAfterTargetIsHit = 2
CombatStyles.HollowManWithFireSpellNoWisp.SecondsToWaitAfterTargetIsAttacked = 1.5
CombatStyles.HollowManWithFireSpellNoWisp.MaxNavSpeed = ENavigationSpeed.NAV_SPEED_WALK
CombatStyles.HollowManWithFireSpellNoWisp.HollowManParams = {}
CombatStyles.HollowManWithFireSpellNoWisp.HollowManParams.WispSpeed = 1.5
CombatStyles.HollowManWithFireSpellNoWisp.HollowManParams.MinimumSpawnDist = 1.75
CombatStyles.HollowManWithFireSpellNoWisp.HollowManParams.SpawnDistRandom = 1.25
CombatStyles.HollowManWithFireSpellNoWisp.HollowManParams.TargetSpeedToDistMultiplier = 1.2
CombatStyles.HollowManWithFireSpellNoWisp.HollowManParams.DistForMove = 6
CombatStyles.HollowManWithFireSpellNoWisp.HollowManParams.ReturnUndergroundDist = 10
CombatStyles.HollowManWithFireSpellNoWisp.HollowManParams.RiseAttackPercentageChance = 0
CombatStyles.HollowManWithFireSpellNoWisp.HollowManParams.RunPercentageChance = 100
CombatStyles.HollowManWithFireSpellNoWisp.HollowManParams.RunPercentageChanceAgainstRanged = 100
CombatStyles.HollowManWithFireSpellNoWisp.HollowManParams.RunAttackPercentageChance = 0
CombatStyles.HollowManWithFireSpellNoWisp.Sequences = {}
CombatStyles.HollowManWithFireSpellNoWisp.Sequences[CombatSituations.Melee] = {
	"HollowmanFireAoECast",
	"HollowmanFireCast",
	"HollowmanFireRearAttack",
	"HollowmanCloseAttackCombo",
	"HollowmanFarAttackCombo",
	"HollowmanAttackCombo",
	"HollowmanAltCloseAttackCombo",
	"HollowmanAltFarAttackCombo",
	"HollowmanAltAttackCombo",
	"IdleLong",
	"IdleStrafeLeft",
	"IdleStrafeRight",
	"BackOff",
	"HollowManAdvance"
}
CombatStyles.HollowManWithFireSpellNoWisp.ValidStates = {}
CombatStyles.HollowManWithFireSpellNoWisp.ValidStates[CombatSituations.Melee] = {
	"WaitForActionToFinish",
	"HollowManBuggerOffAndDie",
	"CheckForBetterTarget",
	"PlayCombatSequence",
	"HollowManCharge",
	"HollowManMove",
	"MoveToFormationPos",
	"FaceTarget"
}


-- HollowMan Elite --
CombatStyles.HollowManElite = {}
CombatStyles.HollowManElite.CombatGroupType = CombatGroupTypes.HollowManLike
CombatStyles.HollowManElite.CanSheatheWeapon = false
CombatStyles.HollowManElite.DualWieldMeleeSlot = DummyObjects.HAND_LEFT
CombatStyles.HollowManElite.NonFormation = true
CombatStyles.HollowManElite.TurnToFaceTolerance = 15
CombatStyles.HollowManElite.PreferredRange = 1.5
CombatStyles.HollowManElite.CanFightUnarmed = true
CombatStyles.HollowManElite.NoWispMove = true
CombatStyles.HollowManElite.Limits = {}
CombatStyles.HollowManElite.Limits[CombatZones.Near] = 1.3
CombatStyles.HollowManElite.Limits[CombatZones.Middle] = 2.5
CombatStyles.HollowManElite.Limits[CombatZones.Far] = 5
CombatStyles.HollowManElite.Limits[CombatZones.Left] = 1
CombatStyles.HollowManElite.Limits[CombatZones.Right] = 1
CombatStyles.HollowManElite.Limits[CombatZones.Rear] = 1
CombatStyles.HollowManElite.MinSecondsBetweenMeleeAttacks = 1
CombatStyles.HollowManElite.SecondsToWaitAfterTargetIsHit = 1
CombatStyles.HollowManElite.SecondsToWaitAfterTargetIsAttacked = 0
CombatStyles.HollowManElite.MaxNavSpeed = ENavigationSpeed.NAV_SPEED_WALK
CombatStyles.HollowManElite.HollowManParams = {}
CombatStyles.HollowManElite.HollowManParams.WispSpeed = 1
CombatStyles.HollowManElite.HollowManParams.MinimumSpawnDist = 1.75
CombatStyles.HollowManElite.HollowManParams.SpawnDistRandom = 1.25
CombatStyles.HollowManElite.HollowManParams.TargetSpeedToDistMultiplier = 1.2
CombatStyles.HollowManElite.HollowManParams.DistForMove = 6
CombatStyles.HollowManElite.HollowManParams.ReturnUndergroundDist = 10
CombatStyles.HollowManElite.HollowManParams.RiseAttackPercentageChance = 100
CombatStyles.HollowManElite.HollowManParams.RunPercentageChance = 100
CombatStyles.HollowManElite.HollowManParams.RunPercentageChanceAgainstRanged = 100
CombatStyles.HollowManElite.HollowManParams.RunAttackPercentageChance = 100
CombatStyles.HollowManElite.Sequences = {}
CombatStyles.HollowManElite.Sequences[CombatSituations.Melee] = {
	"HollowmanEliteCloseAttackCombo",
	"HollowmanEliteFarAttackCombo",
	"HollowmanEliteAttackCombo",
	"HollowmanAltEliteCloseAttackCombo",
	"HollowmanAltEliteFarAttackCombo",
	"HollowmanAltEliteAttackCombo",
	"IdleStrafeLeft",
	"IdleStrafeRight",
	"BackOff",
	"HollowManAdvance"
}
CombatStyles.HollowManElite.ValidStates = {}
CombatStyles.HollowManElite.ValidStates[CombatSituations.Melee] = {
	"WaitForActionToFinish",
	"HollowManBuggerOffAndDie",
	"CheckForBetterTarget",
	"PlayCombatSequence",
	"HollowManCharge",
	"HollowManMove",
	"MoveToFormationPos",
	"FaceTarget"
}


-- HollowMan Elite WithSpell --
CombatStyles.HollowManEliteWithSpell = {}
CombatStyles.HollowManEliteWithSpell.CombatGroupType = CombatGroupTypes.HollowManLike
CombatStyles.HollowManEliteWithSpell.CanSheatheWeapon = false
CombatStyles.HollowManEliteWithSpell.DualWieldMeleeSlot = DummyObjects.HAND_LEFT
CombatStyles.HollowManEliteWithSpell.NonFormation = true
CombatStyles.HollowManEliteWithSpell.TurnToFaceTolerance = 15
CombatStyles.HollowManEliteWithSpell.PreferredRange = 1.5
CombatStyles.HollowManEliteWithSpell.CanFightUnarmed = true
CombatStyles.HollowManEliteWithSpell.NoWispMove = true
CombatStyles.HollowManEliteWithSpell.Limits = {}
CombatStyles.HollowManEliteWithSpell.Limits[CombatZones.Near] = 1.3
CombatStyles.HollowManEliteWithSpell.Limits[CombatZones.Middle] = 2.5
CombatStyles.HollowManEliteWithSpell.Limits[CombatZones.Far] = 5
CombatStyles.HollowManEliteWithSpell.Limits[CombatZones.Left] = 1
CombatStyles.HollowManEliteWithSpell.Limits[CombatZones.Right] = 1
CombatStyles.HollowManEliteWithSpell.Limits[CombatZones.Rear] = 2
CombatStyles.HollowManEliteWithSpell.MinSecondsBetweenMeleeAttacks = 1
CombatStyles.HollowManEliteWithSpell.SecondsToWaitAfterTargetIsHit = 1
CombatStyles.HollowManEliteWithSpell.SecondsToWaitAfterTargetIsAttacked = 0
CombatStyles.HollowManEliteWithSpell.MaxNavSpeed = ENavigationSpeed.NAV_SPEED_WALK
CombatStyles.HollowManEliteWithSpell.HollowManParams = {}
CombatStyles.HollowManEliteWithSpell.HollowManParams.WispSpeed = 1
CombatStyles.HollowManEliteWithSpell.HollowManParams.MinimumSpawnDist = 1.75
CombatStyles.HollowManEliteWithSpell.HollowManParams.SpawnDistRandom = 1.25
CombatStyles.HollowManEliteWithSpell.HollowManParams.TargetSpeedToDistMultiplier = 1.2
CombatStyles.HollowManEliteWithSpell.HollowManParams.DistForMove = 6
CombatStyles.HollowManEliteWithSpell.HollowManParams.ReturnUndergroundDist = 10
CombatStyles.HollowManEliteWithSpell.HollowManParams.RiseAttackPercentageChance = 100
CombatStyles.HollowManEliteWithSpell.HollowManParams.RunPercentageChance = 100
CombatStyles.HollowManEliteWithSpell.HollowManParams.RunPercentageChanceAgainstRanged = 100
CombatStyles.HollowManEliteWithSpell.HollowManParams.RunAttackPercentageChance = 100
CombatStyles.HollowManEliteWithSpell.Sequences = {}
CombatStyles.HollowManEliteWithSpell.Sequences[CombatSituations.Melee] = {
	{"HollowmanEliteShockCast", 10},
	{"HollowmanEliteRearAttack", 5},
	"HollowmanEliteAttackCombo",
	"HollowmanAltEliteCloseAttackCombo",
	"HollowmanAltEliteFarAttackCombo",
	"HollowmanAltEliteAttackCombo",
	"IdleStrafeLeft",
	"IdleStrafeRight",
	"BackOff",
	"HollowManAdvance"
}
CombatStyles.HollowManEliteWithSpell.ValidStates = {}
CombatStyles.HollowManEliteWithSpell.ValidStates[CombatSituations.Melee] = {
	"WaitForActionToFinish",
	"HollowManBuggerOffAndDie",
	"CheckForBetterTarget",
	"PlayCombatSequence",
	"HollowManCharge",
	"HollowManMove",
	"MoveToFormationPos",
	"FaceTarget"
}


-- HollowMan Soldier --
CombatStyles.HollowManSoldier = {}
CombatStyles.HollowManSoldier.CombatGroupType = CombatGroupTypes.HollowManLike
CombatStyles.HollowManSoldier.CanSheatheWeapon = false
CombatStyles.HollowManSoldier.DualWieldMeleeSlot = DummyObjects.HAND_LEFT
CombatStyles.HollowManSoldier.NonFormation = true
CombatStyles.HollowManSoldier.TurnToFaceTolerance = 15
CombatStyles.HollowManSoldier.PreferredRange = 1.5
CombatStyles.HollowManSoldier.CanFightUnarmed = true
CombatStyles.HollowManSoldier.Limits = {}
CombatStyles.HollowManSoldier.Limits[CombatZones.Near] = 1.5
CombatStyles.HollowManSoldier.Limits[CombatZones.Middle] = 2.5
CombatStyles.HollowManSoldier.Limits[CombatZones.Far] = 5
CombatStyles.HollowManSoldier.Limits[CombatZones.Left] = 1
CombatStyles.HollowManSoldier.Limits[CombatZones.Right] = 1
CombatStyles.HollowManSoldier.Limits[CombatZones.Rear] = 1
CombatStyles.HollowManSoldier.MinSecondsBetweenMeleeAttacks = 0
CombatStyles.HollowManSoldier.SecondsToWaitAfterTargetIsHit = 0
CombatStyles.HollowManSoldier.SecondsToWaitAfterTargetIsAttacked = 0
CombatStyles.HollowManSoldier.MaxNavSpeed = ENavigationSpeed.NAV_SPEED_WALK
CombatStyles.HollowManSoldier.HollowManParams = {}
CombatStyles.HollowManSoldier.HollowManParams.WispSpeed = 2
CombatStyles.HollowManSoldier.HollowManParams.MinimumSpawnDist = 1.5
CombatStyles.HollowManSoldier.HollowManParams.SpawnDistRandom = 0.5
CombatStyles.HollowManSoldier.HollowManParams.TargetSpeedToDistMultiplier = 1.2
CombatStyles.HollowManSoldier.HollowManParams.DistForMove = 6
CombatStyles.HollowManSoldier.HollowManParams.ReturnUndergroundDist = 10
CombatStyles.HollowManSoldier.HollowManParams.RiseAttackPercentageChance = 100
CombatStyles.HollowManSoldier.HollowManParams.RunPercentageChance = 0
CombatStyles.HollowManSoldier.HollowManParams.RunPercentageChanceAgainstRanged = 100
CombatStyles.HollowManSoldier.HollowManParams.RunAttackPercentageChance = 0
CombatStyles.HollowManSoldier.Sequences = {}
CombatStyles.HollowManSoldier.Sequences[CombatSituations.Melee] = {
	"SoldierMagicedTooMuch",
	"HollowmanSoldierOrbSuckingResponse",
	"SoldierFarAttackCombo",
	"SoldierCloseAttackCombo",
	"SoldierAttackCombo",
	"SoldierAltFarAttackCombo",
	"SoldierAltCloseAttackCombo",
	"SoldierAltAttackCombo",
	{"SoldierShockCast", 15},
	"IdleStrafeLeft",
	"IdleStrafeRight",
	"BackOff",
	"HollowManAdvance"
}
CombatStyles.HollowManSoldier.Sequences[CombatSituations.HardBlocking] = {
	"HollowManAttackBreak"
}
CombatStyles.HollowManSoldier.CanBlock = true
CombatStyles.HollowManSoldier.BlockData = {}
CombatStyles.HollowManSoldier.BlockData.PrimaryBlockType = EBlockType.BLOCK_TYPE_STATIC
CombatStyles.HollowManSoldier.BlockData.SecondsForSuccessiveHitsToPrimaryBlock = 4
CombatStyles.HollowManSoldier.BlockData.NumberOfHitsToForcePrimaryBlock = 3
CombatStyles.HollowManSoldier.BlockData.MaxHitsToBlock = 4
CombatStyles.HollowManSoldier.BlockData.SecondsToBlockFor = 4
CombatStyles.HollowManSoldier.ValidStates = {}
CombatStyles.HollowManSoldier.ValidStates[CombatSituations.Melee] = {
	"WaitForActionToFinish",
	"HollowManBuggerOffAndDie",
	"CheckForBetterTarget",
	"PlayCombatSequence",
	"HollowManCharge",
	"HollowManWispMove",
	"HollowManMove",
	"MoveToFormationPos",
	"FaceTarget"
}
CombatStyles.HollowManSoldier.ValidStates[CombatSituations.HardBlocking] = CombatStyles.StandardBlockingCombatStates
CombatStyles.HollowManSoldier.ValidStates[CombatSituations.Dodging] = CombatStyles.StandardBlockingCombatStates
CombatStyles.HollowManSoldier.ValidStates[CombatSituations.GroupOrders] = CombatStyles.StandardGroupOrderStates


-- HollowMan Soldier Elite --
CombatStyles.HollowManSoldierElite = {}
CombatStyles.HollowManSoldierElite.CombatGroupType = CombatGroupTypes.HollowManLike
CombatStyles.HollowManSoldierElite.CanSheatheWeapon = false
CombatStyles.HollowManSoldierElite.DualWieldMeleeSlot = DummyObjects.HAND_LEFT
CombatStyles.HollowManSoldierElite.NonFormation = true
CombatStyles.HollowManSoldierElite.TurnToFaceTolerance = 15
CombatStyles.HollowManSoldierElite.PreferredRange = 1.5
CombatStyles.HollowManSoldierElite.CanFightUnarmed = true
CombatStyles.HollowManSoldierElite.Limits = {}
CombatStyles.HollowManSoldierElite.Limits[CombatZones.Near] = 1.5
CombatStyles.HollowManSoldierElite.Limits[CombatZones.Middle] = 2.5
CombatStyles.HollowManSoldierElite.Limits[CombatZones.Far] = 5
CombatStyles.HollowManSoldierElite.Limits[CombatZones.Left] = 1
CombatStyles.HollowManSoldierElite.Limits[CombatZones.Right] = 1
CombatStyles.HollowManSoldierElite.Limits[CombatZones.Rear] = 1
CombatStyles.HollowManSoldierElite.MinSecondsBetweenMeleeAttacks = 0
CombatStyles.HollowManSoldierElite.SecondsToWaitAfterTargetIsHit = 0
CombatStyles.HollowManSoldierElite.SecondsToWaitAfterTargetIsAttacked = 0.5
CombatStyles.HollowManSoldierElite.MaxNavSpeed = ENavigationSpeed.NAV_SPEED_WALK
CombatStyles.HollowManSoldierElite.HollowManParams = {}
CombatStyles.HollowManSoldierElite.HollowManParams.WispSpeed = 2
CombatStyles.HollowManSoldierElite.HollowManParams.MinimumSpawnDist = 1.5
CombatStyles.HollowManSoldierElite.HollowManParams.SpawnDistRandom = 0.5
CombatStyles.HollowManSoldierElite.HollowManParams.TargetSpeedToDistMultiplier = 1.2
CombatStyles.HollowManSoldierElite.HollowManParams.DistForMove = 6
CombatStyles.HollowManSoldierElite.HollowManParams.ReturnUndergroundDist = 10
CombatStyles.HollowManSoldierElite.HollowManParams.RiseAttackPercentageChance = 100
CombatStyles.HollowManSoldierElite.HollowManParams.RunPercentageChance = 0
CombatStyles.HollowManSoldierElite.HollowManParams.RunPercentageChanceAgainstRanged = 0
CombatStyles.HollowManSoldierElite.HollowManParams.RunAttackPercentageChance = 0
CombatStyles.HollowManSoldierElite.Sequences = {}
CombatStyles.HollowManSoldierElite.Sequences[CombatSituations.Melee] = {
	"HollowmanSoldierHeroFlourishResponse",
	"SoldierFarAttackCombo",
	"SoldierCloseAttackCombo",
	"SoldierAttackCombo",
	"SoldierAltFarAttackCombo",
	"SoldierAltCloseAttackCombo",
	"SoldierAltAttackCombo",
	{"SoldierShockCast", 30},
	"IdleStrafeLeft",
	"IdleStrafeRight",
	"BackOff",
	"HollowManAdvance"
}
CombatStyles.HollowManSoldierElite.Sequences[CombatSituations.HardBlocking] = {
	"HollowManAttackBreak"
}
CombatStyles.HollowManSoldierElite.CanBlock = true
CombatStyles.HollowManSoldierElite.BlockData = {}
CombatStyles.HollowManSoldierElite.BlockData.PrimaryBlockType = EBlockType.BLOCK_TYPE_STATIC
CombatStyles.HollowManSoldierElite.BlockData.SecondsForSuccessiveHitsToPrimaryBlock = 4
CombatStyles.HollowManSoldierElite.BlockData.NumberOfHitsToForcePrimaryBlock = 2
CombatStyles.HollowManSoldierElite.BlockData.SecondsToBlockFor = 4
CombatStyles.HollowManSoldierElite.ValidStates = {}
CombatStyles.HollowManSoldierElite.ValidStates[CombatSituations.Melee] = {
	"WaitForActionToFinish",
	"HollowManBuggerOffAndDie",
	"CheckForBetterTarget",
	"PlayCombatSequence",
	"HollowManCharge",
	"HollowManWispMove",
	"HollowManMove",
	"MoveToFormationPos",
	"FaceTarget"
}
CombatStyles.HollowManSoldierElite.ValidStates[CombatSituations.HardBlocking] = CombatStyles.StandardBlockingCombatStates
CombatStyles.HollowManSoldierElite.ValidStates[CombatSituations.Dodging] = CombatStyles.StandardBlockingCombatStates
CombatStyles.HollowManSoldierElite.ValidStates[CombatSituations.GroupOrders] = CombatStyles.StandardGroupOrderStates


-- HollowMan Headless --
CombatStyles.HeadlessHollowMan = DeepCopyTable(CombatStyles.HollowMan)
CombatStyles.HeadlessHollowMan.MinSecondsBetweenMeleeAttacks = nil
CombatStyles.HeadlessHollowMan.ValidStates = {}
CombatStyles.HeadlessHollowMan.ValidStates[CombatSituations.Melee] = {
	"WaitForActionToFinish",
	"HollowManBuggerOffAndDie",
	"HeadlessHollowManAttack",
	"HeadlessHollowManRandomTurn",
	"HeadlessHollowManAttack",
	"HeadlessHollowManBlindSwinging",
	"CheckForBetterTarget"
}
CombatStyles.HeadlessHollowMan.ValidStates[CombatSituations.Ranged] = {
	"WaitForActionToFinish",
	"HeadlessHollowManRandomTurn",
	"FireRangedWeapon",
	"CheckForBetterTarget",
	"MoveToFormationPos"
}



-- HollowMan Headless Boss --
CombatStyles.HeadlessHollowManBoss = {}
CombatStyles.HeadlessHollowManBoss.CombatGroupType = CombatGroupTypes.HollowManLike
CombatStyles.HeadlessHollowManBoss.CanSheatheWeapon = false
CombatStyles.HeadlessHollowManBoss.DualWieldMeleeSlot = DummyObjects.HAND_LEFT
CombatStyles.HeadlessHollowManBoss.NonFormation = true
CombatStyles.HeadlessHollowManBoss.TurnToFaceTolerance = 15
CombatStyles.HeadlessHollowManBoss.PreferredRange = 1.5
CombatStyles.HeadlessHollowManBoss.CanFightUnarmed = true
CombatStyles.HeadlessHollowManBoss.NoWispMove = true
CombatStyles.HeadlessHollowManBoss.Limits = {}
CombatStyles.HeadlessHollowManBoss.Limits[CombatZones.Near] = 1.3
CombatStyles.HeadlessHollowManBoss.Limits[CombatZones.Middle] = 2.5
CombatStyles.HeadlessHollowManBoss.Limits[CombatZones.Far] = 5
CombatStyles.HeadlessHollowManBoss.Limits[CombatZones.Left] = 2.5
CombatStyles.HeadlessHollowManBoss.Limits[CombatZones.Right] = 2.5
CombatStyles.HeadlessHollowManBoss.Limits[CombatZones.Rear] = 2.5
CombatStyles.HeadlessHollowManBoss.MinSecondsBetweenMeleeAttacks = 0
CombatStyles.HeadlessHollowManBoss.SecondsToWaitAfterTargetIsHit = 0
CombatStyles.HeadlessHollowManBoss.SecondsToWaitAfterTargetIsAttacked = 0
CombatStyles.HeadlessHollowManBoss.MaxNavSpeed = ENavigationSpeed.NAV_SPEED_WALK
CombatStyles.HeadlessHollowManBoss.HollowManParams = {}
CombatStyles.HeadlessHollowManBoss.HollowManParams.WispSpeed = 1
CombatStyles.HeadlessHollowManBoss.HollowManParams.MinimumSpawnDist = 1.75
CombatStyles.HeadlessHollowManBoss.HollowManParams.SpawnDistRandom = 1.25
CombatStyles.HeadlessHollowManBoss.HollowManParams.TargetSpeedToDistMultiplier = 1.2
CombatStyles.HeadlessHollowManBoss.HollowManParams.DistForMove = 6
CombatStyles.HeadlessHollowManBoss.HollowManParams.ReturnUndergroundDist = 10
CombatStyles.HeadlessHollowManBoss.HollowManParams.RiseAttackPercentageChance = 0
CombatStyles.HeadlessHollowManBoss.HollowManParams.RunPercentageChance = 0
CombatStyles.HeadlessHollowManBoss.HollowManParams.RunPercentageChanceAgainstRanged = 100
CombatStyles.HeadlessHollowManBoss.HollowManParams.RunAttackPercentageChance = 0
CombatStyles.HeadlessHollowManBoss.Sequences = {}
CombatStyles.HeadlessHollowManBoss.Sequences[CombatSituations.Melee] = {
	"HeadlessHollowmanMeleeAoECast"
}
CombatStyles.HeadlessHollowManBoss.Sequences[CombatSituations.HardBlocking] = {
	"HollowManAttackBreak"
}
CombatStyles.HeadlessHollowManBoss.ValidStates = {}
CombatStyles.HeadlessHollowManBoss.ValidStates[CombatSituations.Melee] = {
	"PlayCombatSequence",
	"WaitForActionToFinish",
	"HollowManBuggerOffAndDie",
	"HeadlessHollowManAttack",
	"HeadlessHollowManRandomTurn",
	"HeadlessHollowManAttack",
	"HeadlessHollowManBlindSwinging",
	"CheckForBetterTarget"
}


-- HollowMan Leader QO815 --
CombatStyles.HollowManLeaderQO815 = {}
CombatStyles.HollowManLeaderQO815.CombatGroupType = CombatGroupTypes.HollowManLike
CombatStyles.HollowManLeaderQO815.CanSheatheWeapon = false
CombatStyles.HollowManLeaderQO815.DualWieldMeleeSlot = DummyObjects.HAND_LEFT
CombatStyles.HollowManLeaderQO815.NonFormation = true
CombatStyles.HollowManLeaderQO815.TurnToFaceTolerance = 15
CombatStyles.HollowManLeaderQO815.PreferredRange = 1.5
CombatStyles.HollowManLeaderQO815.CanFightUnarmed = true
CombatStyles.HollowManLeaderQO815.Limits = {}
CombatStyles.HollowManLeaderQO815.Limits[CombatZones.Near] = 1.5
CombatStyles.HollowManLeaderQO815.Limits[CombatZones.Middle] = 2.5
CombatStyles.HollowManLeaderQO815.Limits[CombatZones.Far] = 5
CombatStyles.HollowManLeaderQO815.Limits[CombatZones.Left] = 1
CombatStyles.HollowManLeaderQO815.Limits[CombatZones.Right] = 1
CombatStyles.HollowManLeaderQO815.Limits[CombatZones.Rear] = 1
CombatStyles.HollowManLeaderQO815.MinSecondsBetweenMeleeAttacks = 0.5
CombatStyles.HollowManLeaderQO815.SecondsToWaitAfterTargetIsHit = 1
CombatStyles.HollowManLeaderQO815.SecondsToWaitAfterTargetIsAttacked = 0
CombatStyles.HollowManLeaderQO815.MaxNavSpeed = ENavigationSpeed.NAV_SPEED_WALK
CombatStyles.HollowManLeaderQO815.HollowManParams = {}
CombatStyles.HollowManLeaderQO815.HollowManParams.WispSpeed = 1
CombatStyles.HollowManLeaderQO815.HollowManParams.MinimumSpawnDist = 1.75
CombatStyles.HollowManLeaderQO815.HollowManParams.SpawnDistRandom = 1.25
CombatStyles.HollowManLeaderQO815.HollowManParams.TargetSpeedToDistMultiplier = 1.2
CombatStyles.HollowManLeaderQO815.HollowManParams.DistForMove = 5
CombatStyles.HollowManLeaderQO815.HollowManParams.ReturnUndergroundDist = 7
CombatStyles.HollowManLeaderQO815.HollowManParams.RiseAttackPercentageChance = 100
CombatStyles.HollowManLeaderQO815.HollowManParams.RunPercentageChance = 0
CombatStyles.HollowManLeaderQO815.HollowManParams.RunPercentageChanceAgainstRanged = 100
CombatStyles.HollowManLeaderQO815.HollowManParams.RunAttackPercentageChance = 0
CombatStyles.HollowManLeaderQO815.Sequences = {}
CombatStyles.HollowManLeaderQO815.Sequences[CombatSituations.Melee] = {
	"HollowmanLeaderQO815CloseAttackCombo",
	"HollowmanLeaderQO815AttackCombo",
	"IdleStrafeLeft",
	"IdleStrafeRight",
	"BackOff",
	"HollowManAdvance"
}
CombatStyles.HollowManLeaderQO815.Sequences[CombatSituations.HardBlocking] = {
	"HollowmanLeaderQO815AttackBreak"
}
CombatStyles.HollowManLeaderQO815.CanBlock = true
CombatStyles.HollowManLeaderQO815.BlockData = {}
CombatStyles.HollowManLeaderQO815.BlockData.PrimaryBlockType = EBlockType.BLOCK_TYPE_STATIC
CombatStyles.HollowManLeaderQO815.BlockData.SecondsForSuccessiveHitsToPrimaryBlock = 6
CombatStyles.HollowManLeaderQO815.BlockData.NumberOfHitsToForcePrimaryBlock = 2
CombatStyles.HollowManLeaderQO815.BlockData.SecondsToBlockFor = 4
CombatStyles.HollowManLeaderQO815.ValidStates = {}
CombatStyles.HollowManLeaderQO815.ValidStates[CombatSituations.Melee] = {
	"WaitForActionToFinish",
	"HollowManBuggerOffAndDie",
	"CheckForBetterTarget",
	"PlayCombatSequence",
	"HollowManCharge",
	"HollowManWispMove",
	"HollowManMove",
	"MoveToFormationPos",
	"FaceTarget"
}
CombatStyles.HollowManLeaderQO815.ValidStates[CombatSituations.HardBlocking] = CombatStyles.StandardBlockingCombatStates


-- HollowMan Ranged --
CombatStyles.HollowManRanged = {}
CombatStyles.HollowManRanged.CombatGroupType = CombatGroupTypes.HollowManLike
CombatStyles.HollowManRanged.CanSheatheWeapon = false
CombatStyles.HollowManRanged.DualWieldMeleeSlot = DummyObjects.HAND_LEFT
CombatStyles.HollowManRanged.NonFormation = true
CombatStyles.HollowManRanged.TurnToFaceTolerance = 15
CombatStyles.HollowManRanged.PreferredRange = 10
CombatStyles.HollowManRanged.CanFightUnarmed = true
CombatStyles.HollowManRanged.NoWispMove = true
CombatStyles.HollowManRanged.MinShootingRange = 3
CombatStyles.HollowManRanged.MaxShootingRange = 15
CombatStyles.HollowManRanged.Limits = {}
CombatStyles.HollowManRanged.Limits[CombatZones.Near] = 1.3
CombatStyles.HollowManRanged.Limits[CombatZones.Middle] = 2
CombatStyles.HollowManRanged.Limits[CombatZones.Far] = 15
CombatStyles.HollowManRanged.Limits[CombatZones.Left] = 1
CombatStyles.HollowManRanged.Limits[CombatZones.Right] = 1
CombatStyles.HollowManRanged.Limits[CombatZones.Rear] = 1
CombatStyles.HollowManRanged.MinSecondsBetweenMeleeAttacks = 3
CombatStyles.HollowManRanged.SecondsToWaitAfterTargetIsHit = 3
CombatStyles.HollowManRanged.SecondsToWaitAfterTargetIsAttacked = 1.5
CombatStyles.HollowManRanged.MaxNavSpeed = ENavigationSpeed.NAV_SPEED_WALK
CombatStyles.HollowManRanged.HollowManParams = {}
CombatStyles.HollowManRanged.HollowManParams.WispSpeed = 1.2
CombatStyles.HollowManRanged.HollowManParams.MinimumSpawnDist = 1.75
CombatStyles.HollowManRanged.HollowManParams.SpawnDistRandom = 1.25
CombatStyles.HollowManRanged.HollowManParams.TargetSpeedToDistMultiplier = 1.2
CombatStyles.HollowManRanged.HollowManParams.DistForMove = 6
CombatStyles.HollowManRanged.HollowManParams.ReturnUndergroundDist = 10
CombatStyles.HollowManRanged.HollowManParams.RiseAttackPercentageChance = 0
CombatStyles.HollowManRanged.HollowManParams.RunPercentageChance = 100
CombatStyles.HollowManRanged.HollowManParams.RunPercentageChanceAgainstRanged = 100
CombatStyles.HollowManRanged.HollowManParams.RunAttackPercentageChance = 0
CombatStyles.HollowManRanged.Sequences = {}
CombatStyles.HollowManRanged.Sequences[CombatSituations.Ranged] = {
	"HollowManRangedCloseAttack",
	"HollowManRangedMidAttack"
}
CombatStyles.HollowManRanged.ValidStates = {}
CombatStyles.HollowManRanged.ValidStates[CombatSituations.Ranged] = {
	"WaitForActionToFinish",
	"HollowManBuggerOffAndDie",
	"CheckForBetterTarget",
	"PlayCombatSequence",
	"HollowManRangedAdvance",
	"HollowManFireRangedWeapon",
	"MoveToFormationPos",
	"IdleWithRangedWeapon"
}
CombatStyles.HollowManRanged.ShootingBalanceData = {}
CombatStyles.HollowManRanged.ShootingBalanceData.StartingChanceToHitWithFirearm = 0
CombatStyles.HollowManRanged.ShootingBalanceData.MaxChanceToHitWithFirearmCap = 0.05
CombatStyles.HollowManRanged.ShootingBalanceData.ChanceToHitModBonusRangeDistance = 9
CombatStyles.HollowManRanged.ShootingBalanceData.ChanceToHitModSegmentLength = 3
CombatStyles.HollowManRanged.ShootingBalanceData.ChanceToHitModPercentageIncrease = 0.01
CombatStyles.HollowManRanged.ShootingBalanceData.ChanceToHitModConsecutiveShotPercentageIncrease = 0.01
CombatStyles.HollowManRanged.ShootingBalanceData.ChanceToHitModConsecutiveShotsTimeFrame = 24
CombatStyles.HollowManRanged.ShootingBalanceData.ChanceToHitModPercentageDecreasePerOneSpeed = 0.9
CombatStyles.HollowManRanged.ShootingBalanceData.ChanceToHitModTargetInCoverPercentageMultiplier = 0.9
CombatStyles.HollowManRanged.ShootingBalanceData.ChanceToHitModOffScreenPercentageMultiplier = 0.05


-- HollowMan Ranged Turret --
CombatStyles.HollowManRangedTurret = {}
CombatStyles.HollowManRangedTurret.CombatGroupType = CombatGroupTypes.HollowManLike
CombatStyles.HollowManRangedTurret.CanSheatheWeapon = false
CombatStyles.HollowManRangedTurret.DualWieldMeleeSlot = DummyObjects.HAND_LEFT
CombatStyles.HollowManRangedTurret.NonFormation = true
CombatStyles.HollowManRangedTurret.TurnToFaceTolerance = 15
CombatStyles.HollowManRangedTurret.PreferredRange = 10
CombatStyles.HollowManRangedTurret.CanFightUnarmed = true
CombatStyles.HollowManRangedTurret.NoWispMove = true
CombatStyles.HollowManRangedTurret.TurretBalanceData = {}
CombatStyles.HollowManRangedTurret.TurretBalanceData.DistanceToMoveBackToShootingPosition = 1
CombatStyles.HollowManRangedTurret.TurretBalanceData.DistanceOverWhichToFindNewShootingPosition = 5
CombatStyles.HollowManRangedTurret.TurretBalanceData.NonTurretCombatStyle = "HollowManRanged"
CombatStyles.HollowManRangedTurret.CanStandOffAndShoot = "Turret"
CombatStyles.HollowManRangedTurret.Limits = {}
CombatStyles.HollowManRangedTurret.Limits[CombatZones.Near] = 1.3
CombatStyles.HollowManRangedTurret.Limits[CombatZones.Middle] = 2
CombatStyles.HollowManRangedTurret.Limits[CombatZones.Far] = 11
CombatStyles.HollowManRangedTurret.Limits[CombatZones.Left] = 1
CombatStyles.HollowManRangedTurret.Limits[CombatZones.Right] = 1
CombatStyles.HollowManRangedTurret.Limits[CombatZones.Rear] = 1
CombatStyles.HollowManRangedTurret.MinSecondsBetweenMeleeAttacks = 3
CombatStyles.HollowManRangedTurret.SecondsToWaitAfterTargetIsHit = 3
CombatStyles.HollowManRangedTurret.SecondsToWaitAfterTargetIsAttacked = 1.5
CombatStyles.HollowManRangedTurret.MaxNavSpeed = ENavigationSpeed.NAV_SPEED_WALK
CombatStyles.HollowManRangedTurret.HollowManParams = {}
CombatStyles.HollowManRangedTurret.HollowManParams.WispSpeed = 1.3
CombatStyles.HollowManRangedTurret.HollowManParams.MinimumSpawnDist = 1.75
CombatStyles.HollowManRangedTurret.HollowManParams.SpawnDistRandom = 0
CombatStyles.HollowManRangedTurret.HollowManParams.TargetSpeedToDistMultiplier = 1.2
CombatStyles.HollowManRangedTurret.HollowManParams.DistForMove = 6
CombatStyles.HollowManRangedTurret.HollowManParams.ReturnUndergroundDist = 10
CombatStyles.HollowManRangedTurret.HollowManParams.RiseAttackPercentageChance = 0
CombatStyles.HollowManRangedTurret.HollowManParams.RunPercentageChance = 100
CombatStyles.HollowManRangedTurret.HollowManParams.RunPercentageChanceAgainstRanged = 100
CombatStyles.HollowManRangedTurret.HollowManParams.RunAttackPercentageChance = 0
CombatStyles.HollowManRangedTurret.Sequences = {}
CombatStyles.HollowManRangedTurret.Sequences[CombatSituations.Ranged] = {
	"HollowManRangedCloseAttack",
	"HollowManRangedMidAttack"
}
CombatStyles.HollowManRangedTurret.ValidStates = {}
CombatStyles.HollowManRangedTurret.ValidStates[CombatSituations.Ranged] = {
	"WaitForActionToFinish",
	"HollowManBuggerOffAndDie",
	"CheckForBetterTarget",
	"PlayCombatSequence",
	"HollowManWispMoveToFiringPosition",
	"HollowManFireRangedWeapon",
	"FaceTarget",
	"IdleWithRangedWeapon"
}
CombatStyles.HollowManRangedTurret.ShootingBalanceData = {}
CombatStyles.HollowManRangedTurret.ShootingBalanceData.StartingChanceToHitWithFirearm = 0
CombatStyles.HollowManRangedTurret.ShootingBalanceData.MaxChanceToHitWithFirearmCap = 0.05
CombatStyles.HollowManRangedTurret.ShootingBalanceData.ChanceToHitModBonusRangeDistance = 9
CombatStyles.HollowManRangedTurret.ShootingBalanceData.ChanceToHitModSegmentLength = 3
CombatStyles.HollowManRangedTurret.ShootingBalanceData.ChanceToHitModPercentageIncrease = 0.01
CombatStyles.HollowManRangedTurret.ShootingBalanceData.ChanceToHitModConsecutiveShotPercentageIncrease = 0.01
CombatStyles.HollowManRangedTurret.ShootingBalanceData.ChanceToHitModConsecutiveShotsTimeFrame = 25
CombatStyles.HollowManRangedTurret.ShootingBalanceData.ChanceToHitModPercentageDecreasePerOneSpeed = 0.9
CombatStyles.HollowManRangedTurret.ShootingBalanceData.ChanceToHitModTargetInCoverPercentageMultiplier = 0.9
CombatStyles.HollowManRangedTurret.ShootingBalanceData.ChanceToHitModOffScreenPercentageMultiplier = 0.05


-- HollowMan Ranged Turret NoWisp --
CombatStyles.HollowManRangedTurretNoWisp = {}
CombatStyles.HollowManRangedTurretNoWisp.CombatGroupType = CombatGroupTypes.HollowManLike
CombatStyles.HollowManRangedTurretNoWisp.CanSheatheWeapon = false
CombatStyles.HollowManRangedTurretNoWisp.DualWieldMeleeSlot = DummyObjects.HAND_LEFT
CombatStyles.HollowManRangedTurretNoWisp.NonFormation = true
CombatStyles.HollowManRangedTurretNoWisp.TurnToFaceTolerance = 15
CombatStyles.HollowManRangedTurretNoWisp.PreferredRange = 10
CombatStyles.HollowManRangedTurretNoWisp.CanFightUnarmed = true
CombatStyles.HollowManRangedTurretNoWisp.NoWispMove = true
CombatStyles.HollowManRangedTurretNoWisp.NoWispSpawn = true
CombatStyles.HollowManRangedTurretNoWisp.MoveToFiringPosNoWait = true
CombatStyles.HollowManRangedTurretNoWisp.TurretBalanceData = {}
CombatStyles.HollowManRangedTurretNoWisp.TurretBalanceData.DistanceToMoveBackToShootingPosition = 2
CombatStyles.HollowManRangedTurretNoWisp.TurretBalanceData.DistanceOverWhichToFindNewShootingPosition = 8
CombatStyles.HollowManRangedTurretNoWisp.TurretBalanceData.NonTurretCombatStyle = nil
CombatStyles.HollowManRangedTurretNoWisp.CanStandOffAndShoot = "Turret"
CombatStyles.HollowManRangedTurretNoWisp.Limits = {}
CombatStyles.HollowManRangedTurretNoWisp.Limits[CombatZones.Near] = 1.5
CombatStyles.HollowManRangedTurretNoWisp.Limits[CombatZones.Middle] = 1.75
CombatStyles.HollowManRangedTurretNoWisp.Limits[CombatZones.Far] = 2
CombatStyles.HollowManRangedTurretNoWisp.Limits[CombatZones.Left] = 1
CombatStyles.HollowManRangedTurretNoWisp.Limits[CombatZones.Right] = 1
CombatStyles.HollowManRangedTurretNoWisp.Limits[CombatZones.Rear] = 1
CombatStyles.HollowManRangedTurretNoWisp.MinSecondsBetweenMeleeAttacks = 3
CombatStyles.HollowManRangedTurretNoWisp.SecondsToWaitAfterTargetIsHit = 3
CombatStyles.HollowManRangedTurretNoWisp.SecondsToWaitAfterTargetIsAttacked = 1.5
CombatStyles.HollowManRangedTurretNoWisp.MaxNavSpeed = ENavigationSpeed.NAV_SPEED_WALK
CombatStyles.HollowManRangedTurretNoWisp.HollowManParams = {}
CombatStyles.HollowManRangedTurretNoWisp.HollowManParams.WispSpeed = 1.3
CombatStyles.HollowManRangedTurretNoWisp.HollowManParams.MinimumSpawnDist = 1.75
CombatStyles.HollowManRangedTurretNoWisp.HollowManParams.SpawnDistRandom = 0
CombatStyles.HollowManRangedTurretNoWisp.HollowManParams.TargetSpeedToDistMultiplier = 1.2
CombatStyles.HollowManRangedTurretNoWisp.HollowManParams.DistForMove = 6
CombatStyles.HollowManRangedTurretNoWisp.HollowManParams.ReturnUndergroundDist = 10
CombatStyles.HollowManRangedTurretNoWisp.HollowManParams.RiseAttackPercentageChance = 0
CombatStyles.HollowManRangedTurretNoWisp.HollowManParams.RunPercentageChance = 100
CombatStyles.HollowManRangedTurretNoWisp.HollowManParams.RunPercentageChanceAgainstRanged = 100
CombatStyles.HollowManRangedTurretNoWisp.HollowManParams.RunAttackPercentageChance = 0
CombatStyles.HollowManRangedTurretNoWisp.Sequences = {}
CombatStyles.HollowManRangedTurretNoWisp.Sequences[CombatSituations.Ranged] = {
	"HollowManRangedCloseAttack",
	"HollowManRangedMidAttack"
}
CombatStyles.HollowManRangedTurretNoWisp.Sequences[CombatSituations.Melee] = {
	"WaitForActionToFinish",
	"HollowManTurretWeaponFixUp"
}
CombatStyles.HollowManRangedTurretNoWisp.ValidStates = {}
CombatStyles.HollowManRangedTurretNoWisp.ValidStates[CombatSituations.Ranged] = {
	"WaitForActionToFinish",
	"HollowManBuggerOffAndDie",
	"CheckForBetterTarget",
	"PlayCombatSequence",
	"HollowManWispMoveToFiringPosition",
	"HollowManFireRangedWeapon",
	"FaceTarget",
	"IdleWithRangedWeapon"
}
CombatStyles.HollowManRangedTurretNoWisp.ShootingBalanceData = {}
CombatStyles.HollowManRangedTurretNoWisp.ShootingBalanceData.StartingChanceToHitWithFirearm = 0
CombatStyles.HollowManRangedTurretNoWisp.ShootingBalanceData.MaxChanceToHitWithFirearmCap = 0.05
CombatStyles.HollowManRangedTurretNoWisp.ShootingBalanceData.ChanceToHitModBonusRangeDistance = 9
CombatStyles.HollowManRangedTurretNoWisp.ShootingBalanceData.ChanceToHitModSegmentLength = 3
CombatStyles.HollowManRangedTurretNoWisp.ShootingBalanceData.ChanceToHitModPercentageIncrease = 0.01
CombatStyles.HollowManRangedTurretNoWisp.ShootingBalanceData.ChanceToHitModConsecutiveShotPercentageIncrease = 0.01
CombatStyles.HollowManRangedTurretNoWisp.ShootingBalanceData.ChanceToHitModConsecutiveShotsTimeFrame = 25
CombatStyles.HollowManRangedTurretNoWisp.ShootingBalanceData.ChanceToHitModPercentageDecreasePerOneSpeed = 0.9
CombatStyles.HollowManRangedTurretNoWisp.ShootingBalanceData.ChanceToHitModTargetInCoverPercentageMultiplier = 0.9
CombatStyles.HollowManRangedTurretNoWisp.ShootingBalanceData.ChanceToHitModOffScreenPercentageMultiplier = 0.05


-- HollowMan Ranged NeverMiss --
CombatStyles.HollowManRangedNeverMiss = {}
CombatStyles.HollowManRangedNeverMiss.CombatGroupType = CombatGroupTypes.HollowManLike
CombatStyles.HollowManRangedNeverMiss.CanSheatheWeapon = false
CombatStyles.HollowManRangedNeverMiss.DualWieldMeleeSlot = DummyObjects.HAND_LEFT
CombatStyles.HollowManRangedNeverMiss.NonFormation = true
CombatStyles.HollowManRangedNeverMiss.TurnToFaceTolerance = 15
CombatStyles.HollowManRangedNeverMiss.PreferredRange = 10
CombatStyles.HollowManRangedNeverMiss.CanFightUnarmed = true
CombatStyles.HollowManRangedNeverMiss.NoWispMove = true
CombatStyles.HollowManRangedNeverMiss.MinShootingRange = 3
CombatStyles.HollowManRangedNeverMiss.MaxShootingRange = 15
CombatStyles.HollowManRangedNeverMiss.Limits = {}
CombatStyles.HollowManRangedNeverMiss.Limits[CombatZones.Near] = 1.3
CombatStyles.HollowManRangedNeverMiss.Limits[CombatZones.Middle] = 2
CombatStyles.HollowManRangedNeverMiss.Limits[CombatZones.Far] = 15
CombatStyles.HollowManRangedNeverMiss.Limits[CombatZones.Left] = 1
CombatStyles.HollowManRangedNeverMiss.Limits[CombatZones.Right] = 1
CombatStyles.HollowManRangedNeverMiss.Limits[CombatZones.Rear] = 1
CombatStyles.HollowManRangedNeverMiss.MinSecondsBetweenMeleeAttacks = 3
CombatStyles.HollowManRangedNeverMiss.SecondsToWaitAfterTargetIsHit = 3
CombatStyles.HollowManRangedNeverMiss.SecondsToWaitAfterTargetIsAttacked = 1.5
CombatStyles.HollowManRangedNeverMiss.MaxNavSpeed = ENavigationSpeed.NAV_SPEED_WALK
CombatStyles.HollowManRangedNeverMiss.HollowManParams = {}
CombatStyles.HollowManRangedNeverMiss.HollowManParams.WispSpeed = 1.3
CombatStyles.HollowManRangedNeverMiss.HollowManParams.MinimumSpawnDist = 1.75
CombatStyles.HollowManRangedNeverMiss.HollowManParams.SpawnDistRandom = 1.25
CombatStyles.HollowManRangedNeverMiss.HollowManParams.TargetSpeedToDistMultiplier = 1.2
CombatStyles.HollowManRangedNeverMiss.HollowManParams.DistForMove = 6
CombatStyles.HollowManRangedNeverMiss.HollowManParams.ReturnUndergroundDist = 10
CombatStyles.HollowManRangedNeverMiss.HollowManParams.RiseAttackPercentageChance = 0
CombatStyles.HollowManRangedNeverMiss.HollowManParams.RunPercentageChance = 100
CombatStyles.HollowManRangedNeverMiss.HollowManParams.RunPercentageChanceAgainstRanged = 100
CombatStyles.HollowManRangedNeverMiss.HollowManParams.RunAttackPercentageChance = 0
CombatStyles.HollowManRangedNeverMiss.Sequences = {}
CombatStyles.HollowManRangedNeverMiss.Sequences[CombatSituations.Ranged] = {
	"HollowManRangedCloseAttack",
	"HollowManRangedMidAttack"
}
CombatStyles.HollowManRangedNeverMiss.ValidStates = {}
CombatStyles.HollowManRangedNeverMiss.ValidStates[CombatSituations.Ranged] = {
	"WaitForActionToFinish",
	"HollowManBuggerOffAndDie",
	"CheckForBetterTarget",
	"PlayCombatSequence",
	"HollowManRangedAdvance",
	"HollowManFireRangedWeapon",
	"MoveToFormationPos",
	"IdleWithRangedWeapon"
}


-- HollowMan Summoner --
CombatStyles.HollowManSummoner = {}
CombatStyles.HollowManSummoner.CombatGroupType = CombatGroupTypes.HollowManLike
CombatStyles.HollowManSummoner.CanSheatheWeapon = false
CombatStyles.HollowManSummoner.DualWieldMeleeSlot = DummyObjects.HAND_LEFT
CombatStyles.HollowManSummoner.NonFormation = true
CombatStyles.HollowManSummoner.TurnToFaceTolerance = 15
CombatStyles.HollowManSummoner.PreferredRange = 2.5
CombatStyles.HollowManSummoner.CanFightUnarmed = true
CombatStyles.HollowManSummoner.NoWispMove = true
CombatStyles.HollowManSummoner.Limits = {}
CombatStyles.HollowManSummoner.Limits[CombatZones.Near] = 1.5
CombatStyles.HollowManSummoner.Limits[CombatZones.Middle] = 4
CombatStyles.HollowManSummoner.Limits[CombatZones.Far] = 6
CombatStyles.HollowManSummoner.Limits[CombatZones.Left] = 1
CombatStyles.HollowManSummoner.Limits[CombatZones.Right] = 1
CombatStyles.HollowManSummoner.Limits[CombatZones.Rear] = 3
CombatStyles.HollowManSummoner.MinSecondsBetweenMeleeAttacks = 0.25
CombatStyles.HollowManSummoner.SecondsToWaitAfterTargetIsHit = 0.25
CombatStyles.HollowManSummoner.SecondsToWaitAfterTargetIsAttacked = 0
CombatStyles.HollowManSummoner.MaxNavSpeed = ENavigationSpeed.NAV_SPEED_WALK
CombatStyles.HollowManSummoner.HollowManParams = {}
CombatStyles.HollowManSummoner.HollowManParams.WispSpeed = 1
CombatStyles.HollowManSummoner.HollowManParams.MinimumSpawnDist = 1.75
CombatStyles.HollowManSummoner.HollowManParams.SpawnDistRandom = 1.25
CombatStyles.HollowManSummoner.HollowManParams.TargetSpeedToDistMultiplier = 1.2
CombatStyles.HollowManSummoner.HollowManParams.DistForMove = 6
CombatStyles.HollowManSummoner.HollowManParams.ReturnUndergroundDist = 8
CombatStyles.HollowManSummoner.HollowManParams.RiseAttackPercentageChance = 100
CombatStyles.HollowManSummoner.HollowManParams.RunPercentageChance = 100
CombatStyles.HollowManSummoner.HollowManParams.RunPercentageChanceAgainstRanged = 100
CombatStyles.HollowManSummoner.HollowManParams.RunAttackPercentageChance = 100
CombatStyles.HollowManSummoner.Sequences = {}
CombatStyles.HollowManSummoner.Sequences[CombatSituations.Melee] = {
	"HollowmanSummonerRangedCounter",
	{"HollowmanSummonerBackAttack", 5},
	"HollowmanSummonerFarAttackCombo",
	"HollowmanSummonerCloseAttackCombo",
	"HollowmanSummonerAttackCombo",
	"IdleStrafeLeft",
	"IdleStrafeRight",
	"BackOff",
	"HollowManAdvance"
}
CombatStyles.HollowManSummoner.Sequences[CombatSituations.HardBlocking] = {
	"HollowmanSummonerAttackOutOfBlock"
}
CombatStyles.HollowManSummoner.ValidStates = {}
CombatStyles.HollowManSummoner.ValidStates[CombatSituations.Melee] = {
	"WaitForActionToFinish",
	"HollowManBuggerOffAndDie",
	"CheckForBetterTarget",
	"HollowManSummonAllies",
	"PlayCombatSequence",
	"HollowManCharge",
	"HollowManMove",
	"MoveToFormationPos",
	"FaceTarget"
}
CombatStyles.HollowManSummoner.ValidStates[CombatSituations.HardBlocking] = CombatStyles.StandardBlockingCombatStates
CombatStyles.HollowManSummoner.SummonerData = {
	"CreatureHollowMan",
	"CreatureHollowManRanged",
	"CreatureHollowMan",
	"CreatureHollowManRanged",
	"CreatureHollowMan",
	"CreatureHollowManRanged",
	"CreatureHollowMan",
	"CreatureHollowManRanged"
}
CombatStyles.HollowManSummoner.CanBlock = true
CombatStyles.HollowManSummoner.BlockData = {}
CombatStyles.HollowManSummoner.BlockData.PrimaryBlockType = EBlockType.BLOCK_TYPE_STATIC
CombatStyles.HollowManSummoner.BlockData.SecondsForSuccessiveHitsToPrimaryBlock = 6
CombatStyles.HollowManSummoner.BlockData.NumberOfHitsToForcePrimaryBlock = 3
CombatStyles.HollowManSummoner.BlockData.SecondsToBlockFor = 1
CombatStyles.HollowManSummoner.CanEvadeShots = false


-- HollowMan Summoner WithoutSummon --
CombatStyles.HollowManSummonerWithoutSummon = {}
CombatStyles.HollowManSummonerWithoutSummon.CombatGroupType = CombatGroupTypes.HollowManLike
CombatStyles.HollowManSummonerWithoutSummon.CanSheatheWeapon = false
CombatStyles.HollowManSummonerWithoutSummon.DualWieldMeleeSlot = DummyObjects.HAND_LEFT
CombatStyles.HollowManSummonerWithoutSummon.NonFormation = true
CombatStyles.HollowManSummonerWithoutSummon.TurnToFaceTolerance = 15
CombatStyles.HollowManSummonerWithoutSummon.PreferredRange = 2.5
CombatStyles.HollowManSummonerWithoutSummon.CanFightUnarmed = true
CombatStyles.HollowManSummonerWithoutSummon.NoWispMove = true
CombatStyles.HollowManSummonerWithoutSummon.NoWispSpawn = true
CombatStyles.HollowManSummonerWithoutSummon.Limits = {}
CombatStyles.HollowManSummonerWithoutSummon.Limits[CombatZones.Near] = 1.5
CombatStyles.HollowManSummonerWithoutSummon.Limits[CombatZones.Middle] = 4
CombatStyles.HollowManSummonerWithoutSummon.Limits[CombatZones.Far] = 6
CombatStyles.HollowManSummonerWithoutSummon.Limits[CombatZones.Left] = 1
CombatStyles.HollowManSummonerWithoutSummon.Limits[CombatZones.Right] = 1
CombatStyles.HollowManSummonerWithoutSummon.Limits[CombatZones.Rear] = 3
CombatStyles.HollowManSummonerWithoutSummon.MinSecondsBetweenMeleeAttacks = 0.25
CombatStyles.HollowManSummonerWithoutSummon.SecondsToWaitAfterTargetIsHit = 0.25
CombatStyles.HollowManSummonerWithoutSummon.SecondsToWaitAfterTargetIsAttacked = 0
CombatStyles.HollowManSummonerWithoutSummon.MaxNavSpeed = ENavigationSpeed.NAV_SPEED_WALK
CombatStyles.HollowManSummonerWithoutSummon.HollowManParams = {}
CombatStyles.HollowManSummonerWithoutSummon.HollowManParams.WispSpeed = 1
CombatStyles.HollowManSummonerWithoutSummon.HollowManParams.MinimumSpawnDist = 1.75
CombatStyles.HollowManSummonerWithoutSummon.HollowManParams.SpawnDistRandom = 1.25
CombatStyles.HollowManSummonerWithoutSummon.HollowManParams.TargetSpeedToDistMultiplier = 1.2
CombatStyles.HollowManSummonerWithoutSummon.HollowManParams.DistForMove = 6
CombatStyles.HollowManSummonerWithoutSummon.HollowManParams.ReturnUndergroundDist = 8
CombatStyles.HollowManSummonerWithoutSummon.HollowManParams.RiseAttackPercentageChance = 100
CombatStyles.HollowManSummonerWithoutSummon.HollowManParams.RunPercentageChance = 100
CombatStyles.HollowManSummonerWithoutSummon.HollowManParams.RunPercentageChanceAgainstRanged = 100
CombatStyles.HollowManSummonerWithoutSummon.HollowManParams.RunAttackPercentageChance = 100
CombatStyles.HollowManSummonerWithoutSummon.Sequences = {}
CombatStyles.HollowManSummonerWithoutSummon.Sequences[CombatSituations.Melee] = {
	"HollowmanSummonerRangedCounter",
	{"HollowmanSummonerBackAttack", 5},
	"HollowmanSummonerFarAttackCombo",
	"HollowmanSummonerCloseAttackCombo",
	"HollowmanSummonerAttackCombo",
	"IdleStrafeLeft",
	"IdleStrafeRight",
	"BackOff",
	"HollowManAdvance"
}
CombatStyles.HollowManSummonerWithoutSummon.Sequences[CombatSituations.HardBlocking] = {
	"HollowmanSummonerAttackOutOfBlock"
}
CombatStyles.HollowManSummonerWithoutSummon.ValidStates = {}
CombatStyles.HollowManSummonerWithoutSummon.ValidStates[CombatSituations.Melee] = {
	"WaitForActionToFinish",
	"HollowManBuggerOffAndDie",
	"CheckForBetterTarget",
	"PlayCombatSequence",
	"HollowManCharge",
	"HollowManMove",
	"MoveToFormationPos",
	"FaceTarget"
}
CombatStyles.HollowManSummonerWithoutSummon.ValidStates[CombatSituations.HardBlocking] = CombatStyles.StandardBlockingCombatStates
CombatStyles.HollowManSummonerWithoutSummon.CanBlock = true
CombatStyles.HollowManSummonerWithoutSummon.BlockData = {}
CombatStyles.HollowManSummonerWithoutSummon.BlockData.PrimaryBlockType = EBlockType.BLOCK_TYPE_STATIC
CombatStyles.HollowManSummonerWithoutSummon.BlockData.SecondsForSuccessiveHitsToPrimaryBlock = 6
CombatStyles.HollowManSummonerWithoutSummon.BlockData.NumberOfHitsToForcePrimaryBlock = 3
CombatStyles.HollowManSummonerWithoutSummon.BlockData.SecondsToBlockFor = 1
CombatStyles.HollowManSummonerWithoutSummon.CanEvadeShots = false


-- HollowMan Summoner Elite --
CombatStyles.HollowManSummonerElite = {}
CombatStyles.HollowManSummonerElite.CombatGroupType = CombatGroupTypes.HollowManLike
CombatStyles.HollowManSummonerElite.CanSheatheWeapon = false
CombatStyles.HollowManSummonerElite.DualWieldMeleeSlot = DummyObjects.HAND_LEFT
CombatStyles.HollowManSummonerElite.NonFormation = true
CombatStyles.HollowManSummonerElite.TurnToFaceTolerance = 15
CombatStyles.HollowManSummonerElite.PreferredRange = 2.5
CombatStyles.HollowManSummonerElite.CanFightUnarmed = true
CombatStyles.HollowManSummonerElite.NoWispMove = true
CombatStyles.HollowManSummonerElite.Limits = {}
CombatStyles.HollowManSummonerElite.Limits[CombatZones.Near] = 1.5
CombatStyles.HollowManSummonerElite.Limits[CombatZones.Middle] = 4
CombatStyles.HollowManSummonerElite.Limits[CombatZones.Far] = 6
CombatStyles.HollowManSummonerElite.Limits[CombatZones.Left] = 1
CombatStyles.HollowManSummonerElite.Limits[CombatZones.Right] = 1
CombatStyles.HollowManSummonerElite.Limits[CombatZones.Rear] = 3
CombatStyles.HollowManSummonerElite.MinSecondsBetweenMeleeAttacks = 0.1
CombatStyles.HollowManSummonerElite.SecondsToWaitAfterTargetIsHit = 0.1
CombatStyles.HollowManSummonerElite.SecondsToWaitAfterTargetIsAttacked = 0
CombatStyles.HollowManSummonerElite.MaxNavSpeed = ENavigationSpeed.NAV_SPEED_WALK
CombatStyles.HollowManSummonerElite.HollowManParams = {}
CombatStyles.HollowManSummonerElite.HollowManParams.WispSpeed = 1
CombatStyles.HollowManSummonerElite.HollowManParams.MinimumSpawnDist = 1.75
CombatStyles.HollowManSummonerElite.HollowManParams.SpawnDistRandom = 1.25
CombatStyles.HollowManSummonerElite.HollowManParams.TargetSpeedToDistMultiplier = 1.2
CombatStyles.HollowManSummonerElite.HollowManParams.DistForMove = 6
CombatStyles.HollowManSummonerElite.HollowManParams.ReturnUndergroundDist = 10
CombatStyles.HollowManSummonerElite.HollowManParams.RiseAttackPercentageChance = 100
CombatStyles.HollowManSummonerElite.HollowManParams.RunPercentageChance = 100
CombatStyles.HollowManSummonerElite.HollowManParams.RunPercentageChanceAgainstRanged = 100
CombatStyles.HollowManSummonerElite.HollowManParams.RunAttackPercentageChance = 100
CombatStyles.HollowManSummonerElite.Sequences = {}
CombatStyles.HollowManSummonerElite.Sequences[CombatSituations.Melee] = {
	"HollowmanSummonerRangedCounter",
	{"HollowmanSummonerBackAttack", 5},
	{"HollowmanSummonerSpellCast", 15},
	"HollowmanSummonerFarAttackCombo",
	"HollowmanSummonerCloseAttackCombo",
	"HollowmanSummonerAttackCombo",
	"IdleStrafeLeft",
	"IdleStrafeRight",
	"BackOff",
	"HollowManAdvance"
}
CombatStyles.HollowManSummonerElite.Sequences[CombatSituations.HardBlocking] = {
	"HollowmanSummonerAttackOutOfBlock"
}
CombatStyles.HollowManSummonerElite.ValidStates = {}
CombatStyles.HollowManSummonerElite.ValidStates[CombatSituations.Melee] = {
	"WaitForActionToFinish",
	"HollowManBuggerOffAndDie",
	"CheckForBetterTarget",
	"HollowManSummonAllies",
	"PlayCombatSequence",
	"HollowManCharge",
	"HollowManMove",
	"MoveToFormationPos",
	"FaceTarget"
}
CombatStyles.HollowManSummonerElite.ValidStates[CombatSituations.HardBlocking] = CombatStyles.StandardBlockingCombatStates
CombatStyles.HollowManSummonerElite.SummonerData = {
	"CreatureHollowManElite",
	"CreatureHollowManElite",
	"CreatureHollowManElite",
	"CreatureHollowManElite",
	"CreatureHollowManElite"
}
CombatStyles.HollowManSummonerElite.CanBlock = true
CombatStyles.HollowManSummonerElite.BlockData = {}
CombatStyles.HollowManSummonerElite.BlockData.PrimaryBlockType = EBlockType.BLOCK_TYPE_STATIC
CombatStyles.HollowManSummonerElite.BlockData.SecondsForSuccessiveHitsToPrimaryBlock = 6
CombatStyles.HollowManSummonerElite.BlockData.NumberOfHitsToForcePrimaryBlock = 2
CombatStyles.HollowManSummonerElite.BlockData.SecondsToBlockFor = 1
CombatStyles.HollowManSummonerElite.CanEvadeShots = false


-- HollowMan Summoner WithFireSpell DLC2 --
CombatStyles.DLC2HollowManSummonerWithFireSpell = {}
CombatStyles.DLC2HollowManSummonerWithFireSpell.CombatGroupType = CombatGroupTypes.HollowManLike
CombatStyles.DLC2HollowManSummonerWithFireSpell.CanSheatheWeapon = false
CombatStyles.DLC2HollowManSummonerWithFireSpell.DualWieldMeleeSlot = DummyObjects.HAND_LEFT
CombatStyles.DLC2HollowManSummonerWithFireSpell.NonFormation = true
CombatStyles.DLC2HollowManSummonerWithFireSpell.TurnToFaceTolerance = 15
CombatStyles.DLC2HollowManSummonerWithFireSpell.PreferredRange = 2.5
CombatStyles.DLC2HollowManSummonerWithFireSpell.CanFightUnarmed = true
CombatStyles.DLC2HollowManSummonerWithFireSpell.NoWispMove = true
CombatStyles.DLC2HollowManSummonerWithFireSpell.Limits = {}
CombatStyles.DLC2HollowManSummonerWithFireSpell.Limits[CombatZones.Near] = 1.5
CombatStyles.DLC2HollowManSummonerWithFireSpell.Limits[CombatZones.Middle] = 4
CombatStyles.DLC2HollowManSummonerWithFireSpell.Limits[CombatZones.Far] = 6
CombatStyles.DLC2HollowManSummonerWithFireSpell.Limits[CombatZones.Left] = 1
CombatStyles.DLC2HollowManSummonerWithFireSpell.Limits[CombatZones.Right] = 1
CombatStyles.DLC2HollowManSummonerWithFireSpell.Limits[CombatZones.Rear] = 3
CombatStyles.DLC2HollowManSummonerWithFireSpell.MinSecondsBetweenMeleeAttacks = 0.25
CombatStyles.DLC2HollowManSummonerWithFireSpell.SecondsToWaitAfterTargetIsHit = 0.25
CombatStyles.DLC2HollowManSummonerWithFireSpell.SecondsToWaitAfterTargetIsAttacked = 0
CombatStyles.DLC2HollowManSummonerWithFireSpell.MaxNavSpeed = ENavigationSpeed.NAV_SPEED_WALK
CombatStyles.DLC2HollowManSummonerWithFireSpell.HollowManParams = {}
CombatStyles.DLC2HollowManSummonerWithFireSpell.HollowManParams.WispSpeed = 1
CombatStyles.DLC2HollowManSummonerWithFireSpell.HollowManParams.MinimumSpawnDist = 1.75
CombatStyles.DLC2HollowManSummonerWithFireSpell.HollowManParams.SpawnDistRandom = 1.25
CombatStyles.DLC2HollowManSummonerWithFireSpell.HollowManParams.TargetSpeedToDistMultiplier = 1.2
CombatStyles.DLC2HollowManSummonerWithFireSpell.HollowManParams.DistForMove = 6
CombatStyles.DLC2HollowManSummonerWithFireSpell.HollowManParams.ReturnUndergroundDist = 10
CombatStyles.DLC2HollowManSummonerWithFireSpell.HollowManParams.RiseAttackPercentageChance = 100
CombatStyles.DLC2HollowManSummonerWithFireSpell.HollowManParams.RunPercentageChance = 100
CombatStyles.DLC2HollowManSummonerWithFireSpell.HollowManParams.RunPercentageChanceAgainstRanged = 100
CombatStyles.DLC2HollowManSummonerWithFireSpell.HollowManParams.RunAttackPercentageChance = 100
CombatStyles.DLC2HollowManSummonerWithFireSpell.Sequences = {}
CombatStyles.DLC2HollowManSummonerWithFireSpell.Sequences[CombatSituations.Melee] = {
	"DLC2HollowmanSummonerRangedCounter",
	"DLC2HollowmanSummonerBackAttack",
	"DLC2HollowmanSummonerSpellCast",
	"HollowmanSummonerFarAttackCombo",
	"HollowmanSummonerCloseAttackCombo",
	"HollowmanSummonerAttackCombo",
	"IdleStrafeLeft",
	"IdleStrafeRight",
	"BackOff",
	"HollowManAdvance"
}
CombatStyles.DLC2HollowManSummonerWithFireSpell.Sequences[CombatSituations.HardBlocking] = {
	"DLC2HollowmanSummonerAttackOutOfBlock"
}
CombatStyles.DLC2HollowManSummonerWithFireSpell.ValidStates = {}
CombatStyles.DLC2HollowManSummonerWithFireSpell.ValidStates[CombatSituations.Melee] = {
	"WaitForActionToFinish",
	"HollowManBuggerOffAndDie",
	"CheckForBetterTarget",
	"HollowManSummonAllies",
	"PlayCombatSequence",
	"HollowManCharge",
	"HollowManMove",
	"MoveToFormationPos",
	"FaceTarget"
}
CombatStyles.DLC2HollowManSummonerWithFireSpell.ValidStates[CombatSituations.HardBlocking] = CombatStyles.StandardBlockingCombatStates
CombatStyles.DLC2HollowManSummonerWithFireSpell.SummonerData = {
	"CreatureHollowManWithFireSpell",
	"CreatureHollowManWithFireSpell",
	"CreatureHollowManWithFireSpell",
	"CreatureHollowManWithFireSpell",
	"CreatureHollowManWithFireSpell"
}
CombatStyles.DLC2HollowManSummonerWithFireSpell.CanBlock = true
CombatStyles.DLC2HollowManSummonerWithFireSpell.BlockData = {}
CombatStyles.DLC2HollowManSummonerWithFireSpell.BlockData.PrimaryBlockType = EBlockType.BLOCK_TYPE_STATIC
CombatStyles.DLC2HollowManSummonerWithFireSpell.BlockData.SecondsForSuccessiveHitsToPrimaryBlock = 6
CombatStyles.DLC2HollowManSummonerWithFireSpell.BlockData.NumberOfHitsToForcePrimaryBlock = 2
CombatStyles.DLC2HollowManSummonerWithFireSpell.BlockData.SecondsToBlockFor = 1
CombatStyles.DLC2HollowManSummonerWithFireSpell.CanEvadeShots = false


CombatStyles.DLC2HollowManSummonerWithFireSpellScripted = {}
CombatStyles.DLC2HollowManSummonerWithFireSpellScripted.CombatGroupType = CombatGroupTypes.HollowManLike
CombatStyles.DLC2HollowManSummonerWithFireSpellScripted.CanSheatheWeapon = false
CombatStyles.DLC2HollowManSummonerWithFireSpellScripted.DualWieldMeleeSlot = DummyObjects.HAND_LEFT
CombatStyles.DLC2HollowManSummonerWithFireSpellScripted.NonFormation = true
CombatStyles.DLC2HollowManSummonerWithFireSpellScripted.TurnToFaceTolerance = 15
CombatStyles.DLC2HollowManSummonerWithFireSpellScripted.PreferredRange = 2.5
CombatStyles.DLC2HollowManSummonerWithFireSpellScripted.CanFightUnarmed = true
CombatStyles.DLC2HollowManSummonerWithFireSpellScripted.NoWispMove = true
CombatStyles.DLC2HollowManSummonerWithFireSpellScripted.NoWispSpawn = true
CombatStyles.DLC2HollowManSummonerWithFireSpellScripted.Limits = {}
CombatStyles.DLC2HollowManSummonerWithFireSpellScripted.Limits[CombatZones.Near] = 1.5
CombatStyles.DLC2HollowManSummonerWithFireSpellScripted.Limits[CombatZones.Middle] = 4
CombatStyles.DLC2HollowManSummonerWithFireSpellScripted.Limits[CombatZones.Far] = 6
CombatStyles.DLC2HollowManSummonerWithFireSpellScripted.Limits[CombatZones.Left] = 1
CombatStyles.DLC2HollowManSummonerWithFireSpellScripted.Limits[CombatZones.Right] = 1
CombatStyles.DLC2HollowManSummonerWithFireSpellScripted.Limits[CombatZones.Rear] = 3
CombatStyles.DLC2HollowManSummonerWithFireSpellScripted.MinSecondsBetweenMeleeAttacks = 0.25
CombatStyles.DLC2HollowManSummonerWithFireSpellScripted.SecondsToWaitAfterTargetIsHit = 0.25
CombatStyles.DLC2HollowManSummonerWithFireSpellScripted.SecondsToWaitAfterTargetIsAttacked = 0
CombatStyles.DLC2HollowManSummonerWithFireSpellScripted.MaxNavSpeed = ENavigationSpeed.NAV_SPEED_WALK
CombatStyles.DLC2HollowManSummonerWithFireSpellScripted.HollowManParams = {}
CombatStyles.DLC2HollowManSummonerWithFireSpellScripted.HollowManParams.WispSpeed = 1
CombatStyles.DLC2HollowManSummonerWithFireSpellScripted.HollowManParams.MinimumSpawnDist = 1.75
CombatStyles.DLC2HollowManSummonerWithFireSpellScripted.HollowManParams.SpawnDistRandom = 1.25
CombatStyles.DLC2HollowManSummonerWithFireSpellScripted.HollowManParams.TargetSpeedToDistMultiplier = 1.2
CombatStyles.DLC2HollowManSummonerWithFireSpellScripted.HollowManParams.DistForMove = 6
CombatStyles.DLC2HollowManSummonerWithFireSpellScripted.HollowManParams.ReturnUndergroundDist = 10
CombatStyles.DLC2HollowManSummonerWithFireSpellScripted.HollowManParams.RiseAttackPercentageChance = 100
CombatStyles.DLC2HollowManSummonerWithFireSpellScripted.HollowManParams.RunPercentageChance = 100
CombatStyles.DLC2HollowManSummonerWithFireSpellScripted.HollowManParams.RunPercentageChanceAgainstRanged = 100
CombatStyles.DLC2HollowManSummonerWithFireSpellScripted.HollowManParams.RunAttackPercentageChance = 100
CombatStyles.DLC2HollowManSummonerWithFireSpellScripted.Sequences = {}
CombatStyles.DLC2HollowManSummonerWithFireSpellScripted.Sequences[CombatSituations.Melee] = {
	"DLC2HollowmanSummonerRangedCounter",
	"DLC2HollowmanSummonerBackAttack",
	"DLC2HollowmanSummonerSpellCast",
	"HollowmanSummonerFarAttackCombo",
	"HollowmanSummonerCloseAttackCombo",
	"HollowmanSummonerAttackCombo",
	"IdleStrafeLeft",
	"IdleStrafeRight",
	"BackOff",
	"HollowManAdvance"
}
CombatStyles.DLC2HollowManSummonerWithFireSpellScripted.Sequences[CombatSituations.HardBlocking] = CombatStyles.StandardBlockingCombatStates
CombatStyles.DLC2HollowManSummonerWithFireSpellScripted.ValidStates = {}
CombatStyles.DLC2HollowManSummonerWithFireSpellScripted.ValidStates[CombatSituations.Melee] = {
	"WaitForActionToFinish",
	"HollowManBuggerOffAndDie",
	"CheckForBetterTarget",
	"HollowManSummonAllies",
	"PlayCombatSequence",
	"HollowManCharge",
	"HollowManMove",
	"MoveToFormationPos",
	"FaceTarget"
}
CombatStyles.DLC2HollowManSummonerWithFireSpellScripted.ValidStates[CombatSituations.HardBlocking] = CombatStyles.StandardBlockingCombatStates
CombatStyles.DLC2HollowManSummonerWithFireSpellScripted.SummonerData = {
	"CreatureHollowManWithFireSpellScripted",
	"CreatureHollowManWithFireSpellScripted",
	"CreatureHollowManWithFireSpellScripted",
	"CreatureHollowManWithFireSpellScripted",
	"CreatureHollowManWithFireSpellScripted"
}
CombatStyles.DLC2HollowManSummonerWithFireSpellScripted.CanBlock = true
CombatStyles.DLC2HollowManSummonerWithFireSpellScripted.BlockData = {}
CombatStyles.DLC2HollowManSummonerWithFireSpellScripted.BlockData.PrimaryBlockType = EBlockType.BLOCK_TYPE_STATIC
CombatStyles.DLC2HollowManSummonerWithFireSpellScripted.BlockData.SecondsForSuccessiveHitsToPrimaryBlock = 6
CombatStyles.DLC2HollowManSummonerWithFireSpellScripted.BlockData.NumberOfHitsToForcePrimaryBlock = 2
CombatStyles.DLC2HollowManSummonerWithFireSpellScripted.BlockData.SecondsToBlockFor = 1
CombatStyles.DLC2HollowManSummonerWithFireSpellScripted.CanEvadeShots = false



-- uncomment for debug
-- GUI.DisplayMessageBox("undeadcombatstyles.lua successfully loaded!")
-- while (GUI.IsDisplayBoxActive()) do
	-- coroutine.yield()
-- end