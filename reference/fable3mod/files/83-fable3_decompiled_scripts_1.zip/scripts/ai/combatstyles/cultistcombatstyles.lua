
-- Cultist --
CombatStyles.Cultist = {}
CombatStyles.Cultist.NonFormation = true
CombatStyles.Cultist.MaxNavSpeed = ENavigationSpeed.NAV_SPEED_WALK
CombatStyles.Cultist.Limits = {}
CombatStyles.Cultist.Limits[CombatZones.Near] = 2
CombatStyles.Cultist.Limits[CombatZones.Middle] = 7
CombatStyles.Cultist.Limits[CombatZones.Far] = 12
CombatStyles.Cultist.Limits[CombatZones.Left] = 2
CombatStyles.Cultist.Limits[CombatZones.Right] = 2
CombatStyles.Cultist.Limits[CombatZones.Rear] = 2
CombatStyles.Cultist.Sequences = {}
CombatStyles.Cultist.Sequences[CombatSituations.Melee] = {
	"BackOff",
	"Idle"
}
CombatStyles.Cultist.MinSecondsBetweenRangedAttacks = 4
CombatStyles.Cultist.LightningDamage = 20
CombatStyles.Cultist.LightningExplosionDamage = 30
CombatStyles.Cultist.CultistData = {}
CombatStyles.Cultist.CultistData.SecondsSpentVulnerable = 4
CombatStyles.Cultist.CultistData.SummonedCreatureType = "CreatureMinionMelee"
CombatStyles.Cultist.CultistData.SummonedCreatureCount = 2
CombatStyles.Cultist.CultistData.SpawnRadius = 1.5
CombatStyles.Cultist.CultistData.MinimumShieldTime = 8
CombatStyles.Cultist.CultistData.HitsToStartShield = 2
CombatStyles.Cultist.ValidStates = {}
CombatStyles.Cultist.ValidStates[CombatSituations.Melee] = {
	"CultistShield",
	"WaitForActionToFinish",
	"CheckForBetterTarget",
	"CultistSummon",
	"CultistBallLightning",
	"PlayCombatSequence",
	"NonFormationKeepDistanceMovement",
	"FaceTarget"
}


-- Cultist Elite --
CombatStyles.CultistElite = {}
CombatStyles.CultistElite.NonFormation = true
CombatStyles.CultistElite.MaxNavSpeed = ENavigationSpeed.NAV_SPEED_WALK
CombatStyles.CultistElite.Limits = {}
CombatStyles.CultistElite.Limits[CombatZones.Near] = 2
CombatStyles.CultistElite.Limits[CombatZones.Middle] = 7
CombatStyles.CultistElite.Limits[CombatZones.Far] = 12
CombatStyles.CultistElite.Limits[CombatZones.Left] = 2
CombatStyles.CultistElite.Limits[CombatZones.Right] = 2
CombatStyles.CultistElite.Limits[CombatZones.Rear] = 2
CombatStyles.CultistElite.Sequences = {}
CombatStyles.CultistElite.Sequences[CombatSituations.Melee] = {
	"BackOff",
	"Idle"
}
CombatStyles.CultistElite.MinSecondsBetweenRangedAttacks = 4
CombatStyles.CultistElite.LightningDamage = 25
CombatStyles.CultistElite.LightningExplosionDamage = 35
CombatStyles.CultistElite.CultistData = {}
CombatStyles.CultistElite.CultistData.SecondsSpentVulnerable = 4
CombatStyles.CultistElite.CultistData.SummonedCreatureType = "CreatureMinionMelee"
CombatStyles.CultistElite.CultistData.SummonedCreatureCount = 3
CombatStyles.CultistElite.CultistData.SpawnRadius = 1.5
CombatStyles.CultistElite.CultistData.MinimumShieldTime = 8
CombatStyles.CultistElite.CultistData.HitsToStartShield = 2
CombatStyles.CultistElite.ValidStates = {}
CombatStyles.CultistElite.ValidStates[CombatSituations.Melee] = {
	"CultistShield",
	"WaitForActionToFinish",
	"CheckForBetterTarget",
	"CultistSummon",
	"CultistBallLightning",
	"PlayCombatSequence",
	"NonFormationKeepDistanceMovement",
	"FaceTarget"
}


-- Cultist Boss StageOne --
CombatStyles.CultistBossStageOne = {}
CombatStyles.CultistBossStageOne.NonFormation = true
CombatStyles.CultistBossStageOne.MaxNavSpeed = ENavigationSpeed.NAV_SPEED_WALK
CombatStyles.CultistBossStageOne.Limits = {}
CombatStyles.CultistBossStageOne.Limits[CombatZones.Near] = 4
CombatStyles.CultistBossStageOne.Limits[CombatZones.Middle] = 6
CombatStyles.CultistBossStageOne.Limits[CombatZones.Far] = 15
CombatStyles.CultistBossStageOne.Limits[CombatZones.Left] = 2
CombatStyles.CultistBossStageOne.Limits[CombatZones.Right] = 2
CombatStyles.CultistBossStageOne.Limits[CombatZones.Rear] = 2
CombatStyles.CultistBossStageOne.Sequences = {}
CombatStyles.CultistBossStageOne.Sequences[CombatSituations.Melee] = {
	"BackOff",
	"Idle"
}
CombatStyles.CultistBossStageOne.CultistBossData = {}
CombatStyles.CultistBossStageOne.CultistBossData.FireballSpellLevel = 2
CombatStyles.CultistBossStageOne.CultistBossData.ForcePushSpellLevel = 3
CombatStyles.CultistBossStageOne.CultistBossData.IceStormSpellLevel = 3
CombatStyles.CultistBossStageOne.CultistBossData.UseWeaves = false
CombatStyles.CultistBossStageOne.CultistBossData.SecondsBetweenFireballs = 5
CombatStyles.CultistBossStageOne.CultistBossData.SecondsBetweenIceStormsAgainstRangedTarget = 15
CombatStyles.CultistBossStageOne.CultistBossData.SecondsBetweenIceStormsAgainstMeleeTarget = 30
CombatStyles.CultistBossStageOne.CultistBossData.SecondsInNearZoneToTriggerKeepAway = 5
CombatStyles.CultistBossStageOne.CultistBossData.RangedHitsToTriggerIceStorm = 3
CombatStyles.CultistBossStageOne.CultistBossData.SecondsToRememberHitsFor = 8
CombatStyles.CultistBossStageOne.CanBlock = true
CombatStyles.CultistBossStageOne.BlockData = {}
CombatStyles.CultistBossStageOne.BlockData.PrimaryBlockType = EBlockType.BLOCK_TYPE_STATIC
CombatStyles.CultistBossStageOne.BlockData.SecondsForSuccessiveHitsToPrimaryBlock = 6
CombatStyles.CultistBossStageOne.BlockData.NumberOfHitsToForcePrimaryBlock = 2
CombatStyles.CultistBossStageOne.BlockData.SecondaryBlockType = EBlockType.BLOCK_TYPE_DODGE_MELEE
CombatStyles.CultistBossStageOne.BlockData.SecondsForSuccessiveHitsToSecondaryBlock = 8
CombatStyles.CultistBossStageOne.BlockData.NumberOfHitsToForceSecondaryBlock = 3
CombatStyles.CultistBossStageOne.BlockData.SecondsToBlockFor = 2
CombatStyles.CultistBossStageOne.BlockData.MaxHitsToBlock = 6
CombatStyles.CultistBossStageOne.DodgeAnimations = {
	"DodgeLeft",
	"DodgeRight"
}
CombatStyles.CultistBossStageOne.ValidStates = {}
CombatStyles.CultistBossStageOne.ValidStates[CombatSituations.Melee] = {
	"CultistBossUpdateTargetData",
	"WaitForActionToFinish",
	"CultistBossKeepAway",
	"CultistBossFireball",
	"CultistBossIceStorm",
	"PlayCombatSequence",
	"NonFormationKeepDistanceMovement",
	"CultsitBossFaceTarget"
}
CombatStyles.CultistBossStageOne.ValidStates[CombatSituations.SoftBlocking] = CombatStyles.StandardBlockingCombatStates
CombatStyles.CultistBossStageOne.ValidStates[CombatSituations.HardBlocking] = CombatStyles.StandardBlockingCombatStates
CombatStyles.CultistBossStageOne.ValidStates[CombatSituations.Dodging] = CombatStyles.StandardBlockingCombatStates
CombatStyles.CultistBossStageOne.ValidStates[CombatSituations.GroupOrders] = CombatStyles.StandardGroupOrderStates


-- Cultist Boss StageTwo --
CombatStyles.CultistBossStageTwo = {}
CombatStyles.CultistBossStageTwo.NonFormation = true
CombatStyles.CultistBossStageTwo.MaxNavSpeed = ENavigationSpeed.NAV_SPEED_WALK
CombatStyles.CultistBossStageTwo.Limits = {}
CombatStyles.CultistBossStageTwo.Limits[CombatZones.Near] = 4
CombatStyles.CultistBossStageTwo.Limits[CombatZones.Middle] = 6
CombatStyles.CultistBossStageTwo.Limits[CombatZones.Far] = 15
CombatStyles.CultistBossStageTwo.Limits[CombatZones.Left] = 2
CombatStyles.CultistBossStageTwo.Limits[CombatZones.Right] = 2
CombatStyles.CultistBossStageTwo.Limits[CombatZones.Rear] = 2
CombatStyles.CultistBossStageTwo.Sequences = {}
CombatStyles.CultistBossStageTwo.Sequences[CombatSituations.Melee] = {
	"BackOff",
	"Idle"
}
CombatStyles.CultistBossStageTwo.CultistBossData = {}
CombatStyles.CultistBossStageTwo.CultistBossData.FireballSpellLevel = 3
CombatStyles.CultistBossStageTwo.CultistBossData.ForcePushSpellLevel = 4
CombatStyles.CultistBossStageTwo.CultistBossData.IceStormSpellLevel = 4
CombatStyles.CultistBossStageTwo.CultistBossData.UseWeaves = false
CombatStyles.CultistBossStageTwo.CultistBossData.SecondsBetweenFireballs = 3
CombatStyles.CultistBossStageTwo.CultistBossData.SecondsBetweenIceStormsAgainstRangedTarget = 12
CombatStyles.CultistBossStageTwo.CultistBossData.SecondsBetweenIceStormsAgainstMeleeTarget = 20
CombatStyles.CultistBossStageTwo.CultistBossData.SecondsInNearZoneToTriggerKeepAway = 3
CombatStyles.CultistBossStageTwo.CultistBossData.RangedHitsToTriggerIceStorm = 2
CombatStyles.CultistBossStageTwo.CultistBossData.SecondsToRememberHitsFor = 8
CombatStyles.CultistBossStageTwo.CanBlock = true
CombatStyles.CultistBossStageTwo.BlockData = {}
CombatStyles.CultistBossStageTwo.BlockData.PrimaryBlockType = EBlockType.BLOCK_TYPE_STATIC
CombatStyles.CultistBossStageTwo.BlockData.SecondsForSuccessiveHitsToPrimaryBlock = 6
CombatStyles.CultistBossStageTwo.BlockData.NumberOfHitsToForcePrimaryBlock = 2
CombatStyles.CultistBossStageTwo.BlockData.SecondaryBlockType = EBlockType.BLOCK_TYPE_DODGE_MELEE
CombatStyles.CultistBossStageTwo.BlockData.SecondsForSuccessiveHitsToSecondaryBlock = 8
CombatStyles.CultistBossStageTwo.BlockData.NumberOfHitsToForceSecondaryBlock = 2
CombatStyles.CultistBossStageTwo.BlockData.SecondsToBlockFor = 2
CombatStyles.CultistBossStageTwo.BlockData.MaxHitsToBlock = 7
CombatStyles.CultistBossStageTwo.DodgeAnimations = {
	"DodgeLeft",
	"DodgeRight"
}
CombatStyles.CultistBossStageTwo.ValidStates = {}
CombatStyles.CultistBossStageTwo.ValidStates[CombatSituations.Melee] = {
	"CultistBossUpdateTargetData",
	"WaitForActionToFinish",
	"CultistBossKeepAway",
	"CultistBossFireball",
	"CultistBossIceStorm",
	"PlayCombatSequence",
	"NonFormationKeepDistanceMovement",
	"CultsitBossFaceTarget"
}
CombatStyles.CultistBossStageTwo.ValidStates[CombatSituations.SoftBlocking] = CombatStyles.StandardBlockingCombatStates
CombatStyles.CultistBossStageTwo.ValidStates[CombatSituations.HardBlocking] = CombatStyles.StandardBlockingCombatStates
CombatStyles.CultistBossStageTwo.ValidStates[CombatSituations.Dodging] = CombatStyles.StandardBlockingCombatStates
CombatStyles.CultistBossStageTwo.ValidStates[CombatSituations.GroupOrders] = CombatStyles.StandardGroupOrderStates



-- uncomment for debug
-- GUI.DisplayMessageBox("cultistcombatstyles.lua successfully loaded!")
-- while (GUI.IsDisplayBoxActive()) do
	-- coroutine.yield()
-- end
