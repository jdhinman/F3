
-- LoganSoldier Easy --
CombatStyles.LoganSoldierEasy = {}
CombatStyles.LoganSoldierEasy.CombatGroupType = CombatGroupTypes.BanditLike
CombatStyles.LoganSoldierEasy.CanStrafe = true
CombatStyles.LoganSoldierEasy.CanSheatheWeapon = true
CombatStyles.LoganSoldierEasy.DesiredRange = 4
CombatStyles.LoganSoldierEasy.EnterStrafeDist = 3
CombatStyles.LoganSoldierEasy.EnterRangedStrafeDist = 10
CombatStyles.LoganSoldierEasy.StrafeActionSpeed = 1
CombatStyles.LoganSoldierEasy.Limits = {}
CombatStyles.LoganSoldierEasy.Limits[CombatZones.Near] = 1.5
CombatStyles.LoganSoldierEasy.Limits[CombatZones.Middle] = 3.5
CombatStyles.LoganSoldierEasy.Limits[CombatZones.Far] = 5.5
CombatStyles.LoganSoldierEasy.Limits[CombatZones.Left] = 2
CombatStyles.LoganSoldierEasy.Limits[CombatZones.Right] = 2
CombatStyles.LoganSoldierEasy.Limits[CombatZones.Rear] = 3
CombatStyles.LoganSoldierEasy.FleeAnim = "Flee"
CombatStyles.LoganSoldierEasy.FleeIntoAnim = "FleeInto"
CombatStyles.LoganSoldierEasy.FleeOutOfAnim = "FleeOutOf"
CombatStyles.LoganSoldierEasy.CombatStyleWhenDisarmed = "BasicUnarmed"
CombatStyles.LoganSoldierEasy.Sequences = {}
CombatStyles.LoganSoldierEasy.Sequences[CombatSituations.Melee] = {
	"LoganSoldierFarAttackCombo",
	"LoganSoldierAttackComboVar01",
	"LoganSoldierTwoStrikesAttackCombo",
	"BanditCloseAttackCombo",
	"BanditAttackCombo",
	"Idle",
	"BanditHeroFlourishResponse",
    "BanditLeftAttack",
    "BanditRightAttack",
    "BanditRearAttack"
}
CombatStyles.LoganSoldierEasy.Sequences[CombatSituations.Ranged] = {
	"NearRifleStrikeOne",
	"NearRifleStrikeTwo",
	"MidRifleStrikeOne",
	"MidRifleStrikeTwo",
	"RangedIdle"
}
CombatStyles.LoganSoldierEasy.Sequences[CombatSituations.GroupOrders] = {
	"BanditGroupRifleShooting"
}
CombatStyles.LoganSoldierEasy.MinSecondsBetweenMeleeAttacks = 2
CombatStyles.LoganSoldierEasy.SecondsToWaitAfterTargetIsHit = 3
CombatStyles.LoganSoldierEasy.MinSecondsBetweenSpecialRangedAttacks = 24
CombatStyles.LoganSoldierEasy.MinSecondsBetweenRangedAttacks = 6
CombatStyles.LoganSoldierEasy.CanStandOffAndShoot = "Aggressive"
CombatStyles.LoganSoldierEasy.CanBlock = true
CombatStyles.LoganSoldierEasy.BlockData = {}
CombatStyles.LoganSoldierEasy.BlockData.PrimaryBlockType = EBlockType.BLOCK_TYPE_STATIC
CombatStyles.LoganSoldierEasy.BlockData.SecondsForSuccessiveHitsToPrimaryBlock = 5
CombatStyles.LoganSoldierEasy.BlockData.NumberOfHitsToForcePrimaryBlock = 3
CombatStyles.LoganSoldierEasy.BlockData.MaxHitsToBlock = 2
CombatStyles.LoganSoldierEasy.BlockData.SecondsToBlockFor = 1.5
CombatStyles.LoganSoldierEasy.DodgeAnimations = {
	"DodgeLeft",
    "DodgeRight"
}
CombatStyles.LoganSoldierEasy.CanEvadeShots = false
CombatStyles.LoganSoldierEasy.AntiSpamData = {}
CombatStyles.LoganSoldierEasy.AntiSpamData.TimeToCheckFor = 5
CombatStyles.LoganSoldierEasy.AntiSpamData.ShotsToTrigger = 4
CombatStyles.LoganSoldierEasy.AntiSpamData.SpellsToTrigger = 4
CombatStyles.LoganSoldierEasy.AntiSpamData.TimeToAggroFor = 15
CombatStyles.LoganSoldierEasy.FastWeaponChanges = {
	"SheatheOneHandedWeaponThenUnsheatheRifle",
	"SheatheRifleThenUnsheatheOneHandedWeapon"
}
CombatStyles.LoganSoldierEasy.OuterRingPercentAsRanged = 0.75
CombatStyles.LoganSoldierEasy.ValidStates = {}
CombatStyles.LoganSoldierEasy.ValidStates[CombatSituations.Melee] = {
	"AntiSpamCheck",
	"PlayBanterCombatComment",
	"WaitForActionToFinish",
	"LaughAtKnockdown",
	"UpdateWeapon",
	"CheckForBetterTarget",
	"OuterRingKeepDistance",
	"OuterRingSpreadOut",
	"PlayCombatSequence",
	"MoveToFormationPos",
	"FaceTarget"
}
CombatStyles.LoganSoldierEasy.ValidStates[CombatSituations.Ranged] = {
	"AntiSpamCheck",
	"PlayBanterCombatComment",
	"WaitForActionToFinish",
	"UpdateWeapon",
	"CheckForBetterTarget",
	"GetTargetInSights",
	"FireMultiShotRangedWeapon",
	"FireRangedWeapon",
	"OuterRingKeepDistance",
	"OuterRingSpreadOut",
	"PlayCombatSequence",
	"MoveToFormationPos",
	"FaceTarget",
	"IdleWithRangedWeapon"
}
CombatStyles.LoganSoldierEasy.ValidStates[CombatSituations.HardBlocking] = CombatStyles.StandardBlockingCombatStates
CombatStyles.LoganSoldierEasy.ValidStates[CombatSituations.SoftBlocking] = CombatStyles.StandardBlockingCombatStates
CombatStyles.LoganSoldierEasy.ValidStates[CombatSituations.Dodging] = CombatStyles.StandardBlockingCombatStates
CombatStyles.LoganSoldierEasy.ValidStates[CombatSituations.GroupOrders] = CombatStyles.StandardGroupOrderStates
CombatStyles.LoganSoldierEasy.ShootingBalanceData = {}
CombatStyles.LoganSoldierEasy.ShootingBalanceData.StartingChanceToHitWithFirearm = 0
CombatStyles.LoganSoldierEasy.ShootingBalanceData.MaxChanceToHitWithFirearmCap = 0.1
CombatStyles.LoganSoldierEasy.ShootingBalanceData.ChanceToHitModBonusRangeDistance = 9
CombatStyles.LoganSoldierEasy.ShootingBalanceData.ChanceToHitModSegmentLength = 3
CombatStyles.LoganSoldierEasy.ShootingBalanceData.ChanceToHitModPercentageIncrease = 0.01
CombatStyles.LoganSoldierEasy.ShootingBalanceData.ChanceToHitModConsecutiveShotPercentageIncrease = 0.01
CombatStyles.LoganSoldierEasy.ShootingBalanceData.ChanceToHitModConsecutiveShotsTimeFrame = 28
CombatStyles.LoganSoldierEasy.ShootingBalanceData.ChanceToHitModPercentageDecreasePerOneSpeed = 0.25
CombatStyles.LoganSoldierEasy.ShootingBalanceData.ChanceToHitModTargetInCoverPercentageMultiplier = 0.9


-- LoganSoldier -- 
CombatStyles.LoganSoldier = {}
CombatStyles.LoganSoldier.CombatGroupType = CombatGroupTypes.BanditLike
CombatStyles.LoganSoldier.CanStrafe = true
CombatStyles.LoganSoldier.DesiredRange = 4
CombatStyles.LoganSoldier.EnterStrafeDist = 3
CombatStyles.LoganSoldier.StrafeActionSpeed = 1
CombatStyles.LoganSoldier.EnterRangedStrafeDist = 10
CombatStyles.LoganSoldier.CanSheatheWeapon = true
CombatStyles.LoganSoldier.Limits = {}
CombatStyles.LoganSoldier.Limits[CombatZones.Near] = 1.5
CombatStyles.LoganSoldier.Limits[CombatZones.Middle] = 3.5
CombatStyles.LoganSoldier.Limits[CombatZones.Far] = 5.5
CombatStyles.LoganSoldier.Limits[CombatZones.Left] = 2
CombatStyles.LoganSoldier.Limits[CombatZones.Right] = 2
CombatStyles.LoganSoldier.Limits[CombatZones.Rear] = 3
CombatStyles.LoganSoldier.CanFlee = false
CombatStyles.LoganSoldier.CombatStyleWhenDisarmed = "BasicUnarmed"
CombatStyles.LoganSoldier.Sequences = {}
CombatStyles.LoganSoldier.Sequences[CombatSituations.Melee] = {
	"BanditInteruptSpellMelee",
	"BanditEliteOrbSuckingResponse",
	"LoganSoldierFarAttackCombo",
	"LoganSoldierAttackComboVar01",
	"LoganSoldierAttackCombo",
	"LoganSoldierTwoStrikesAttackCombo",
	"BanditEliteAttackCombo",
	"BanditEliteCloseAttackCombo",
	"BanditEliteFastBackOff",
	"BanditLeftAttack",
    "BanditRightAttack",
    "LoganSoldierRearAttack",
    "Idle"
}
CombatStyles.LoganSoldier.Sequences[CombatSituations.Ranged] = {
	"NearRifleStrikeOne",
	"NearRifleStrikeTwo",
	"MidRifleStrikeOne",
	"MidRifleStrikeTwo",
	"BanditLeaderInteruptSpellRanged",
	"RangedIdle",
	"BanditFastBackOff"
}
CombatStyles.LoganSoldier.Sequences[CombatSituations.HardBlocking] = {
	"LoganSoldierAttackOutOfBlock"
}
CombatStyles.LoganSoldier.Sequences[CombatSituations.GroupOrders] = {
	"BanditGroupRifleShooting",
	"BanditGroupMeleeAttack",
	"BanditGoad",
	"BanditOuterGoad"
}
CombatStyles.LoganSoldier.FastWeaponChanges = {
	"SheatheOneHandedWeaponThenUnsheatheRifle",
	"SheatheRifleThenUnsheatheOneHandedWeapon"
}
CombatStyles.LoganSoldier.MinSecondsBetweenMeleeAttacks = 1.75
CombatStyles.LoganSoldier.SecondsToWaitAfterTargetIsHit = 2.25
CombatStyles.LoganSoldier.MinSecondsBetweenRangedAttacks = 4
CombatStyles.LoganSoldier.MinSecondsBetweenSpecialRangedAttacks = 16
CombatStyles.LoganSoldier.CanStandOffAndShoot = "Aggressive"
CombatStyles.LoganSoldier.CanBlock = true
CombatStyles.LoganSoldier.BlockData = {}
CombatStyles.LoganSoldier.BlockData.PrimaryBlockType = EBlockType.BLOCK_TYPE_STATIC
CombatStyles.LoganSoldier.BlockData.SecondsForSuccessiveHitsToPrimaryBlock = 8
CombatStyles.LoganSoldier.BlockData.NumberOfHitsToForcePrimaryBlock = 2
CombatStyles.LoganSoldier.BlockData.SecondsToBlockFor = 1.8
CombatStyles.LoganSoldier.DodgeAnimations = {
	"DodgeLeft",
    "DodgeRight"
}
CombatStyles.LoganSoldier.CanEvadeShots = false
CombatStyles.LoganSoldier.AntiSpamData = {}
CombatStyles.LoganSoldier.AntiSpamData.TimeToCheckFor = 4
CombatStyles.LoganSoldier.AntiSpamData.ShotsToTrigger = 4
CombatStyles.LoganSoldier.AntiSpamData.SpellsToTrigger = 4
CombatStyles.LoganSoldier.AntiSpamData.TimeToAggroFor = 8
CombatStyles.LoganSoldier.OuterRingPercentAsRanged = 0.5
CombatStyles.LoganSoldier.ValidStates = {}
CombatStyles.LoganSoldier.ValidStates[CombatSituations.Melee] = {
	"AntiSpamCheck",
	"PlayBanterCombatComment",
	"WaitForActionToFinish",
	"UpdateWeapon",
	"CheckForBetterTarget",
	"RetreatFromFlourish",
	"OuterRingKeepDistance",
	"OuterRingSpreadOut",
	"PlayCombatSequence",
	"MoveToFormationPos",
	"FaceTarget"
}
CombatStyles.LoganSoldier.ValidStates[CombatSituations.Ranged] = {
	"AntiSpamCheck",
	"PlayBanterCombatComment",
	"WaitForActionToFinish",
	"UpdateWeapon",
	"CheckForBetterTarget",
	"RetreatFromFlourish",
	"GetTargetInSights",
	"FireMultiShotRangedWeapon",
	"FireRangedWeapon",
	"OuterRingKeepDistance",
	"OuterRingSpreadOut",
	"PlayCombatSequence",
	"MoveToFormationPos",
	"FaceTarget",
	"IdleWithRangedWeapon"
}
CombatStyles.LoganSoldier.ValidStates[CombatSituations.SoftBlocking] = CombatStyles.StandardBlockingCombatStates
CombatStyles.LoganSoldier.ValidStates[CombatSituations.HardBlocking] = CombatStyles.StandardBlockingCombatStates
CombatStyles.LoganSoldier.ValidStates[CombatSituations.Dodging] = CombatStyles.StandardBlockingCombatStates
CombatStyles.LoganSoldier.ValidStates[CombatSituations.GroupOrders] = CombatStyles.StandardGroupOrderStates
CombatStyles.LoganSoldier.ShootingBalanceData = {}
CombatStyles.LoganSoldier.ShootingBalanceData.StartingChanceToHitWithFirearm = 0
CombatStyles.LoganSoldier.ShootingBalanceData.MaxChanceToHitWithFirearmCap = 0.12
CombatStyles.LoganSoldier.ShootingBalanceData.ChanceToHitModBonusRangeDistance = 9
CombatStyles.LoganSoldier.ShootingBalanceData.ChanceToHitModSegmentLength = 3
CombatStyles.LoganSoldier.ShootingBalanceData.ChanceToHitModPercentageIncrease = 0.01
CombatStyles.LoganSoldier.ShootingBalanceData.ChanceToHitModConsecutiveShotPercentageIncrease = 0.01
CombatStyles.LoganSoldier.ShootingBalanceData.ChanceToHitModConsecutiveShotsTimeFrame = 21
CombatStyles.LoganSoldier.ShootingBalanceData.ChanceToHitModPercentageDecreasePerOneSpeed = 0.15
CombatStyles.LoganSoldier.ShootingBalanceData.ChanceToHitModTargetInCoverPercentageMultiplier = 0.9
CombatStyles.LoganSoldier.ShootingBalanceData.ChanceToHitModOffScreenPercentageMultiplier = 0.15


-- LoganSoldier Aggressive --
CombatStyles.LoganSoldierAggressive = {}
CombatStyles.LoganSoldierAggressive.CombatGroupType = CombatGroupTypes.BanditLike
CombatStyles.LoganSoldierAggressive.CanStrafe = true
CombatStyles.LoganSoldierAggressive.DesiredRange = 2.5
CombatStyles.LoganSoldierAggressive.EnterStrafeDist = 3
CombatStyles.LoganSoldierAggressive.StrafeActionSpeed = 1
CombatStyles.LoganSoldierAggressive.EnterRangedStrafeDist = 10
CombatStyles.LoganSoldierAggressive.CanSheatheWeapon = true
CombatStyles.LoganSoldierAggressive.Limits = {}
CombatStyles.LoganSoldierAggressive.Limits[CombatZones.Near] = 1.5
CombatStyles.LoganSoldierAggressive.Limits[CombatZones.Middle] = 3.5
CombatStyles.LoganSoldierAggressive.Limits[CombatZones.Far] = 5.5
CombatStyles.LoganSoldierAggressive.Limits[CombatZones.Left] = 2
CombatStyles.LoganSoldierAggressive.Limits[CombatZones.Right] = 2
CombatStyles.LoganSoldierAggressive.Limits[CombatZones.Rear] = 3
CombatStyles.LoganSoldierAggressive.CanFlee = false
CombatStyles.LoganSoldierAggressive.CombatStyleWhenDisarmed = "BasicUnarmed"
CombatStyles.LoganSoldierAggressive.Sequences = {}
CombatStyles.LoganSoldierAggressive.Sequences[CombatSituations.Melee] = {
	"LoganSoldierRearAttack",
	"LoganSoldierInteruptAllSpellsMelee",
	"LoganSoldierFlourishResponse",
	"LoganSoldierFarAttackCombo",
	"LoganSoldierAttackComboVar01",
	"LoganSoldierAttackCombo",
	"LoganSoldierTwoStrikesAttackCombo",
	"BanditEliteAttackCombo",
	"BanditEliteCloseAttackCombo",
	"BanditEliteFastBackOff",
	"BanditLeftAttack",
    "BanditRightAttack",
    "Idle"
}
CombatStyles.LoganSoldierAggressive.Sequences[CombatSituations.Ranged] = {
	"NearRifleStrikeOne",
	"NearRifleStrikeTwo",
	"MidRifleStrikeOne",
	"MidRifleStrikeTwo",
	"BanditLeaderInteruptSpellRanged",
	"RangedIdle",
	"BanditFastBackOff"
}
CombatStyles.LoganSoldierAggressive.Sequences[CombatSituations.HardBlocking] = {
	"LoganSoldierAttackOutOfBlock"
}
CombatStyles.LoganSoldierAggressive.FastWeaponChanges = {
	"SheatheOneHandedWeaponThenUnsheatheRifle",
	"SheatheRifleThenUnsheatheOneHandedWeapon"
}
CombatStyles.LoganSoldierAggressive.MinSecondsBetweenMeleeAttacks = 1
CombatStyles.LoganSoldierAggressive.SecondsToWaitAfterTargetIsHit = 1.5
CombatStyles.LoganSoldierAggressive.CanBlock = true
CombatStyles.LoganSoldierAggressive.BlockData = {}
CombatStyles.LoganSoldierAggressive.BlockData.PrimaryBlockType = EBlockType.BLOCK_TYPE_STATIC
CombatStyles.LoganSoldierAggressive.BlockData.SecondsForSuccessiveHitsToPrimaryBlock = 8
CombatStyles.LoganSoldierAggressive.BlockData.NumberOfHitsToForcePrimaryBlock = 3
CombatStyles.LoganSoldierAggressive.BlockData.SecondsToBlockFor = 1.8
CombatStyles.LoganSoldierAggressive.DodgeAnimations = {
	"DodgeLeft",
    "DodgeRight"
}
CombatStyles.LoganSoldierAggressive.CanEvadeShots = false
CombatStyles.LoganSoldierAggressive.AntiSpamData = {}
CombatStyles.LoganSoldierAggressive.AntiSpamData.TimeToCheckFor = 4
CombatStyles.LoganSoldierAggressive.AntiSpamData.ShotsToTrigger = 4
CombatStyles.LoganSoldierAggressive.AntiSpamData.SpellsToTrigger = 4
CombatStyles.LoganSoldierAggressive.AntiSpamData.TimeToAggroFor = 8
CombatStyles.LoganSoldierAggressive.OuterRingPercentAsRanged = 0.5
CombatStyles.LoganSoldierAggressive.ValidStates = {}
CombatStyles.LoganSoldierAggressive.ValidStates[CombatSituations.Melee] = {
	"AntiSpamCheck",
	"PlayBanterCombatComment",
	"WaitForActionToFinish",
	"UpdateWeapon",
	"CheckForBetterTarget",
	"OuterRingKeepDistance",
	"OuterRingSpreadOut",
	"PlayCombatSequence",
	"MoveToFormationPos",
	"FaceTarget"
}
CombatStyles.LoganSoldierAggressive.ValidStates[CombatSituations.SoftBlocking] = CombatStyles.StandardBlockingCombatStates
CombatStyles.LoganSoldierAggressive.ValidStates[CombatSituations.HardBlocking] = CombatStyles.StandardBlockingCombatStates
CombatStyles.LoganSoldierAggressive.ValidStates[CombatSituations.Dodging] = CombatStyles.StandardBlockingCombatStates
CombatStyles.LoganSoldierAggressive.ValidStates[CombatSituations.GroupOrders] = CombatStyles.StandardGroupOrderStates


-- LoganSoldier Pistolier --
CombatStyles.LoganSoldierPistolier = {}
CombatStyles.LoganSoldierPistolier.CombatGroupType = CombatGroupTypes.BanditLike
CombatStyles.LoganSoldierPistolier.CanStrafe = true
CombatStyles.LoganSoldierPistolier.DesiredRange = 4
CombatStyles.LoganSoldierPistolier.EnterStrafeDist = 3
CombatStyles.LoganSoldierPistolier.StrafeActionSpeed = 1
CombatStyles.LoganSoldierPistolier.EnterRangedStrafeDist = 10
CombatStyles.LoganSoldierPistolier.CanSheatheWeapon = true
CombatStyles.LoganSoldierPistolier.Limits = {}
CombatStyles.LoganSoldierPistolier.Limits[CombatZones.Near] = 1.5
CombatStyles.LoganSoldierPistolier.Limits[CombatZones.Middle] = 3.5
CombatStyles.LoganSoldierPistolier.Limits[CombatZones.Far] = 5.5
CombatStyles.LoganSoldierPistolier.Limits[CombatZones.Left] = 2
CombatStyles.LoganSoldierPistolier.Limits[CombatZones.Right] = 2
CombatStyles.LoganSoldierPistolier.Limits[CombatZones.Rear] = 3
CombatStyles.LoganSoldierPistolier.CanFlee = false
CombatStyles.LoganSoldierPistolier.CombatStyleWhenDisarmed = "BasicUnarmed"
CombatStyles.LoganSoldierPistolier.Sequences = {}
CombatStyles.LoganSoldierPistolier.Sequences[CombatSituations.Melee] = {
	"BanditInteruptSpellMelee",
	"BanditEliteOrbSuckingResponse",
	"LoganSoldierFarAttackCombo",
	"LoganSoldierAttackComboVar01",
	"LoganSoldierAttackCombo",
	"LoganSoldierTwoStrikesAttackCombo",
	"BanditEliteAttackCombo",
	"BanditEliteCloseAttackCombo",
	"BanditEliteFastBackOff",
	"BanditLeftAttack",
    "BanditRightAttack",
    "LoganSoldierRearAttack",
    "Idle"
}
CombatStyles.LoganSoldierPistolier.Sequences[CombatSituations.Ranged] = {
	"NearRifleStrikeOne",
	"NearRifleStrikeTwo",
	"MidRifleStrikeOne",
	"MidRifleStrikeTwo",
	"BanditLeaderInteruptSpellRanged",
	"RangedIdle",
	"BanditFastBackOff"
}
CombatStyles.LoganSoldierPistolier.Sequences[CombatSituations.HardBlocking] = {
	"LoganSoldierAttackOutOfBlock"
}
CombatStyles.LoganSoldierPistolier.Sequences[CombatSituations.GroupOrders] = {
	"BanditGroupRifleShooting",
	"BanditGroupMeleeAttack",
	"BanditGoad",
	"BanditOuterGoad"
}
CombatStyles.LoganSoldierPistolier.FastWeaponChanges = {
	"SheatheOneHandedWeaponThenUnsheatheRifle",
	"SheatheRifleThenUnsheatheOneHandedWeapon"
}
CombatStyles.LoganSoldierPistolier.MinSecondsBetweenMeleeAttacks = 1.25
CombatStyles.LoganSoldierPistolier.SecondsToWaitAfterTargetIsHit = 1.75
CombatStyles.LoganSoldierPistolier.MinSecondsBetweenRangedAttacks = 4
CombatStyles.LoganSoldierPistolier.MinSecondsBetweenSpecialRangedAttacks = 16
CombatStyles.LoganSoldierPistolier.CanStandOffAndShoot = "Defensive"
CombatStyles.LoganSoldierPistolier.CanBlock = true
CombatStyles.LoganSoldierPistolier.BlockData = {}
CombatStyles.LoganSoldierPistolier.BlockData.PrimaryBlockType = EBlockType.BLOCK_TYPE_STATIC
CombatStyles.LoganSoldierPistolier.BlockData.SecondsForSuccessiveHitsToPrimaryBlock = 8
CombatStyles.LoganSoldierPistolier.BlockData.NumberOfHitsToForcePrimaryBlock = 2
CombatStyles.LoganSoldierPistolier.BlockData.SecondsToBlockFor = 1.8
CombatStyles.LoganSoldierPistolier.DodgeAnimations = {
	"DodgeLeft",
    "DodgeRight"
}
CombatStyles.LoganSoldierPistolier.CanEvadeShots = false
CombatStyles.LoganSoldierPistolier.AntiSpamData = {}
CombatStyles.LoganSoldierPistolier.AntiSpamData.TimeToCheckFor = 4
CombatStyles.LoganSoldierPistolier.AntiSpamData.ShotsToTrigger = 4
CombatStyles.LoganSoldierPistolier.AntiSpamData.SpellsToTrigger = 4
CombatStyles.LoganSoldierPistolier.AntiSpamData.TimeToAggroFor = 8
CombatStyles.LoganSoldierPistolier.OuterRingPercentAsRanged = 0.5
CombatStyles.LoganSoldierPistolier.ValidStates = {}
CombatStyles.LoganSoldierPistolier.ValidStates[CombatSituations.Melee] = {
	"AntiSpamCheck",
	"PlayBanterCombatComment",
	"WaitForActionToFinish",
	"UpdateWeapon",
	"CheckForBetterTarget",
	"RetreatFromFlourish",
	"OuterRingKeepDistance",
	"OuterRingSpreadOut",
	"PlayCombatSequence",
	"MoveToFormationPos",
	"FaceTarget"
}
CombatStyles.LoganSoldierPistolier.ValidStates[CombatSituations.Ranged] = {
	"AntiSpamCheck",
	"PlayBanterCombatComment",
	"WaitForActionToFinish",
	"UpdateWeapon",
	"CheckForBetterTarget",
	"RetreatFromFlourish",
	"GetTargetInSights",
	"FireMultiShotRangedWeapon",
	"FireRangedWeapon",
	"OuterRingKeepDistance",
	"OuterRingSpreadOut",
	"PlayCombatSequence",
	"MoveToFormationPos",
	"FaceTarget",
	"IdleWithRangedWeapon"
}
CombatStyles.LoganSoldierPistolier.ValidStates[CombatSituations.SoftBlocking] = CombatStyles.StandardBlockingCombatStates
CombatStyles.LoganSoldierPistolier.ValidStates[CombatSituations.HardBlocking] = CombatStyles.StandardBlockingCombatStates
CombatStyles.LoganSoldierPistolier.ValidStates[CombatSituations.Dodging] = CombatStyles.StandardBlockingCombatStates
CombatStyles.LoganSoldierPistolier.ValidStates[CombatSituations.GroupOrders] = CombatStyles.StandardGroupOrderStates
CombatStyles.LoganSoldierPistolier.ShootingBalanceData = {}
CombatStyles.LoganSoldierPistolier.ShootingBalanceData.StartingChanceToHitWithFirearm = 0
CombatStyles.LoganSoldierPistolier.ShootingBalanceData.MaxChanceToHitWithFirearmCap = 0.12
CombatStyles.LoganSoldierPistolier.ShootingBalanceData.ChanceToHitModBonusRangeDistance = 9
CombatStyles.LoganSoldierPistolier.ShootingBalanceData.ChanceToHitModSegmentLength = 3
CombatStyles.LoganSoldierPistolier.ShootingBalanceData.ChanceToHitModPercentageIncrease = 0.01
CombatStyles.LoganSoldierPistolier.ShootingBalanceData.ChanceToHitModConsecutiveShotPercentageIncrease = 0.01
CombatStyles.LoganSoldierPistolier.ShootingBalanceData.ChanceToHitModConsecutiveShotsTimeFrame = 21
CombatStyles.LoganSoldierPistolier.ShootingBalanceData.ChanceToHitModPercentageDecreasePerOneSpeed = 0.15
CombatStyles.LoganSoldierPistolier.ShootingBalanceData.ChanceToHitModTargetInCoverPercentageMultiplier = 0.9
CombatStyles.LoganSoldierPistolier.ShootingBalanceData.ChanceToHitModOffScreenPercentageMultiplier = 0.15


-- LoganSoldier Elite --
CombatStyles.LoganSoldierElite = {}
CombatStyles.LoganSoldierElite.CombatGroupType = CombatGroupTypes.BanditLike
CombatStyles.LoganSoldierElite.CanStrafe = true
CombatStyles.LoganSoldierElite.DesiredRange = 4
CombatStyles.LoganSoldierElite.EnterStrafeDist = 3
CombatStyles.LoganSoldierElite.StrafeActionSpeed = 1
CombatStyles.LoganSoldierElite.EnterRangedStrafeDist = 10
CombatStyles.LoganSoldierElite.CanSheatheWeapon = true
CombatStyles.LoganSoldierElite.Limits = {}
CombatStyles.LoganSoldierElite.Limits[CombatZones.Near] = 1.5
CombatStyles.LoganSoldierElite.Limits[CombatZones.Middle] = 3.5
CombatStyles.LoganSoldierElite.Limits[CombatZones.Far] = 5.5
CombatStyles.LoganSoldierElite.Limits[CombatZones.Left] = 2
CombatStyles.LoganSoldierElite.Limits[CombatZones.Right] = 2
CombatStyles.LoganSoldierElite.Limits[CombatZones.Rear] = 3
CombatStyles.LoganSoldierElite.CanFlee = false
CombatStyles.LoganSoldierElite.CombatStyleWhenDisarmed = "BasicUnarmed"
CombatStyles.LoganSoldierElite.Sequences = {}
CombatStyles.LoganSoldierElite.Sequences[CombatSituations.Melee] = {
	"BanditInteruptSpellMelee",
	"BanditEliteOrbSuckingResponse",
	"LoganSoldierFarAttackCombo",
	"LoganSoldierTwoStrikesAttackCombo",
	"LoganSoldierElitePushBackCombo",
	"LoganSoldierAttackComboVar01",
	"LoganSoldierAttackCombo",
	"BanditEliteAttackCombo",
	"LoganSoldierEliteClosePushBackAttack",
	"BanditEliteCloseAttackCombo",
	"BanditEliteFastBackOff",
	"BanditLeftAttack",
	"BanditRightAttack",
    "LoganSoldierRearAttack",
    "Idle"
}
CombatStyles.LoganSoldierElite.Sequences[CombatSituations.Ranged] = {
	"NearRifleStrikeOne",
	"NearRifleStrikeTwo",
	"MidRifleStrikeOne",
	"MidRifleStrikeTwo",
	"BanditLeaderInteruptSpellRanged",
	"RangedIdle",
	"BanditFastBackOff"
}
CombatStyles.LoganSoldierElite.Sequences[CombatSituations.HardBlocking] = {
	"LoganSoldierAttackOutOfBlock"
}
CombatStyles.LoganSoldierElite.Sequences[CombatSituations.GroupOrders] = {
	"BanditGroupRifleShooting",
	"BanditGroupMeleeAttack",
	"BanditGoad",
	"BanditOuterGoad"
}
CombatStyles.LoganSoldierElite.FastWeaponChanges = {
	"SheatheOneHandedWeaponThenUnsheatheRifle",
	"SheatheRifleThenUnsheatheOneHandedWeapon"
}
CombatStyles.LoganSoldierElite.MinSecondsBetweenMeleeAttacks = 1.1
CombatStyles.LoganSoldierElite.SecondsToWaitAfterTargetIsHit = 1.75
CombatStyles.LoganSoldierElite.MinSecondsBetweenRangedAttacks = 3
CombatStyles.LoganSoldierElite.MinSecondsBetweenSpecialRangedAttacks = 16
CombatStyles.LoganSoldierElite.CanStandOffAndShoot = "Aggressive"
CombatStyles.LoganSoldierElite.CanBlock = true
CombatStyles.LoganSoldierElite.BlockData = {}
CombatStyles.LoganSoldierElite.BlockData.PrimaryBlockType = EBlockType.BLOCK_TYPE_STATIC
CombatStyles.LoganSoldierElite.BlockData.SecondsForSuccessiveHitsToPrimaryBlock = 8
CombatStyles.LoganSoldierElite.BlockData.NumberOfHitsToForcePrimaryBlock = 2
CombatStyles.LoganSoldierElite.BlockData.SecondsToBlockFor = 1.8
CombatStyles.LoganSoldierElite.DodgeAnimations = {
	"DodgeLeft",
    "DodgeRight"
}
CombatStyles.LoganSoldierElite.CanEvadeShots = false
CombatStyles.LoganSoldierElite.AntiSpamData = {}
CombatStyles.LoganSoldierElite.AntiSpamData.TimeToCheckFor = 4
CombatStyles.LoganSoldierElite.AntiSpamData.ShotsToTrigger = 4
CombatStyles.LoganSoldierElite.AntiSpamData.SpellsToTrigger = 4
CombatStyles.LoganSoldierElite.AntiSpamData.TimeToAggroFor = 8
CombatStyles.LoganSoldierElite.OuterRingPercentAsRanged = 0.5
CombatStyles.LoganSoldierElite.ValidStates = {}
CombatStyles.LoganSoldierElite.ValidStates[CombatSituations.Melee] = {
	"AntiSpamCheck",
	"PlayBanterCombatComment",
	"WaitForActionToFinish",
	"UpdateWeapon",
	"CheckForBetterTarget",
	"RetreatFromFlourish",
	"RetreatFromSpellCharging",
	"OuterRingKeepDistance",
	"OuterRingSpreadOut",
	"PlayCombatSequence",
	"MoveToFormationPos",
	"FaceTarget"
}
CombatStyles.LoganSoldierElite.ValidStates[CombatSituations.Ranged] = {
	"AntiSpamCheck",
	"PlayBanterCombatComment",
	"WaitForActionToFinish",
	"UpdateWeapon",
	"CheckForBetterTarget",
	"RetreatFromFlourish",
	"RetreatFromSpellCharging",
	"GetTargetInSights",
	"FireMultiShotRangedWeapon",
	"FireRangedWeapon",
	"OuterRingKeepDistance",
	"OuterRingSpreadOut",
	"PlayCombatSequence",
	"MoveToFormationPos",
	"FaceTarget",
	"IdleWithRangedWeapon"
}
CombatStyles.LoganSoldierElite.ValidStates[CombatSituations.SoftBlocking] = CombatStyles.StandardBlockingCombatStates
CombatStyles.LoganSoldierElite.ValidStates[CombatSituations.HardBlocking] = CombatStyles.StandardBlockingCombatStates
CombatStyles.LoganSoldierElite.ValidStates[CombatSituations.Dodging] = CombatStyles.StandardBlockingCombatStates
CombatStyles.LoganSoldierElite.ValidStates[CombatSituations.GroupOrders] = CombatStyles.StandardGroupOrderStates
CombatStyles.LoganSoldierElite.ShootingBalanceData = {}
CombatStyles.LoganSoldierElite.ShootingBalanceData.StartingChanceToHitWithFirearm = 0
CombatStyles.LoganSoldierElite.ShootingBalanceData.MaxChanceToHitWithFirearmCap = 0.15
CombatStyles.LoganSoldierElite.ShootingBalanceData.ChanceToHitModBonusRangeDistance = 9
CombatStyles.LoganSoldierElite.ShootingBalanceData.ChanceToHitModSegmentLength = 3
CombatStyles.LoganSoldierElite.ShootingBalanceData.ChanceToHitModPercentageIncrease = 0.01
CombatStyles.LoganSoldierElite.ShootingBalanceData.ChanceToHitModConsecutiveShotPercentageIncrease = 0.01
CombatStyles.LoganSoldierElite.ShootingBalanceData.ChanceToHitModConsecutiveShotsTimeFrame = 21
CombatStyles.LoganSoldierElite.ShootingBalanceData.ChanceToHitModPercentageDecreasePerOneSpeed = 0.05
CombatStyles.LoganSoldierElite.ShootingBalanceData.ChanceToHitModTargetInCoverPercentageMultiplier = 0.9
CombatStyles.LoganSoldierElite.ShootingBalanceData.ChanceToHitModOffScreenPercentageMultiplier = 0.15


-- LoganSoldier Elite Aggressive --
CombatStyles.LoganSoldierEliteAggressive = {}
CombatStyles.LoganSoldierEliteAggressive.CombatGroupType = CombatGroupTypes.BanditLike
CombatStyles.LoganSoldierEliteAggressive.CanStrafe = true
CombatStyles.LoganSoldierEliteAggressive.DesiredRange = 2.5
CombatStyles.LoganSoldierEliteAggressive.EnterStrafeDist = 3
CombatStyles.LoganSoldierEliteAggressive.StrafeActionSpeed = 1
CombatStyles.LoganSoldierEliteAggressive.EnterRangedStrafeDist = 10
CombatStyles.LoganSoldierEliteAggressive.CanSheatheWeapon = true
CombatStyles.LoganSoldierEliteAggressive.Limits = {}
CombatStyles.LoganSoldierEliteAggressive.Limits[CombatZones.Near] = 1.5
CombatStyles.LoganSoldierEliteAggressive.Limits[CombatZones.Middle] = 3.5
CombatStyles.LoganSoldierEliteAggressive.Limits[CombatZones.Far] = 5.5
CombatStyles.LoganSoldierEliteAggressive.Limits[CombatZones.Left] = 2
CombatStyles.LoganSoldierEliteAggressive.Limits[CombatZones.Right] = 2
CombatStyles.LoganSoldierEliteAggressive.Limits[CombatZones.Rear] = 3
CombatStyles.LoganSoldierEliteAggressive.CanFlee = false
CombatStyles.LoganSoldierEliteAggressive.CombatStyleWhenDisarmed = "BasicUnarmed"
CombatStyles.LoganSoldierEliteAggressive.Sequences = {}
CombatStyles.LoganSoldierEliteAggressive.Sequences[CombatSituations.Melee] = {
	"LoganSoldierRearAttack",
	"LoganSoldierInteruptAllSpellsMelee",
	"LoganSoldierFlourishResponse",
	"LoganSoldierFarAttackCombo",
	"LoganSoldierTwoStrikesAttackCombo",
	"LoganSoldierElitePushBackCombo",
	"LoganSoldierAttackComboVar01",
	"LoganSoldierAttackCombo",
	"BanditEliteAttackCombo",
	"LoganSoldierEliteClosePushBackAttack",
	"BanditEliteCloseAttackCombo",
	"BanditEliteFastBackOff",
	"BanditLeftAttack",
    "BanditRightAttack",
    "Idle"
}
CombatStyles.LoganSoldierEliteAggressive.Sequences[CombatSituations.HardBlocking] = {
	"LoganSoldierAttackOutOfBlock"
}
CombatStyles.LoganSoldierEliteAggressive.FastWeaponChanges = {
	"SheatheOneHandedWeaponThenUnsheatheRifle",
	"SheatheRifleThenUnsheatheOneHandedWeapon"
}
CombatStyles.LoganSoldierEliteAggressive.MinSecondsBetweenMeleeAttacks = 0.5
CombatStyles.LoganSoldierEliteAggressive.SecondsToWaitAfterTargetIsHit = 1
CombatStyles.LoganSoldierEliteAggressive.CanStandOffAndShoot = "Aggressive"
CombatStyles.LoganSoldierEliteAggressive.CanBlock = true
CombatStyles.LoganSoldierEliteAggressive.BlockData = {}
CombatStyles.LoganSoldierEliteAggressive.BlockData.PrimaryBlockType = EBlockType.BLOCK_TYPE_STATIC
CombatStyles.LoganSoldierEliteAggressive.BlockData.SecondsForSuccessiveHitsToPrimaryBlock = 8
CombatStyles.LoganSoldierEliteAggressive.BlockData.NumberOfHitsToForcePrimaryBlock = 3
CombatStyles.LoganSoldierEliteAggressive.BlockData.SecondsToBlockFor = 1.8
CombatStyles.LoganSoldierEliteAggressive.DodgeAnimations = {
	"DodgeLeft",
    "DodgeRight"
}
CombatStyles.LoganSoldierEliteAggressive.CanEvadeShots = false
CombatStyles.LoganSoldierEliteAggressive.AntiSpamData = {}
CombatStyles.LoganSoldierEliteAggressive.AntiSpamData.TimeToCheckFor = 4
CombatStyles.LoganSoldierEliteAggressive.AntiSpamData.ShotsToTrigger = 4
CombatStyles.LoganSoldierEliteAggressive.AntiSpamData.SpellsToTrigger = 4
CombatStyles.LoganSoldierEliteAggressive.AntiSpamData.TimeToAggroFor = 8
CombatStyles.LoganSoldierEliteAggressive.OuterRingPercentAsRanged = 0.5
CombatStyles.LoganSoldierEliteAggressive.ValidStates = {}
CombatStyles.LoganSoldierEliteAggressive.ValidStates[CombatSituations.Melee] = {
	"AntiSpamCheck",
	"PlayBanterCombatComment",
	"WaitForActionToFinish",
	"UpdateWeapon",
	"CheckForBetterTarget",
	"OuterRingKeepDistance",
	"OuterRingSpreadOut",
	"PlayCombatSequence",
	"MoveToFormationPos",
	"FaceTarget"
}
CombatStyles.LoganSoldierEliteAggressive.ValidStates[CombatSituations.SoftBlocking] = CombatStyles.StandardBlockingCombatStates
CombatStyles.LoganSoldierEliteAggressive.ValidStates[CombatSituations.HardBlocking] = CombatStyles.StandardBlockingCombatStates
CombatStyles.LoganSoldierEliteAggressive.ValidStates[CombatSituations.Dodging] = CombatStyles.StandardBlockingCombatStates
CombatStyles.LoganSoldierEliteAggressive.ValidStates[CombatSituations.GroupOrders] = CombatStyles.StandardGroupOrderStates


-- LoganSoldier Grenadier --
CombatStyles.LoganSoldierGrenadier = {}
CombatStyles.LoganSoldierGrenadier.CombatGroupType = CombatGroupTypes.BanditLike
CombatStyles.LoganSoldierGrenadier.CanStrafe = true
CombatStyles.LoganSoldierGrenadier.DesiredRange = 4
CombatStyles.LoganSoldierGrenadier.EnterStrafeDist = 3
CombatStyles.LoganSoldierGrenadier.StrafeActionSpeed = 1
CombatStyles.LoganSoldierGrenadier.EnterRangedStrafeDist = 10
CombatStyles.LoganSoldierGrenadier.CanSheatheWeapon = true
CombatStyles.LoganSoldierGrenadier.Limits = {}
CombatStyles.LoganSoldierGrenadier.Limits[CombatZones.Near] = 1.5
CombatStyles.LoganSoldierGrenadier.Limits[CombatZones.Middle] = 3.5
CombatStyles.LoganSoldierGrenadier.Limits[CombatZones.Far] = 8
CombatStyles.LoganSoldierGrenadier.Limits[CombatZones.Left] = 2
CombatStyles.LoganSoldierGrenadier.Limits[CombatZones.Right] = 2
CombatStyles.LoganSoldierGrenadier.Limits[CombatZones.Rear] = 3
CombatStyles.LoganSoldierGrenadier.CanFlee = false
CombatStyles.LoganSoldierGrenadier.CombatStyleWhenDisarmed = "BasicUnarmed"
CombatStyles.LoganSoldierGrenadier.Sequences = {}
CombatStyles.LoganSoldierGrenadier.Sequences[CombatSituations.Melee] = {
	{"LoganSoldierSwordGrenadeThrow", 15},
	"LoganSoldierAntiSpamSwordGrenadeThrow",
	"BanditInteruptSpellMelee",
	"BanditEliteOrbSuckingResponse",
	"LoganSoldierTwoStrikesAttackCombo",
	"LoganSoldierAttackComboVar01",
	"LoganSoldierAttackCombo",
	"LoganSoldierEliteClosePushBackAttack",
	"BanditEliteAttackCombo",
	"BanditEliteCloseAttackCombo",
	"BanditEliteFastBackOff",
	"BanditLeftAttack",
	"BanditRightAttack",
	"LoganSoldierRearAttack",
	"Idle"
}
CombatStyles.LoganSoldierGrenadier.Sequences[CombatSituations.Ranged] = {
	{"LoganSoldierPistolGrenadeThrow", 15},
	"LoganSoldierAntiSpamPistolGrenadeThrow",
	"NearRifleStrikeOne",
	"NearRifleStrikeTwo",
	"MidRifleStrikeOne",
	"MidRifleStrikeTwo",
	"BanditLeaderInteruptSpellRanged",
	"RangedIdle",
	"BanditFastBackOff"
}
CombatStyles.LoganSoldierGrenadier.Sequences[CombatSituations.HardBlocking] = {
	"LoganSoldierAttackOutOfBlock"
}
CombatStyles.LoganSoldierGrenadier.Sequences[CombatSituations.GroupOrders] = {
	"BanditGroupRifleShooting",
	"BanditGroupMeleeAttack",
	"BanditGoad",
	"BanditOuterGoad"
}
CombatStyles.LoganSoldierGrenadier.FastWeaponChanges = {
	"SheatheOneHandedWeaponThenUnsheathePistol",
	"SheathePistolThenUnsheatheOneHandedWeapon"
}
CombatStyles.LoganSoldierGrenadier.ShootsInMelee = true
CombatStyles.LoganSoldierGrenadier.MinSecondsBetweenMeleeAttacks = 0.6
CombatStyles.LoganSoldierGrenadier.SecondsToWaitAfterTargetIsHit = 1.1
CombatStyles.LoganSoldierGrenadier.MinSecondsBetweenRangedAttacks = 2.5
CombatStyles.LoganSoldierGrenadier.MinSecondsBetweenSpecialRangedAttacks = 15
CombatStyles.LoganSoldierGrenadier.CanStandOffAndShoot = "Defensive"
CombatStyles.LoganSoldierGrenadier.CanBlock = true
CombatStyles.LoganSoldierGrenadier.BlockData = {}
CombatStyles.LoganSoldierGrenadier.BlockData.PrimaryBlockType = EBlockType.BLOCK_TYPE_STATIC
CombatStyles.LoganSoldierGrenadier.BlockData.SecondsForSuccessiveHitsToPrimaryBlock = 8
CombatStyles.LoganSoldierGrenadier.BlockData.NumberOfHitsToForcePrimaryBlock = 1
CombatStyles.LoganSoldierGrenadier.BlockData.SecondsToBlockFor = 1.8
CombatStyles.LoganSoldierGrenadier.DodgeAnimations = {
	"DodgeLeft",
    "DodgeRight"
}
CombatStyles.LoganSoldierGrenadier.CanEvadeShots = false
CombatStyles.LoganSoldierGrenadier.AntiSpamData = {}
CombatStyles.LoganSoldierGrenadier.AntiSpamData.TimeToCheckFor = 4
CombatStyles.LoganSoldierGrenadier.AntiSpamData.ShotsToTrigger = 4
CombatStyles.LoganSoldierGrenadier.AntiSpamData.SpellsToTrigger = 4
CombatStyles.LoganSoldierGrenadier.AntiSpamData.TimeToAggroFor = 8
CombatStyles.LoganSoldierGrenadier.OuterRingPercentAsRanged = 0.5
CombatStyles.LoganSoldierGrenadier.ValidStates = {}
CombatStyles.LoganSoldierGrenadier.ValidStates[CombatSituations.Melee] = {
	"AntiSpamCheck",
	"PlayBanterCombatComment",
	"WaitForActionToFinish",
	"UpdateWeapon",
	"CheckForBetterTarget",
	"RetreatFromFlourish",
	"RetreatFromSpellCharging",
	"OuterRingKeepDistance",
	"OuterRingSpreadOut",
	"PlayCombatSequence",
	"ThrowGrenadeAtDistantTarget",
	"MoveToFormationPos",
	"FaceTarget"
}
CombatStyles.LoganSoldierGrenadier.ValidStates[CombatSituations.Ranged] = {
	"AntiSpamCheck",
	"PlayBanterCombatComment",
	"WaitForActionToFinish",
	"UpdateWeapon",
	"CheckForBetterTarget",
	"RetreatFromFlourish",
	"RetreatFromSpellCharging",
	"GetTargetInSights",
	"PlayCombatSequence",
	"ThrowGrenadeAtDistantTarget",
	"FireMultiShotRangedWeapon",
	"FireRangedWeapon",
	"OuterRingKeepDistance",
	"OuterRingSpreadOut",
	"MoveToFormationPos",
	"FaceTarget",
	"IdleWithRangedWeapon"
}
CombatStyles.LoganSoldierGrenadier.ValidStates[CombatSituations.SoftBlocking] = CombatStyles.StandardBlockingCombatStates
CombatStyles.LoganSoldierGrenadier.ValidStates[CombatSituations.HardBlocking] = CombatStyles.StandardBlockingCombatStates
CombatStyles.LoganSoldierGrenadier.ValidStates[CombatSituations.Dodging] = CombatStyles.StandardBlockingCombatStates
CombatStyles.LoganSoldierGrenadier.ValidStates[CombatSituations.GroupOrders] = CombatStyles.StandardGroupOrderStates
CombatStyles.LoganSoldierGrenadier.ShootingBalanceData = {}
CombatStyles.LoganSoldierGrenadier.ShootingBalanceData.StartingChanceToHitWithFirearm = 0
CombatStyles.LoganSoldierGrenadier.ShootingBalanceData.MaxChanceToHitWithFirearmCap = 0.15
CombatStyles.LoganSoldierGrenadier.ShootingBalanceData.ChanceToHitModBonusRangeDistance = 9
CombatStyles.LoganSoldierGrenadier.ShootingBalanceData.ChanceToHitModSegmentLength = 3
CombatStyles.LoganSoldierGrenadier.ShootingBalanceData.ChanceToHitModPercentageIncrease = 0.01
CombatStyles.LoganSoldierGrenadier.ShootingBalanceData.ChanceToHitModConsecutiveShotPercentageIncrease = 0.01
CombatStyles.LoganSoldierGrenadier.ShootingBalanceData.ChanceToHitModConsecutiveShotsTimeFrame = 21
CombatStyles.LoganSoldierGrenadier.ShootingBalanceData.ChanceToHitModPercentageDecreasePerOneSpeed = 0.05
CombatStyles.LoganSoldierGrenadier.ShootingBalanceData.ChanceToHitModTargetInCoverPercentageMultiplier = 0.9
CombatStyles.LoganSoldierGrenadier.ShootingBalanceData.ChanceToHitModOffScreenPercentageMultiplier = 0.15


-- LoganSoldier Turret --
CombatStyles.LoganSoldierTurret = DeepCopyTable(CombatStyles.LoganSoldier)
CombatStyles.LoganSoldierTurret.CanStandOffAndShoot = "Turret"
CombatStyles.LoganSoldierTurret.MinTimeToReturnToFiringPos = 20
CombatStyles.LoganSoldierTurret.NonFormation = true
CombatStyles.LoganSoldierTurret.TurretBalanceData = {}
CombatStyles.LoganSoldierTurret.TurretBalanceData.DistanceToMoveBackToShootingPosition = 1
CombatStyles.LoganSoldierTurret.TurretBalanceData.DistanceOverWhichToFindNewShootingPosition = 5
CombatStyles.LoganSoldierTurret.TurretBalanceData.NonTurretCombatStyle = "LoganSoldier"
CombatStyles.LoganSoldierTurret.Limits = {}
CombatStyles.LoganSoldierTurret.Limits[CombatZones.Near] = 1.5
CombatStyles.LoganSoldierTurret.Limits[CombatZones.Middle] = 2.5
CombatStyles.LoganSoldierTurret.Limits[CombatZones.Far] = 4.5
CombatStyles.LoganSoldierTurret.Limits[CombatZones.Left] = 1
CombatStyles.LoganSoldierTurret.Limits[CombatZones.Right] = 1
CombatStyles.LoganSoldierTurret.Limits[CombatZones.Rear] = 1
CombatStyles.LoganSoldierTurret.Sequences = {}
CombatStyles.LoganSoldierTurret.Sequences[CombatSituations.Melee] = {
	"Advance",
	"GuardCloseAttack",
	"GuardAttack",
	"FastBackOff",
	"BanditOuterGoad"
}
CombatStyles.LoganSoldierTurret.Sequences[CombatSituations.Ranged] = {
	"NearRifleStrikeOne",
	"NearRifleStrikeTwo",
	"MidRifleStrikeOne",
	"MidRifleStrikeTwo",
	"Idle",
	"FarIdle"
}
CombatStyles.LoganSoldierTurret.ValidStates = {}
CombatStyles.LoganSoldierTurret.ValidStates[CombatSituations.Ranged] = {
	"AntiSpamCheck",
	"PlayBanterCombatComment",
	"WaitForActionToFinish",
	"TurretUpdateWeapon",
	"TurretCheckTargetProximity",
	"CheckForBetterTarget",
	"MoveToFiringPosition",
	"FireMultiShotRangedWeapon",
	"FireRangedWeapon",
	"PlayCombatSequence",
	"FaceTarget",
	"IdleWithRangedWeapon"
}
CombatStyles.LoganSoldierTurret.ValidStates[CombatSituations.Melee] = {
	"AntiSpamCheck",
	"PlayBanterCombatComment",
	"WaitForActionToFinish",
	"TurretUpdateWeapon",
	"TurretCheckTargetProximity",
	"CheckForBetterTarget",
	"PlayCombatSequence",
	"FaceTarget"
}


-- LoganSoldier Turret Elite --
CombatStyles.LoganSoldierTurretElite = DeepCopyTable(CombatStyles.LoganSoldierElite)
CombatStyles.LoganSoldierTurretElite.CanStandOffAndShoot = "Turret"
CombatStyles.LoganSoldierTurretElite.MinTimeToReturnToFiringPos = 20
CombatStyles.LoganSoldierTurretElite.NonFormation = true
CombatStyles.LoganSoldierTurretElite.TurretBalanceData = {}
CombatStyles.LoganSoldierTurretElite.TurretBalanceData.DistanceToMoveBackToShootingPosition = 1
CombatStyles.LoganSoldierTurretElite.TurretBalanceData.DistanceOverWhichToFindNewShootingPosition = 5
CombatStyles.LoganSoldierTurretElite.TurretBalanceData.NonTurretCombatStyle = "LoganSoldierElite"
CombatStyles.LoganSoldierTurretElite.Limits = {}
CombatStyles.LoganSoldierTurretElite.Limits[CombatZones.Near] = 1.5
CombatStyles.LoganSoldierTurretElite.Limits[CombatZones.Middle] = 2.5
CombatStyles.LoganSoldierTurretElite.Limits[CombatZones.Far] = 4.5
CombatStyles.LoganSoldierTurretElite.Limits[CombatZones.Left] = 1
CombatStyles.LoganSoldierTurretElite.Limits[CombatZones.Right] = 1
CombatStyles.LoganSoldierTurretElite.Limits[CombatZones.Rear] = 1
CombatStyles.LoganSoldierTurretElite.Sequences = {}
CombatStyles.LoganSoldierTurretElite.Sequences[CombatSituations.Melee] = {
	"Advance",
	"GuardCloseAttack",
	"GuardAttack",
	"FastBackOff",
	"BanditOuterGoad",
	"Idle"
}
CombatStyles.LoganSoldierTurretElite.Sequences[CombatSituations.Ranged] = {
	"NearRifleStrikeOne",
	"NearRifleStrikeTwo",
	"MidRifleStrikeOne",
	"MidRifleStrikeTwo",
	"Idle",
	"FarIdle"
}
CombatStyles.LoganSoldierTurretElite.ValidStates = {}
CombatStyles.LoganSoldierTurretElite.ValidStates[CombatSituations.Ranged] = {
	"AntiSpamCheck",
	"PlayBanterCombatComment",
	"WaitForActionToFinish",
	"TurretUpdateWeapon",
	"TurretCheckTargetProximity",
	"CheckForBetterTarget",
	"MoveToFiringPosition",
	"FireMultiShotRangedWeapon",
	"FireRangedWeapon",
	"PlayCombatSequence",
	"FaceTarget",
	"IdleWithRangedWeapon"
}
CombatStyles.LoganSoldierTurretElite.ValidStates[CombatSituations.Melee] = {
	"AntiSpamCheck",
	"PlayBanterCombatComment",
	"WaitForActionToFinish",
	"TurretUpdateWeapon",
	"TurretCheckTargetProximity",
	"CheckForBetterTarget",
	"PlayCombatSequence",
	"FaceTarget"
}


-- LoganSoldier Grenadier Turret --
CombatStyles.LoganSoldierGrenadierTurret = DeepCopyTable(CombatStyles.LoganSoldierGrenadier)
CombatStyles.LoganSoldierGrenadierTurret.CanStandOffAndShoot = "Turret"
CombatStyles.LoganSoldierGrenadierTurret.MinTimeToReturnToFiringPos = 20
CombatStyles.LoganSoldierGrenadierTurret.NonFormation = true
CombatStyles.LoganSoldierGrenadierTurret.TurretBalanceData = {}
CombatStyles.LoganSoldierGrenadierTurret.TurretBalanceData.DistanceToMoveBackToShootingPosition = 1
CombatStyles.LoganSoldierGrenadierTurret.TurretBalanceData.DistanceOverWhichToFindNewShootingPosition = 5
CombatStyles.LoganSoldierGrenadierTurret.TurretBalanceData.NonTurretCombatStyle = "LoganSoldierGrenadier"
CombatStyles.LoganSoldierGrenadierTurret.Limits = {}
CombatStyles.LoganSoldierGrenadierTurret.Limits[CombatZones.Near] = 1.5
CombatStyles.LoganSoldierGrenadierTurret.Limits[CombatZones.Middle] = 2.5
CombatStyles.LoganSoldierGrenadierTurret.Limits[CombatZones.Far] = 4.5
CombatStyles.LoganSoldierGrenadierTurret.Limits[CombatZones.Left] = 1
CombatStyles.LoganSoldierGrenadierTurret.Limits[CombatZones.Right] = 1
CombatStyles.LoganSoldierGrenadierTurret.Limits[CombatZones.Rear] = 1
CombatStyles.LoganSoldierGrenadierTurret.Sequences = {}
CombatStyles.LoganSoldierGrenadierTurret.Sequences[CombatSituations.Melee] = {
	{"LoganSoldierPistolGrenadeThrow", 5},
	"Advance",
	"GuardCloseAttack",
	"GuardAttack",
	"FastBackOff",
	"BanditOuterGoad",
	"Idle"
}
CombatStyles.LoganSoldierGrenadierTurret.Sequences[CombatSituations.Ranged] = {
	{"LoganSoldierPistolGrenadeThrow", 5},
	"NearRifleStrikeOne",
	"NearRifleStrikeTwo",
	"MidRifleStrikeOne",
	"MidRifleStrikeTwo",
	"Idle",
	"FarIdle"
}
CombatStyles.LoganSoldierGrenadierTurret.ValidStates = {}
CombatStyles.LoganSoldierGrenadierTurret.ValidStates[CombatSituations.Ranged] = {
	 "AntiSpamCheck",
	 "PlayBanterCombatComment",
	 "WaitForActionToFinish",
	 "TurretUpdateWeapon",
	 "TurretCheckTargetProximity",
	 "CheckForBetterTarget",
	 "MoveToFiringPosition",
	 "ThrowGrenadeAtDistantTarget",
	 "FireMultiShotRangedWeapon",
	 "FireRangedWeapon",
	 "PlayCombatSequence",
	 "FaceTarget",
	 "IdleWithRangedWeapon"
}
CombatStyles.LoganSoldierGrenadierTurret.ValidStates[CombatSituations.Melee] = {
	"AntiSpamCheck",
	"PlayBanterCombatComment",
	"WaitForActionToFinish",
	"TurretUpdateWeapon",
	"TurretCheckTargetProximity",
	"CheckForBetterTarget",
	"PlayCombatSequence",
	"FaceTarget"
}


-- LoganSoldier Turret NoWait --
CombatStyles.LoganSoldierTurretNoWait = DeepCopyTable(CombatStyles.LoganSoldierTurret)
CombatStyles.LoganSoldierTurretNoWait.MoveToFiringPosNoWait = true


-- LoganSoldier Turret Elite NoWait --
CombatStyles.LoganSoldierTurretEliteNoWait = DeepCopyTable(CombatStyles.LoganSoldierTurretElite)
CombatStyles.LoganSoldierTurretEliteNoWait.MoveToFiringPosNoWait = true


-- LoganSoldier Grenadier Turret NoWait --
CombatStyles.LoganSoldierGrenadierTurretNoWait = DeepCopyTable(CombatStyles.LoganSoldierGrenadierTurret)
CombatStyles.LoganSoldierGrenadierTurretNoWait.MoveToFiringPosNoWait = true



-- uncomment for debug
-- GUI.DisplayMessageBox("logansoldiercombatstyles.lua successfully loaded!")
-- while (GUI.IsDisplayBoxActive()) do
	-- coroutine.yield()
-- end