
-- DeadRising ShadowHobbe --
CombatStyles.DeadRisingShadowHobbe = DeepCopyTable(CombatStyles.ShadowHobbe)
CombatStyles.DeadRisingShadowHobbe.CanStrafe = false
CombatStyles.DeadRisingShadowHobbe.NonFormation = false
CombatStyles.DeadRisingShadowHobbe.CanSheatheWeapon = false
CombatStyles.DeadRisingShadowHobbe.DisableAimMode = true
CombatStyles.DeadRisingShadowHobbe.DoSpotTargetAnim = false
CombatStyles.DeadRisingShadowHobbe.MinSecondsBetweenMeleeAttacks = 0
CombatStyles.DeadRisingShadowHobbe.SecondsToWaitAfterTargetIsHit = 0


-- DeadRising ShadowBandit --
CombatStyles.DeadRisingShadowBandit = DeepCopyTable(CombatStyles.ShadowBandit)
CombatStyles.DeadRisingShadowBandit.NonFormation = true
CombatStyles.DeadRisingShadowBandit.CanSheatheWeapon = false
CombatStyles.DeadRisingShadowBandit.DisableAimMode = true
CombatStyles.DeadRisingShadowBandit.DoSpotTargetAnim = false
CombatStyles.DeadRisingShadowBandit.MinSecondsBetweenMeleeAttacks = 0
CombatStyles.DeadRisingShadowBandit.SecondsToWaitAfterTargetIsHit = 0


-- uncomment for debug
-- GUI.DisplayMessageBox("deadrisercombatstyles.lua successfully loaded!")
-- while (GUI.IsDisplayBoxActive()) do
	-- coroutine.yield()
-- end