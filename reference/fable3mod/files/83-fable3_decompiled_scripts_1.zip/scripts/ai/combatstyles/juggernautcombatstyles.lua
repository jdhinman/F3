-- this script is empty
-- so it can be used for hijack


-- uncomment for debug
-- GUI.DisplayMessageBox("juggernautcombatstyles.lua successfully loaded!")
-- while (GUI.IsDisplayBoxActive()) do
	-- coroutine.yield()
-- end