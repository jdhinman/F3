
-- Sentinel --
CombatStyles.Sentinel = {}
CombatStyles.Sentinel.NonFormation = true
CombatStyles.Sentinel.CanSheatheWeapon = false
CombatStyles.Sentinel.TargetFilter = CombatStates.SentinelTargetFilter
CombatStyles.Sentinel.ActionModifiers = {}
CombatStyles.Sentinel.ActionModifiers.MinDistToTarget = 1.2
CombatStyles.Sentinel.PreferredRange = 3
CombatStyles.Sentinel.TurnToFaceTolerance = 360
CombatStyles.Sentinel.MaxNavSpeed = ENavigationSpeed.NAV_SPEED_WALK
CombatStyles.Sentinel.UseExtendedZones = true
CombatStyles.Sentinel.Limits = {}
CombatStyles.Sentinel.Limits[CombatZones.Near] = 1.5
CombatStyles.Sentinel.Limits[CombatZones.Middle] = 3
CombatStyles.Sentinel.Limits[CombatZones.Far] = 12
CombatStyles.Sentinel.Limits[CombatZones.Left] = 3
CombatStyles.Sentinel.Limits[CombatZones.Right] = 3
CombatStyles.Sentinel.Limits[CombatZones.Rear] = 3
CombatStyles.Sentinel.Limits[CombatZones.LeftFar] = 12
CombatStyles.Sentinel.Limits[CombatZones.RightFar] = 12
CombatStyles.Sentinel.Limits[CombatZones.RearFar] = 12
CombatStyles.Sentinel.Angles = {}
CombatStyles.Sentinel.Angles[AngleToleranceZones.LeftFar_Min] = 45
CombatStyles.Sentinel.Angles[AngleToleranceZones.LeftFar_Max] = 145
CombatStyles.Sentinel.Angles[AngleToleranceZones.RightFar_Min] = 45
CombatStyles.Sentinel.Angles[AngleToleranceZones.RightFar_Max] = 145
CombatStyles.Sentinel.Angles[AngleToleranceZones.RearFar_Min] = 90
CombatStyles.Sentinel.Angles[AngleToleranceZones.RearFar_Max] = 180
CombatStyles.Sentinel.Sequences = {}
CombatStyles.Sentinel.Sequences[CombatSituations.Melee] = {
	{"SentinelAntiSpamGroundSlam", 2},
	"SentinelGroundSlam",
	"SentinelSpinStrike",
	"Idle"
}
CombatStyles.Sentinel.MinSecondsBetweenMeleeAttacks = 1.5
CombatStyles.Sentinel.MinSecondsBetweenRangedAttacks = 8
CombatStyles.Sentinel.SecondsToWaitAfterTargetIsHit = 4
CombatStyles.Sentinel.ValidStates = {}
CombatStyles.Sentinel.ValidStates[CombatSituations.Melee] = {
	"SentinelDataSetup",
	"WaitForActionToFinish",
	"CheckForBetterTarget",
	"SentinelSummon",
	"PlayCombatSequence",
	"SentinelAOERangedCounterattack",
	"SentinelLinearRangedAttack",
	"SentinelAOERangedAttack",
	"MoveToFormationPos",
	"FaceTarget",
	"SentinelWaitMenacingly"
}
CombatStyles.Sentinel.SentinelBalanceData = {}
CombatStyles.Sentinel.SentinelBalanceData.NumberOfHitsToTriggerMagicRetribution = 4
CombatStyles.Sentinel.SentinelBalanceData.SecondsNotHitToReduceRetributionCountByOne = 10
CombatStyles.Sentinel.SentinelBalanceData.NumberOfHitsToShowWarningLight = 2
CombatStyles.Sentinel.SentinelBalanceData.PowerLevelOfRetaliation = 1
CombatStyles.Sentinel.SentinelBalanceData.StartSummonWhenHealthPercentageBelow = 80
CombatStyles.Sentinel.SentinelBalanceData.MaxToSpawn = 6
CombatStyles.Sentinel.SentinelBalanceData.MinSecondsBetweenSpawns = 3
CombatStyles.Sentinel.SentinelBalanceData.MaxSummonsPerSpawn = 2
CombatStyles.Sentinel.SentinelBalanceData.EntityToSummon = "CreatureShadowDervish"
CombatStyles.Sentinel.SentinelBalanceData.AOERangedAttackEntity = "SentinelRangedAttackExplosion"
CombatStyles.Sentinel.SentinelBalanceData.SecondsBetweenAOEAttacks = 9
CombatStyles.Sentinel.SentinelBalanceData.LinearRangedAttackEntity = "SentinelLinearAttackLarge"
CombatStyles.Sentinel.SentinelBalanceData.SecondsBetweenLinearAttacks = 6


-- Sentinel Easy --
CombatStyles.SentinelEasy = {}
CombatStyles.SentinelEasy.NonFormation = true
CombatStyles.SentinelEasy.CanSheatheWeapon = false
CombatStyles.SentinelEasy.TargetFilter = CombatStates.SentinelTargetFilter
CombatStyles.SentinelEasy.ActionModifiers = {}
CombatStyles.SentinelEasy.ActionModifiers.MinDistToTarget = 1.2
CombatStyles.SentinelEasy.PreferredRange = 3
CombatStyles.SentinelEasy.TurnToFaceTolerance = 360
CombatStyles.SentinelEasy.MaxNavSpeed = ENavigationSpeed.NAV_SPEED_WALK
CombatStyles.SentinelEasy.UseExtendedZones = true
CombatStyles.SentinelEasy.Limits = {}
CombatStyles.SentinelEasy.Limits[CombatZones.Near] = 1.5
CombatStyles.SentinelEasy.Limits[CombatZones.Middle] = 3
CombatStyles.SentinelEasy.Limits[CombatZones.Far] = 12
CombatStyles.SentinelEasy.Limits[CombatZones.Left] = 3
CombatStyles.SentinelEasy.Limits[CombatZones.Right] = 3
CombatStyles.SentinelEasy.Limits[CombatZones.Rear] = 3
CombatStyles.SentinelEasy.Limits[CombatZones.LeftFar] = 12
CombatStyles.SentinelEasy.Limits[CombatZones.RightFar] = 12
CombatStyles.SentinelEasy.Limits[CombatZones.RearFar] = 12
CombatStyles.SentinelEasy.Angles = {}
CombatStyles.SentinelEasy.Angles[AngleToleranceZones.LeftFar_Min] = 45
CombatStyles.SentinelEasy.Angles[AngleToleranceZones.LeftFar_Max] = 145
CombatStyles.SentinelEasy.Angles[AngleToleranceZones.RightFar_Min] = 45
CombatStyles.SentinelEasy.Angles[AngleToleranceZones.RightFar_Max] = 145
CombatStyles.SentinelEasy.Angles[AngleToleranceZones.RearFar_Min] = 90
CombatStyles.SentinelEasy.Angles[AngleToleranceZones.RearFar_Max] = 180
CombatStyles.SentinelEasy.Sequences = {}
CombatStyles.SentinelEasy.Sequences[CombatSituations.Melee] = {
	{"SentinelAntiSpamGroundSlam", 5},
	"SentinelGroundSlam",
	"SentinelSpinStrike",
	"Idle"
}
CombatStyles.SentinelEasy.MinSecondsBetweenMeleeAttacks = 1.5
CombatStyles.SentinelEasy.MinSecondsBetweenRangedAttacks = 9
CombatStyles.SentinelEasy.SecondsToWaitAfterTargetIsHit = 4
CombatStyles.SentinelEasy.ValidStates = {}
CombatStyles.SentinelEasy.ValidStates[CombatSituations.Melee] = {
	"SentinelDataSetup",
	"WaitForActionToFinish",
	"CheckForBetterTarget",
	"SentinelSummon",
	"PlayCombatSequence",
	"SentinelAOERangedCounterattack",
	"SentinelLinearRangedAttack",
	"SentinelAOERangedAttack",
	"MoveToFormationPos",
	"FaceTarget",
	"SentinelWaitMenacingly"
}
CombatStyles.SentinelEasy.SentinelBalanceData = {}
CombatStyles.SentinelEasy.SentinelBalanceData.NumberOfHitsToTriggerMagicRetribution = 7
CombatStyles.SentinelEasy.SentinelBalanceData.SecondsNotHitToReduceRetributionCountByOne = 10
CombatStyles.SentinelEasy.SentinelBalanceData.NumberOfHitsToShowWarningLight = 5
CombatStyles.SentinelEasy.SentinelBalanceData.PowerLevelOfRetaliation = 0
CombatStyles.SentinelEasy.SentinelBalanceData.StartSummonWhenHealthPercentageBelow = 50
CombatStyles.SentinelEasy.SentinelBalanceData.MaxToSpawn = 4
CombatStyles.SentinelEasy.SentinelBalanceData.MinSecondsBetweenSpawns = 3
CombatStyles.SentinelEasy.SentinelBalanceData.MaxSummonsPerSpawn = 2
CombatStyles.SentinelEasy.SentinelBalanceData.EntityToSummon = "CreatureShadowRenegade"
CombatStyles.SentinelEasy.SentinelBalanceData.AOERangedAttackEntity = "SentinelRangedAttackExplosionWeak"
CombatStyles.SentinelEasy.SentinelBalanceData.SecondsBetweenAOEAttacks = 12
CombatStyles.SentinelEasy.SentinelBalanceData.LinearRangedAttackEntity = "SentinelLinearAttackSmall"
CombatStyles.SentinelEasy.SentinelBalanceData.SecondsBetweenLinearAttacks = 8


-- Sentinel Turret --
CombatStyles.SentinelTurret = DeepCopyTable(CombatStyles.Sentinel)
CombatStyles.SentinelTurret.ValidStates = {}
CombatStyles.SentinelTurret.ValidStates[CombatSituations.Melee] = {
	"SentinelDataSetup",
	"MagicStanceRetribution",
	"WaitForActionToFinish",
	"CheckForBetterTarget",
	"SentinelSummon",
	"PlayCombatSequence",
	"SentinelLinearRangedAttack",
	"SentinelAOERangedAttack",
	"FaceTarget",
	"SentinelWaitMenacingly"
}


-- Sentinel Easy Turret --
CombatStyles.SentinelEasyTurret = DeepCopyTable(CombatStyles.SentinelEasy)
CombatStyles.SentinelEasyTurret.ValidStates = {}
CombatStyles.SentinelEasyTurret.ValidStates[CombatSituations.Melee] = {
	"SentinelDataSetup",
	"MagicStanceRetribution",
	"WaitForActionToFinish",
	"CheckForBetterTarget",
	"SentinelSummon",
	"PlayCombatSequence",
	"SentinelLinearRangedAttack",
	"SentinelAOERangedAttack",
	"FaceTarget",
	"SentinelWaitMenacingly"
}


-- uncomment for debug
-- GUI.DisplayMessageBox("sentinelcombatstyles.lua successfully loaded!")
-- while (GUI.IsDisplayBoxActive()) do
	-- coroutine.yield()
-- end