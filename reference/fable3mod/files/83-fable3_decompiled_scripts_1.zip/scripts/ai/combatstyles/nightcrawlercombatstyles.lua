
-- Night Crawler --
CombatStyles.NightCrawler = {}
CombatStyles.NightCrawler.CanSheatheWeapon = false
CombatStyles.NightCrawler.PreferredRange = 1.5
CombatStyles.NightCrawler.NonFormation = true
CombatStyles.NightCrawler.MaxNavSpeed = ENavigationSpeed.NAV_SPEED_WALK
CombatStyles.NightCrawler.Limits = {}
CombatStyles.NightCrawler.Limits[CombatZones.Near] = 1.5
CombatStyles.NightCrawler.Limits[CombatZones.Middle] = 3.5
CombatStyles.NightCrawler.Limits[CombatZones.Far] = 8
CombatStyles.NightCrawler.Limits[CombatZones.Left] = 1.5
CombatStyles.NightCrawler.Limits[CombatZones.Right] = 1.5
CombatStyles.NightCrawler.Limits[CombatZones.Rear] = 1.5
CombatStyles.NightCrawler.Sequences = {}
CombatStyles.NightCrawler.Sequences[CombatSituations.Melee] = {
	"NightCrawlerSpamResponse",
	"NightCrawlerClawAttack",
	"NightCrawlerClawAttackLeft",
	"NightCrawlerClawAttackRight",
	"Idle"
}
CombatStyles.NightCrawler.MinSecondsBetweenMeleeAttacks = 5
CombatStyles.NightCrawler.MinSecondsBetweenRangedAttacks = 6
CombatStyles.NightCrawler.NightCrawlerData = {}
CombatStyles.NightCrawler.NightCrawlerData.MaxToSpawn = 9
CombatStyles.NightCrawler.NightCrawlerData.MinSecondsBetweenSpawns = 1
CombatStyles.NightCrawler.NightCrawlerData.MaxSummonsPerSpawn = 3
CombatStyles.NightCrawler.NightCrawlerData.EntityToSummon = "CreatureShadowRenegade"
CombatStyles.NightCrawler.ValidStates = {}
CombatStyles.NightCrawler.ValidStates[CombatSituations.Melee] = {
	"WaitForActionToFinish",
	"UpdateWeapon",
	"CheckForBetterTarget",
	"NightCrawlerSummon",
	"NightCrawlerSpewAttack",
	"NightCrawlerRangedAttack",
	"PlayCombatSequence",
	"MoveToFormationPos",
	"FaceTarget"
}


-- Night Crawler Elite --
CombatStyles.NightCrawlerElite = {}
CombatStyles.NightCrawlerElite.CanSheatheWeapon = false
CombatStyles.NightCrawlerElite.PreferredRange = 1.5
CombatStyles.NightCrawlerElite.NonFormation = true
CombatStyles.NightCrawlerElite.MaxNavSpeed = ENavigationSpeed.NAV_SPEED_WALK
CombatStyles.NightCrawlerElite.Limits = {}
CombatStyles.NightCrawlerElite.Limits[CombatZones.Near] = 1.5
CombatStyles.NightCrawlerElite.Limits[CombatZones.Middle] = 3.5
CombatStyles.NightCrawlerElite.Limits[CombatZones.Far] = 8
CombatStyles.NightCrawlerElite.Limits[CombatZones.Left] = 1.5
CombatStyles.NightCrawlerElite.Limits[CombatZones.Right] = 1.5
CombatStyles.NightCrawlerElite.Limits[CombatZones.Rear] = 1.5
CombatStyles.NightCrawlerElite.Sequences = {}
CombatStyles.NightCrawlerElite.Sequences[CombatSituations.Melee] = {
	"NightCrawlerSpamResponse",
	"NightCrawlerClawAttack",
	"NightCrawlerClawAttackLeft",
	"NightCrawlerClawAttackRight",
	"Idle"
}
CombatStyles.NightCrawlerElite.MinSecondsBetweenMeleeAttacks = 5
CombatStyles.NightCrawlerElite.MinSecondsBetweenRangedAttacks = 6
CombatStyles.NightCrawlerElite.NightCrawlerData = {}
CombatStyles.NightCrawlerElite.NightCrawlerData.RangedHitsToTriggerTeleport = 3
CombatStyles.NightCrawlerElite.NightCrawlerData.SecondsToCheckForHitsForTeleport = 6
CombatStyles.NightCrawlerElite.NightCrawlerData.MaxToSpawn = 12
CombatStyles.NightCrawlerElite.NightCrawlerData.MinSecondsBetweenSpawns = 2
CombatStyles.NightCrawlerElite.NightCrawlerData.MaxSummonsPerSpawn = 4
CombatStyles.NightCrawlerElite.NightCrawlerData.EntityToSummon = "CreatureShadowDervish"
CombatStyles.NightCrawlerElite.ValidStates = {}
CombatStyles.NightCrawlerElite.ValidStates[CombatSituations.Melee] = {
	"NightCrawlerJump",
	"WaitForActionToFinish",
	"UpdateWeapon",
	"CheckForBetterTarget",
	"NightCrawlerSummon",
	"NightCrawlerSpewAttack",
	"NightCrawlerRangedAttack",
	"PlayCombatSequence",
	"MoveToFormationPos",
	"FaceTarget"
}


-- uncomment for debug
-- GUI.DisplayMessageBox("nightcrawlercombatstyles.lua successfully loaded!")
-- while (GUI.IsDisplayBoxActive()) do
	-- coroutine.yield()
-- end