
-- Highwayman Easy --
CombatStyles.HighwaymanEasy = {}
CombatStyles.HighwaymanEasy.CombatGroupType = CombatGroupTypes.HighwaymanLike
CombatStyles.HighwaymanEasy.CanStrafe = true
CombatStyles.HighwaymanEasy.CanSheatheWeapon = false
CombatStyles.HighwaymanEasy.MovementTolerance = 0.45
CombatStyles.HighwaymanEasy.PreferredRange = 3.4
CombatStyles.HighwaymanEasy.ActionModifiers = {}
CombatStyles.HighwaymanEasy.ActionModifiers.MinDistToTarget = 0.75
CombatStyles.HighwaymanEasy.Limits = {}
CombatStyles.HighwaymanEasy.Limits[CombatZones.Near] = 1.5
CombatStyles.HighwaymanEasy.Limits[CombatZones.Middle] = 3.5
CombatStyles.HighwaymanEasy.Limits[CombatZones.Far] = 5
CombatStyles.HighwaymanEasy.Limits[CombatZones.Left] = 2
CombatStyles.HighwaymanEasy.Limits[CombatZones.Right] = 2
CombatStyles.HighwaymanEasy.Limits[CombatZones.Rear] = 2.5
CombatStyles.HighwaymanEasy.StrafeActionSpeed = 1
CombatStyles.HighwaymanEasy.EnterStrafeDist = 5
CombatStyles.HighwaymanEasy.LeaveStrafeDelta = 2
CombatStyles.HighwaymanEasy.FleeAnim = "Flee"
CombatStyles.HighwaymanEasy.FleeIntoAnim = "FleeInto"
CombatStyles.HighwaymanEasy.FleeOutOfAnim = "FleeOutOf"
CombatStyles.HighwaymanEasy.Sequences = {}
CombatStyles.HighwaymanEasy.Sequences[CombatSituations.Melee] = {
	"HighwaymanGetRidOfPistol",
	"HighwaymanShotTooMuch",
	"HighwaymanFarAttackCombo",
	"HighwaymanAttackCombo",
	"HighwaymanCloseAttackCombo",
	"HighwaymanRollBack",
	"HighwaymanGoad",
	"HighwaymanIdleStrafeLeft",
	"HighwaymanIdleStrafeRight",
	"HighwaymanLeftAttack",
	"HighwaymanRightAttack",
	"HighwaymanRearAttack",
	"Idle"
}
CombatStyles.HighwaymanEasy.Sequences[CombatSituations.Dodging] = {
	"HighwaymanRollBackShooting"
}
CombatStyles.HighwaymanEasy.Sequences[CombatSituations.GroupOrders] = {
	"HighwaymanGroupShooting",
	"HighwaymanAttackCombo",
	"HighwaymanStrikeThenRoll"
}
CombatStyles.HighwaymanEasy.RunIntoAttack = "RunIntoAttack"
CombatStyles.HighwaymanEasy.MinSecondsBetweenMeleeAttacks = 4.5
CombatStyles.HighwaymanEasy.SecondsToWaitAfterTargetIsHit = 5
CombatStyles.HighwaymanEasy.MinSecondsBetweenRangedAttacks = 4
CombatStyles.HighwaymanEasy.TimeAfterBeingStruckWithinWhichWeCanShoot = 6
CombatStyles.HighwaymanEasy.CanBlock = true
CombatStyles.HighwaymanEasy.BlockData = {}
CombatStyles.HighwaymanEasy.BlockData.PrimaryBlockType = EBlockType.BLOCK_TYPE_PUSHED_BACK
CombatStyles.HighwaymanEasy.BlockData.SecondsForSuccessiveHitsToPrimaryBlock = 6
CombatStyles.HighwaymanEasy.BlockData.NumberOfHitsToForcePrimaryBlock = 2
CombatStyles.HighwaymanEasy.BlockData.SecondaryBlockType = EBlockType.BLOCK_TYPE_DODGE_MELEE
CombatStyles.HighwaymanEasy.BlockData.SecondsForSuccessiveHitsToSecondaryBlock = 8
CombatStyles.HighwaymanEasy.BlockData.NumberOfHitsToForceSecondaryBlock = 2
CombatStyles.HighwaymanEasy.BlockData.SecondsToBlockFor = 2
CombatStyles.HighwaymanEasy.DodgeAnimations = {
	"RollLeft",
    "RollRight"
}
CombatStyles.HighwaymanEasy.CanEvadeShots = false
CombatStyles.HighwaymanEasy.EvadeShotsData = {}
CombatStyles.HighwaymanEasy.EvadeShotsData.TimeToCheckFor = 6
CombatStyles.HighwaymanEasy.EvadeShotsData.TimeToEvadeFor = 5
CombatStyles.HighwaymanEasy.EvadeShotsData.HitsToStartEvading = 3
CombatStyles.HighwaymanEasy.EvadeAnimations = {
	"DodgeBackLeft",
    "DodgeBackRight"
}
CombatStyles.HighwaymanEasy.ValidStates = {}
CombatStyles.HighwaymanEasy.ValidStates[CombatSituations.Melee] = {
	"PlayBanterCombatComment",
	"WaitForActionToFinish",
	"HighwaymanFireRangedWeapon",
	"UpdateWeapon",
	"CheckForBetterTarget",
	"RetreatFromFlourish",
	"OuterRingKeepDistance",
	"OuterRingSpreadOut",
	"PlayCombatSequence",
	"MoveToFormationPos",
	"FaceTarget"
}
CombatStyles.HighwaymanEasy.ValidStates[CombatSituations.SoftBlocking] = CombatStyles.StandardBlockingCombatStates
CombatStyles.HighwaymanEasy.ValidStates[CombatSituations.HardBlocking] = CombatStyles.StandardBlockingCombatStates
CombatStyles.HighwaymanEasy.ValidStates[CombatSituations.Dodging] = CombatStyles.StandardBlockingCombatStates
CombatStyles.HighwaymanEasy.ValidStates[CombatSituations.GroupOrders] = CombatStyles.StandardGroupOrderStates
CombatStyles.HighwaymanEasy.ShootingBalanceData = {}
CombatStyles.HighwaymanEasy.ShootingBalanceData.StartingChanceToHitWithFirearm = 0.5
CombatStyles.HighwaymanEasy.ShootingBalanceData.MaxChanceToHitWithFirearmCap = 0.5
CombatStyles.HighwaymanEasy.ShootingBalanceData.ChanceToHitModBonusRangeDistance = 9
CombatStyles.HighwaymanEasy.ShootingBalanceData.ChanceToHitModSegmentLength = 3
CombatStyles.HighwaymanEasy.ShootingBalanceData.ChanceToHitModPercentageIncrease = 0.05
CombatStyles.HighwaymanEasy.ShootingBalanceData.ChanceToHitModConsecutiveShotPercentageIncrease = 0.08
CombatStyles.HighwaymanEasy.ShootingBalanceData.ChanceToHitModConsecutiveShotsTimeFrame = 25
CombatStyles.HighwaymanEasy.ShootingBalanceData.ChanceToHitModPercentageDecreasePerOneSpeed = 0.9
CombatStyles.HighwaymanEasy.ShootingBalanceData.ChanceToHitModTargetInCoverPercentageMultiplier = 0.9
CombatStyles.HighwaymanEasy.ShootingBalanceData.ChanceToHitModOffScreenPercentageMultiplier = 0.05


-- Highwayman --
CombatStyles.Highwayman = {}
CombatStyles.Highwayman.CombatGroupType = CombatGroupTypes.HighwaymanLike
CombatStyles.Highwayman.CanStrafe = true
CombatStyles.Highwayman.CanSheatheWeapon = false
CombatStyles.Highwayman.MovementTolerance = 0.45
CombatStyles.Highwayman.PreferredRange = 3.4
CombatStyles.Highwayman.ActionModifiers = {}
CombatStyles.Highwayman.ActionModifiers.MinDistToTarget = 0.75
CombatStyles.Highwayman.Limits = {}
CombatStyles.Highwayman.Limits[CombatZones.Near] = 1.5
CombatStyles.Highwayman.Limits[CombatZones.Middle] = 3.5
CombatStyles.Highwayman.Limits[CombatZones.Far] = 5
CombatStyles.Highwayman.Limits[CombatZones.Left] = 2
CombatStyles.Highwayman.Limits[CombatZones.Right] = 2
CombatStyles.Highwayman.Limits[CombatZones.Rear] = 2.5
CombatStyles.Highwayman.StrafeActionSpeed = 1
CombatStyles.Highwayman.EnterStrafeDist = 5
CombatStyles.Highwayman.LeaveStrafeDelta = 2
CombatStyles.Highwayman.FleeAnim = "Flee"
CombatStyles.Highwayman.FleeIntoAnim = "FleeInto"
CombatStyles.Highwayman.FleeOutOfAnim = "FleeOutOf"
CombatStyles.Highwayman.Sequences = {}
CombatStyles.Highwayman.Sequences[CombatSituations.Melee] = {
	"HighwaymanGetRidOfPistol",
	"HighwaymanShotTooMuch",
	"HighwaymanFarAttackCombo",
	"HighwaymanAttackCombo",
	"HighwaymanCloseAttackCombo",
	"HighwaymanRollBack",
	"HighwaymanGoad",
	"HighwaymanIdleStrafeLeft",
	"HighwaymanIdleStrafeRight",
	"HighwaymanLeftAttack",
	"HighwaymanRightAttack",
	"HighwaymanRearAttack",
	"Idle"
}
CombatStyles.Highwayman.Sequences[CombatSituations.Dodging] = {
	"HighwaymanRollBackShooting"
}
CombatStyles.Highwayman.Sequences[CombatSituations.GroupOrders] = {
	"HighwaymanGroupShooting",
	"HighwaymanAttackCombo",
	"HighwaymanStrikeThenRoll"
}
CombatStyles.Highwayman.RunIntoAttack = "RunIntoAttack"
CombatStyles.Highwayman.MinSecondsBetweenMeleeAttacks = 3.5
CombatStyles.Highwayman.SecondsToWaitAfterTargetIsHit = 4
CombatStyles.Highwayman.MinSecondsBetweenRangedAttacks = 4
CombatStyles.Highwayman.TimeAfterBeingStruckWithinWhichWeCanShoot = 6
CombatStyles.Highwayman.CanBlock = true
CombatStyles.Highwayman.BlockData = {}
CombatStyles.Highwayman.BlockData.PrimaryBlockType = EBlockType.BLOCK_TYPE_PUSHED_BACK
CombatStyles.Highwayman.BlockData.SecondsForSuccessiveHitsToPrimaryBlock = 6
CombatStyles.Highwayman.BlockData.NumberOfHitsToForcePrimaryBlock = 2
CombatStyles.Highwayman.BlockData.SecondaryBlockType = EBlockType.BLOCK_TYPE_DODGE_MELEE
CombatStyles.Highwayman.BlockData.SecondsForSuccessiveHitsToSecondaryBlock = 8
CombatStyles.Highwayman.BlockData.NumberOfHitsToForceSecondaryBlock = 1
CombatStyles.Highwayman.BlockData.SecondsToBlockFor = 2
CombatStyles.Highwayman.DodgeAnimations = {
	"RollLeft",
    "RollRight"
}
CombatStyles.Highwayman.CanEvadeShots = false
CombatStyles.Highwayman.EvadeShotsData = {}
CombatStyles.Highwayman.EvadeShotsData.TimeToCheckFor = 6
CombatStyles.Highwayman.EvadeShotsData.TimeToEvadeFor = 5
CombatStyles.Highwayman.EvadeShotsData.HitsToStartEvading = 3
CombatStyles.Highwayman.EvadeAnimations = {
	"DodgeBackLeft",
    "DodgeBackRight"
}
CombatStyles.Highwayman.ValidStates = {}
CombatStyles.Highwayman.ValidStates[CombatSituations.Melee] = {
	"PlayBanterCombatComment",
	"WaitForActionToFinish",
	"HighwaymanFireRangedWeapon",
	"UpdateWeapon",
	"CheckForBetterTarget",
	"RetreatFromFlourish",
	"OuterRingKeepDistance",
	"OuterRingSpreadOut",
	"PlayCombatSequence",
	"MoveToFormationPos",
	"FaceTarget"
}
CombatStyles.Highwayman.ValidStates[CombatSituations.SoftBlocking] = CombatStyles.StandardBlockingCombatStates
CombatStyles.Highwayman.ValidStates[CombatSituations.HardBlocking] = CombatStyles.StandardBlockingCombatStates
CombatStyles.Highwayman.ValidStates[CombatSituations.Dodging] = CombatStyles.StandardBlockingCombatStates
CombatStyles.Highwayman.ValidStates[CombatSituations.GroupOrders] = CombatStyles.StandardGroupOrderStates
CombatStyles.Highwayman.ShootingBalanceData = {}
CombatStyles.Highwayman.ShootingBalanceData.StartingChanceToHitWithFirearm = 0.5
CombatStyles.Highwayman.ShootingBalanceData.MaxChanceToHitWithFirearmCap = 0.5
CombatStyles.Highwayman.ShootingBalanceData.ChanceToHitModBonusRangeDistance = 9
CombatStyles.Highwayman.ShootingBalanceData.ChanceToHitModSegmentLength = 3
CombatStyles.Highwayman.ShootingBalanceData.ChanceToHitModPercentageIncrease = 0.05
CombatStyles.Highwayman.ShootingBalanceData.ChanceToHitModConsecutiveShotPercentageIncrease = 0.08
CombatStyles.Highwayman.ShootingBalanceData.ChanceToHitModConsecutiveShotsTimeFrame = 25
CombatStyles.Highwayman.ShootingBalanceData.ChanceToHitModPercentageDecreasePerOneSpeed = 0.9
CombatStyles.Highwayman.ShootingBalanceData.ChanceToHitModTargetInCoverPercentageMultiplier = 0.9
CombatStyles.Highwayman.ShootingBalanceData.ChanceToHitModOffScreenPercentageMultiplier = 0.05


-- Highwayman Elite --
CombatStyles.HighwaymanElite = {}
CombatStyles.HighwaymanElite.CombatGroupType = CombatGroupTypes.HighwaymanLike
CombatStyles.HighwaymanElite.CanStrafe = true
CombatStyles.HighwaymanElite.CanSheatheWeapon = false
CombatStyles.HighwaymanElite.MovementTolerance = 0.45
CombatStyles.HighwaymanElite.PreferredRange = 3.4
CombatStyles.HighwaymanElite.ActionModifiers = {}
CombatStyles.HighwaymanElite.ActionModifiers.MinDistToTarget = 0.75
CombatStyles.HighwaymanElite.Limits = {}
CombatStyles.HighwaymanElite.Limits[CombatZones.Near] = 1.5
CombatStyles.HighwaymanElite.Limits[CombatZones.Middle] = 3.5
CombatStyles.HighwaymanElite.Limits[CombatZones.Far] = 5
CombatStyles.HighwaymanElite.Limits[CombatZones.Left] = 2
CombatStyles.HighwaymanElite.Limits[CombatZones.Right] = 2
CombatStyles.HighwaymanElite.Limits[CombatZones.Rear] = 2.5
CombatStyles.HighwaymanElite.StrafeActionSpeed = 1
CombatStyles.HighwaymanElite.EnterStrafeDist = 5
CombatStyles.HighwaymanElite.LeaveStrafeDelta = 2
CombatStyles.HighwaymanElite.FleeAnim = "Flee"
CombatStyles.HighwaymanElite.FleeIntoAnim = "FleeInto"
CombatStyles.HighwaymanElite.FleeOutOfAnim = "FleeOutOf"
CombatStyles.HighwaymanElite.Sequences = {}
CombatStyles.HighwaymanElite.Sequences[CombatSituations.Melee] = {
	"HighwaymanGetRidOfPistol",
	"HighwaymanShotTooMuch",
	"HighwaymanEliteOrbSuckingResponse",
	"HighwaymanEliteFarAttackCombo",
	"HighwaymanEliteAttackCombo",
	"HighwaymanEliteCloseAttackCombo",
	"HighwaymanStrikeThenRoll",
	"HighwaymanGoad",
	"HighwaymanIdleStrafeLeft",
	"HighwaymanIdleStrafeRight",
	"HighwaymanLeftAttack",
	"HighwaymanRightAttack",
	"HighwaymanRearAttack",
	"Idle"
}
CombatStyles.HighwaymanElite.Sequences[CombatSituations.Dodging] = {
	"HighwaymanRollBackShooting"
}
CombatStyles.HighwaymanElite.RunIntoAttack = "RunIntoAttack"
CombatStyles.HighwaymanElite.MinSecondsBetweenMeleeAttacks = 2.5
CombatStyles.HighwaymanElite.SecondsToWaitAfterTargetIsHit = 3
CombatStyles.HighwaymanElite.MinSecondsBetweenRangedAttacks = 3
CombatStyles.HighwaymanElite.TimeAfterBeingStruckWithinWhichWeCanShoot = 6
CombatStyles.HighwaymanElite.CanBlock = true
CombatStyles.HighwaymanElite.BlockData = {}
CombatStyles.HighwaymanElite.BlockData.PrimaryBlockType = EBlockType.BLOCK_TYPE_PUSHED_BACK
CombatStyles.HighwaymanElite.BlockData.SecondsForSuccessiveHitsToPrimaryBlock = 6
CombatStyles.HighwaymanElite.BlockData.NumberOfHitsToForcePrimaryBlock = 2
CombatStyles.HighwaymanElite.BlockData.SecondaryBlockType = EBlockType.BLOCK_TYPE_DODGE_MELEE
CombatStyles.HighwaymanElite.BlockData.SecondsForSuccessiveHitsToSecondaryBlock = 8
CombatStyles.HighwaymanElite.BlockData.NumberOfHitsToForceSecondaryBlock = 2
CombatStyles.HighwaymanElite.BlockData.SecondsToBlockFor = 1
CombatStyles.HighwaymanElite.DodgeAnimations = {
	"RollLeft",
    "RollRight"
}
CombatStyles.HighwaymanElite.CanEvadeShots = false
CombatStyles.HighwaymanElite.EvadeShotsData = {}
CombatStyles.HighwaymanElite.EvadeShotsData.TimeToCheckFor = 6
CombatStyles.HighwaymanElite.EvadeShotsData.TimeToEvadeFor = 5
CombatStyles.HighwaymanElite.EvadeShotsData.HitsToStartEvading = 3
CombatStyles.HighwaymanElite.EvadeAnimations = {
	"DodgeBackLeft",
    "DodgeBackRight"
}
CombatStyles.HighwaymanElite.AntiSpamData = {}
CombatStyles.HighwaymanElite.AntiSpamData.TimeToCheckFor = 5
CombatStyles.HighwaymanElite.AntiSpamData.ShotsToTrigger = 3
CombatStyles.HighwaymanElite.AntiSpamData.SpellsToTrigger = 3
CombatStyles.HighwaymanElite.AntiSpamData.TimeToAggroFor = 15
CombatStyles.HighwaymanElite.ValidStates = {}
CombatStyles.HighwaymanElite.ValidStates[CombatSituations.Melee] = {
	"AntiSpamCheck",
	"PlayBanterCombatComment",
	"WaitForActionToFinish",
	"HighwaymanFireRangedWeapon",
	"UpdateWeapon",
	"CheckForBetterTarget",
	"RetreatFromFlourish",
	"RetreatFromSpellCharging",
	"OuterRingKeepDistance",
	"OuterRingSpreadOut",
	"PlayCombatSequence",
	"MoveToFormationPos",
	"FaceTarget"
}
CombatStyles.HighwaymanElite.ValidStates[CombatSituations.SoftBlocking] = CombatStyles.StandardBlockingCombatStates
CombatStyles.HighwaymanElite.ValidStates[CombatSituations.HardBlocking] = CombatStyles.StandardBlockingCombatStates
CombatStyles.HighwaymanElite.ValidStates[CombatSituations.Dodging] = CombatStyles.StandardBlockingCombatStates
CombatStyles.HighwaymanElite.ValidStates[CombatSituations.GroupOrders] = CombatStyles.StandardGroupOrderStates
CombatStyles.HighwaymanElite.ShootingBalanceData = {}
CombatStyles.HighwaymanElite.ShootingBalanceData.StartingChanceToHitWithFirearm = 0.5
CombatStyles.HighwaymanElite.ShootingBalanceData.MaxChanceToHitWithFirearmCap = 0.5
CombatStyles.HighwaymanElite.ShootingBalanceData.ChanceToHitModBonusRangeDistance = 9
CombatStyles.HighwaymanElite.ShootingBalanceData.ChanceToHitModSegmentLength = 3
CombatStyles.HighwaymanElite.ShootingBalanceData.ChanceToHitModPercentageIncrease = 0.05
CombatStyles.HighwaymanElite.ShootingBalanceData.ChanceToHitModConsecutiveShotPercentageIncrease = 0.08
CombatStyles.HighwaymanElite.ShootingBalanceData.ChanceToHitModConsecutiveShotsTimeFrame = 25
CombatStyles.HighwaymanElite.ShootingBalanceData.ChanceToHitModPercentageDecreasePerOneSpeed = 0.9
CombatStyles.HighwaymanElite.ShootingBalanceData.ChanceToHitModTargetInCoverPercentageMultiplier = 0.9
CombatStyles.HighwaymanElite.ShootingBalanceData.ChanceToHitModOffScreenPercentageMultiplier = 0.05
CombatStyles.HighwaymanElite.SecondsBetweenGroupActions = 30
CombatStyles.HighwaymanElite.PercentChanceThatGroupActionIsShoot = 25


-- Dervish Queen --
CombatStyles.DervishQueen = {}
CombatStyles.DervishQueen.CombatGroupType = CombatGroupTypes.HighwaymanLike
CombatStyles.DervishQueen.CanStrafe = true
CombatStyles.DervishQueen.CanSheatheWeapon = false
CombatStyles.DervishQueen.MovementTolerance = 0.45
CombatStyles.DervishQueen.PreferredRange = 3.4
CombatStyles.DervishQueen.ActionModifiers = {}
CombatStyles.DervishQueen.ActionModifiers.MinDistToTarget = 0.75
CombatStyles.DervishQueen.Limits = {}
CombatStyles.DervishQueen.Limits[CombatZones.Near] = 1
CombatStyles.DervishQueen.Limits[CombatZones.Middle] = 2
CombatStyles.DervishQueen.Limits[CombatZones.Far] = 3.9
CombatStyles.DervishQueen.Limits[CombatZones.Left] = 2
CombatStyles.DervishQueen.Limits[CombatZones.Right] = 2
CombatStyles.DervishQueen.Limits[CombatZones.Rear] = 2.5
CombatStyles.DervishQueen.StrafeActionSpeed = 1
CombatStyles.DervishQueen.EnterStrafeDist = 5
CombatStyles.DervishQueen.LeaveStrafeDelta = 2
CombatStyles.DervishQueen.CanFlee = false
CombatStyles.DervishQueen.CombatStyleWhenDisarmed = "BasicUnarmed"
CombatStyles.DervishQueen.Sequences = {}
CombatStyles.DervishQueen.Sequences[CombatSituations.Melee] = {
	{"DervishQueenVortex", 10},
	"HighwaymanGetRidOfPistol",
	"HighwaymanShotTooMuch",
	"HighwaymanEliteOrbSuckingResponse",
	"HighwaymanEliteFarAttackCombo",
	"HighwaymanEliteAttackCombo",
	"HighwaymanEliteCloseAttackCombo",
	"HighwaymanStrikeThenRoll",
	"HighwaymanGoad",
	"HighwaymanIdleStrafeLeft",
	"HighwaymanIdleStrafeRight",
	"HighwaymanLeftAttack",
	"HighwaymanRightAttack",
	"HighwaymanRearAttack",
	"Idle"
}
CombatStyles.DervishQueen.RunIntoAttack = "RunIntoAttack"
CombatStyles.DervishQueen.MinSecondsBetweenMeleeAttacks = 1
CombatStyles.DervishQueen.SecondsToWaitAfterTargetIsHit = 1.5
CombatStyles.DervishQueen.MinSecondsBetweenRangedAttacks = 2.5
CombatStyles.DervishQueen.TimeAfterBeingStruckWithinWhichWeCanShoot = 5
CombatStyles.DervishQueen.CanBlock = true
CombatStyles.DervishQueen.BlockData = {}
CombatStyles.DervishQueen.BlockData.PrimaryBlockType = EBlockType.BLOCK_TYPE_PUSHED_BACK
CombatStyles.DervishQueen.BlockData.SecondsForSuccessiveHitsToPrimaryBlock = 6
CombatStyles.DervishQueen.BlockData.NumberOfHitsToForcePrimaryBlock = 2
CombatStyles.DervishQueen.BlockData.SecondaryBlockType = EBlockType.BLOCK_TYPE_DODGE_MELEE
CombatStyles.DervishQueen.BlockData.SecondsForSuccessiveHitsToSecondaryBlock = 8
CombatStyles.DervishQueen.BlockData.NumberOfHitsToForceSecondaryBlock = 1
CombatStyles.DervishQueen.BlockData.SecondsToBlockFor = 2
CombatStyles.DervishQueen.DodgeAnimations = {
	"RollLeft",
    "RollRight"
}
CombatStyles.DervishQueen.CanEvadeShots = true
CombatStyles.DervishQueen.EvadeShotsData = {}
CombatStyles.DervishQueen.EvadeShotsData.TimeToCheckFor = 6
CombatStyles.DervishQueen.EvadeShotsData.TimeToEvadeFor = 5
CombatStyles.DervishQueen.EvadeShotsData.HitsToStartEvading = 3
CombatStyles.DervishQueen.EvadeAnimations = {
	"DodgeBackLeft",
    "DodgeBackRight"
}
CombatStyles.DervishQueen.AntiSpamData = {}
CombatStyles.DervishQueen.AntiSpamData.TimeToCheckFor = 5
CombatStyles.DervishQueen.AntiSpamData.ShotsToTrigger = 3
CombatStyles.DervishQueen.AntiSpamData.SpellsToTrigger = 3
CombatStyles.DervishQueen.AntiSpamData.TimeToAggroFor = 15
CombatStyles.DervishQueen.ValidStates = {}
CombatStyles.DervishQueen.ValidStates[CombatSituations.Melee] = {
	"AntiSpamCheck",
	"PlayBanterCombatComment",
	"WaitForActionToFinish",
	"CultistSummon",
	"HighwaymanFireRangedWeapon",
	"UpdateWeapon",
	"CheckForBetterTarget",
	"RetreatFromFlourish",
	"OuterRingKeepDistance",
	"OuterRingSpreadOut",
	"PlayCombatSequence",
	"MoveToFormationPos",
	"FaceTarget"
}
CombatStyles.DervishQueen.ValidStates[CombatSituations.SoftBlocking] = CombatStyles.StandardBlockingCombatStates
CombatStyles.DervishQueen.ValidStates[CombatSituations.HardBlocking] = CombatStyles.StandardBlockingCombatStates
CombatStyles.DervishQueen.ValidStates[CombatSituations.Dodging] = CombatStyles.StandardBlockingCombatStates
CombatStyles.DervishQueen.ValidStates[CombatSituations.GroupOrders] = CombatStyles.StandardGroupOrderStates
CombatStyles.DervishQueen.ShootingBalanceData = {}
CombatStyles.DervishQueen.ShootingBalanceData.StartingChanceToHitWithFirearm = 0.5
CombatStyles.DervishQueen.ShootingBalanceData.MaxChanceToHitWithFirearmCap = 0.5
CombatStyles.DervishQueen.ShootingBalanceData.ChanceToHitModBonusRangeDistance = 9
CombatStyles.DervishQueen.ShootingBalanceData.ChanceToHitModSegmentLength = 3
CombatStyles.DervishQueen.ShootingBalanceData.ChanceToHitModPercentageIncrease = 0.05
CombatStyles.DervishQueen.ShootingBalanceData.ChanceToHitModConsecutiveShotPercentageIncrease = 0.08
CombatStyles.DervishQueen.ShootingBalanceData.ChanceToHitModConsecutiveShotsTimeFrame = 25
CombatStyles.DervishQueen.ShootingBalanceData.ChanceToHitModPercentageDecreasePerOneSpeed = 0.9
CombatStyles.DervishQueen.ShootingBalanceData.ChanceToHitModTargetInCoverPercentageMultiplier = 0.9
CombatStyles.DervishQueen.ShootingBalanceData.ChanceToHitModOffScreenPercentageMultiplier = 0.05
CombatStyles.DervishQueen.CultistData = {}
CombatStyles.DervishQueen.CultistData.SecondsSpentVulnerable = 0
CombatStyles.DervishQueen.CultistData.SummonedCreatureType = "CreatureDervish"
CombatStyles.DervishQueen.CultistData.SummonedCreatureCount = 2
CombatStyles.DervishQueen.CultistData.SpawnRadius = 1.5
CombatStyles.DervishQueen.CultistData.MinimumShieldTime = 0
CombatStyles.DervishQueen.CultistData.HitsToStartShield = 9999999827968 --never?


-- Castle Assassin--
CombatStyles.CastleAssassin = {}
CombatStyles.CastleAssassin.CombatGroupType = CombatGroupTypes.HighwaymanLike
CombatStyles.CastleAssassin.CanStrafe = true
CombatStyles.CastleAssassin.CanSheatheWeapon = false
CombatStyles.CastleAssassin.MovementTolerance = 0.45
CombatStyles.CastleAssassin.ActionModifiers = {}
CombatStyles.CastleAssassin.ActionModifiers.MinDistToTarget = 0.75
CombatStyles.CastleAssassin.Limits = {}
CombatStyles.CastleAssassin.Limits[CombatZones.Near] = 1.5
CombatStyles.CastleAssassin.Limits[CombatZones.Middle] = 3.5
CombatStyles.CastleAssassin.Limits[CombatZones.Far] = 5
CombatStyles.CastleAssassin.Limits[CombatZones.Left] = 2
CombatStyles.CastleAssassin.Limits[CombatZones.Right] = 2
CombatStyles.CastleAssassin.Limits[CombatZones.Rear] = 2.5
CombatStyles.CastleAssassin.StrafeActionSpeed = 1
CombatStyles.CastleAssassin.EnterStrafeDist = 5
CombatStyles.CastleAssassin.LeaveStrafeDelta = 2
CombatStyles.CastleAssassin.FleeAnim = "Flee"
CombatStyles.CastleAssassin.FleeIntoAnim = "FleeInto"
CombatStyles.CastleAssassin.FleeOutOfAnim = "FleeOutOf"
CombatStyles.CastleAssassin.Sequences = {}
CombatStyles.CastleAssassin.Sequences[CombatSituations.Melee] = {
	"HighwaymanGetRidOfPistol",
	"AssassinShotTooMuch",
	"AssassinFarAttackCombo",
	"AssassinAttackCombo",
	"AssassinCloseAttackCombo",
	"HighwaymanGoad",
	"HighwaymanIdleStrafeLeft",
	"HighwaymanIdleStrafeRight",
	"AssassinRearAttack",
	"Idle"
}
CombatStyles.CastleAssassin.Sequences[CombatSituations.Dodging] = {
	"AssassinOutOfBlock"
}
CombatStyles.CastleAssassin.RunIntoAttack = "RunIntoAttack"
CombatStyles.CastleAssassin.MinSecondsBetweenMeleeAttacks = 0.1
CombatStyles.CastleAssassin.SecondsToWaitAfterTargetIsHit = 0.25
CombatStyles.CastleAssassin.MinSecondsBetweenRangedAttacks = 2
CombatStyles.CastleAssassin.TimeAfterBeingStruckWithinWhichWeCanShoot = 6
CombatStyles.CastleAssassin.CanBlock = true
CombatStyles.CastleAssassin.BlockData = {}
CombatStyles.CastleAssassin.BlockData.PrimaryBlockType = EBlockType.BLOCK_TYPE_PUSHED_BACK
CombatStyles.CastleAssassin.BlockData.SecondsForSuccessiveHitsToPrimaryBlock = 6
CombatStyles.CastleAssassin.BlockData.NumberOfHitsToForcePrimaryBlock = 1
CombatStyles.CastleAssassin.BlockData.SecondaryBlockType = EBlockType.BLOCK_TYPE_DODGE_MELEE
CombatStyles.CastleAssassin.BlockData.SecondsForSuccessiveHitsToSecondaryBlock = 8
CombatStyles.CastleAssassin.BlockData.NumberOfHitsToForceSecondaryBlock = 1
CombatStyles.CastleAssassin.BlockData.SecondsToBlockFor = 2
CombatStyles.CastleAssassin.DodgeAnimations = {
	"RollLeft",
    "RollRight"
}
CombatStyles.CastleAssassin.CanEvadeShots = false
CombatStyles.CastleAssassin.EvadeShotsData = {}
CombatStyles.CastleAssassin.EvadeShotsData.TimeToCheckFor = 6
CombatStyles.CastleAssassin.EvadeShotsData.TimeToEvadeFor = 5
CombatStyles.CastleAssassin.EvadeShotsData.HitsToStartEvading = 3
CombatStyles.CastleAssassin.EvadeAnimations = {
	"DodgeBackLeft",
    "DodgeBackRight"
}
CombatStyles.CastleAssassin.AntiSpamData = {}
CombatStyles.CastleAssassin.AntiSpamData.TimeToCheckFor = 5
CombatStyles.CastleAssassin.AntiSpamData.ShotsToTrigger = 3
CombatStyles.CastleAssassin.AntiSpamData.SpellsToTrigger = 3
CombatStyles.CastleAssassin.AntiSpamData.TimeToAggroFor = 15
CombatStyles.CastleAssassin.ValidStates = {}
CombatStyles.CastleAssassin.ValidStates[CombatSituations.Melee] = {
	"AntiSpamCheck",
	"PlayBanterCombatComment",
	"WaitForActionToFinish",
	"UpdateWeapon",
	"CheckForBetterTarget",
	"RetreatFromFlourish",
	"AssassinReactToSpellCharging",
	"OuterRingKeepDistance",
	"OuterRingSpreadOut",
	"PlayCombatSequence",
	"MoveToFormationPos",
	"FaceTarget"
}
CombatStyles.CastleAssassin.ValidStates[CombatSituations.SoftBlocking] = CombatStyles.StandardBlockingCombatStates
CombatStyles.CastleAssassin.ValidStates[CombatSituations.HardBlocking] = CombatStyles.StandardBlockingCombatStates
CombatStyles.CastleAssassin.ValidStates[CombatSituations.Dodging] = CombatStyles.StandardBlockingCombatStates
CombatStyles.CastleAssassin.ValidStates[CombatSituations.GroupOrders] = CombatStyles.StandardGroupOrderStates
CombatStyles.CastleAssassin.ShootingBalanceData = {}
CombatStyles.CastleAssassin.ShootingBalanceData.StartingChanceToHitWithFirearm = 0.5
CombatStyles.CastleAssassin.ShootingBalanceData.MaxChanceToHitWithFirearmCap = 0.5
CombatStyles.CastleAssassin.ShootingBalanceData.ChanceToHitModBonusRangeDistance = 9
CombatStyles.CastleAssassin.ShootingBalanceData.ChanceToHitModSegmentLength = 3
CombatStyles.CastleAssassin.ShootingBalanceData.ChanceToHitModPercentageIncrease = 0.05
CombatStyles.CastleAssassin.ShootingBalanceData.ChanceToHitModConsecutiveShotPercentageIncrease = 0.08
CombatStyles.CastleAssassin.ShootingBalanceData.ChanceToHitModConsecutiveShotsTimeFrame = 25
CombatStyles.CastleAssassin.ShootingBalanceData.ChanceToHitModPercentageDecreasePerOneSpeed = 0.9
CombatStyles.CastleAssassin.ShootingBalanceData.ChanceToHitModTargetInCoverPercentageMultiplier = 0.9
CombatStyles.CastleAssassin.ShootingBalanceData.ChanceToHitModOffScreenPercentageMultiplier = 0.05
CombatStyles.CastleAssassin.SecondsBetweenGroupActions = 30
CombatStyles.CastleAssassin.PercentChanceThatGroupActionIsShoot = 25



-- Devils Island Assassin --
CombatStyles.DevilsIslandAssassin = {}
CombatStyles.DevilsIslandAssassin.CombatGroupType = CombatGroupTypes.HighwaymanLike
CombatStyles.DevilsIslandAssassin.CanStrafe = true
CombatStyles.DevilsIslandAssassin.CanSheatheWeapon = false
CombatStyles.DevilsIslandAssassin.MovementTolerance = 0.45
CombatStyles.DevilsIslandAssassin.ActionModifiers = {}
CombatStyles.DevilsIslandAssassin.ActionModifiers.MinDistToTarget = 0.75
CombatStyles.DevilsIslandAssassin.Limits = {}
CombatStyles.DevilsIslandAssassin.Limits[CombatZones.Near] = 1.5
CombatStyles.DevilsIslandAssassin.Limits[CombatZones.Middle] = 3.5
CombatStyles.DevilsIslandAssassin.Limits[CombatZones.Far] = 5
CombatStyles.DevilsIslandAssassin.Limits[CombatZones.Left] = 2
CombatStyles.DevilsIslandAssassin.Limits[CombatZones.Right] = 2
CombatStyles.DevilsIslandAssassin.Limits[CombatZones.Rear] = 2.5
CombatStyles.DevilsIslandAssassin.StrafeActionSpeed = 1
CombatStyles.DevilsIslandAssassin.EnterStrafeDist = 5
CombatStyles.DevilsIslandAssassin.LeaveStrafeDelta = 2
CombatStyles.DevilsIslandAssassin.FleeAnim = "Flee"
CombatStyles.DevilsIslandAssassin.FleeIntoAnim = "FleeInto"
CombatStyles.DevilsIslandAssassin.FleeOutOfAnim = "FleeOutOf"
CombatStyles.DevilsIslandAssassin.Sequences = {}
CombatStyles.DevilsIslandAssassin.Sequences[CombatSituations.Melee] = {
	"HighwaymanGetRidOfPistol",
	"AssassinShotTooMuch",
	"AssassinFarAttackCombo",
	"AssassinAttackCombo",
	"AssassinCloseAttackCombo",
	"HighwaymanGoad",
	"HighwaymanIdleStrafeLeft",
	"HighwaymanIdleStrafeRight",
	"AssassinRearAttack",
	"Idle"
}
CombatStyles.DevilsIslandAssassin.Sequences[CombatSituations.Dodging] = {
	"AssassinOutOfBlock"
}
CombatStyles.DevilsIslandAssassin.RunIntoAttack = "RunIntoAttack"
CombatStyles.DevilsIslandAssassin.MinSecondsBetweenMeleeAttacks = 0.25
CombatStyles.DevilsIslandAssassin.SecondsToWaitAfterTargetIsHit = 0.5
CombatStyles.DevilsIslandAssassin.MinSecondsBetweenRangedAttacks = 2
CombatStyles.DevilsIslandAssassin.TimeAfterBeingStruckWithinWhichWeCanShoot = 6
CombatStyles.DevilsIslandAssassin.CanBlock = true
CombatStyles.DevilsIslandAssassin.BlockData = {}
CombatStyles.DevilsIslandAssassin.BlockData.PrimaryBlockType = EBlockType.BLOCK_TYPE_PUSHED_BACK
CombatStyles.DevilsIslandAssassin.BlockData.SecondsForSuccessiveHitsToPrimaryBlock = 6
CombatStyles.DevilsIslandAssassin.BlockData.NumberOfHitsToForcePrimaryBlock = 2
CombatStyles.DevilsIslandAssassin.BlockData.SecondaryBlockType = EBlockType.BLOCK_TYPE_DODGE_MELEE
CombatStyles.DevilsIslandAssassin.BlockData.SecondsForSuccessiveHitsToSecondaryBlock = 8
CombatStyles.DevilsIslandAssassin.BlockData.NumberOfHitsToForceSecondaryBlock = 1
CombatStyles.DevilsIslandAssassin.BlockData.SecondsToBlockFor = 1.5
CombatStyles.DevilsIslandAssassin.DodgeAnimations = {
	"RollLeft",
    "RollRight"
}
CombatStyles.DevilsIslandAssassin.CanEvadeShots = false
CombatStyles.DevilsIslandAssassin.EvadeShotsData = {}
CombatStyles.DevilsIslandAssassin.EvadeShotsData.TimeToCheckFor = 6
CombatStyles.DevilsIslandAssassin.EvadeShotsData.TimeToEvadeFor = 5
CombatStyles.DevilsIslandAssassin.EvadeShotsData.HitsToStartEvading = 3
CombatStyles.DevilsIslandAssassin.EvadeAnimations = {
	"DodgeBackLeft",
    "DodgeBackRight"
}
CombatStyles.DevilsIslandAssassin.AntiSpamData = {}
CombatStyles.DevilsIslandAssassin.AntiSpamData.TimeToCheckFor = 5
CombatStyles.DevilsIslandAssassin.AntiSpamData.ShotsToTrigger = 3
CombatStyles.DevilsIslandAssassin.AntiSpamData.SpellsToTrigger = 3
CombatStyles.DevilsIslandAssassin.AntiSpamData.TimeToAggroFor = 15
CombatStyles.DevilsIslandAssassin.ValidStates = {}
CombatStyles.DevilsIslandAssassin.ValidStates[CombatSituations.Melee] = {
	"AntiSpamCheck",
	"PlayBanterCombatComment",
	"WaitForActionToFinish",
	"UpdateWeapon",
	"CheckForBetterTarget",
	"RetreatFromFlourish",
	"AssassinReactToSpellCharging",
	"PlayCombatSequence",
	"MoveToFormationPos",
	"FaceTarget"
}
CombatStyles.DevilsIslandAssassin.ValidStates[CombatSituations.SoftBlocking] = CombatStyles.StandardBlockingCombatStates
CombatStyles.DevilsIslandAssassin.ValidStates[CombatSituations.HardBlocking] = CombatStyles.StandardBlockingCombatStates
CombatStyles.DevilsIslandAssassin.ValidStates[CombatSituations.Dodging] = CombatStyles.StandardBlockingCombatStates
CombatStyles.DevilsIslandAssassin.ValidStates[CombatSituations.GroupOrders] = CombatStyles.StandardGroupOrderStates
CombatStyles.DevilsIslandAssassin.ShootingBalanceData = {}
CombatStyles.DevilsIslandAssassin.ShootingBalanceData.StartingChanceToHitWithFirearm = 0.5
CombatStyles.DevilsIslandAssassin.ShootingBalanceData.MaxChanceToHitWithFirearmCap = 0.5
CombatStyles.DevilsIslandAssassin.ShootingBalanceData.ChanceToHitModBonusRangeDistance = 9
CombatStyles.DevilsIslandAssassin.ShootingBalanceData.ChanceToHitModSegmentLength = 3
CombatStyles.DevilsIslandAssassin.ShootingBalanceData.ChanceToHitModPercentageIncrease = 0.05
CombatStyles.DevilsIslandAssassin.ShootingBalanceData.ChanceToHitModConsecutiveShotPercentageIncrease = 0.08
CombatStyles.DevilsIslandAssassin.ShootingBalanceData.ChanceToHitModConsecutiveShotsTimeFrame = 25
CombatStyles.DevilsIslandAssassin.ShootingBalanceData.ChanceToHitModPercentageDecreasePerOneSpeed = 0.9
CombatStyles.DevilsIslandAssassin.ShootingBalanceData.ChanceToHitModTargetInCoverPercentageMultiplier = 0.9
CombatStyles.DevilsIslandAssassin.ShootingBalanceData.ChanceToHitModOffScreenPercentageMultiplier = 0.05
CombatStyles.DevilsIslandAssassin.SecondsBetweenGroupActions = 30
CombatStyles.DevilsIslandAssassin.PercentChanceThatGroupActionIsShoot = 25



-- uncomment for debug
-- GUI.DisplayMessageBox("highwaymencombatstyles.lua successfully loaded!")
-- while (GUI.IsDisplayBoxActive()) do
	-- coroutine.yield()
-- end