
CombatStates = {}
CombatStates.OuterRingSpreadArc = 90
CombatStates.OuterRingEqualiseAngle = 60
CombatStates.NonFormationSpreadArc = 100
CombatStates.NonFormationEqualiseAngle = 60

CombatStates.InvalidState = function()

end

HobbeSpellFunctions = {}
HobbeSpellFunctions.HealRadius = 5
HobbeSpellFunctions.EnrageRadius = 10

HobbeSpellFunctions.Heal = function()

end

HobbeSpellFunctions.Enrage = function()

end
