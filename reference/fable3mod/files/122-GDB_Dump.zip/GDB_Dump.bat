@echo off
ECHO.Select dump mode
ECHO.1. Default
ECHO.2. Floats instead of hex
ECHO.3. Labels
ECHO.4. Unknown hash tables
SET /P dump_mode=
CD /D "%~dp0"
IF "%dump_mode%" == "2" (
	GDB_Dump.exe -f "%~1" > "%~dpn1_float.txt"
) ELSE (
	IF "%dump_mode%" == "3" (
		GDB_Dump.exe -l "%~1" > "%~dpn1_labels.txt"
	) ELSE (
		IF "%dump_mode%" == "4" (
			GDB_Dump.exe -u "%~1" > "%~dpn1_unknown.txt"
		) ELSE (
			GDB_Dump.exe "%~1" > "%~dpn1.txt"
		)
	)
)