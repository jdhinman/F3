-- Artofeel camera mod

	Debug.ReloadCameras()
	-- SACCamera.ForceIndoors = true
	-- SACCamera.ForceToIndoors = true
	-- SACCamera.IgnoreAllIndoors = false
	-- SACCamera.IgnoreDrop = false
	-- SACCamera.LimitCouchModeMovement = true
	-- SACCamera.InterestingEntities = true
	SACCamera.GetImportance = true
	SACCamera.ManualHeightIsRelative = true
	SACCamera.IdleCameraResetEnabled = false
	-- SACCamera.DisableCouchCam = true
	-- SACCamera.DisableLiveCam = true
	-- SACCamera.IgnorePitch = true
	-- SACCamera.LimitPitch = true
	SACCamera.EnableMouseTrack = true
	SACCamera.EnableMouseSelfLevel = true
	SACCamera.MouseIgnoresCombatCamera = false
	SACCamera.SmoothBlend = true
	-- SACCamera.VerticalDeadZone = 10
	-- SACCamera.MaxHorizontalIgnoreDeadZone = 2
	-- SACCamera.InwardsRotateSpeed = 100
	-- SACCamera.OutwardsRotateSpeed = 100
	-- SACCamera.NearbyFoes = 10
	-- SACCamera.IdleCameraResetTime = 10
	-- SACCamera.Intensity = 1
	-- SACCamera.ClosenessToTiltUpMax = 4
	-- SACCamera.ClosenessToTiltUpStart = 3
	-- SACCamera.ReCentre = true
	-- SACCamera.BorderFOV = 80
	-- SACCamera.HeroRadiusMultiplierSinglePlayer = 1
	-- SACCamera.VelocityThresholdToPush = 0.5
	-- SACCamera.TimeToPopUp = 2
	-- SACCamera.TimeToPopIn = 3
	-- SACCamera.TimeToPopInNeutral = 1
	-- SACCamera.DriftRate = 150
	-- SACCamera.TurnDriftRate = 300
	SACCamera.TransitionBlur = 100
	
	SACCamera.MaxHeightChange = 0.25
	SACCamera.HeightOffsetUpperBound = 2
	SACCamera.HeightOffsetLowerBound = 2
	-- SACCamera.HeightImportanceFactor = 3
	
	-- SACCamera.TargetingTurnBuffer = 4.5
	-- SACCamera.TargetingTurnPower = 4.5
	-- SACCamera.TargetingTiltBuffer = 4.5
	-- SACCamera.TargetingTiltPower = 4.5
	-- SACCamera.TargetingMinDistance = 4.5
	
	-- SACCamera.ShrinkOnPush = true
	-- SACCamera.ShrinkOnRotate = true
	-- SACCamera.OnlyShrinkOnSide = false
	-- SACCamera.TimeToStartShrinking = 0.5
	-- SACCamera.TimeToEndShrinking = 5
	-- SACCamera.MaxShrinkageFactor = 200
	-- SACCamera.TimeToShrinkOnRotate = 5
	
	-- SACCamera.InsideBuildingHysteresis = 0.3
	-- SACCamera.NearDropHysteresis = 0.6
	-- SACCamera.SprintingHysteresis = 0.1
	-- SACCamera.FallingHysteresis = 0.5
	-- SACCamera.VaultingHysteresis = 0.1
	-- SACCamera.HandHoldingHysteresis = 0.1
	
	SACCamera.SelfLevelWeight = 100
	SACCamera.CameraTransitionTime = 20
	SACCamera.AutoRotateSpeed = 50
	SACCamera.SlopeDamping = 13
	SACCamera.CameraFOVDamping = 10
	SACCamera.RotateDamp = 4
	SACCamera.RotateSpeed = 300
	SACCamera.HeightDamp = 4
	SACCamera.HeightAdjustSpeed = 0.2
	SACCamera.CameraMoveDamping = 2
	SACCamera.MouseDampFactor = 4
	SACCamera.InterestingEnemyDamping = 15
	FirstPersonCamera.RotateSmoothAmountMouse = 10
	
	Debug.SetRangedCursorXSpeed(2)
	Debug.SetRangedCursorYSpeed(2)
	
	SACCamera.InterestedInEnemies = true
	SACCamera.InterestedInScriptEntities = true
	SACCamera.InterestedInECEntities = true
	SACCamera.UseRegionOverrides = false
	SACCamera.InterestingEnemyDistance = 50
	SACCamera.InterestingEntityDistance = 10
	-- SACCamera.InterestingRangeFadeFactor = 5
	SACCamera.SecondaryInterestRange = 15
	SACCamera.CombatValues.FullHeroCamDistance = 50
	SACCamera.CombatValues.FullCombatCamDistance = 30
	
	SACCamera.ExteriorZoomLevels.StringLength = 2
	SACCamera.ExteriorZoomLevels.FocalOffset = 1.2
	SACCamera.ExteriorZoomLevels.HeightOffset = 0.3
	-- SACCamera.ExteriorZoomLevels.CageRadius = 10
	-- SACCamera.ExteriorZoomLevels.MaxCageRadius = 100
	-- SACCamera.ExteriorZoomLevels.HorizontalFocalOffset = 0
	-- SACCamera.ExteriorZoomLevels.SlotWidth = 5
	-- SACCamera.ExteriorZoomLevels.SlotDepthFar = 100
	-- SACCamera.ExteriorZoomLevels.SlotDepthNear = -100
	-- SACCamera.ExteriorZoomLevels.TrackAmount = 0
	-- SACCamera.ExteriorZoomLevels.MaxCoopDistance = 100
	SACCamera.ExteriorZoomLevels.DisregardsGroundSlope = false
	SACCamera.ExteriorZoomLevels.OverridesCombat = false
	SACCamera.ExteriorZoomLevels.BoolInterpolate = true
	-- SACCamera.ExteriorZoomLevels.SafeInterpolate = true
	SACCamera.ExteriorZoomLevels.FOV = 65
	SACCamera.ExteriorZoomLevels.BlendTime = 80
	
	SACCamera.InteriorZoomLevels.StringLength = 1.5
	SACCamera.InteriorZoomLevels.FocalOffset = 1.8
	SACCamera.InteriorZoomLevels.HeightOffset = 0.4
	SACCamera.InteriorZoomLevels.FOV = 80
	SACCamera.InteriorZoomLevels.DisregardsGroundSlope = false
	SACCamera.InteriorZoomLevels.OverridesCombat = false
	SACCamera.InteriorZoomLevels.BoolInterpolate = false
	SACCamera.InteriorZoomLevels.BlendTime = 15
	SACCamera.InteriorZoomLevels.BlendOutTime = 5
	
	SACCamera.CombatExteriorZoomLevel.StringLength = 5
	SACCamera.CombatExteriorZoomLevel.FOV = 65
	SACCamera.CombatExteriorZoomLevel.DisregardsGroundSlope = false
	SACCamera.CombatExteriorZoomLevel.BoolInterpolate = false
	SACCamera.CombatExteriorZoomLevel.BlendTime = 20
	
	SACCamera.CombatInteriorZoomLevel.StringLength = 2.5
	SACCamera.CombatInteriorZoomLevel.FOV = 75
	SACCamera.CombatInteriorZoomLevel.DisregardsGroundSlope = false
	SACCamera.CombatInteriorZoomLevel.BoolInterpolate = false
	SACCamera.CombatInteriorZoomLevel.BlendTime = 5
	
	SACCamera.CombatExteriorZoomLevelMouse.StringLength = 5
	SACCamera.CombatExteriorZoomLevelMouse.FOV = 65
	SACCamera.CombatExteriorZoomLevelMouse.DisregardsGroundSlope = false
	SACCamera.CombatExteriorZoomLevelMouse.BoolInterpolate = false
	SACCamera.CombatExteriorZoomLevelMouse.BlendTime = 20
	
	SACCamera.CombatInteriorZoomLevelMouse.StringLength = 2.5
	SACCamera.CombatInteriorZoomLevelMouse.FOV = 75
	SACCamera.CombatInteriorZoomLevelMouse.DisregardsGroundSlope = false
	SACCamera.CombatInteriorZoomLevelMouse.BoolInterpolate = false
	SACCamera.CombatInteriorZoomLevelMouse.BlendTime = 5
	
	--"Quest Give" Camera
	SACCamera.ICSZoomLevel.StringLength = 2.5
	SACCamera.ICSZoomLevel.FocalOffset = 1.4
	SACCamera.ICSZoomLevel.HeightOffset = -0.8
	SACCamera.ICSZoomLevel.FOV = 60
	SACCamera.ICSZoomLevel.DisregardsGroundSlope = false
	SACCamera.ICSZoomLevel.OverridesCombat = false
	SACCamera.ICSZoomLevel.BoolInterpolate = true
	SACCamera.ICSZoomLevel.BlendTime = 25
	SACCamera.ICSZoomLevel.BlendOutTime = 5
	
	SACCamera.ICSChildZoomLevel.StringLength = 2.5
	SACCamera.ICSChildZoomLevel.FocalOffset = 1.4
	SACCamera.ICSChildZoomLevel.HeightOffset = -0.2
	SACCamera.ICSChildZoomLevel.FOV = 60
	SACCamera.ICSChildZoomLevel.DisregardsGroundSlope = false
	SACCamera.ICSChildZoomLevel.OverridesCombat = false
	SACCamera.ICSChildZoomLevel.BoolInterpolate = true
	SACCamera.ICSChildZoomLevel.BlendTime = 25
	SACCamera.ICSChildZoomLevel.BlendOutTime = 5
	
	SACCamera.VanityZoomLevels.StringLength = 4
	SACCamera.VanityZoomLevels.FOV = 160
	SACCamera.VanityZoomLevels.DisregardsGroundSlope = false
	SACCamera.VanityZoomLevels.OverridesCombat = false
	SACCamera.VanityZoomLevels.BoolInterpolate = false
	SACCamera.VanityZoomLevels.BlendTime = 5
	
	-- SACCamera.SprintZoomLevel.StringLength = 1
	-- SACCamera.SprintZoomLevel.FocalOffset = 2
	SACCamera.SprintZoomLevel.StringLength = 1.75
	SACCamera.SprintZoomLevel.FocalOffset = 1.6
	SACCamera.SprintZoomLevel.HeightOffset = 0
	SACCamera.SprintZoomLevel.FOV = 80
	SACCamera.SprintZoomLevel.DisregardsGroundSlope = false
	SACCamera.SprintZoomLevel.OverridesCombat = false
	SACCamera.SprintZoomLevel.BoolInterpolate = false
	SACCamera.SprintZoomLevel.BlendTime = 50
	
	SACCamera.NearToDropZoomLevel.StringLength = 6
	SACCamera.NearToDropZoomLevel.FocalOffset = 2
	SACCamera.NearToDropZoomLevel.HeightOffset = 4
	SACCamera.NearToDropZoomLevel.FOV = 85
	SACCamera.NearToDropZoomLevel.DisregardsGroundSlope = false
	SACCamera.NearToDropZoomLevel.OverridesCombat = false
	SACCamera.NearToDropZoomLevel.BlendTime = 100
	
	SACCamera.VaultZoomLevel.StringLength = 4
	SACCamera.VaultZoomLevel.FocalOffset = 1.5
	SACCamera.VaultZoomLevel.HeightOffset = 2
	SACCamera.VaultZoomLevel.FOV = 65
	SACCamera.VaultZoomLevel.DisregardsGroundSlope = false
	SACCamera.VaultZoomLevel.OverridesCombat = true
	SACCamera.VaultZoomLevel.BoolInterpolate = false
	SACCamera.VaultZoomLevel.BlendTime = 10
	
	SACCamera.FallZoomLevel.StringLength = 1
	SACCamera.FallZoomLevel.FocalOffset = 3
	SACCamera.FallZoomLevel.HeightOffset = 6
	SACCamera.FallZoomLevel.FOV = 75
	SACCamera.FallZoomLevel.DisregardsGroundSlope = true
	SACCamera.FallZoomLevel.OverridesCombat = true
	SACCamera.FallZoomLevel.BoolInterpolate = true
	SACCamera.FallZoomLevel.BlendTime = 10
	
	SACCamera.HandHoldZoomLevel.StringLength = 2.5
	SACCamera.HandHoldZoomLevel.FocalOffset = 1.4
	SACCamera.HandHoldZoomLevel.HeightOffset = 0.6
	SACCamera.HandHoldZoomLevel.FOV = 60
	SACCamera.HandHoldZoomLevel.DisregardsGroundSlope = false
	SACCamera.HandHoldZoomLevel.OverridesCombat = false
	SACCamera.HandHoldZoomLevel.BoolInterpolate = true
	SACCamera.HandHoldZoomLevel.BlendTime = 30
	
	SACCamera.AssassinZoomLevel.StringLength = 2.5
	SACCamera.AssassinZoomLevel.FocalOffset = 0
	SACCamera.AssassinZoomLevel.FOV = 15
	SACCamera.AssassinZoomLevel.DisregardsGroundSlope = false
	SACCamera.AssassinZoomLevel.OverridesCombat = false
	SACCamera.AssassinZoomLevel.BlendTime = 10
	
	SACCamera.TrollZoomLevel.StringLength = 2.5
	SACCamera.TrollZoomLevel.FocalOffset = 6
	SACCamera.TrollZoomLevel.FOV = 150
	SACCamera.TrollZoomLevel.DisregardsGroundSlope = false
	SACCamera.TrollZoomLevel.OverridesCombat = false
	SACCamera.TrollZoomLevel.BlendTime = 10
	
	--Mortar camera
	Orchestra.EnableCameraShake = true
	Orchestra.ExplosionCrescendoMinTimeBetweenCuts = 0.5
	Orchestra.ExplosionCrescendoKillCount = 1
	Orchestra.FlourishTypes.Explosion.Duration = 1
	Orchestra.FlourishTypes.Explosion.TimeMultiplier = 1
	Orchestra.FlourishTypes.Explosion.BlendInTime = 8
	Orchestra.FlourishTypes.Explosion.BlendOutTime = 10
	Orchestra.FlourishTypes.Explosion.IgnoreCollisionCheck = false
	CameraOverrides.Mortar.Dist = 20
	CameraOverrides.Mortar.Offset = 12
	CameraOverrides.Mortar.ZoomInDist = 14
	CameraOverrides.Mortar.ZoomInOffset = 8
	CameraOverrides.Mortar.ZoomOutDist = 18
	CameraOverrides.Mortar.ZoomOutOffset = 10
	
	Debug.SetCombatFinishersOverrideCameraAnimProbability(100.0)
	